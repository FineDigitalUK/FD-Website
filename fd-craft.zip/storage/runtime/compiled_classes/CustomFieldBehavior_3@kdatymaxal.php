<?php
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

use yii\base\Behavior;

/**
 * Custom field behavior
 *
 * This class provides attributes for all the unique custom field handles.
 *
 * @method $this buttonType(mixed $value) Sets the [[buttonType]] property
 * @method $this buttonUrl(mixed $value) Sets the [[buttonUrl]] property
 * @method $this ctaButtons(mixed $value) Sets the [[ctaButtons]] property
 * @method $this headlineLineOne(mixed $value) Sets the [[headlineLineOne]] property
 * @method $this headlineLineTwo(mixed $value) Sets the [[headlineLineTwo]] property
 * @method $this heroDescription(mixed $value) Sets the [[heroDescription]] property
 * @method $this heroVideo(mixed $value) Sets the [[heroVideo]] property
 * @method $this image(mixed $value) Sets the [[image]] property
 * @method $this imageAlt(mixed $value) Sets the [[imageAlt]] property
 * @method $this linkText(mixed $value) Sets the [[linkText]] property
 * @method $this plainText(mixed $value) Sets the [[plainText]] property
 * @method $this textArea(mixed $value) Sets the [[textArea]] property
 * @method $this urlAddress(mixed $value) Sets the [[urlAddress]] property
 */
class CustomFieldBehavior extends Behavior
{
    /**
     * @var bool Whether the behavior should provide methods based on the field handles.
     */
    public bool $hasMethods = false;

    /**
     * @var bool Whether properties on the class should be settable directly.
     */
    public bool $canSetProperties = true;

    /**
     * @var array<string,bool> List of supported field handles.
     */
    public static $fieldHandles = [
        'buttonType' => true,
        'buttonUrl' => true,
        'ctaButtons' => true,
        'headlineLineOne' => true,
        'headlineLineTwo' => true,
        'heroDescription' => true,
        'heroVideo' => true,
        'image' => true,
        'imageAlt' => true,
        'linkText' => true,
        'plainText' => true,
        'textArea' => true,
        'urlAddress' => true,
    ];

    /**
     * @var array<string,bool> List of generated field handles.
     */
    public static $generatedFieldHandles = [

    ];

    /**
     * @var \craft\fields\data\SingleOptionFieldData Value for field with the handle “buttonType”.
     */
    public $buttonType;

    /**
     * @var \craft\fields\data\LinkData|null Value for field with the handle “buttonUrl”.
     */
    public $buttonUrl;

    /**
     * @var \craft\elements\db\EntryQuery|\craft\elements\ElementCollection<\craft\elements\Entry> Value for field with the handle “ctaButtons”.
     */
    public $ctaButtons;

    /**
     * @var string|null Value for field with the handle “headlineLineOne”.
     */
    public $headlineLineOne;

    /**
     * @var string|null Value for field with the handle “headlineLineTwo”.
     */
    public $headlineLineTwo;

    /**
     * @var string|null Value for field with the handle “heroDescription”.
     */
    public $heroDescription;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “heroVideo”.
     */
    public $heroVideo;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “image”.
     */
    public $image;

    /**
     * @var string|null Value for field with the handle “imageAlt”.
     */
    public $imageAlt;

    /**
     * @var string|null Value for field with the handle “linkText”.
     */
    public $linkText;

    /**
     * @var string|null Value for field with the handle “plainText”.
     */
    public $plainText;

    /**
     * @var string|null Value for field with the handle “textArea”.
     */
    public $textArea;

    /**
     * @var \craft\fields\data\LinkData|null Value for field with the handle “urlAddress”.
     */
    public $urlAddress;

    /**
     * @var array Additional custom field values we don’t know about yet.
     */
    private array $_customFieldValues = [];

    /**
     * @inheritdoc
     */
    public function __call($name, $params)
    {
        if (
            $this->hasMethods &&
            (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name])) &&
            count($params) === 1
        ) {
            $this->$name = $params[0];
            return $this->owner;
        }
        return parent::__call($name, $params);
    }

    /**
     * @inheritdoc
     */
    public function hasMethod($name): bool
    {
        if ($this->hasMethods && (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name]))) {
            return true;
        }
        return parent::hasMethod($name);
    }

    /**
     * @inheritdoc
     */
    public function __isset($name): bool
    {
        if (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name])) {
            return true;
        }
        return parent::__isset($name);
    }

    /**
     * @inheritdoc
     */
    public function __get($name)
    {
        if (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name])) {
            return $this->_customFieldValues[$name] ?? null;
        }
        return parent::__get($name);
    }

    /**
     * @inheritdoc
     */
    public function __set($name, $value)
    {
        if (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name])) {
            $this->_customFieldValues[$name] = $value;
            return;
        }
        parent::__set($name, $value);
    }

    /**
     * @inheritdoc
     */
    public function canGetProperty($name, $checkVars = true): bool
    {
        if ($checkVars && (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name]))) {
            return true;
        }
        return parent::canGetProperty($name, $checkVars);
    }

    /**
     * @inheritdoc
     */
    public function canSetProperty($name, $checkVars = true): bool
    {
        if (!$this->canSetProperties) {
            return false;
        }
        if ($checkVars && (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name]))) {
            return true;
        }
        return parent::canSetProperty($name, $checkVars);
    }
}
