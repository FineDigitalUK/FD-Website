<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/mailertransportadapters/Gmail/settings.twig */
class __TwigTemplate_896064ba0d929aa9e21cf74ccf95d2fe extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/mailertransportadapters/Gmail/settings.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/mailertransportadapters/Gmail/settings.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 4
        yield "
";
        // line 5
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 5, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Username", "app"), "id" => "username", "name" => "username", "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 10
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 10, $this->source); })()), "username", [], "any", false, false, false, 10), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 11
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 11, $this->source); })()), "getErrors", ["username"], "method", false, false, false, 11), "disabled" =>         // line 12
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 12, $this->source); })())]]);
        // line 13
        yield "

";
        // line 15
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 15, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Password", "app"), "id" => "password", "name" => "password", "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 20
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 20, $this->source); })()), "password", [], "any", false, false, false, 20), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 21
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 21, $this->source); })()), "getErrors", ["password"], "method", false, false, false, 21), "disabled" =>         // line 22
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 22, $this->source); })())]]);
        // line 23
        yield "
";
        craft\helpers\Template::endProfile("template", "_components/mailertransportadapters/Gmail/settings.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/mailertransportadapters/Gmail/settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  67 => 23,  65 => 22,  64 => 21,  63 => 20,  62 => 15,  58 => 13,  56 => 12,  55 => 11,  54 => 10,  53 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% set readOnly = readOnly ?? false %}

{{ forms.autosuggestField({
    label: \"Username\"|t('app'),
    id: 'username',
    name: 'username',
    suggestEnvVars: true,
    value: adapter.username,
    errors: adapter.getErrors('username'),
    disabled: readOnly,
}) }}

{{ forms.autosuggestField({
    label: \"Password\"|t('app'),
    id: 'password',
    name: 'password',
    suggestEnvVars: true,
    value: adapter.password,
    errors: adapter.getErrors('password'),
    disabled: readOnly,
}) }}
", "_components/mailertransportadapters/Gmail/settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/mailertransportadapters/Gmail/settings.twig");
    }
}
