<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* components/cta-button */
class __TwigTemplate_26660c712dd92106b8d52f704d60d67a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/cta-button");
        craft\helpers\Template::preloadSingles(['ctas', 'layout', 'spacing', 'layoutClasses', 'ctaEntry', 'buttonText', 'buttonUrl', 'typeClasses', 'buttonType', 'cta']);
        // line 4
        yield "
";
        // line 6
        if (((array_key_exists("ctas", $context) || craft\helpers\Template::fallbackExists("ctas")) && $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["ctas"]) || array_key_exists("ctas", $context) ? $context["ctas"] : (craft\helpers\Template::fallbackExists("ctas") ? craft\helpers\Template::fallback("ctas") : (function () { throw new RuntimeError('Variable "ctas" does not exist.', 6, $this->source); })()))))) {
            // line 7
            yield "  ";
            $context["layout"] = (($context["layout"]) ?? ("horizontal"));
            // line 8
            yield "  ";
            $context["spacing"] = (($context["spacing"]) ?? ("gap-4"));
            // line 9
            yield "  
  ";
            // line 11
            yield "  ";
            $context["layoutClasses"] = ["horizontal" => ("flex flex-wrap " .             // line 12
(isset($context["spacing"]) || array_key_exists("spacing", $context) ? $context["spacing"] : (craft\helpers\Template::fallbackExists("spacing") ? craft\helpers\Template::fallback("spacing") : (function () { throw new RuntimeError('Variable "spacing" does not exist.', 12, $this->source); })()))), "vertical" => ("flex flex-col " .             // line 13
(isset($context["spacing"]) || array_key_exists("spacing", $context) ? $context["spacing"] : (craft\helpers\Template::fallbackExists("spacing") ? craft\helpers\Template::fallback("spacing") : (function () { throw new RuntimeError('Variable "spacing" does not exist.', 13, $this->source); })()))), "centered" => ("flex flex-wrap justify-center " .             // line 14
(isset($context["spacing"]) || array_key_exists("spacing", $context) ? $context["spacing"] : (craft\helpers\Template::fallbackExists("spacing") ? craft\helpers\Template::fallback("spacing") : (function () { throw new RuntimeError('Variable "spacing" does not exist.', 14, $this->source); })())))];
            // line 16
            yield "
  <div class=\"";
            // line 17
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["layoutClasses"]) || array_key_exists("layoutClasses", $context) ? $context["layoutClasses"] : (craft\helpers\Template::fallbackExists("layoutClasses") ? craft\helpers\Template::fallback("layoutClasses") : (function () { throw new RuntimeError('Variable "layoutClasses" does not exist.', 17, $this->source); })())), (isset($context["layout"]) || array_key_exists("layout", $context) ? $context["layout"] : (craft\helpers\Template::fallbackExists("layout") ? craft\helpers\Template::fallback("layout") : (function () { throw new RuntimeError('Variable "layout" does not exist.', 17, $this->source); })())), [], "array", false, false, false, 17), "html", null, true);
            yield "\">
    ";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["ctas"]) || array_key_exists("ctas", $context) ? $context["ctas"] : (craft\helpers\Template::fallbackExists("ctas") ? craft\helpers\Template::fallback("ctas") : (function () { throw new RuntimeError('Variable "ctas" does not exist.', 18, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["ctaEntry"]) {
                // line 19
                yield "      ";
                // line 20
                yield "      ";
                $context["buttonText"] = craft\helpers\Template::attribute($this->env, $this->source, $context["ctaEntry"], "linkText", [], "any", false, false, false, 20);
                // line 21
                yield "      ";
                $context["buttonUrl"] = craft\helpers\Template::attribute($this->env, $this->source, $context["ctaEntry"], "urlAddress", [], "any", false, false, false, 21);
                // line 22
                yield "      ";
                $context["buttonType"] = craft\helpers\Template::attribute($this->env, $this->source, $context["ctaEntry"], "buttonType", [], "any", false, false, false, 22);
                // line 23
                yield "
      ";
                // line 25
                yield "      ";
                $context["typeClasses"] = ["normal" => "px-6 py-3 bg-gray-600 text-white hover:bg-gray-700 focus:ring-gray-500 rounded-lg transition-all", "cta" => "px-8 py-4 bg-brand text-white font-bold rounded-xl shadow-lg hover:bg-brand/90 transition transform hover:-translate-y-1 hover:scale-105", "ctaAlt" => "px-8 py-4 bg-white/20 border border-white/30 text-white font-bold rounded-xl shadow-lg hover:bg-white/40 transition transform hover:-translate-y-1 hover:scale-105 backdrop-blur"];
                // line 30
                yield "
      ";
                // line 32
                yield "      ";
                if (((isset($context["buttonText"]) || array_key_exists("buttonText", $context) ? $context["buttonText"] : (craft\helpers\Template::fallbackExists("buttonText") ? craft\helpers\Template::fallback("buttonText") : (function () { throw new RuntimeError('Variable "buttonText" does not exist.', 32, $this->source); })())) && (isset($context["buttonUrl"]) || array_key_exists("buttonUrl", $context) ? $context["buttonUrl"] : (craft\helpers\Template::fallbackExists("buttonUrl") ? craft\helpers\Template::fallback("buttonUrl") : (function () { throw new RuntimeError('Variable "buttonUrl" does not exist.', 32, $this->source); })())))) {
                    // line 33
                    yield "        <a href=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["buttonUrl"]) || array_key_exists("buttonUrl", $context) ? $context["buttonUrl"] : (craft\helpers\Template::fallbackExists("buttonUrl") ? craft\helpers\Template::fallback("buttonUrl") : (function () { throw new RuntimeError('Variable "buttonUrl" does not exist.', 33, $this->source); })())), "html", null, true);
                    yield "\" class=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["typeClasses"]) || array_key_exists("typeClasses", $context) ? $context["typeClasses"] : (craft\helpers\Template::fallbackExists("typeClasses") ? craft\helpers\Template::fallback("typeClasses") : (function () { throw new RuntimeError('Variable "typeClasses" does not exist.', 33, $this->source); })())), (isset($context["buttonType"]) || array_key_exists("buttonType", $context) ? $context["buttonType"] : (craft\helpers\Template::fallbackExists("buttonType") ? craft\helpers\Template::fallback("buttonType") : (function () { throw new RuntimeError('Variable "buttonType" does not exist.', 33, $this->source); })())), [], "array", false, false, false, 33), "html", null, true);
                    yield "\">
          ";
                    // line 34
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["buttonText"]) || array_key_exists("buttonText", $context) ? $context["buttonText"] : (craft\helpers\Template::fallbackExists("buttonText") ? craft\helpers\Template::fallback("buttonText") : (function () { throw new RuntimeError('Variable "buttonText" does not exist.', 34, $this->source); })())), "html", null, true);
                    yield "
        </a>
      ";
                }
                // line 37
                yield "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['ctaEntry'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            yield "  </div>
";
        }
        // line 40
        yield "
";
        // line 42
        if ((array_key_exists("cta", $context) || craft\helpers\Template::fallbackExists("cta"))) {
            // line 43
            yield "  ";
            $context["buttonText"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["cta"]) || array_key_exists("cta", $context) ? $context["cta"] : (craft\helpers\Template::fallbackExists("cta") ? craft\helpers\Template::fallback("cta") : (function () { throw new RuntimeError('Variable "cta" does not exist.', 43, $this->source); })())), "linkText", [], "any", false, false, false, 43);
            // line 44
            yield "  ";
            $context["buttonUrl"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["cta"]) || array_key_exists("cta", $context) ? $context["cta"] : (craft\helpers\Template::fallbackExists("cta") ? craft\helpers\Template::fallback("cta") : (function () { throw new RuntimeError('Variable "cta" does not exist.', 44, $this->source); })())), "urlAddress", [], "any", false, false, false, 44);
            // line 45
            yield "  ";
            $context["buttonType"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["cta"]) || array_key_exists("cta", $context) ? $context["cta"] : (craft\helpers\Template::fallbackExists("cta") ? craft\helpers\Template::fallback("cta") : (function () { throw new RuntimeError('Variable "cta" does not exist.', 45, $this->source); })())), "buttonType", [], "any", false, false, false, 45);
            // line 46
            yield "
  ";
            // line 48
            yield "  ";
            $context["typeClasses"] = ["normal" => "px-6 py-3 bg-gray-600 text-white hover:bg-gray-700 focus:ring-gray-500 rounded-lg transition-all", "cta" => "px-8 py-4 bg-brand text-white font-bold rounded-xl shadow-lg hover:bg-brand/90 transition transform hover:-translate-y-1 hover:scale-105", "ctaAlt" => "px-8 py-4 bg-white/20 border border-white/30 text-white font-bold rounded-xl shadow-lg hover:bg-white/40 transition transform hover:-translate-y-1 hover:scale-105 backdrop-blur"];
            // line 53
            yield "
  ";
            // line 55
            yield "  ";
            if (((isset($context["buttonText"]) || array_key_exists("buttonText", $context) ? $context["buttonText"] : (craft\helpers\Template::fallbackExists("buttonText") ? craft\helpers\Template::fallback("buttonText") : (function () { throw new RuntimeError('Variable "buttonText" does not exist.', 55, $this->source); })())) && (isset($context["buttonUrl"]) || array_key_exists("buttonUrl", $context) ? $context["buttonUrl"] : (craft\helpers\Template::fallbackExists("buttonUrl") ? craft\helpers\Template::fallback("buttonUrl") : (function () { throw new RuntimeError('Variable "buttonUrl" does not exist.', 55, $this->source); })())))) {
                // line 56
                yield "    <a href=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["buttonUrl"]) || array_key_exists("buttonUrl", $context) ? $context["buttonUrl"] : (craft\helpers\Template::fallbackExists("buttonUrl") ? craft\helpers\Template::fallback("buttonUrl") : (function () { throw new RuntimeError('Variable "buttonUrl" does not exist.', 56, $this->source); })())), "html", null, true);
                yield "\" class=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["typeClasses"]) || array_key_exists("typeClasses", $context) ? $context["typeClasses"] : (craft\helpers\Template::fallbackExists("typeClasses") ? craft\helpers\Template::fallback("typeClasses") : (function () { throw new RuntimeError('Variable "typeClasses" does not exist.', 56, $this->source); })())), (isset($context["buttonType"]) || array_key_exists("buttonType", $context) ? $context["buttonType"] : (craft\helpers\Template::fallbackExists("buttonType") ? craft\helpers\Template::fallback("buttonType") : (function () { throw new RuntimeError('Variable "buttonType" does not exist.', 56, $this->source); })())), [], "array", false, false, false, 56), "html", null, true);
                yield "\">
      ";
                // line 57
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["buttonText"]) || array_key_exists("buttonText", $context) ? $context["buttonText"] : (craft\helpers\Template::fallbackExists("buttonText") ? craft\helpers\Template::fallback("buttonText") : (function () { throw new RuntimeError('Variable "buttonText" does not exist.', 57, $this->source); })())), "html", null, true);
                yield "
    </a>
  ";
            }
        }
        craft\helpers\Template::endProfile("template", "components/cta-button");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "components/cta-button";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  154 => 57,  147 => 56,  144 => 55,  141 => 53,  138 => 48,  135 => 46,  132 => 45,  129 => 44,  126 => 43,  124 => 42,  121 => 40,  117 => 38,  111 => 37,  105 => 34,  98 => 33,  95 => 32,  92 => 30,  89 => 25,  86 => 23,  83 => 22,  80 => 21,  77 => 20,  75 => 19,  71 => 18,  67 => 17,  64 => 16,  62 => 14,  61 => 13,  60 => 12,  58 => 11,  55 => 9,  52 => 8,  49 => 7,  47 => 6,  44 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{# CTA Button Component for Craft 5 Entries Field #}
{# Usage for single CTA: {% include 'components/cta-button' with { 'cta': ctaEntry } %} #}
{# Usage for entries field: {% include 'components/cta-button' with { 'ctas': entry.ctaButtons } %} #}

{# Multiple CTAs rendering #}
{% if ctas is defined and ctas|length %}
  {% set layout = layout ?? 'horizontal' %}
  {% set spacing = spacing ?? 'gap-4' %}
  
  {# Layout classes #}
  {% set layoutClasses = {
    'horizontal': 'flex flex-wrap ' ~ spacing,
    'vertical': 'flex flex-col ' ~ spacing,
    'centered': 'flex flex-wrap justify-center ' ~ spacing
  } %}

  <div class=\"{{ layoutClasses[layout] }}\">
    {% for ctaEntry in ctas %}
      {# Render each CTA directly without recursive include #}
      {% set buttonText = ctaEntry.linkText %}
      {% set buttonUrl = ctaEntry.urlAddress %}
      {% set buttonType = ctaEntry.buttonType %}

      {# Button type classes - using your original styles #}
      {% set typeClasses = {
        'normal': 'px-6 py-3 bg-gray-600 text-white hover:bg-gray-700 focus:ring-gray-500 rounded-lg transition-all',
        'cta': 'px-8 py-4 bg-brand text-white font-bold rounded-xl shadow-lg hover:bg-brand/90 transition transform hover:-translate-y-1 hover:scale-105',
        'ctaAlt': 'px-8 py-4 bg-white/20 border border-white/30 text-white font-bold rounded-xl shadow-lg hover:bg-white/40 transition transform hover:-translate-y-1 hover:scale-105 backdrop-blur'
      } %}

      {# Render the button #}
      {% if buttonText and buttonUrl %}
        <a href=\"{{ buttonUrl }}\" class=\"{{ typeClasses[buttonType] }}\">
          {{ buttonText }}
        </a>
      {% endif %}
    {% endfor %}
  </div>
{% endif %}

{# Single CTA rendering #}
{% if cta is defined %}
  {% set buttonText = cta.linkText %}
  {% set buttonUrl = cta.urlAddress %}
  {% set buttonType = cta.buttonType %}

  {# Button type classes - using your original styles #}
  {% set typeClasses = {
    'normal': 'px-6 py-3 bg-gray-600 text-white hover:bg-gray-700 focus:ring-gray-500 rounded-lg transition-all',
    'cta': 'px-8 py-4 bg-brand text-white font-bold rounded-xl shadow-lg hover:bg-brand/90 transition transform hover:-translate-y-1 hover:scale-105',
    'ctaAlt': 'px-8 py-4 bg-white/20 border border-white/30 text-white font-bold rounded-xl shadow-lg hover:bg-white/40 transition transform hover:-translate-y-1 hover:scale-105 backdrop-blur'
  } %}

  {# Render the button #}
  {% if buttonText and buttonUrl %}
    <a href=\"{{ buttonUrl }}\" class=\"{{ typeClasses[buttonType] }}\">
      {{ buttonText }}
    </a>
  {% endif %}
{% endif %}", "components/cta-button", "/var/www/html/templates/components/cta-button.twig");
    }
}
