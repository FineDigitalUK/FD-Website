<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/fieldtypes/Assets/input.twig */
class __TwigTemplate_faa7c2b3dabdb6d2cc0f9268d6363dcd extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_includes/forms/elementSelect.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Assets/input.twig");
        // line 3
        $context["registerJs"] = false;
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\prismjs\\PrismJsAsset"], "method", false, false, false, 5);
        // line 7
        $context["jsSettings"] = ["id" => $this->env->getFilter('namespaceInputId')->getCallable()(        // line 8
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 8, $this->source); })())), "name" => $this->env->getFilter('namespaceInputName')->getCallable()(        // line 9
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 9, $this->source); })())), "elementType" =>         // line 10
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 10, $this->source); })()), "sources" =>         // line 11
(isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 11, $this->source); })()), "condition" => ((        // line 12
(isset($context["condition"]) || array_key_exists("condition", $context) ? $context["condition"] : (function () { throw new RuntimeError('Variable "condition" does not exist.', 12, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["condition"]) || array_key_exists("condition", $context) ? $context["condition"] : (function () { throw new RuntimeError('Variable "condition" does not exist.', 12, $this->source); })()), "getConfig", [], "method", false, false, false, 12)) : (null)), "referenceElementId" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 13
($context["referenceElement"] ?? null), "id", [], "any", true, true, false, 13) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["referenceElement"] ?? null), "id", [], "any", false, false, false, 13)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["referenceElement"] ?? null), "id", [], "any", false, false, false, 13)) : (null)), "referenceElementOwnerId" => (($this->env->getTest('instance of')->getCallable()(((        // line 14
$context["referenceElement"]) ?? (null)), "craft\\base\\NestedElementInterface")) ? (craft\helpers\Template::attribute($this->env, $this->source,         // line 15
(isset($context["referenceElement"]) || array_key_exists("referenceElement", $context) ? $context["referenceElement"] : (function () { throw new RuntimeError('Variable "referenceElement" does not exist.', 15, $this->source); })()), "getOwnerId", [], "method", false, false, false, 15)) : (null)), "referenceElementSiteId" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 17
($context["referenceElement"] ?? null), "siteId", [], "any", true, true, false, 17) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["referenceElement"] ?? null), "siteId", [], "any", false, false, false, 17)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["referenceElement"] ?? null), "siteId", [], "any", false, false, false, 17)) : (null)), "criteria" =>         // line 18
(isset($context["criteria"]) || array_key_exists("criteria", $context) ? $context["criteria"] : (function () { throw new RuntimeError('Variable "criteria" does not exist.', 18, $this->source); })()), "searchCriteria" => ((        // line 19
$context["searchCriteria"]) ?? (null)), "sourceElementId" =>         // line 20
(isset($context["sourceElementId"]) || array_key_exists("sourceElementId", $context) ? $context["sourceElementId"] : (function () { throw new RuntimeError('Variable "sourceElementId" does not exist.', 20, $this->source); })()), "defaultPlacement" =>         // line 21
(isset($context["defaultPlacement"]) || array_key_exists("defaultPlacement", $context) ? $context["defaultPlacement"] : (function () { throw new RuntimeError('Variable "defaultPlacement" does not exist.', 21, $this->source); })()), "viewMode" =>         // line 22
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 22, $this->source); })()), "limit" =>         // line 23
(isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 23, $this->source); })()), "modalStorageKey" =>         // line 24
(isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 24, $this->source); })()), "fieldId" =>         // line 25
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 25, $this->source); })()), "prevalidate" => ((        // line 26
$context["prevalidate"]) ?? (false)), "canUpload" =>         // line 27
(isset($context["canUpload"]) || array_key_exists("canUpload", $context) ? $context["canUpload"] : (function () { throw new RuntimeError('Variable "canUpload" does not exist.', 27, $this->source); })()), "fsType" =>         // line 28
(isset($context["fsType"]) || array_key_exists("fsType", $context) ? $context["fsType"] : (function () { throw new RuntimeError('Variable "fsType" does not exist.', 28, $this->source); })()), "defaultFieldLayoutId" =>         // line 29
(isset($context["defaultFieldLayoutId"]) || array_key_exists("defaultFieldLayoutId", $context) ? $context["defaultFieldLayoutId"] : (function () { throw new RuntimeError('Variable "defaultFieldLayoutId" does not exist.', 29, $this->source); })()), "modalSettings" => ["hideSidebar" => ((        // line 31
$context["hideSidebar"]) ?? (false)), "defaultSource" => ((        // line 32
$context["defaultSource"]) ?? (null)), "defaultSourcePath" => ((        // line 33
$context["defaultSourcePath"]) ?? (null)), "preferStoredSource" => ((        // line 34
$context["preferStoredSource"]) ?? (false)), "showSourcePath" => ((        // line 35
$context["showSourcePath"]) ?? (true)), "indexSettings" => ["showFolders" => ((        // line 37
$context["showFolders"]) ?? (true))], "modalTitle" =>         // line 39
(isset($context["selectionLabel"]) || array_key_exists("selectionLabel", $context) ? $context["selectionLabel"] : (function () { throw new RuntimeError('Variable "selectionLabel" does not exist.', 39, $this->source); })())], "describedBy" => ((((        // line 41
$context["describedBy"]) ?? (false))) ? (Twig\Extension\CoreExtension::join($this->extensions['craft\web\twig\Extension']->mapFilter($this->env, Twig\Extension\CoreExtension::split($this->env->getCharset(), (isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 41, $this->source); })()), " "), function ($__id__) use ($context, $macros) { $context["id"] = $__id__; return $this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 41, $this->source); })())); }), " ")) : (null)), "allowSelfRelations" => ((        // line 42
$context["allowSelfRelations"]) ?? (false))];
        // line 45
        ob_start();
        // line 46
        yield "    new ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 46, $this->source); })()), "html", null, true);
        yield "(";
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["jsSettings"]) || array_key_exists("jsSettings", $context) ? $context["jsSettings"] : (function () { throw new RuntimeError('Variable "jsSettings" does not exist.', 46, $this->source); })()));
        yield ");
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_includes/forms/elementSelect.twig", "_components/fieldtypes/Assets/input.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Assets/input.twig");
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/fieldtypes/Assets/input.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  93 => 1,  85 => 46,  83 => 45,  81 => 42,  80 => 41,  79 => 39,  78 => 37,  77 => 35,  76 => 34,  75 => 33,  74 => 32,  73 => 31,  72 => 29,  71 => 28,  70 => 27,  69 => 26,  68 => 25,  67 => 24,  66 => 23,  65 => 22,  64 => 21,  63 => 20,  62 => 19,  61 => 18,  60 => 17,  59 => 15,  58 => 14,  57 => 13,  56 => 12,  55 => 11,  54 => 10,  53 => 9,  52 => 8,  51 => 7,  49 => 5,  47 => 3,  39 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '_includes/forms/elementSelect.twig' %}

{% set registerJs = false %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\prismjs\\\\PrismJsAsset\") %}

{% set jsSettings = {
    id: id|namespaceInputId,
    name: name|namespaceInputName,
    elementType: elementType,
    sources: sources,
    condition: condition ? condition.getConfig() : null,
    referenceElementId: referenceElement.id ?? null,
    referenceElementOwnerId: (referenceElement ?? null) is instance of('craft\\\\base\\\\NestedElementInterface')
        ? referenceElement.getOwnerId()
        : null,
    referenceElementSiteId: referenceElement.siteId ?? null,
    criteria: criteria,
    searchCriteria: searchCriteria ?? null,
    sourceElementId: sourceElementId,
    defaultPlacement,
    viewMode: viewMode,
    limit: limit,
    modalStorageKey: storageKey,
    fieldId: fieldId,
    prevalidate: prevalidate ?? false,
    canUpload: canUpload,
    fsType: fsType,
    defaultFieldLayoutId: defaultFieldLayoutId,
    modalSettings: {
        hideSidebar: hideSidebar ?? false,
        defaultSource: defaultSource ?? null,
        defaultSourcePath: defaultSourcePath ?? null,
        preferStoredSource: preferStoredSource ?? false,
        showSourcePath: showSourcePath ?? true,
        indexSettings: {
            showFolders: showFolders ?? true,
        },
        modalTitle: selectionLabel,
    },
    describedBy: (describedBy ?? false) ? describedBy|split(' ')|map(id => id|namespaceInputId)|join(' ') : null,
    allowSelfRelations: allowSelfRelations ?? false,
} %}

{% js %}
    new {{ jsClass }}({{ jsSettings|json_encode|raw }});
{% endjs %}
", "_components/fieldtypes/Assets/input.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fieldtypes/Assets/input.twig");
    }
}
