<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/sites/index.twig */
class __TwigTemplate_1e59a974604e4bb0b7674714173fc83f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'sidebar' => [$this, 'block_sidebar'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/sites/index.twig");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Sites", "app");
        // line 3
        $context["readOnly"] =  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "app", [], "any", false, false, false, 3), "config", [], "any", false, false, false, 3), "general", [], "any", false, false, false, 3), "allowAdminChanges", [], "any", false, false, false, 3);
        // line 5
        $context["multiple"] = (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 5, $this->source); })())) > 1) &&  !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 5, $this->source); })()));
        // line 6
        $context["canSort"] = (((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 6, $this->source); })()) && (isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 6, $this->source); })())) &&  !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 6, $this->source); })()));
        // line 57
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 57, $this->source); })())) {
            // line 58
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 115
        ob_start();
        // line 116
        yield "    new Craft.SitesAdmin();

    new Craft.SiteAdminTable({
        tableSelector: '#sites',
        minItems: 1,
        sortable: true,
        reorderAction: 'sites/reorder-sites',
        deleteAction: 'sites/delete-site',
    });
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 4]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sites/index.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/sites/index.twig");
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 10
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 10, $this->source); })())) {
            // line 11
            yield "        ";
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["href" => craft\helpers\UrlHelper::url("settings/sites/new", ((            // line 12
(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 12, $this->source); })())) ? (["groupId" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 12, $this->source); })()), "id", [], "any", false, false, false, 12)]) : (null))), "class" => ["btn", "submit", "add", "icon", ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 13
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 13, $this->source); })()), "app", [], "any", false, false, false, 13), "sites", [], "any", false, false, false, 13), "getRemainingSites", [], "method", false, false, false, 13)) ? (null) : ("disabled"))], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("New site", "app")]);
            // line 15
            yield "
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_sidebar(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "sidebar");
        // line 21
        yield "    <nav>
        <ul id=\"groups\">
            <li><a href=\"";
        // line 23
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("settings/sites"), "html", null, true);
        yield "\"";
        if ( !(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 23, $this->source); })())) {
            yield " class=\"sel\"";
        }
        yield ">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("All Sites", "app"), "html", null, true);
        yield "</a></li>
            ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 24, $this->source); })()), "app", [], "any", false, false, false, 24), "sites", [], "any", false, false, false, 24), "getAllGroups", [], "method", false, false, false, 24));
        foreach ($context['_seq'] as $context["_key"] => $context["g"]) {
            // line 25
            yield "                <li>
                    ";
            // line 26
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["href" => craft\helpers\UrlHelper::url("settings/sites", ["groupId" => craft\helpers\Template::attribute($this->env, $this->source,             // line 27
$context["g"], "id", [], "any", false, false, false, 27)]), "class" => (((            // line 28
(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 28, $this->source); })()) && (craft\helpers\Template::attribute($this->env, $this->source, $context["g"], "id", [], "any", false, false, false, 28) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 28, $this->source); })()), "id", [], "any", false, false, false, 28)))) ? ("sel") : (false)), "text" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 29
$context["g"], "name", [], "any", false, false, false, 29), "site"), "data" => ["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 31
$context["g"], "id", [], "any", false, false, false, 31), "raw-name" => craft\helpers\Template::attribute($this->env, $this->source,             // line 32
$context["g"], "getName", [false], "method", false, false, false, 32)]]);
            // line 34
            yield "
                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['g'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        yield "        </ul>
    </nav>

    ";
        // line 40
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 40, $this->source); })())) {
            // line 41
            yield "        <div class=\"buttons\">
            <button type=\"button\" id=\"newgroupbtn\" class=\"btn add icon\">";
            // line 42
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("New group", "app"), "html", null, true);
            yield "</button>

            ";
            // line 44
            if ((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 44, $this->source); })())) {
                // line 45
                yield "                <button type=\"button\" id=\"groupsettingsbtn\" class=\"btn settings icon menubtn\" title=\"";
                yield "Settings";
                yield "\" aria-label=\"";
                yield "Settings";
                yield "\"></button>
                <div class=\"menu\">
                    <ul>
                        <li><a data-action=\"rename\" role=\"button\">";
                // line 48
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Rename selected group", "app"), "html", null, true);
                yield "</a></li>
                        <li><a data-action=\"delete\" role=\"button\"";
                // line 49
                if ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 49, $this->source); })()))) {
                    yield " class=\"disabled\" title=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("You can only delete groups that have no sites.", "app"), "html", null, true);
                    yield "\"";
                }
                yield ">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Delete selected group", "app"), "html", null, true);
                yield "</a></li>
                    </ul>
                </div>
            ";
            }
            // line 53
            yield "        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "sidebar");
        yield from [];
    }

    // line 61
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 62
        yield "    ";
        if ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 62, $this->source); })()))) {
            // line 63
            yield "        <div class=\"tablepane\">
            <table id=\"sites\" class=\"data fullwidth\">
                <thead>
                    <th scope=\"col\">";
            // line 66
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "html", null, true);
            yield "</th>
                    <th scope=\"col\">";
            // line 67
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "html", null, true);
            yield "</th>
                    <th scope=\"col\">";
            // line 68
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "html", null, true);
            yield "</th>
                    <th scope=\"col\">";
            // line 69
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Primary", "app"), "html", null, true);
            yield "</th>
                    <th scope=\"col\">";
            // line 70
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "html", null, true);
            yield "</th>
                    ";
            // line 71
            if ( !(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 71, $this->source); })())) {
                // line 72
                yield "                        <th scope=\"col\">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "html", null, true);
                yield "</th>
                    ";
            }
            // line 74
            yield "                    ";
            if ((isset($context["canSort"]) || array_key_exists("canSort", $context) ? $context["canSort"] : (function () { throw new RuntimeError('Variable "canSort" does not exist.', 74, $this->source); })())) {
                // line 75
                yield "                        <td class=\"thin\"></td>
                    ";
            }
            // line 77
            yield "                    ";
            if ((isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 77, $this->source); })())) {
                // line 78
                yield "                        <td class=\"thin\"></td>
                    ";
            }
            // line 80
            yield "                </thead>
                <tbody>
                    ";
            // line 82
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 82, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                // line 83
                yield "                        <tr data-id=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [], "any", false, false, false, 83), "html", null, true);
                yield "\" data-uid=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "uid", [], "any", false, false, false, 83), "html", null, true);
                yield "\" data-name=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", [], "any", false, false, false, 83), "site"), "html", null, true);
                yield "\">
                            <th scope=\"row\" data-title=\"";
                // line 84
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "html", null, true);
                yield "\">
                                <a href=\"";
                // line 85
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url(("settings/sites/" . craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [], "any", false, false, false, 85))), "html", null, true);
                yield "\">
                                    <span class=\"status ";
                // line 86
                yield ((craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "enabled", [], "any", false, false, false, 86)) ? ("enabled") : ("disabled"));
                yield "\"></span>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", [], "any", false, false, false, 86), "site"), "html", null, true);
                yield "
                                </a>
                            </th>
                            <td data-title=\"";
                // line 89
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "html", null, true);
                yield "\"><code>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", [], "any", false, false, false, 89), "html", null, true);
                yield "</code></td>
                            <td data-title=\"";
                // line 90
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "html", null, true);
                yield "\"><code>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "language", [], "any", false, false, false, 90), "html", null, true);
                yield "</code></td>
                            <td data-title=\"";
                // line 91
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Primary", "app"), "html", null, true);
                yield "\">";
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "primary", [], "any", false, false, false, 91)) {
                    yield "<div data-icon=\"check\" aria-label=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Yes", "app"), "html", null, true);
                    yield "\"></div>";
                }
                yield "</td>
                            <td data-title=\"";
                // line 92
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "html", null, true);
                yield "\"><code>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "baseUrl", [], "any", false, false, false, 92), "html", null, true);
                yield "</code></td>
                            ";
                // line 93
                if ( !(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 93, $this->source); })())) {
                    // line 94
                    yield "                                <td data-title=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "html", null, true);
                    yield "\">";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "group", [], "any", false, false, false, 94), "name", [], "any", false, false, false, 94), "site"), "html", null, true);
                    yield "</td>
                            ";
                }
                // line 96
                yield "                            ";
                if ((isset($context["canSort"]) || array_key_exists("canSort", $context) ? $context["canSort"] : (function () { throw new RuntimeError('Variable "canSort" does not exist.', 96, $this->source); })())) {
                    // line 97
                    yield "                                <td class=\"thin\"><a class=\"move icon\" title=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                    yield "\" aria-label=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                    yield "\" role=\"button\"></a></td>
                            ";
                }
                // line 99
                yield "                            ";
                if ((isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 99, $this->source); })())) {
                    // line 100
                    yield "                                <td class=\"thin\"><a class=\"delete icon";
                    if (craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "primary", [], "any", false, false, false, 100)) {
                        yield " disabled";
                    }
                    yield "\" title=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    yield "\" aria-label=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    yield "\" role=\"button\"></a></td>
                            ";
                }
                // line 102
                yield "                        </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['site'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 104
            yield "                </tbody>
            </table>
        </div>
    ";
        } else {
            // line 108
            yield "        <div class=\"zilch\">
            <p>";
            // line 109
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("No sites exist for this group yet.", "app"), "html", null, true);
            yield "</p>
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/sites/index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  373 => 109,  370 => 108,  364 => 104,  357 => 102,  345 => 100,  342 => 99,  334 => 97,  331 => 96,  323 => 94,  321 => 93,  315 => 92,  305 => 91,  299 => 90,  293 => 89,  285 => 86,  281 => 85,  277 => 84,  268 => 83,  264 => 82,  260 => 80,  256 => 78,  253 => 77,  249 => 75,  246 => 74,  240 => 72,  238 => 71,  234 => 70,  230 => 69,  226 => 68,  222 => 67,  218 => 66,  213 => 63,  210 => 62,  202 => 61,  194 => 53,  181 => 49,  177 => 48,  168 => 45,  166 => 44,  161 => 42,  158 => 41,  156 => 40,  151 => 37,  143 => 34,  141 => 32,  140 => 31,  139 => 29,  138 => 28,  137 => 27,  136 => 26,  133 => 25,  129 => 24,  119 => 23,  115 => 21,  107 => 20,  99 => 15,  97 => 13,  96 => 12,  94 => 11,  91 => 10,  83 => 9,  77 => 1,  65 => 116,  63 => 115,  60 => 58,  58 => 57,  56 => 6,  54 => 5,  52 => 3,  50 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"Sites\"|t('app') %}
{% set readOnly = not craft.app.config.general.allowAdminChanges %}

{% set multiple = (sites|length > 1) and not readOnly %}
{% set canSort = group and multiple and not readOnly %}


{% block actionButton %}
    {% if not readOnly %}
        {{ tag('a', {
            href: url('settings/sites/new', (group ? { groupId: group.id } : null)),
            class:  ['btn', 'submit', 'add', 'icon', craft.app.sites.getRemainingSites() ? null : 'disabled'],
            text: \"New site\"|t('app'),
        }) }}
    {% endif %}
{% endblock %}


{% block sidebar %}
    <nav>
        <ul id=\"groups\">
            <li><a href=\"{{ url('settings/sites') }}\"{% if not group %} class=\"sel\"{% endif %}>{{ \"All Sites\"|t('app') }}</a></li>
            {% for g in craft.app.sites.getAllGroups() %}
                <li>
                    {{ tag('a', {
                        href: url('settings/sites', {groupId: g.id}),
                        class: group and g.id == group.id ? 'sel' : false,
                        text: g.name|t('site'),
                        data: {
                            id: g.id,
                            'raw-name': g.getName(false),
                        },
                    }) }}
                </li>
            {% endfor %}
        </ul>
    </nav>

    {% if not readOnly %}
        <div class=\"buttons\">
            <button type=\"button\" id=\"newgroupbtn\" class=\"btn add icon\">{{ \"New group\"|t('app') }}</button>

            {% if group %}
                <button type=\"button\" id=\"groupsettingsbtn\" class=\"btn settings icon menubtn\" title=\"{{ 'Settings' }}\" aria-label=\"{{ 'Settings' }}\"></button>
                <div class=\"menu\">
                    <ul>
                        <li><a data-action=\"rename\" role=\"button\">{{ \"Rename selected group\"|t('app') }}</a></li>
                        <li><a data-action=\"delete\" role=\"button\"{% if sites|length %} class=\"disabled\" title=\"{{ 'You can only delete groups that have no sites.'|t('app') }}\"{% endif %}>{{ \"Delete selected group\"|t('app') }}</a></li>
                    </ul>
                </div>
            {% endif %}
        </div>
    {% endif %}
{% endblock %}

{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    {% if sites|length %}
        <div class=\"tablepane\">
            <table id=\"sites\" class=\"data fullwidth\">
                <thead>
                    <th scope=\"col\">{{ \"Name\"|t('app') }}</th>
                    <th scope=\"col\">{{ \"Handle\"|t('app') }}</th>
                    <th scope=\"col\">{{ \"Language\"|t('app') }}</th>
                    <th scope=\"col\">{{ \"Primary\"|t('app') }}</th>
                    <th scope=\"col\">{{ \"Base URL\"|t('app') }}</th>
                    {% if not group %}
                        <th scope=\"col\">{{ \"Group\"|t('app') }}</th>
                    {% endif %}
                    {% if canSort %}
                        <td class=\"thin\"></td>
                    {% endif %}
                    {% if multiple %}
                        <td class=\"thin\"></td>
                    {% endif %}
                </thead>
                <tbody>
                    {% for site in sites %}
                        <tr data-id=\"{{ site.id }}\" data-uid=\"{{ site.uid }}\" data-name=\"{{ site.name|t('site') }}\">
                            <th scope=\"row\" data-title=\"{{ 'Name'|t('app') }}\">
                                <a href=\"{{ url('settings/sites/' ~ site.id) }}\">
                                    <span class=\"status {{ site.enabled ? 'enabled' : 'disabled' }}\"></span>{{ site.name|t('site') }}
                                </a>
                            </th>
                            <td data-title=\"{{ 'Handle'|t('app') }}\"><code>{{ site.handle }}</code></td>
                            <td data-title=\"{{ 'Language'|t('app') }}\"><code>{{ site.language }}</code></td>
                            <td data-title=\"{{ 'Primary'|t('app') }}\">{% if site.primary %}<div data-icon=\"check\" aria-label=\"{{ 'Yes'|t('app') }}\"></div>{% endif %}</td>
                            <td data-title=\"{{ 'Base URL'|t('app') }}\"><code>{{ site.baseUrl }}</code></td>
                            {% if not group %}
                                <td data-title=\"{{ 'Group'|t('app') }}\">{{ site.group.name|t('site') }}</td>
                            {% endif %}
                            {% if canSort %}
                                <td class=\"thin\"><a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" aria-label=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a></td>
                            {% endif %}
                            {% if multiple %}
                                <td class=\"thin\"><a class=\"delete icon{% if site.primary %} disabled{% endif %}\" title=\"{{ 'Delete'|t('app') }}\" aria-label=\"{{ 'Delete'|t('app') }}\" role=\"button\"></a></td>
                            {% endif %}
                        </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    {% else %}
        <div class=\"zilch\">
            <p>{{ 'No sites exist for this group yet.'|t('app') }}</p>
        </div>
    {% endif %}
{% endblock %}


{% js on ready %}
    new Craft.SitesAdmin();

    new Craft.SiteAdminTable({
        tableSelector: '#sites',
        minItems: 1,
        sortable: true,
        reorderAction: 'sites/reorder-sites',
        deleteAction: 'sites/delete-site',
    });
{% endjs %}
", "settings/sites/index.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/sites/index.twig");
    }
}
