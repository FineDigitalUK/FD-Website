<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _special/login-modal.twig */
class __TwigTemplate_0d5105dfaf5b440fb64e042fb0eea262 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_special/login-modal.twig");
        // line 1
        yield "<div class=\"modal login-modal fitted\" lang=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "app", [], "any", false, false, false, 1), "getTargetLanguage", [], "method", false, false, false, 1), "html", null, true);
        yield "\">
  <div class=\"body\">
    <div class=\"login-modal-intro readable\">
      ";
        // line 4
        if ((isset($context["forElevatedSession"]) || array_key_exists("forElevatedSession", $context) ? $context["forElevatedSession"] : (function () { throw new RuntimeError('Variable "forElevatedSession" does not exist.', 4, $this->source); })())) {
            // line 5
            yield "        <h1>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Confirm your identity.", "app"), "html", null, true);
            yield "</h1>
        <p>";
            // line 6
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("You must reverify your identity before proceeding.", "app"), "html", null, true);
            yield "</p>
      ";
        } else {
            // line 8
            yield "        <h1>";
            yield $this->extensions['craft\web\twig\Extension']->widontFilter($this->extensions['craft\web\twig\Extension']->translateFilter("Your session has ended.", "app"));
            yield "</h1>
        <p>";
            // line 9
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Sign back in to continue.", "app"), "html", null, true);
            yield "</p>
      ";
        }
        // line 11
        yield "    </div>

    <div class=\"login-modal-form\">
      ";
        // line 14
        yield from $this->loadTemplate("_special/login.twig", "_special/login-modal.twig", 14)->unwrap()->yield($context);
        // line 15
        yield "    </div>
  </div>
</div>
";
        craft\helpers\Template::endProfile("template", "_special/login-modal.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_special/login-modal.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  79 => 15,  77 => 14,  72 => 11,  67 => 9,  62 => 8,  57 => 6,  52 => 5,  50 => 4,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<div class=\"modal login-modal fitted\" lang=\"{{ craft.app.getTargetLanguage() }}\">
  <div class=\"body\">
    <div class=\"login-modal-intro readable\">
      {% if forElevatedSession %}
        <h1>{{ 'Confirm your identity.'|t('app') }}</h1>
        <p>{{ 'You must reverify your identity before proceeding.'|t('app') }}</p>
      {% else %}
        <h1>{{ 'Your session has ended.'|t('app')|widont }}</h1>
        <p>{{ 'Sign back in to continue.'|t('app') }}</p>
      {% endif %}
    </div>

    <div class=\"login-modal-form\">
      {% include '_special/login.twig' %}
    </div>
  </div>
</div>
", "_special/login-modal.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_special/login-modal.twig");
    }
}
