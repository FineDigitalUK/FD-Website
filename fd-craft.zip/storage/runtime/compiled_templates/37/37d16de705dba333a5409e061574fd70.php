<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _elements/toolbar */
class __TwigTemplate_9f3da8bd3480e98d50a3df7afddd50dc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/toolbar");
        // line 1
        $macros["_v0"] = $this->macros["_v0"] = $this->loadTemplate("_includes/forms", "_elements/toolbar", 1)->unwrap();
        // line 3
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 3, $this->source); })()), "registerTranslations", ["app", ["Sort by {attribute}", "Score", "Structure", "Display in a table", "Display hierarchically", "Display as thumbnails"]], "method", false, false, false, 3);
        // line 11
        yield "
";
        // line 12
        echo \Craft::$app->getView()->invokeHook("cp.elements.toolbar", $context);

        // line 13
        yield "
";
        // line 14
        if (((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 14, $this->source); })()) || (isset($context["isAdministrative"]) || array_key_exists("isAdministrative", $context) ? $context["isAdministrative"] : (function () { throw new RuntimeError('Variable "isAdministrative" does not exist.', 14, $this->source); })()))) {
            // line 15
            yield "    <div>
        <label id=\"";
            // line 16
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 16, $this->source); })()), "html", null, true);
            yield "status-label\" class=\"visually-hidden\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Status", "app"), "html", null, true);
            yield "</label>
        <button id=\"";
            // line 17
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 17, $this->source); })()), "html", null, true);
            yield "status-button\" aria-labelledby=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 17, $this->source); })()), "html", null, true);
            yield "status-label\" type=\"button\" class=\"btn menubtn statusmenubtn\"><span class=\"status all\"></span>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
            yield "</button>
        <div class=\"menu\">
            <ul class=\"padded\">
                <li><a data-status=\"\" class=\"sel\"><span class=\"status all\"></span>";
            // line 20
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
            yield "</a></li>
                ";
            // line 21
            if ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 21, $this->source); })())) {
                // line 22
                yield "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable((isset($context["elementStatuses"]) || array_key_exists("elementStatuses", $context) ? $context["elementStatuses"] : (function () { throw new RuntimeError('Variable "elementStatuses" does not exist.', 22, $this->source); })()));
                foreach ($context['_seq'] as $context["status"] => $context["info"]) {
                    // line 23
                    yield "                        ";
                    $context["label"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [], "any", true, true, false, 23) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [], "any", false, false, false, 23)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [], "any", false, false, false, 23)) : ($context["info"]));
                    // line 24
                    yield "                        ";
                    $context["color"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [], "any", true, true, false, 24) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [], "any", false, false, false, 24)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [], "any", false, false, false, 24)) : (""));
                    // line 25
                    yield "                        ";
                    $context["color"] = (($this->env->getTest('instance of')->getCallable()((isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 25, $this->source); })()), "craft\\enums\\Color")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 25, $this->source); })()), "value", [], "any", false, false, false, 25)) : ((isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 25, $this->source); })())));
                    // line 26
                    yield "                        <li><a data-status=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["status"], "html", null, true);
                    yield "\"><span class=\"status ";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["status"], "html", null, true);
                    yield " ";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 26, $this->source); })()), "html", null, true);
                    yield "\"></span>";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 26, $this->source); })()), "html", null, true);
                    yield "</a></li>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['status'], $context['info'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 28
                yield "                ";
            }
            // line 29
            yield "            </ul>
            ";
            // line 30
            if ((isset($context["isAdministrative"]) || array_key_exists("isAdministrative", $context) ? $context["isAdministrative"] : (function () { throw new RuntimeError('Variable "isAdministrative" does not exist.', 30, $this->source); })())) {
                // line 31
                yield "                ";
                if ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 31, $this->source); })())) {
                    yield "<hr class=\"padded\" role=\"presentation\">";
                }
                // line 32
                yield "                <ul class=\"padded\">
                    ";
                // line 33
                if ((($context["canHaveDrafts"]) ?? (false))) {
                    // line 34
                    yield "                        <li><a data-drafts><span class=\"icon\" data-icon=\"draft\" aria-hidden=\"true\"></span>";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Drafts", "app"), "html", null, true);
                    yield "</a></li>
                    ";
                }
                // line 36
                yield "                    <li><a data-trashed><span class=\"icon\" data-icon=\"trash\" aria-hidden=\"true\"></span>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Trashed", "app"), "html", null, true);
                yield "</a></li>
                </ul>
            ";
            }
            // line 39
            yield "        </div>
    </div>
";
        }
        // line 42
        if ((isset($context["showSiteMenu"]) || array_key_exists("showSiteMenu", $context) ? $context["showSiteMenu"] : (function () { throw new RuntimeError('Variable "showSiteMenu" does not exist.', 42, $this->source); })())) {
            // line 43
            yield "    ";
            yield from $this->loadTemplate("_elements/sitemenu", "_elements/toolbar", 43)->unwrap()->yield($context);
        }
        // line 45
        yield "<div class=\"search-container flex-grow texticon has-filter-btn\">
    <span class=\"texticon-icon search icon\" aria-hidden=\"true\"></span>
    ";
        // line 47
        yield $macros["_v0"]->getTemplateForMacro("macro_text", $context, 47, $this->getSourceContext())->macro_text(...[["class" => "clearable", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Search", "app"), "value" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 50
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 50, $this->source); })()), "app", [], "any", false, false, false, 50), "request", [], "any", false, false, false, 50), "getParam", ["search"], "method", false, false, false, 50), "inputAttributes" => ["aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Search", "app")]]]]);
        // line 56
        yield "
    ";
        // line 57
        yield $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["role" => "button", "class" => "clear-btn hidden", "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("Clear search", "app"), "aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Clear search", "app")]]);
        // line 64
        yield "
    <button type=\"button\" class=\"filter-btn\" title=\"";
        // line 65
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Filter results", "app"), "html", null, true);
        yield "\" aria-label=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Filter results", "app"), "html", null, true);
        yield "\" aria-expanded=\"false\"></button>
</div>
";
        craft\helpers\Template::endProfile("template", "_elements/toolbar");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_elements/toolbar";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  169 => 65,  166 => 64,  164 => 57,  161 => 56,  159 => 50,  158 => 47,  154 => 45,  150 => 43,  148 => 42,  143 => 39,  136 => 36,  130 => 34,  128 => 33,  125 => 32,  120 => 31,  118 => 30,  115 => 29,  112 => 28,  97 => 26,  94 => 25,  91 => 24,  88 => 23,  83 => 22,  81 => 21,  77 => 20,  67 => 17,  61 => 16,  58 => 15,  56 => 14,  53 => 13,  50 => 12,  47 => 11,  45 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% from \"_includes/forms\" import text -%}

{% do view.registerTranslations('app', [
    \"Sort by {attribute}\",
    \"Score\",
    \"Structure\",
    \"Display in a table\",
    \"Display hierarchically\",
    \"Display as thumbnails\",
]) %}

{% hook 'cp.elements.toolbar' %}

{% if showStatusMenu or isAdministrative %}
    <div>
        <label id=\"{{ idPrefix }}status-label\" class=\"visually-hidden\">{{ \"Status\"|t('app') }}</label>
        <button id=\"{{ idPrefix }}status-button\" aria-labelledby=\"{{ idPrefix }}status-label\" type=\"button\" class=\"btn menubtn statusmenubtn\"><span class=\"status all\"></span>{{ \"All\"|t('app') }}</button>
        <div class=\"menu\">
            <ul class=\"padded\">
                <li><a data-status=\"\" class=\"sel\"><span class=\"status all\"></span>{{ \"All\"|t('app') }}</a></li>
                {% if showStatusMenu %}
                    {% for status, info in elementStatuses %}
                        {% set label = info.label ?? info %}
                        {% set color = info.color ?? '' %}
                        {% set color = color is instance of ('craft\\\\enums\\\\Color') ? color.value : color %}
                        <li><a data-status=\"{{ status }}\"><span class=\"status {{ status }} {{ color }}\"></span>{{ label }}</a></li>
                    {% endfor %}
                {% endif %}
            </ul>
            {% if isAdministrative %}
                {% if showStatusMenu %}<hr class=\"padded\" role=\"presentation\">{% endif %}
                <ul class=\"padded\">
                    {% if canHaveDrafts ?? false %}
                        <li><a data-drafts><span class=\"icon\" data-icon=\"draft\" aria-hidden=\"true\"></span>{{ 'Drafts'|t('app') }}</a></li>
                    {% endif %}
                    <li><a data-trashed><span class=\"icon\" data-icon=\"trash\" aria-hidden=\"true\"></span>{{ \"Trashed\"|t('app') }}</a></li>
                </ul>
            {% endif %}
        </div>
    </div>
{% endif %}
{% if showSiteMenu %}
    {% include \"_elements/sitemenu\" %}
{% endif %}
<div class=\"search-container flex-grow texticon has-filter-btn\">
    <span class=\"texticon-icon search icon\" aria-hidden=\"true\"></span>
    {{ text({
        class: 'clearable',
        placeholder: \"Search\"|t('app'),
        value: craft.app.request.getParam('search'),
        inputAttributes: {
            aria: {
                label: 'Search'|t('app'),
            },
        },
    }) }}
    {{ tag('button', {
        role: 'button',
        class: 'clear-btn hidden',
        title: 'Clear search'|t('app'),
        aria: {
            label: 'Clear search'|t('app'),
        },
    }) }}
    <button type=\"button\" class=\"filter-btn\" title=\"{{ 'Filter results'|t('app') }}\" aria-label=\"{{ 'Filter results'|t('app') }}\" aria-expanded=\"false\"></button>
</div>
", "_elements/toolbar", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/toolbar.twig");
    }
}
