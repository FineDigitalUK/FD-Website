<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _layouts/cp */
class __TwigTemplate_4ac5e4f618e7bd177d3bc541b29aa8a7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'mainFormAttributes' => [$this, 'block_mainFormAttributes'],
            'header' => [$this, 'block_header'],
            'pageTitle' => [$this, 'block_pageTitle'],
            'main' => [$this, 'block_main'],
            'content' => [$this, 'block_content'],
            'actionButton' => [$this, 'block_actionButton'],
            'submitButton' => [$this, 'block_submitButton'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 42
        return "_layouts/basecp.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/cp");
        // line 45
        $context["queue"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 45, $this->source); })()), "app", [], "any", false, false, false, 45), "queue", [], "any", false, false, false, 45);
        // line 46
        ob_start();
        // line 47
        if ($this->env->getTest('instance of')->getCallable()((isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 47, $this->source); })()), "craft\\queue\\QueueInterface")) {
            // line 48
            yield "    Craft.cp.setJobInfo(";
            yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 48, $this->source); })()), "getJobInfo", [100], "method", false, false, false, 48));
            yield ", false);
    ";
            // line 49
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 49, $this->source); })()), "getHasReservedJobs", [], "method", false, false, false, 49)) {
                // line 50
                yield "        Craft.cp.trackJobProgress(true);
    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 51
(isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 51, $this->source); })()), "getHasWaitingJobs", [], "method", false, false, false, 51)) {
                // line 52
                yield "        Craft.cp.runQueue();
    ";
            }
        } else {
            // line 55
            yield "    Craft.cp.enableQueue = false;
";
        }
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 59
        $context["sidebarState"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true, false, 59), "request", [], "any", false, true, false, 59), "rawCookies", [], "any", false, true, false, 59), "value", [(("Craft-" . craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 59, $this->source); })()), "app", [], "any", false, false, false, 59), "systemUid", [], "any", false, false, false, 59)) . ":sidebar")], "method", true, true, false, 59) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true, false, 59), "request", [], "any", false, true, false, 59), "rawCookies", [], "any", false, true, false, 59), "value", [(("Craft-" . craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 59, $this->source); })()), "app", [], "any", false, false, false, 59), "systemUid", [], "any", false, false, false, 59)) . ":sidebar")], "method", false, false, false, 59)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true, false, 59), "request", [], "any", false, true, false, 59), "rawCookies", [], "any", false, true, false, 59), "value", [(("Craft-" . craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 59, $this->source); })()), "app", [], "any", false, false, false, 59), "systemUid", [], "any", false, false, false, 59)) . ":sidebar")], "method", false, false, false, 59)) : ("expanded"));
        // line 60
        $context["bodyAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["data" => ["sidebar" =>         // line 62
(isset($context["sidebarState"]) || array_key_exists("sidebarState", $context) ? $context["sidebarState"] : (function () { throw new RuntimeError('Variable "sidebarState" does not exist.', 62, $this->source); })())]], ((        // line 64
$context["bodyAttributes"]) ?? ([])), true);
        // line 66
        $context["fullPageForm"] = (array_key_exists("fullPageForm", $context) && (isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 66, $this->source); })()));
        // line 68
        $context["editionName"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 68, $this->source); })()), "app", [], "any", false, false, false, 68), "edition", [], "any", false, false, false, 68), "name", [], "any", false, false, false, 68);
        // line 69
        $context["canUpgradeEdition"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 69, $this->source); })()), "app", [], "any", false, false, false, 69), "getCanUpgradeEdition", [], "method", false, false, false, 69);
        // line 70
        $context["licensedEdition"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 70, $this->source); })()), "app", [], "any", false, false, false, 70), "getLicensedEdition", [], "method", false, false, false, 70);
        // line 71
        $context["isTrial"] = ( !((isset($context["licensedEdition"]) || array_key_exists("licensedEdition", $context) ? $context["licensedEdition"] : (function () { throw new RuntimeError('Variable "licensedEdition" does not exist.', 71, $this->source); })()) === null) &&  !((isset($context["licensedEdition"]) || array_key_exists("licensedEdition", $context) ? $context["licensedEdition"] : (function () { throw new RuntimeError('Variable "licensedEdition" does not exist.', 71, $this->source); })()) === (isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 71, $this->source); })())));
        // line 72
        $context["trialInfo"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 72, $this->source); })()), "cp", [], "any", false, false, false, 72), "trialInfo", [], "method", false, false, false, 72);
        // line 74
        $context["contentNotice"] = Twig\Extension\CoreExtension::trim((($context["contentNotice"]) ?? (((        $this->unwrap()->hasBlock("contentNotice", $context, $blocks)) ? (        $this->unwrap()->renderBlock("contentNotice", $context, $blocks)) : ("")))));
        // line 75
        $context["sidebar"] = Twig\Extension\CoreExtension::trim((($context["sidebar"]) ?? (((        $this->unwrap()->hasBlock("sidebar", $context, $blocks)) ? (        $this->unwrap()->renderBlock("sidebar", $context, $blocks)) : ("")))));
        // line 76
        $context["toolbar"] = Twig\Extension\CoreExtension::trim((($context["toolbar"]) ?? (((        $this->unwrap()->hasBlock("toolbar", $context, $blocks)) ? (        $this->unwrap()->renderBlock("toolbar", $context, $blocks)) : ("")))));
        // line 77
        $context["actionButton"] = Twig\Extension\CoreExtension::trim((($context["actionButton"]) ?? (((        $this->unwrap()->hasBlock("actionButton", $context, $blocks)) ? (        $this->unwrap()->renderBlock("actionButton", $context, $blocks)) : ("")))));
        // line 78
        $context["additionalButtons"] = (($context["additionalButtons"]) ?? (null));
        // line 79
        $context["details"] = Twig\Extension\CoreExtension::trim((($context["details"]) ?? (((        $this->unwrap()->hasBlock("details", $context, $blocks)) ? (        $this->unwrap()->renderBlock("details", $context, $blocks)) : ("")))));
        // line 80
        $context["footer"] = Twig\Extension\CoreExtension::trim((($context["footer"]) ?? (((        $this->unwrap()->hasBlock("footer", $context, $blocks)) ? (        $this->unwrap()->renderBlock("footer", $context, $blocks)) : ("")))));
        // line 81
        $context["crumbs"] = (($context["crumbs"]) ?? (null));
        // line 82
        $context["contextMenu"] = Twig\Extension\CoreExtension::trim((($context["contextMenu"]) ?? (((        $this->unwrap()->hasBlock("contextMenu", $context, $blocks)) ? (        $this->unwrap()->renderBlock("contextMenu", $context, $blocks)) : ("")))));
        // line 83
        $context["actionMenu"] = (($context["actionMenu"]) ?? (""));
        // line 84
        $context["tabs"] = ((($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (($context["tabs"]) ?? ([]))) > 1)) ? ((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 84, $this->source); })())) : (null));
        // line 85
        $context["errorSummary"] = (($context["errorSummary"]) ?? (null));
        // line 87
        $context["mainContentClasses"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [((        // line 88
(isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 88, $this->source); })())) ? ("has-sidebar") : ("")), ((        // line 89
(isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 89, $this->source); })())) ? ("has-details") : (""))]);
        // line 92
        $context["bodyClass"] = craft\helpers\Html::explodeClass((($context["bodyClass"]) ?? ([])));
        // line 93
        $context["showHeader"] = (($context["showHeader"]) ?? (true));
        // line 94
        if ( !(isset($context["showHeader"]) || array_key_exists("showHeader", $context) ? $context["showHeader"] : (function () { throw new RuntimeError('Variable "showHeader" does not exist.', 94, $this->source); })())) {
            // line 95
            $context["bodyClass"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["bodyClass"]) || array_key_exists("bodyClass", $context) ? $context["bodyClass"] : (function () { throw new RuntimeError('Variable "bodyClass" does not exist.', 95, $this->source); })()), "no-header");
        }
        // line 97
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 97, $this->source); })()), "app", [], "any", false, false, false, 97), "hasModule", ["debug"], "method", false, false, false, 97)) {
            // line 98
            $context["bodyClass"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["bodyClass"]) || array_key_exists("bodyClass", $context) ? $context["bodyClass"] : (function () { throw new RuntimeError('Variable "bodyClass" does not exist.', 98, $this->source); })()), "has-debug-toolbar");
        }
        // line 101
        $context["mainAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => "main", "role" => "main"], ((        // line 104
$context["mainAttributes"]) ?? ([])));
        // line 106
        $context["formActions"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 106, $this->source); })()), "cp", [], "any", false, false, false, 106), "prepFormActions", [(($context["formActions"]) ?? (null))], "method", false, false, false, 106);
        // line 108
        $context["mainFormAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => "main-form", "method" => "post", "accept-charset" => "UTF-8", "novalidate" => true, "data" => ["saveshortcut" => ((        // line 114
$context["saveShortcut"]) ?? (true)), "saveshortcut-redirect" => ((((        // line 115
$context["saveShortcutRedirect"]) ?? (false))) ? ($this->env->getFilter('hash')->getCallable()((isset($context["saveShortcutRedirect"]) || array_key_exists("saveShortcutRedirect", $context) ? $context["saveShortcutRedirect"] : (function () { throw new RuntimeError('Variable "saveShortcutRedirect" does not exist.', 115, $this->source); })()))) : (false)), "saveshortcut-scroll" => ((        // line 116
$context["retainScrollOnSaveShortcut"]) ?? (false)), "actions" => ((        // line 117
$context["formActions"]) ?? (false)), "confirm-unload" => true, "delta" => craft\helpers\Template::attribute($this->env, $this->source,         // line 119
(isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 119, $this->source); })()), "getIsDeltaRegistrationActive", [], "method", false, false, false, 119), "delta-names" => craft\helpers\Template::attribute($this->env, $this->source,         // line 120
(isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 120, $this->source); })()), "getDeltaNames", [], "method", false, false, false, 120), "initial-delta-values" => craft\helpers\Template::attribute($this->env, $this->source,         // line 121
(isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 121, $this->source); })()), "getInitialDeltaValues", [], "method", false, false, false, 121), "modified-delta-names" => array_values(array_unique($this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Template::attribute($this->env, $this->source,         // line 122
(isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 122, $this->source); })()), "getModifiedDeltaNames", [], "method", false, false, false, 122), (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true, false, 122), "request", [], "any", false, true, false, 122), "getBodyParam", ["modifiedDeltaNames"], "method", true, true, false, 122) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true, false, 122), "request", [], "any", false, true, false, 122), "getBodyParam", ["modifiedDeltaNames"], "method", false, false, false, 122)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true, false, 122), "request", [], "any", false, true, false, 122), "getBodyParam", ["modifiedDeltaNames"], "method", false, false, false, 122)) : ([])))))]], ((        // line 124
$context["mainFormAttributes"]) ?? ([])), true);
        // line 126
        $context["userPhoto"] = Twig\Extension\CoreExtension::include($this->env, $context, "_layouts/components/header-photo.twig");
        // line 128
        ob_start();
        // line 129
        yield "// Remove the hash so the browser doesn't scroll to it
window.LOCATION_HASH = document.location.hash ? decodeURIComponent(document.location.hash.substr(1)) : null;
history.replaceState(undefined, undefined, window.location.href.match(/^[^#]*/)[0]);
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 1]);
        // line 412
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 412, $this->source); })()), "can", ["performUpdates"], "method", false, false, false, 412) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 412, $this->source); })()), "app", [], "any", false, false, false, 412), "updates", [], "any", false, false, false, 412), "getIsUpdateInfoCached", [], "method", false, false, false, 412))) {
            // line 413
            ob_start();
            // line 414
            yield "    Craft.cp.checkForUpdates();
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 42
        $this->parent = $this->loadTemplate("_layouts/basecp.twig", "_layouts/cp", 42);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_layouts/cp");
    }

    // line 134
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 135
        yield "    ";
        yield from $this->loadTemplate("_layouts/components/skip-links", "_layouts/cp", 135)->unwrap()->yield($context);
        // line 136
        yield "
    <div id=\"global-container\">
        ";
        // line 138
        yield from $this->loadTemplate("_layouts/components/global-sidebar", "_layouts/cp", 138)->unwrap()->yield($context);
        // line 139
        yield "
        <div id=\"page-container\">
            ";
        // line 141
        yield from $this->loadTemplate("_layouts/components/alerts", "_layouts/cp", 141)->unwrap()->yield($context);
        // line 142
        yield "
            <div id=\"global-header\" role=\"region\" aria-label=\"";
        // line 143
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        yield "\">
                <div class=\"flex flex-nowrap gap-xs\">
                    ";
        // line 145
        yield from $this->loadTemplate("_layouts/components/crumbs", "_layouts/cp", 145)->unwrap()->yield($context);
        // line 146
        yield "                    ";
        if ((isset($context["contextMenu"]) || array_key_exists("contextMenu", $context) ? $context["contextMenu"] : (function () { throw new RuntimeError('Variable "contextMenu" does not exist.', 146, $this->source); })())) {
            // line 147
            yield "                        <div id=\"context-menu-container\" class=\"context-menu-container\">
                            ";
            // line 148
            yield (isset($context["contextMenu"]) || array_key_exists("contextMenu", $context) ? $context["contextMenu"] : (function () { throw new RuntimeError('Variable "contextMenu" does not exist.', 148, $this->source); })());
            yield "
                        </div>
                    ";
        }
        // line 151
        yield "                </div>
                <button
                    type=\"button\"
                    id=\"announcements-btn\"
                    class=\"btn hidden\"
                    title=\"";
        // line 156
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("What’s New", "app"), "html", null, true);
        yield "\"
                >
                    <span class=\"visually-hidden\">";
        // line 158
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("What’s New", "app"), "html", null, true);
        yield "</span>
                    ";
        // line 159
        yield craft\helpers\Cp::iconSvg("gift");
        yield "
                </button>

                ";
        // line 163
        yield "                <div class=\"account-toggle-wrapper\">
                    <button
                        id=\"user-info\"
                        aria-controls=\"account-menu\"
                        class=\"btn menu-toggle\"
                        aria-label=\"";
        // line 168
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        yield "\"
                        title=\"";
        // line 169
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        yield "\"
                        data-disclosure-trigger
                    >
                        ";
        // line 172
        yield (isset($context["userPhoto"]) || array_key_exists("userPhoto", $context) ? $context["userPhoto"] : (function () { throw new RuntimeError('Variable "userPhoto" does not exist.', 172, $this->source); })());
        yield "
                    </button>
                    <div
                        id=\"account-menu\"
                        class=\"menu menu--disclosure\"
                        data-align=\"right\"
                        data-align-to=\".header-photo\"
                    >
                        <ul>
                            <li>
                                <a href=\"";
        // line 182
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("myaccount"), "html", null, true);
        yield "\" class=\"flex flex-nowrap\">
                                    ";
        // line 183
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 183, $this->source); })()), "photoId", [], "any", false, false, false, 183)) {
            // line 184
            yield "                                        ";
            yield (isset($context["userPhoto"]) || array_key_exists("userPhoto", $context) ? $context["userPhoto"] : (function () { throw new RuntimeError('Variable "userPhoto" does not exist.', 184, $this->source); })());
            yield "
                                    ";
        }
        // line 186
        yield "                                    <div class=\"flex-grow\">
                                        <div>";
        // line 187
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 187, $this->source); })()), "username", [], "any", false, false, false, 187), "html", null, true);
        yield "</div>
                                        ";
        // line 188
        if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 188, $this->source); })()), "app", [], "any", false, false, false, 188), "config", [], "any", false, false, false, 188), "general", [], "any", false, false, false, 188), "useEmailAsUsername", [], "any", false, false, false, 188)) {
            // line 189
            yield "                                            <div class=\"smalltext\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 189, $this->source); })()), "email", [], "any", false, false, false, 189), "html", null, true);
            yield "</div>
                                        ";
        }
        // line 191
        yield "                                    </div>
                                </a>
                            </li>
                        </ul>
                        <hr>
                        <ul>
                            <li><a href=\"";
        // line 197
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("logout"), "html", null, true);
        yield "\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Sign out", "app"), "html", null, true);
        yield "</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div id=\"main-container\">

                <main ";
        // line 205
        yield craft\helpers\Html::renderTagAttributes((isset($context["mainAttributes"]) || array_key_exists("mainAttributes", $context) ? $context["mainAttributes"] : (function () { throw new RuntimeError('Variable "mainAttributes" does not exist.', 205, $this->source); })()));
        yield ">

                    ";
        // line 207
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 207, $this->source); })())) {
            // line 208
            yield "<form ";
            yield from $this->unwrap()->yieldBlock('mainFormAttributes', $context, $blocks);
            yield ">";
            // line 209
            yield craft\helpers\Html::csrfInput();
        }
        // line 211
        yield "
                        ";
        // line 212
        if ((isset($context["showHeader"]) || array_key_exists("showHeader", $context) ? $context["showHeader"] : (function () { throw new RuntimeError('Variable "showHeader" does not exist.', 212, $this->source); })())) {
            // line 213
            yield "                            <div id=\"header-container\">
                                <header id=\"header\">
                                    ";
            // line 215
            yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
            // line 237
            yield "                                </header><!-- #header -->
                            </div>
                        ";
        }
        // line 240
        yield "
                        <div id=\"main-content\" class=\"";
        // line 241
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join((isset($context["mainContentClasses"]) || array_key_exists("mainContentClasses", $context) ? $context["mainContentClasses"] : (function () { throw new RuntimeError('Variable "mainContentClasses" does not exist.', 241, $this->source); })()), " "), "html", null, true);
        yield "\">
                            ";
        // line 243
        yield "                            ";
        if ((isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 243, $this->source); })())) {
            // line 244
            yield "                                <div id=\"sidebar-container\">
                                    <div id=\"sidebar-toggle-container\">
                                        <button
                                                type=\"button\"
                                                id=\"sidebar-toggle\"
                                                class=\"btn menubtn chromeless\"
                                                aria-controls=\"sidebar-container\"
                                                aria-expanded=\"false\"
                                        >
                                            ";
            // line 253
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Show sidebar", "app"), "html", null, true);
            yield "
                                        </button>
                                    </div>
                                    <div id=\"sidebar\" class=\"sidebar\">
                                        ";
            // line 257
            yield (isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 257, $this->source); })());
            yield "
                                    </div>
                                </div>
                            ";
        }
        // line 261
        yield "
                            ";
        // line 263
        yield "                            <div id=\"content-container\">
                                <div class=\"content-grid\">

                                    ";
        // line 266
        yield from $this->unwrap()->yieldBlock('main', $context, $blocks);
        // line 325
        yield "                                </div>
                            </div><!-- #content-container -->

                            ";
        // line 328
        if ( !Twig\Extension\CoreExtension::testEmpty((isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 328, $this->source); })()))) {
            // line 329
            yield "                                <div id=\"details-container\" data-state=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 329, $this->source); })()), "app", [], "any", false, false, false, 329), "request", [], "any", false, false, false, 329), "rawCookies", [], "any", false, false, false, 329), "value", [(("Craft-" . craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 329, $this->source); })()), "app", [], "any", false, false, false, 329), "systemUid", [], "any", false, false, false, 329)) . ":sidebar-details")], "method", false, false, false, 329), "html", null, true);
            yield "\">
                                    <div id=\"details\">
                                        <div class=\"details\">
                                            ";
            // line 332
            yield (isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 332, $this->source); })());
            yield "
                                        </div>
                                    </div>
                                </div>
                            ";
        }
        // line 337
        yield "                        </div><!-- #main-content -->

                        ";
        // line 339
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 339, $this->source); })())) {
            // line 340
            yield "</form><!-- #main-form -->";
        }
        // line 342
        yield "                </main><!-- #main -->
            </div><!-- #main-container -->

            <footer id=\"global-footer\">
                ";
        // line 346
        if ((isset($context["trialInfo"]) || array_key_exists("trialInfo", $context) ? $context["trialInfo"] : (function () { throw new RuntimeError('Variable "trialInfo" does not exist.', 346, $this->source); })())) {
            // line 347
            yield "                    <div id=\"trial-info\" class=\"readable\">
                        <span>
                            ";
            // line 349
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["trialInfo"]) || array_key_exists("trialInfo", $context) ? $context["trialInfo"] : (function () { throw new RuntimeError('Variable "trialInfo" does not exist.', 349, $this->source); })()), "message", [], "any", false, false, false, 349), "html", null, true);
            yield "
                            ";
            // line 350
            $context["linkText"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Buy now", "app");
            // line 351
            yield "                            ";
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["class" => "go", "href" => craft\helpers\Template::attribute($this->env, $this->source,             // line 353
(isset($context["trialInfo"]) || array_key_exists("trialInfo", $context) ? $context["trialInfo"] : (function () { throw new RuntimeError('Variable "trialInfo" does not exist.', 353, $this->source); })()), "cartUrl", [], "any", false, false, false, 353), "target" => "_blank", "text" =>             // line 355
(isset($context["linkText"]) || array_key_exists("linkText", $context) ? $context["linkText"] : (function () { throw new RuntimeError('Variable "linkText" does not exist.', 355, $this->source); })()), "aria" => ["label" =>             // line 356
(isset($context["linkText"]) || array_key_exists("linkText", $context) ? $context["linkText"] : (function () { throw new RuntimeError('Variable "linkText" does not exist.', 356, $this->source); })())]]);
            // line 357
            yield "
                        </span>
                    </div>
                ";
        }
        // line 361
        yield "                <div id=\"app-info\">
                    ";
        // line 362
        $context["fullEditionName"] = $this->extensions['craft\web\twig\Extension']->translateFilter("{edition} edition", "app", ["edition" => (isset($context["editionName"]) || array_key_exists("editionName", $context) ? $context["editionName"] : (function () { throw new RuntimeError('Variable "editionName" does not exist.', 362, $this->source); })())]);
        // line 363
        yield "                    <span class=\"flex items-center\">
                        <span lang=\"en\" class=\"flex items-center\">
                            Craft CMS
                            <span id=\"edition-logo\" title=\"";
        // line 366
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["fullEditionName"]) || array_key_exists("fullEditionName", $context) ? $context["fullEditionName"] : (function () { throw new RuntimeError('Variable "fullEditionName" does not exist.', 366, $this->source); })()), "html", null, true);
        yield "\">
                                <span aria-hidden=\"true\">";
        // line 367
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["editionName"]) || array_key_exists("editionName", $context) ? $context["editionName"] : (function () { throw new RuntimeError('Variable "editionName" does not exist.', 367, $this->source); })()), "html", null, true);
        yield "</span>
                                <span class=\"visually-hidden\">";
        // line 368
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["fullEditionName"]) || array_key_exists("fullEditionName", $context) ? $context["fullEditionName"] : (function () { throw new RuntimeError('Variable "fullEditionName" does not exist.', 368, $this->source); })()), "html", null, true);
        yield "</span>
                            </span>
                        </span>
                        ";
        // line 371
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 371, $this->source); })()), "app", [], "any", false, false, false, 371), "version", [], "any", false, false, false, 371), "html", null, true);
        yield "
                    </span>
                    ";
        // line 373
        if (((isset($context["canUpgradeEdition"]) || array_key_exists("canUpgradeEdition", $context) ? $context["canUpgradeEdition"] : (function () { throw new RuntimeError('Variable "canUpgradeEdition" does not exist.', 373, $this->source); })()) &&  !(isset($context["isTrial"]) || array_key_exists("isTrial", $context) ? $context["isTrial"] : (function () { throw new RuntimeError('Variable "isTrial" does not exist.', 373, $this->source); })()))) {
            // line 374
            yield "                        ";
            $context["linkText"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Upgrade to Craft Pro", "app");
            // line 375
            yield "                        <span>
                            <a
                                class=\"go\"
                                href=\"";
            // line 378
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("plugin-store/upgrade-craft"), "html", null, true);
            yield "\"
                                aria-label=\"";
            // line 379
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["linkText"]) || array_key_exists("linkText", $context) ? $context["linkText"] : (function () { throw new RuntimeError('Variable "linkText" does not exist.', 379, $this->source); })()), "html", null, true);
            yield "\"
                            >";
            // line 380
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["linkText"]) || array_key_exists("linkText", $context) ? $context["linkText"] : (function () { throw new RuntimeError('Variable "linkText" does not exist.', 380, $this->source); })()), "html", null, true);
            yield "</a>
                        </span>
                    ";
        }
        // line 383
        yield "                </div>
            </footer>

        </div><!-- #page-container -->
    </div><!-- #global-container -->
";
        craft\helpers\Template::endProfile("block", "body");
        yield from [];
    }

    // line 208
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_mainFormAttributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "mainFormAttributes");
        yield craft\helpers\Html::renderTagAttributes((isset($context["mainFormAttributes"]) || array_key_exists("mainFormAttributes", $context) ? $context["mainFormAttributes"] : (function () { throw new RuntimeError('Variable "mainFormAttributes" does not exist.', 208, $this->source); })()));
        craft\helpers\Template::endProfile("block", "mainFormAttributes");
        yield from [];
    }

    // line 215
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "header");
        // line 216
        yield "                                        <div id=\"page-title\" class=\"";
        if ((isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 216, $this->source); })())) {
            yield " has-toolbar";
        }
        yield "\">
                                            ";
        // line 217
        yield from $this->unwrap()->yieldBlock('pageTitle', $context, $blocks);
        // line 223
        yield "                                        </div>
                                        ";
        // line 224
        if ((isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 224, $this->source); })())) {
            // line 225
            yield "                                            <div id=\"toolbar\" class=\"flex\">
                                                ";
            // line 226
            yield (isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 226, $this->source); })());
            yield "
                                            </div>
                                        ";
        }
        // line 229
        yield "                                        ";
        if (((((isset($context["actionButton"]) || array_key_exists("actionButton", $context) ? $context["actionButton"] : (function () { throw new RuntimeError('Variable "actionButton" does not exist.', 229, $this->source); })()) || (isset($context["additionalButtons"]) || array_key_exists("additionalButtons", $context) ? $context["additionalButtons"] : (function () { throw new RuntimeError('Variable "additionalButtons" does not exist.', 229, $this->source); })())) || (isset($context["actionMenu"]) || array_key_exists("actionMenu", $context) ? $context["actionMenu"] : (function () { throw new RuntimeError('Variable "actionMenu" does not exist.', 229, $this->source); })())) || (isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 229, $this->source); })()))) {
            // line 230
            yield "                                            <div id=\"action-buttons\" class=\"flex\">
                                                ";
            // line 231
            yield (isset($context["additionalButtons"]) || array_key_exists("additionalButtons", $context) ? $context["additionalButtons"] : (function () { throw new RuntimeError('Variable "additionalButtons" does not exist.', 231, $this->source); })());
            yield "
                                                ";
            // line 232
            yield (isset($context["actionButton"]) || array_key_exists("actionButton", $context) ? $context["actionButton"] : (function () { throw new RuntimeError('Variable "actionButton" does not exist.', 232, $this->source); })());
            yield "
                                                ";
            // line 233
            yield (isset($context["actionMenu"]) || array_key_exists("actionMenu", $context) ? $context["actionMenu"] : (function () { throw new RuntimeError('Variable "actionMenu" does not exist.', 233, $this->source); })());
            yield "
                                            </div>
                                        ";
        }
        // line 236
        yield "                                    ";
        craft\helpers\Template::endProfile("block", "header");
        yield from [];
    }

    // line 217
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_pageTitle(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "pageTitle");
        // line 218
        yield "                                                ";
        if ((array_key_exists("title", $context) && $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 218, $this->source); })())))) {
            // line 219
            yield "                                                    <h1 id=\"page-heading\" class=\"screen-title\" title=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 219, $this->source); })()), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 219, $this->source); })()), "html", null, true);
            yield "</h1>
                                                ";
        }
        // line 221
        yield "                                                <div id=\"revision-indicators\"></div>
                                            ";
        craft\helpers\Template::endProfile("block", "pageTitle");
        yield from [];
    }

    // line 266
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 267
        yield "                                        <div class=\"content-grid__main\">
                                            ";
        // line 268
        if ( !Twig\Extension\CoreExtension::testEmpty((isset($context["errorSummary"]) || array_key_exists("errorSummary", $context) ? $context["errorSummary"] : (function () { throw new RuntimeError('Variable "errorSummary" does not exist.', 268, $this->source); })()))) {
            // line 269
            yield "                                                ";
            yield ((array_key_exists("errorSummary", $context)) ? ((isset($context["errorSummary"]) || array_key_exists("errorSummary", $context) ? $context["errorSummary"] : (function () { throw new RuntimeError('Variable "errorSummary" does not exist.', 269, $this->source); })())) : (""));
            yield "
                                            ";
        }
        // line 271
        yield "
                                            <div id=\"content\" class=\"content-pane\">
                                                ";
        // line 273
        if (((isset($context["contentNotice"]) || array_key_exists("contentNotice", $context) ? $context["contentNotice"] : (function () { throw new RuntimeError('Variable "contentNotice" does not exist.', 273, $this->source); })()) || (isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 273, $this->source); })()))) {
            // line 274
            yield "                                                    <header id=\"content-header\" class=\"pane-header\">
                                                        ";
            // line 275
            yield (((isset($context["contentNotice"]) || array_key_exists("contentNotice", $context) ? $context["contentNotice"] : (function () { throw new RuntimeError('Variable "contentNotice" does not exist.', 275, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->tagFunction("div", ["id" => "content-notice", "html" =>             // line 277
(isset($context["contentNotice"]) || array_key_exists("contentNotice", $context) ? $context["contentNotice"] : (function () { throw new RuntimeError('Variable "contentNotice" does not exist.', 277, $this->source); })()), "role" => "status"])) : (""));
            // line 279
            yield "
                                                        ";
            // line 280
            if ((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 280, $this->source); })())) {
                // line 281
                yield "                                                            ";
                yield from $this->loadTemplate("_includes/tabs", "_layouts/cp", 281)->unwrap()->yield(CoreExtension::merge($context, ["containerAttributes" => ["id" => "tabs"]]));
                // line 286
                yield "                                                        ";
            }
            // line 287
            yield "                                                    </header>
                                                ";
        }
        // line 289
        yield "
                                                ";
        // line 290
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 293
        yield "
                                                ";
        // line 295
        yield "                                                ";
        if ((isset($context["footer"]) || array_key_exists("footer", $context) ? $context["footer"] : (function () { throw new RuntimeError('Variable "footer" does not exist.', 295, $this->source); })())) {
            // line 296
            yield "                                                    <div id=\"footer\" class=\"flex flex-justify\">
                                                        ";
            // line 297
            yield (isset($context["footer"]) || array_key_exists("footer", $context) ? $context["footer"] : (function () { throw new RuntimeError('Variable "footer" does not exist.', 297, $this->source); })());
            yield "
                                                    </div>
                                                ";
        }
        // line 300
        yield "                                            </div>
                                        </div>

                                        ";
        // line 303
        if ( !Twig\Extension\CoreExtension::testEmpty((isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 303, $this->source); })()))) {
            // line 304
            yield "                                            <div class=\"content-grid__toggle\">
                                                ";
            // line 305
            yield from $this->loadTemplate("_layouts/cp", "_layouts/cp", 305, "1235591114")->unwrap()->yield(CoreExtension::toArray(["id" => "details-toggle", "controls" => "details-container", "persist" => true, "storageMode" => "cookies", "storageKey" => "sidebar-details"]));
            // line 322
            yield "                                            </div>
                                        ";
        }
        // line 324
        yield "                                    ";
        craft\helpers\Template::endProfile("block", "main");
        yield from [];
    }

    // line 290
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 291
        yield "                                                    ";
        yield ((array_key_exists("content", $context)) ? ((isset($context["content"]) || array_key_exists("content", $context) ? $context["content"] : (function () { throw new RuntimeError('Variable "content" does not exist.', 291, $this->source); })())) : (""));
        yield "
                                                ";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    // line 391
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 392
        yield "    ";
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 392, $this->source); })())) {
            // line 393
            yield "        <div class=\"btngroup\">
            ";
            // line 394
            yield from $this->unwrap()->yieldBlock('submitButton', $context, $blocks);
            // line 397
            yield "            ";
            if ((($context["formActions"]) ?? (false))) {
                // line 398
                yield "                <button
                    type=\"button\"
                    class=\"btn submit menubtn\"
                    aria-label=\"";
                // line 401
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("More actions", "app"), "html", null, true);
                yield "\"
                    aria-controls=\"form-action-menu\"
                    data-disclosure-trigger
                ></button>
                ";
                // line 405
                yield from $this->loadTemplate("_layouts/components/form-action-menu", "_layouts/cp", 405)->unwrap()->yield($context);
                // line 406
                yield "            ";
            }
            // line 407
            yield "        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 394
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_submitButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "submitButton");
        // line 395
        yield "                <button type=\"submit\" class=\"btn submit\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($context["submitButtonLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"))), "html", null, true);
        yield "</button>
            ";
        craft\helpers\Template::endProfile("block", "submitButton");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_layouts/cp";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  782 => 395,  774 => 394,  766 => 407,  763 => 406,  761 => 405,  754 => 401,  749 => 398,  746 => 397,  744 => 394,  741 => 393,  738 => 392,  730 => 391,  721 => 291,  713 => 290,  707 => 324,  703 => 322,  701 => 305,  698 => 304,  696 => 303,  691 => 300,  685 => 297,  682 => 296,  679 => 295,  676 => 293,  674 => 290,  671 => 289,  667 => 287,  664 => 286,  661 => 281,  659 => 280,  656 => 279,  654 => 277,  653 => 275,  650 => 274,  648 => 273,  644 => 271,  638 => 269,  636 => 268,  633 => 267,  625 => 266,  618 => 221,  610 => 219,  607 => 218,  599 => 217,  593 => 236,  587 => 233,  583 => 232,  579 => 231,  576 => 230,  573 => 229,  567 => 226,  564 => 225,  562 => 224,  559 => 223,  557 => 217,  550 => 216,  542 => 215,  529 => 208,  518 => 383,  512 => 380,  508 => 379,  504 => 378,  499 => 375,  496 => 374,  494 => 373,  489 => 371,  483 => 368,  479 => 367,  475 => 366,  470 => 363,  468 => 362,  465 => 361,  459 => 357,  457 => 356,  456 => 355,  455 => 353,  453 => 351,  451 => 350,  447 => 349,  443 => 347,  441 => 346,  435 => 342,  432 => 340,  430 => 339,  426 => 337,  418 => 332,  411 => 329,  409 => 328,  404 => 325,  402 => 266,  397 => 263,  394 => 261,  387 => 257,  380 => 253,  369 => 244,  366 => 243,  362 => 241,  359 => 240,  354 => 237,  352 => 215,  348 => 213,  346 => 212,  343 => 211,  340 => 209,  336 => 208,  334 => 207,  329 => 205,  316 => 197,  308 => 191,  302 => 189,  300 => 188,  296 => 187,  293 => 186,  287 => 184,  285 => 183,  281 => 182,  268 => 172,  262 => 169,  258 => 168,  251 => 163,  245 => 159,  241 => 158,  236 => 156,  229 => 151,  223 => 148,  220 => 147,  217 => 146,  215 => 145,  210 => 143,  207 => 142,  205 => 141,  201 => 139,  199 => 138,  195 => 136,  192 => 135,  184 => 134,  178 => 42,  173 => 414,  171 => 413,  169 => 412,  163 => 129,  161 => 128,  159 => 126,  157 => 124,  156 => 122,  155 => 121,  154 => 120,  153 => 119,  152 => 117,  151 => 116,  150 => 115,  149 => 114,  148 => 108,  146 => 106,  144 => 104,  143 => 101,  140 => 98,  138 => 97,  135 => 95,  133 => 94,  131 => 93,  129 => 92,  127 => 89,  126 => 88,  125 => 87,  123 => 85,  121 => 84,  119 => 83,  117 => 82,  115 => 81,  113 => 80,  111 => 79,  109 => 78,  107 => 77,  105 => 76,  103 => 75,  101 => 74,  99 => 72,  97 => 71,  95 => 70,  93 => 69,  91 => 68,  89 => 66,  87 => 64,  86 => 62,  85 => 60,  83 => 59,  78 => 55,  73 => 52,  71 => 51,  68 => 50,  66 => 49,  61 => 48,  59 => 47,  57 => 46,  55 => 45,  47 => 42,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
┌────────────────────────────────────────────────────────────────────────────────────┐
│                                 #global-container                                  │
│   ┌─────┐   ┌──────────────────────────────────────────────────────────────────┐   │
│   │     │   │                         #page-container                          │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                      #global-header                      │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │                                                                  │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                          #main                           │   │   │
│   │  #  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  g  │   │   │   │                #header-container                 │   │   │   │
│   │  l  │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │  o  │   │   │                                                          │   │   │
│   │  b  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  a  │   │   │   │                  #main-content                   │   │   │   │
│   │  l  │   │   │   │   ┌─────┐   ┌──────────────────────┐   ┌─────┐   │   │   │   │
│   │  -  │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │  s  │   │   │   │   │  #  │   │                      │   │  #  │   │   │   │   │
│   │  i  │   │   │   │   │  s  │   │                      │   │  d  │   │   │   │   │
│   │  d  │   │   │   │   │  i  │   │                      │   │  e  │   │   │   │   │
│   │  e  │   │   │   │   │  d  │   │       #content       │   │  t  │   │   │   │   │
│   │  b  │   │   │   │   │  e  │   │                      │   │  a  │   │   │   │   │
│   │  a  │   │   │   │   │  b  │   │                      │   │  i  │   │   │   │   │
│   │  r  │   │   │   │   │  a  │   │                      │   │  l  │   │   │   │   │
│   │     │   │   │   │   │  r  │   │                      │   │  s  │   │   │   │   │
│   │     │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │     │   │   │   │   └─────┘   └──────────────────────┘   └─────┘   │   │   │   │
│   │     │   │   │   │                                                  │   │   │   │
│   │     │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │     │   │   │                                                          │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                      #global-footer                      │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   └─────┘   └──────────────────────────────────────────────────────────────────┘   │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘
#}

{% extends '_layouts/basecp.twig' %}

{# The control panel only supports queue components that implement QueueInterface #}
{% set queue = craft.app.queue %}
{% js %}
{% if queue is instance of(\"craft\\\\queue\\\\QueueInterface\") %}
    Craft.cp.setJobInfo({{ queue.getJobInfo(100)|json_encode|raw }}, false);
    {% if queue.getHasReservedJobs() %}
        Craft.cp.trackJobProgress(true);
    {% elseif queue.getHasWaitingJobs() %}
        Craft.cp.runQueue();
    {% endif %}
{% else %}
    Craft.cp.enableQueue = false;
{% endif %}
{% endjs %}

{% set sidebarState = craft.app.request.rawCookies.value('Craft-' ~ craft.app.systemUid ~ ':sidebar') ?? 'expanded' %}
{% set bodyAttributes = {
    data: {
        sidebar: sidebarState,
    },
}|merge(bodyAttributes ?? {}, recursive=true) -%}

{% set fullPageForm = (fullPageForm is defined and fullPageForm) %}

{% set editionName = craft.app.edition.name %}
{% set canUpgradeEdition = craft.app.getCanUpgradeEdition() %}
{% set licensedEdition = craft.app.getLicensedEdition() %}
{% set isTrial = licensedEdition is not same as(null) and licensedEdition is not same as(CraftEdition) %}
{% set trialInfo = craft.cp.trialInfo() %}

{% set contentNotice = (contentNotice ?? block('contentNotice') ?? '')|trim %}
{% set sidebar = (sidebar ?? block('sidebar') ?? '')|trim %}
{% set toolbar = (toolbar ?? block('toolbar') ?? '')|trim %}
{% set actionButton = (actionButton ?? block('actionButton') ?? '')|trim %}
{% set additionalButtons = additionalButtons ?? null %}
{% set details = (details ?? block('details') ?? '')|trim %}
{% set footer = (footer ?? block('footer') ?? '')|trim %}
{% set crumbs = crumbs ?? null %}
{% set contextMenu = (contextMenu ?? block('contextMenu') ?? '')|trim %}
{% set actionMenu = actionMenu ?? '' %}
{% set tabs = (tabs ?? [])|length > 1 ? tabs : null %}
{% set errorSummary = errorSummary ?? null %}

{% set mainContentClasses = [
    sidebar ? 'has-sidebar',
    details ? 'has-details',
]|filter %}

{% set bodyClass = (bodyClass ?? [])|explodeClass %}
{% set showHeader = showHeader ?? true %}
{% if not showHeader %}
    {% set bodyClass = bodyClass|push('no-header') -%}
{% endif %}
{% if craft.app.hasModule('debug') %}
    {% set bodyClass = bodyClass|push('has-debug-toolbar') %}
{% endif %}

{% set mainAttributes = {
    id: 'main',
    role: 'main',
}|merge(mainAttributes ?? []) %}

{% set formActions = craft.cp.prepFormActions(formActions ?? null) %}

{% set mainFormAttributes = {
    id: 'main-form',
    method: 'post',
    'accept-charset': 'UTF-8',
    novalidate: true,
    data: {
        saveshortcut: saveShortcut ?? true,
        'saveshortcut-redirect': (saveShortcutRedirect ?? false) ? saveShortcutRedirect|hash : false,
        'saveshortcut-scroll': retainScrollOnSaveShortcut ?? false,
        actions: formActions ?? false,
        'confirm-unload': true,
        delta: view.getIsDeltaRegistrationActive(),
        'delta-names': view.getDeltaNames(),
        'initial-delta-values': view.getInitialDeltaValues(),
        'modified-delta-names': view.getModifiedDeltaNames()|merge(craft.app.request.getBodyParam('modifiedDeltaNames') ?? [])|unique|values,
    },
}|merge(mainFormAttributes ?? [], recursive=true) %}

{% set userPhoto = include('_layouts/components/header-photo.twig') %}

{% js at head %}
// Remove the hash so the browser doesn't scroll to it
window.LOCATION_HASH = document.location.hash ? decodeURIComponent(document.location.hash.substr(1)) : null;
history.replaceState(undefined, undefined, window.location.href.match(/^[^#]*/)[0]);
{% endjs %}

{% block body %}
    {% include '_layouts/components/skip-links' %}

    <div id=\"global-container\">
        {% include '_layouts/components/global-sidebar' %}

        <div id=\"page-container\">
            {% include '_layouts/components/alerts' %}

            <div id=\"global-header\" role=\"region\" aria-label=\"{{ 'My Account'|t('app') }}\">
                <div class=\"flex flex-nowrap gap-xs\">
                    {% include '_layouts/components/crumbs' %}
                    {% if contextMenu %}
                        <div id=\"context-menu-container\" class=\"context-menu-container\">
                            {{ contextMenu|raw }}
                        </div>
                    {% endif %}
                </div>
                <button
                    type=\"button\"
                    id=\"announcements-btn\"
                    class=\"btn hidden\"
                    title=\"{{ 'What’s New'|t('app') }}\"
                >
                    <span class=\"visually-hidden\">{{ 'What’s New'|t('app') }}</span>
                    {{ iconSvg('gift') }}
                </button>

                {# New account dropdown #}
                <div class=\"account-toggle-wrapper\">
                    <button
                        id=\"user-info\"
                        aria-controls=\"account-menu\"
                        class=\"btn menu-toggle\"
                        aria-label=\"{{ 'My Account'|t('app') }}\"
                        title=\"{{ 'My Account'|t('app') }}\"
                        data-disclosure-trigger
                    >
                        {{ userPhoto|raw }}
                    </button>
                    <div
                        id=\"account-menu\"
                        class=\"menu menu--disclosure\"
                        data-align=\"right\"
                        data-align-to=\".header-photo\"
                    >
                        <ul>
                            <li>
                                <a href=\"{{ url('myaccount') }}\" class=\"flex flex-nowrap\">
                                    {% if currentUser.photoId %}
                                        {{ userPhoto|raw }}
                                    {% endif %}
                                    <div class=\"flex-grow\">
                                        <div>{{ currentUser.username }}</div>
                                        {% if not craft.app.config.general.useEmailAsUsername %}
                                            <div class=\"smalltext\">{{ currentUser.email }}</div>
                                        {% endif %}
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <hr>
                        <ul>
                            <li><a href=\"{{ url('logout') }}\">{{ \"Sign out\"|t('app') }}</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div id=\"main-container\">

                <main {{ attr(mainAttributes) }}>

                    {% if fullPageForm -%}
                    <form {% block mainFormAttributes %}{{ attr(mainFormAttributes) }}{% endblock %}>
                        {{- csrfInput() }}
                        {%- endif %}

                        {% if showHeader %}
                            <div id=\"header-container\">
                                <header id=\"header\">
                                    {% block header %}
                                        <div id=\"page-title\" class=\"{% if toolbar %} has-toolbar{% endif %}\">
                                            {% block pageTitle %}
                                                {% if title is defined and title|length %}
                                                    <h1 id=\"page-heading\" class=\"screen-title\" title=\"{{ title }}\">{{ title }}</h1>
                                                {% endif %}
                                                <div id=\"revision-indicators\"></div>
                                            {% endblock %}
                                        </div>
                                        {% if toolbar %}
                                            <div id=\"toolbar\" class=\"flex\">
                                                {{ toolbar|raw }}
                                            </div>
                                        {% endif %}
                                        {% if actionButton or additionalButtons or actionMenu or details %}
                                            <div id=\"action-buttons\" class=\"flex\">
                                                {{ additionalButtons|raw }}
                                                {{ actionButton|raw }}
                                                {{ actionMenu|raw }}
                                            </div>
                                        {% endif %}
                                    {% endblock %}
                                </header><!-- #header -->
                            </div>
                        {% endif %}

                        <div id=\"main-content\" class=\"{{ mainContentClasses|join(' ') }}\">
                            {# sidebar #}
                            {% if sidebar %}
                                <div id=\"sidebar-container\">
                                    <div id=\"sidebar-toggle-container\">
                                        <button
                                                type=\"button\"
                                                id=\"sidebar-toggle\"
                                                class=\"btn menubtn chromeless\"
                                                aria-controls=\"sidebar-container\"
                                                aria-expanded=\"false\"
                                        >
                                            {{ 'Show sidebar'|t('app') }}
                                        </button>
                                    </div>
                                    <div id=\"sidebar\" class=\"sidebar\">
                                        {{ sidebar|raw }}
                                    </div>
                                </div>
                            {% endif %}

                            {# content-container #}
                            <div id=\"content-container\">
                                <div class=\"content-grid\">

                                    {% block main %}
                                        <div class=\"content-grid__main\">
                                            {% if errorSummary is not empty %}
                                                {{ errorSummary is defined ? errorSummary|raw }}
                                            {% endif %}

                                            <div id=\"content\" class=\"content-pane\">
                                                {% if contentNotice or tabs %}
                                                    <header id=\"content-header\" class=\"pane-header\">
                                                        {{ contentNotice ? tag('div', {
                                                            id: 'content-notice',
                                                            html: contentNotice,
                                                            role: 'status',
                                                        }) }}
                                                        {% if tabs %}
                                                            {% include \"_includes/tabs\" with {
                                                                containerAttributes: {
                                                                    id: 'tabs',
                                                                },
                                                            } %}
                                                        {% endif %}
                                                    </header>
                                                {% endif %}

                                                {% block content %}
                                                    {{ content is defined ? content|raw }}
                                                {% endblock %}

                                                {# footer #}
                                                {% if footer %}
                                                    <div id=\"footer\" class=\"flex flex-justify\">
                                                        {{ footer|raw }}
                                                    </div>
                                                {% endif %}
                                            </div>
                                        </div>

                                        {% if details is not empty %}
                                            <div class=\"content-grid__toggle\">
                                                {% embed '_includes/disclosure-toggle' with {
                                                    id: 'details-toggle',
                                                    controls: 'details-container',
                                                    persist: true,
                                                    storageMode: 'cookies',
                                                    storageKey: 'sidebar-details',
                                                } only %}
                                                    {% block content %}
                                                        <span class=\"details-toggle__inner\">
                                                            <span
                                                                aria-hidden=\"true\"
                                                                class=\"cp-icon\"
                                                            >{{ iconSvg('angle-right') }}</span>
                                                            <span class=\"visually-hidden\">{{ 'Toggle details sidebar'|t('app') }}</span>
                                                        </span>
                                                    {% endblock %}
                                                {% endembed %}
                                            </div>
                                        {% endif %}
                                    {% endblock %}
                                </div>
                            </div><!-- #content-container -->

                            {% if details is not empty %}
                                <div id=\"details-container\" data-state=\"{{  craft.app.request.rawCookies.value('Craft-' ~ craft.app.systemUid ~  ':sidebar-details')}}\">
                                    <div id=\"details\">
                                        <div class=\"details\">
                                            {{ details|raw }}
                                        </div>
                                    </div>
                                </div>
                            {% endif %}
                        </div><!-- #main-content -->

                        {% if fullPageForm -%}
                    </form><!-- #main-form -->
                    {%- endif %}
                </main><!-- #main -->
            </div><!-- #main-container -->

            <footer id=\"global-footer\">
                {% if trialInfo %}
                    <div id=\"trial-info\" class=\"readable\">
                        <span>
                            {{ trialInfo.message }}
                            {% set linkText = 'Buy now'|t('app') %}
                            {{ tag('a', {
                                class: 'go',
                                href: trialInfo.cartUrl,
                                target: '_blank',
                                text: linkText,
                                aria: {label: linkText},
                            }) }}
                        </span>
                    </div>
                {% endif %}
                <div id=\"app-info\">
                    {% set fullEditionName = '{edition} edition'|t('app', {edition: editionName}) %}
                    <span class=\"flex items-center\">
                        <span lang=\"en\" class=\"flex items-center\">
                            Craft CMS
                            <span id=\"edition-logo\" title=\"{{ fullEditionName }}\">
                                <span aria-hidden=\"true\">{{ editionName }}</span>
                                <span class=\"visually-hidden\">{{ fullEditionName }}</span>
                            </span>
                        </span>
                        {{ craft.app.version }}
                    </span>
                    {% if canUpgradeEdition and not isTrial %}
                        {% set linkText = 'Upgrade to Craft Pro'|t('app') %}
                        <span>
                            <a
                                class=\"go\"
                                href=\"{{ url('plugin-store/upgrade-craft') }}\"
                                aria-label=\"{{ linkText }}\"
                            >{{ linkText }}</a>
                        </span>
                    {% endif %}
                </div>
            </footer>

        </div><!-- #page-container -->
    </div><!-- #global-container -->
{% endblock %}


{% block actionButton %}
    {% if fullPageForm %}
        <div class=\"btngroup\">
            {% block submitButton %}
                <button type=\"submit\" class=\"btn submit\">{{ submitButtonLabel ?? 'Save'|t('app') }}</button>
            {% endblock %}
            {% if formActions ?? false %}
                <button
                    type=\"button\"
                    class=\"btn submit menubtn\"
                    aria-label=\"{{ 'More actions'|t('app') }}\"
                    aria-controls=\"form-action-menu\"
                    data-disclosure-trigger
                ></button>
                {% include '_layouts/components/form-action-menu' %}
            {% endif %}
        </div>
    {% endif %}
{% endblock %}


{% if currentUser.can('performUpdates') and not craft.app.updates.getIsUpdateInfoCached() %}
    {% js %}
    Craft.cp.checkForUpdates();
    {% endjs %}
{% endif %}
", "_layouts/cp", "/var/www/html/vendor/craftcms/cms/src/templates/_layouts/cp.twig");
    }
}


/* _layouts/cp */
class __TwigTemplate_4ac5e4f618e7bd177d3bc541b29aa8a7___1235591114 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 305
        return "_includes/disclosure-toggle";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/cp");
        $this->parent = $this->loadTemplate("_includes/disclosure-toggle", "_layouts/cp", 305);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_layouts/cp");
    }

    // line 312
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 313
        yield "                                                        <span class=\"details-toggle__inner\">
                                                            <span
                                                                aria-hidden=\"true\"
                                                                class=\"cp-icon\"
                                                            >";
        // line 317
        yield craft\helpers\Cp::iconSvg("angle-right");
        yield "</span>
                                                            <span class=\"visually-hidden\">";
        // line 318
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Toggle details sidebar", "app"), "html", null, true);
        yield "</span>
                                                        </span>
                                                    ";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_layouts/cp";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1291 => 318,  1287 => 317,  1281 => 313,  1273 => 312,  1260 => 305,  782 => 395,  774 => 394,  766 => 407,  763 => 406,  761 => 405,  754 => 401,  749 => 398,  746 => 397,  744 => 394,  741 => 393,  738 => 392,  730 => 391,  721 => 291,  713 => 290,  707 => 324,  703 => 322,  701 => 305,  698 => 304,  696 => 303,  691 => 300,  685 => 297,  682 => 296,  679 => 295,  676 => 293,  674 => 290,  671 => 289,  667 => 287,  664 => 286,  661 => 281,  659 => 280,  656 => 279,  654 => 277,  653 => 275,  650 => 274,  648 => 273,  644 => 271,  638 => 269,  636 => 268,  633 => 267,  625 => 266,  618 => 221,  610 => 219,  607 => 218,  599 => 217,  593 => 236,  587 => 233,  583 => 232,  579 => 231,  576 => 230,  573 => 229,  567 => 226,  564 => 225,  562 => 224,  559 => 223,  557 => 217,  550 => 216,  542 => 215,  529 => 208,  518 => 383,  512 => 380,  508 => 379,  504 => 378,  499 => 375,  496 => 374,  494 => 373,  489 => 371,  483 => 368,  479 => 367,  475 => 366,  470 => 363,  468 => 362,  465 => 361,  459 => 357,  457 => 356,  456 => 355,  455 => 353,  453 => 351,  451 => 350,  447 => 349,  443 => 347,  441 => 346,  435 => 342,  432 => 340,  430 => 339,  426 => 337,  418 => 332,  411 => 329,  409 => 328,  404 => 325,  402 => 266,  397 => 263,  394 => 261,  387 => 257,  380 => 253,  369 => 244,  366 => 243,  362 => 241,  359 => 240,  354 => 237,  352 => 215,  348 => 213,  346 => 212,  343 => 211,  340 => 209,  336 => 208,  334 => 207,  329 => 205,  316 => 197,  308 => 191,  302 => 189,  300 => 188,  296 => 187,  293 => 186,  287 => 184,  285 => 183,  281 => 182,  268 => 172,  262 => 169,  258 => 168,  251 => 163,  245 => 159,  241 => 158,  236 => 156,  229 => 151,  223 => 148,  220 => 147,  217 => 146,  215 => 145,  210 => 143,  207 => 142,  205 => 141,  201 => 139,  199 => 138,  195 => 136,  192 => 135,  184 => 134,  178 => 42,  173 => 414,  171 => 413,  169 => 412,  163 => 129,  161 => 128,  159 => 126,  157 => 124,  156 => 122,  155 => 121,  154 => 120,  153 => 119,  152 => 117,  151 => 116,  150 => 115,  149 => 114,  148 => 108,  146 => 106,  144 => 104,  143 => 101,  140 => 98,  138 => 97,  135 => 95,  133 => 94,  131 => 93,  129 => 92,  127 => 89,  126 => 88,  125 => 87,  123 => 85,  121 => 84,  119 => 83,  117 => 82,  115 => 81,  113 => 80,  111 => 79,  109 => 78,  107 => 77,  105 => 76,  103 => 75,  101 => 74,  99 => 72,  97 => 71,  95 => 70,  93 => 69,  91 => 68,  89 => 66,  87 => 64,  86 => 62,  85 => 60,  83 => 59,  78 => 55,  73 => 52,  71 => 51,  68 => 50,  66 => 49,  61 => 48,  59 => 47,  57 => 46,  55 => 45,  47 => 42,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{#
┌────────────────────────────────────────────────────────────────────────────────────┐
│                                 #global-container                                  │
│   ┌─────┐   ┌──────────────────────────────────────────────────────────────────┐   │
│   │     │   │                         #page-container                          │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                      #global-header                      │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │                                                                  │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                          #main                           │   │   │
│   │  #  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  g  │   │   │   │                #header-container                 │   │   │   │
│   │  l  │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │  o  │   │   │                                                          │   │   │
│   │  b  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  a  │   │   │   │                  #main-content                   │   │   │   │
│   │  l  │   │   │   │   ┌─────┐   ┌──────────────────────┐   ┌─────┐   │   │   │   │
│   │  -  │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │  s  │   │   │   │   │  #  │   │                      │   │  #  │   │   │   │   │
│   │  i  │   │   │   │   │  s  │   │                      │   │  d  │   │   │   │   │
│   │  d  │   │   │   │   │  i  │   │                      │   │  e  │   │   │   │   │
│   │  e  │   │   │   │   │  d  │   │       #content       │   │  t  │   │   │   │   │
│   │  b  │   │   │   │   │  e  │   │                      │   │  a  │   │   │   │   │
│   │  a  │   │   │   │   │  b  │   │                      │   │  i  │   │   │   │   │
│   │  r  │   │   │   │   │  a  │   │                      │   │  l  │   │   │   │   │
│   │     │   │   │   │   │  r  │   │                      │   │  s  │   │   │   │   │
│   │     │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │     │   │   │   │   └─────┘   └──────────────────────┘   └─────┘   │   │   │   │
│   │     │   │   │   │                                                  │   │   │   │
│   │     │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │     │   │   │                                                          │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                      #global-footer                      │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   └─────┘   └──────────────────────────────────────────────────────────────────┘   │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘
#}

{% extends '_layouts/basecp.twig' %}

{# The control panel only supports queue components that implement QueueInterface #}
{% set queue = craft.app.queue %}
{% js %}
{% if queue is instance of(\"craft\\\\queue\\\\QueueInterface\") %}
    Craft.cp.setJobInfo({{ queue.getJobInfo(100)|json_encode|raw }}, false);
    {% if queue.getHasReservedJobs() %}
        Craft.cp.trackJobProgress(true);
    {% elseif queue.getHasWaitingJobs() %}
        Craft.cp.runQueue();
    {% endif %}
{% else %}
    Craft.cp.enableQueue = false;
{% endif %}
{% endjs %}

{% set sidebarState = craft.app.request.rawCookies.value('Craft-' ~ craft.app.systemUid ~ ':sidebar') ?? 'expanded' %}
{% set bodyAttributes = {
    data: {
        sidebar: sidebarState,
    },
}|merge(bodyAttributes ?? {}, recursive=true) -%}

{% set fullPageForm = (fullPageForm is defined and fullPageForm) %}

{% set editionName = craft.app.edition.name %}
{% set canUpgradeEdition = craft.app.getCanUpgradeEdition() %}
{% set licensedEdition = craft.app.getLicensedEdition() %}
{% set isTrial = licensedEdition is not same as(null) and licensedEdition is not same as(CraftEdition) %}
{% set trialInfo = craft.cp.trialInfo() %}

{% set contentNotice = (contentNotice ?? block('contentNotice') ?? '')|trim %}
{% set sidebar = (sidebar ?? block('sidebar') ?? '')|trim %}
{% set toolbar = (toolbar ?? block('toolbar') ?? '')|trim %}
{% set actionButton = (actionButton ?? block('actionButton') ?? '')|trim %}
{% set additionalButtons = additionalButtons ?? null %}
{% set details = (details ?? block('details') ?? '')|trim %}
{% set footer = (footer ?? block('footer') ?? '')|trim %}
{% set crumbs = crumbs ?? null %}
{% set contextMenu = (contextMenu ?? block('contextMenu') ?? '')|trim %}
{% set actionMenu = actionMenu ?? '' %}
{% set tabs = (tabs ?? [])|length > 1 ? tabs : null %}
{% set errorSummary = errorSummary ?? null %}

{% set mainContentClasses = [
    sidebar ? 'has-sidebar',
    details ? 'has-details',
]|filter %}

{% set bodyClass = (bodyClass ?? [])|explodeClass %}
{% set showHeader = showHeader ?? true %}
{% if not showHeader %}
    {% set bodyClass = bodyClass|push('no-header') -%}
{% endif %}
{% if craft.app.hasModule('debug') %}
    {% set bodyClass = bodyClass|push('has-debug-toolbar') %}
{% endif %}

{% set mainAttributes = {
    id: 'main',
    role: 'main',
}|merge(mainAttributes ?? []) %}

{% set formActions = craft.cp.prepFormActions(formActions ?? null) %}

{% set mainFormAttributes = {
    id: 'main-form',
    method: 'post',
    'accept-charset': 'UTF-8',
    novalidate: true,
    data: {
        saveshortcut: saveShortcut ?? true,
        'saveshortcut-redirect': (saveShortcutRedirect ?? false) ? saveShortcutRedirect|hash : false,
        'saveshortcut-scroll': retainScrollOnSaveShortcut ?? false,
        actions: formActions ?? false,
        'confirm-unload': true,
        delta: view.getIsDeltaRegistrationActive(),
        'delta-names': view.getDeltaNames(),
        'initial-delta-values': view.getInitialDeltaValues(),
        'modified-delta-names': view.getModifiedDeltaNames()|merge(craft.app.request.getBodyParam('modifiedDeltaNames') ?? [])|unique|values,
    },
}|merge(mainFormAttributes ?? [], recursive=true) %}

{% set userPhoto = include('_layouts/components/header-photo.twig') %}

{% js at head %}
// Remove the hash so the browser doesn't scroll to it
window.LOCATION_HASH = document.location.hash ? decodeURIComponent(document.location.hash.substr(1)) : null;
history.replaceState(undefined, undefined, window.location.href.match(/^[^#]*/)[0]);
{% endjs %}

{% block body %}
    {% include '_layouts/components/skip-links' %}

    <div id=\"global-container\">
        {% include '_layouts/components/global-sidebar' %}

        <div id=\"page-container\">
            {% include '_layouts/components/alerts' %}

            <div id=\"global-header\" role=\"region\" aria-label=\"{{ 'My Account'|t('app') }}\">
                <div class=\"flex flex-nowrap gap-xs\">
                    {% include '_layouts/components/crumbs' %}
                    {% if contextMenu %}
                        <div id=\"context-menu-container\" class=\"context-menu-container\">
                            {{ contextMenu|raw }}
                        </div>
                    {% endif %}
                </div>
                <button
                    type=\"button\"
                    id=\"announcements-btn\"
                    class=\"btn hidden\"
                    title=\"{{ 'What’s New'|t('app') }}\"
                >
                    <span class=\"visually-hidden\">{{ 'What’s New'|t('app') }}</span>
                    {{ iconSvg('gift') }}
                </button>

                {# New account dropdown #}
                <div class=\"account-toggle-wrapper\">
                    <button
                        id=\"user-info\"
                        aria-controls=\"account-menu\"
                        class=\"btn menu-toggle\"
                        aria-label=\"{{ 'My Account'|t('app') }}\"
                        title=\"{{ 'My Account'|t('app') }}\"
                        data-disclosure-trigger
                    >
                        {{ userPhoto|raw }}
                    </button>
                    <div
                        id=\"account-menu\"
                        class=\"menu menu--disclosure\"
                        data-align=\"right\"
                        data-align-to=\".header-photo\"
                    >
                        <ul>
                            <li>
                                <a href=\"{{ url('myaccount') }}\" class=\"flex flex-nowrap\">
                                    {% if currentUser.photoId %}
                                        {{ userPhoto|raw }}
                                    {% endif %}
                                    <div class=\"flex-grow\">
                                        <div>{{ currentUser.username }}</div>
                                        {% if not craft.app.config.general.useEmailAsUsername %}
                                            <div class=\"smalltext\">{{ currentUser.email }}</div>
                                        {% endif %}
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <hr>
                        <ul>
                            <li><a href=\"{{ url('logout') }}\">{{ \"Sign out\"|t('app') }}</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div id=\"main-container\">

                <main {{ attr(mainAttributes) }}>

                    {% if fullPageForm -%}
                    <form {% block mainFormAttributes %}{{ attr(mainFormAttributes) }}{% endblock %}>
                        {{- csrfInput() }}
                        {%- endif %}

                        {% if showHeader %}
                            <div id=\"header-container\">
                                <header id=\"header\">
                                    {% block header %}
                                        <div id=\"page-title\" class=\"{% if toolbar %} has-toolbar{% endif %}\">
                                            {% block pageTitle %}
                                                {% if title is defined and title|length %}
                                                    <h1 id=\"page-heading\" class=\"screen-title\" title=\"{{ title }}\">{{ title }}</h1>
                                                {% endif %}
                                                <div id=\"revision-indicators\"></div>
                                            {% endblock %}
                                        </div>
                                        {% if toolbar %}
                                            <div id=\"toolbar\" class=\"flex\">
                                                {{ toolbar|raw }}
                                            </div>
                                        {% endif %}
                                        {% if actionButton or additionalButtons or actionMenu or details %}
                                            <div id=\"action-buttons\" class=\"flex\">
                                                {{ additionalButtons|raw }}
                                                {{ actionButton|raw }}
                                                {{ actionMenu|raw }}
                                            </div>
                                        {% endif %}
                                    {% endblock %}
                                </header><!-- #header -->
                            </div>
                        {% endif %}

                        <div id=\"main-content\" class=\"{{ mainContentClasses|join(' ') }}\">
                            {# sidebar #}
                            {% if sidebar %}
                                <div id=\"sidebar-container\">
                                    <div id=\"sidebar-toggle-container\">
                                        <button
                                                type=\"button\"
                                                id=\"sidebar-toggle\"
                                                class=\"btn menubtn chromeless\"
                                                aria-controls=\"sidebar-container\"
                                                aria-expanded=\"false\"
                                        >
                                            {{ 'Show sidebar'|t('app') }}
                                        </button>
                                    </div>
                                    <div id=\"sidebar\" class=\"sidebar\">
                                        {{ sidebar|raw }}
                                    </div>
                                </div>
                            {% endif %}

                            {# content-container #}
                            <div id=\"content-container\">
                                <div class=\"content-grid\">

                                    {% block main %}
                                        <div class=\"content-grid__main\">
                                            {% if errorSummary is not empty %}
                                                {{ errorSummary is defined ? errorSummary|raw }}
                                            {% endif %}

                                            <div id=\"content\" class=\"content-pane\">
                                                {% if contentNotice or tabs %}
                                                    <header id=\"content-header\" class=\"pane-header\">
                                                        {{ contentNotice ? tag('div', {
                                                            id: 'content-notice',
                                                            html: contentNotice,
                                                            role: 'status',
                                                        }) }}
                                                        {% if tabs %}
                                                            {% include \"_includes/tabs\" with {
                                                                containerAttributes: {
                                                                    id: 'tabs',
                                                                },
                                                            } %}
                                                        {% endif %}
                                                    </header>
                                                {% endif %}

                                                {% block content %}
                                                    {{ content is defined ? content|raw }}
                                                {% endblock %}

                                                {# footer #}
                                                {% if footer %}
                                                    <div id=\"footer\" class=\"flex flex-justify\">
                                                        {{ footer|raw }}
                                                    </div>
                                                {% endif %}
                                            </div>
                                        </div>

                                        {% if details is not empty %}
                                            <div class=\"content-grid__toggle\">
                                                {% embed '_includes/disclosure-toggle' with {
                                                    id: 'details-toggle',
                                                    controls: 'details-container',
                                                    persist: true,
                                                    storageMode: 'cookies',
                                                    storageKey: 'sidebar-details',
                                                } only %}
                                                    {% block content %}
                                                        <span class=\"details-toggle__inner\">
                                                            <span
                                                                aria-hidden=\"true\"
                                                                class=\"cp-icon\"
                                                            >{{ iconSvg('angle-right') }}</span>
                                                            <span class=\"visually-hidden\">{{ 'Toggle details sidebar'|t('app') }}</span>
                                                        </span>
                                                    {% endblock %}
                                                {% endembed %}
                                            </div>
                                        {% endif %}
                                    {% endblock %}
                                </div>
                            </div><!-- #content-container -->

                            {% if details is not empty %}
                                <div id=\"details-container\" data-state=\"{{  craft.app.request.rawCookies.value('Craft-' ~ craft.app.systemUid ~  ':sidebar-details')}}\">
                                    <div id=\"details\">
                                        <div class=\"details\">
                                            {{ details|raw }}
                                        </div>
                                    </div>
                                </div>
                            {% endif %}
                        </div><!-- #main-content -->

                        {% if fullPageForm -%}
                    </form><!-- #main-form -->
                    {%- endif %}
                </main><!-- #main -->
            </div><!-- #main-container -->

            <footer id=\"global-footer\">
                {% if trialInfo %}
                    <div id=\"trial-info\" class=\"readable\">
                        <span>
                            {{ trialInfo.message }}
                            {% set linkText = 'Buy now'|t('app') %}
                            {{ tag('a', {
                                class: 'go',
                                href: trialInfo.cartUrl,
                                target: '_blank',
                                text: linkText,
                                aria: {label: linkText},
                            }) }}
                        </span>
                    </div>
                {% endif %}
                <div id=\"app-info\">
                    {% set fullEditionName = '{edition} edition'|t('app', {edition: editionName}) %}
                    <span class=\"flex items-center\">
                        <span lang=\"en\" class=\"flex items-center\">
                            Craft CMS
                            <span id=\"edition-logo\" title=\"{{ fullEditionName }}\">
                                <span aria-hidden=\"true\">{{ editionName }}</span>
                                <span class=\"visually-hidden\">{{ fullEditionName }}</span>
                            </span>
                        </span>
                        {{ craft.app.version }}
                    </span>
                    {% if canUpgradeEdition and not isTrial %}
                        {% set linkText = 'Upgrade to Craft Pro'|t('app') %}
                        <span>
                            <a
                                class=\"go\"
                                href=\"{{ url('plugin-store/upgrade-craft') }}\"
                                aria-label=\"{{ linkText }}\"
                            >{{ linkText }}</a>
                        </span>
                    {% endif %}
                </div>
            </footer>

        </div><!-- #page-container -->
    </div><!-- #global-container -->
{% endblock %}


{% block actionButton %}
    {% if fullPageForm %}
        <div class=\"btngroup\">
            {% block submitButton %}
                <button type=\"submit\" class=\"btn submit\">{{ submitButtonLabel ?? 'Save'|t('app') }}</button>
            {% endblock %}
            {% if formActions ?? false %}
                <button
                    type=\"button\"
                    class=\"btn submit menubtn\"
                    aria-label=\"{{ 'More actions'|t('app') }}\"
                    aria-controls=\"form-action-menu\"
                    data-disclosure-trigger
                ></button>
                {% include '_layouts/components/form-action-menu' %}
            {% endif %}
        </div>
    {% endif %}
{% endblock %}


{% if currentUser.can('performUpdates') and not craft.app.updates.getIsUpdateInfoCached() %}
    {% js %}
    Craft.cp.checkForUpdates();
    {% endjs %}
{% endif %}
", "_layouts/cp", "/var/www/html/vendor/craftcms/cms/src/templates/_layouts/cp.twig");
    }
}
