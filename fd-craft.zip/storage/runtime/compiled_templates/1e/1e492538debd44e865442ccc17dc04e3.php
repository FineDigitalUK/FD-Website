<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/editableTable.twig */
class __TwigTemplate_ba2f398f0201bd10ca367ef5960601b8 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'tablecell' => [$this, 'block_tablecell'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/editableTable.twig");
        // line 1
        $context["static"] = (($context["static"]) ?? (false));
        // line 2
        $context["fullWidth"] = (($context["fullWidth"]) ?? (true));
        // line 3
        $context["cols"] = (($context["cols"]) ?? ([]));
        // line 4
        $context["rows"] = (($context["rows"]) ?? ([]));
        // line 5
        $context["initJs"] = ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 5, $this->source); })()) && (($context["initJs"]) ?? (true)));
        // line 6
        $context["minRows"] = (($context["minRows"]) ?? (null));
        // line 7
        $context["maxRows"] = (($context["maxRows"]) ?? (null));
        // line 8
        $context["describedBy"] = (($context["describedBy"]) ?? (null));
        // line 10
        $context["totalRows"] = $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 10, $this->source); })()));
        // line 11
        $context["staticRows"] = (((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 11, $this->source); })()) || (($context["staticRows"]) ?? (false))) || ((((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 11, $this->source); })()) == 1) && ((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 11, $this->source); })()) == 1)) && ((isset($context["totalRows"]) || array_key_exists("totalRows", $context) ? $context["totalRows"] : (function () { throw new RuntimeError('Variable "totalRows" does not exist.', 11, $this->source); })()) == 1)));
        // line 12
        $context["allowAdd"] = ((($context["allowAdd"]) ?? (false)) &&  !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 12, $this->source); })()));
        // line 13
        $context["allowReorder"] = ((($context["allowReorder"]) ?? (false)) &&  !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 13, $this->source); })()));
        // line 14
        $context["allowDelete"] = ((($context["allowDelete"]) ?? (false)) &&  !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 14, $this->source); })()));
        // line 15
        yield "
";
        // line 16
        $context["actionMenuItems"] = [["icon" => "arrow-up", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Move up", "app"), "attributes" => ["data" => ["action" => "moveUp"]]], ["icon" => "arrow-down", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Move down", "app"), "attributes" => ["data" => ["action" => "moveDown"]]]];
        // line 32
        yield "
";
        // line 33
        if ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 33, $this->source); })())) {
            // line 34
            yield "    ";
            yield craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 34, $this->source); })()), "");
            yield "
";
        }
        // line 36
        yield "
";
        // line 56
        yield "
";
        // line 57
        $context["tableAttributes"] = ["id" =>         // line 58
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 58, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["editable", ((        // line 61
(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 61, $this->source); })())) ? ("fullwidth") : ("")), ((        // line 62
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 62, $this->source); })())) ? ("static") : ("")), (((        // line 63
(isset($context["totalRows"]) || array_key_exists("totalRows", $context) ? $context["totalRows"] : (function () { throw new RuntimeError('Variable "totalRows" does not exist.', 63, $this->source); })()) == 0)) ? ("hidden") : (""))])];
        // line 67
        if (        $this->unwrap()->hasBlock("attr", $context, $blocks)) {
            // line 68
            $context["tableAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableAttributes"]) || array_key_exists("tableAttributes", $context) ? $context["tableAttributes"] : (function () { throw new RuntimeError('Variable "tableAttributes" does not exist.', 68, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 70
        yield "
";
        // line 71
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 71, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["col"]) {
            // line 72
            switch (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", [], "any", false, false, false, 72)) {
                case "time":
                {
                    // line 74
                    craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 74, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\timepicker\\TimepickerAsset"], "method", false, false, false, 74);
                    break;
                }
                case "template":
                {
                    // line 76
                    craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 76, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\vue\\VueAsset"], "method", false, false, false, 76);
                    break;
                }
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['col'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        yield "
<span role=\"status\" class=\"visually-hidden\" data-status-message></span>
";
        // line 81
        ob_start();
        // line 82
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 82, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["col"]) {
            // line 83
            yield "        <col>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['col'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 85
        yield "    ";
        if (((isset($context["allowDelete"]) || array_key_exists("allowDelete", $context) ? $context["allowDelete"] : (function () { throw new RuntimeError('Variable "allowDelete" does not exist.', 85, $this->source); })()) && (isset($context["allowReorder"]) || array_key_exists("allowReorder", $context) ? $context["allowReorder"] : (function () { throw new RuntimeError('Variable "allowReorder" does not exist.', 85, $this->source); })()))) {
            // line 86
            yield "        <colgroup span=\"2\"></colgroup>
    ";
        } else {
            // line 88
            yield "        ";
            if ((isset($context["allowDelete"]) || array_key_exists("allowDelete", $context) ? $context["allowDelete"] : (function () { throw new RuntimeError('Variable "allowDelete" does not exist.', 88, $this->source); })())) {
                yield "<col>";
            }
            // line 89
            yield "        ";
            if ((isset($context["allowReorder"]) || array_key_exists("allowReorder", $context) ? $context["allowReorder"] : (function () { throw new RuntimeError('Variable "allowReorder" does not exist.', 89, $this->source); })())) {
                yield "<col>";
            }
            // line 90
            yield "    ";
        }
        // line 91
        yield "    ";
        if ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, (isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 91, $this->source); })()), function ($__c__) use ($context, $macros) { $context["c"] = $__c__; return  !((((craft\helpers\Template::attribute($this->env, $this->source, ($context["c"] ?? null), "headingHtml", [], "any", true, true, false, 91) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["c"] ?? null), "headingHtml", [], "any", false, false, false, 91)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["c"] ?? null), "headingHtml", [], "any", false, false, false, 91)) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["c"] ?? null), "heading", [], "any", true, true, false, 91) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["c"] ?? null), "heading", [], "any", false, false, false, 91)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["c"] ?? null), "heading", [], "any", false, false, false, 91)) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["c"] ?? null), "info", [], "any", true, true, false, 91) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["c"] ?? null), "info", [], "any", false, false, false, 91)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["c"] ?? null), "info", [], "any", false, false, false, 91)) : ("")))))) === ""); }))) {
            // line 92
            yield "        <thead>
            <tr>
                ";
            // line 94
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 94, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["col"]) {
                // line 95
                yield "                    ";
                $context["columnHeadingId"] = (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 95, $this->source); })()) . "-heading-") . craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 95));
                // line 96
                yield "                    <th id=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["columnHeadingId"]) || array_key_exists("columnHeadingId", $context) ? $context["columnHeadingId"] : (function () { throw new RuntimeError('Variable "columnHeadingId" does not exist.', 96, $this->source); })()), "html", null, true);
                yield "\" scope=\"col\" class=\"";
                yield $this->getTemplateForMacro("macro_cellClass", $context, 96, $this->getSourceContext())->macro_cellClass(...[(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 96, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true, false, 96) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", false, false, false, 96)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", false, false, false, 96)) : ([]))]);
                yield "\">";
                // line 97
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "headingHtml", [], "any", true, true, false, 97)) {
                    // line 98
                    yield craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "headingHtml", [], "any", false, false, false, 98);
                } elseif ((((craft\helpers\Template::attribute($this->env, $this->source,                 // line 99
$context["col"], "heading", [], "any", true, true, false, 99) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", [], "any", false, false, false, 99)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", [], "any", false, false, false, 99)) : (false))) {
                    // line 100
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", [], "any", false, false, false, 100), "html", null, true);
                } else {
                    // line 102
                    yield "                            &nbsp;";
                }
                // line 104
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "info", [], "any", true, true, false, 104)) {
                    // line 105
                    yield "<span class=\"info";
                    if ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 105, $this->source); })())) {
                        yield " disabled";
                    }
                    yield "\"";
                    if ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 105, $this->source); })())) {
                        yield " disabled=\"\"";
                    }
                    yield ">";
                    yield $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "info", [], "any", false, false, false, 105));
                    yield "</span>";
                }
                // line 107
                yield "</th>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['col'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 109
            yield "                ";
            if (((isset($context["allowDelete"]) || array_key_exists("allowDelete", $context) ? $context["allowDelete"] : (function () { throw new RuntimeError('Variable "allowDelete" does not exist.', 109, $this->source); })()) || (isset($context["allowReorder"]) || array_key_exists("allowReorder", $context) ? $context["allowReorder"] : (function () { throw new RuntimeError('Variable "allowReorder" does not exist.', 109, $this->source); })()))) {
                // line 110
                yield "                    <th colspan=\"";
                yield ((( !(isset($context["allowDelete"]) || array_key_exists("allowDelete", $context) ? $context["allowDelete"] : (function () { throw new RuntimeError('Variable "allowDelete" does not exist.', 110, $this->source); })()) ||  !(isset($context["allowReorder"]) || array_key_exists("allowReorder", $context) ? $context["allowReorder"] : (function () { throw new RuntimeError('Variable "allowReorder" does not exist.', 110, $this->source); })()))) ? (1) : (2));
                yield "\" scope=\"colgroup\"><span class=\"visually-hidden\">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Row actions", "app"), "html", null, true);
                yield "</span></th>
                ";
            }
            // line 112
            yield "            </tr>
        </thead>
    ";
        }
        // line 115
        yield "    <tbody>
        ";
        // line 116
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 116, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["rowId"] => $context["row"]) {
            // line 117
            yield "            ";
            $context["rowNumber"] = craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 117);
            // line 118
            yield "            ";
            $context["rowName"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Row {index}", "app", ["index" => (isset($context["rowNumber"]) || array_key_exists("rowNumber", $context) ? $context["rowNumber"] : (function () { throw new RuntimeError('Variable "rowNumber" does not exist.', 118, $this->source); })())]);
            // line 119
            yield "            ";
            $context["actionBtnLabel"] = (((isset($context["rowName"]) || array_key_exists("rowName", $context) ? $context["rowName"] : (function () { throw new RuntimeError('Variable "rowName" does not exist.', 119, $this->source); })()) . " ") . $this->extensions['craft\web\twig\Extension']->translateFilter("Actions", "app"));
            // line 120
            yield "            <tr data-id=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["rowId"], "html", null, true);
            yield "\">
                ";
            // line 121
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 121, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["colId"] => $context["col"]) {
                // line 122
                yield "                    ";
                $context["cell"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["row"], $context["colId"], [], "array", true, true, false, 122)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["row"], $context["colId"], [], "array", false, false, false, 122)) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["defaultValues"] ?? null), $context["colId"], [], "array", true, true, false, 122) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["defaultValues"] ?? null), $context["colId"], [], "array", false, false, false, 122)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["defaultValues"] ?? null), $context["colId"], [], "array", false, false, false, 122)) : (null))));
                // line 123
                yield "                    ";
                $context["value"] = ((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "value", [], "any", true, true, false, 123)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new RuntimeError('Variable "cell" does not exist.', 123, $this->source); })()), "value", [], "any", false, false, false, 123)) : ((isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new RuntimeError('Variable "cell" does not exist.', 123, $this->source); })())));
                // line 124
                yield "                    ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", [], "any", false, false, false, 124) == "heading")) {
                    // line 125
                    yield "                        <th scope=\"row\" class=\"";
                    yield $this->getTemplateForMacro("macro_cellClass", $context, 125, $this->getSourceContext())->macro_cellClass(...[(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 125, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", true, true, false, 125) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", false, false, false, 125)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", false, false, false, 125)) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true, false, 125) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", false, false, false, 125)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", false, false, false, 125)) : ([]))))]);
                    yield "\"";
                    if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", true, true, false, 125) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", false, false, false, 125)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", false, false, false, 125)) : (false))) {
                        yield " width=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", false, false, false, 125), "html", null, true);
                        yield "\"";
                    }
                    yield ">";
                    yield (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 125, $this->source); })());
                    yield "</th>
                    ";
                } elseif ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 126
$context["col"], "type", [], "any", false, false, false, 126) == "html")) {
                    // line 127
                    yield "                        <td class=\"";
                    yield $this->getTemplateForMacro("macro_cellClass", $context, 127, $this->getSourceContext())->macro_cellClass(...[(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 127, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", true, true, false, 127) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", false, false, false, 127)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", false, false, false, 127)) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true, false, 127) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", false, false, false, 127)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", false, false, false, 127)) : ([]))))]);
                    yield "\"";
                    if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", true, true, false, 127) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", false, false, false, 127)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", false, false, false, 127)) : (false))) {
                        yield " width=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", false, false, false, 127), "html", null, true);
                        yield "\"";
                    }
                    yield ">";
                    yield (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 127, $this->source); })());
                    yield "</td>
                    ";
                } else {
                    // line 129
                    yield "                        ";
                    $context["headingId"] = (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 129, $this->source); })()) . "-heading-") . craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 129));
                    // line 130
                    yield "                        ";
                    $context["hasErrors"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [], "any", true, true, false, 130) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [], "any", false, false, false, 130)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [], "any", false, false, false, 130)) : (false));
                    // line 131
                    yield "                        ";
                    $context["cellName"] = ((((((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 131, $this->source); })()) . "[") . $context["rowId"]) . "][") . $context["colId"]) . "]");
                    // line 132
                    yield "                        ";
                    $context["isCode"] = ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "code", [], "any", true, true, false, 132) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "code", [], "any", false, false, false, 132)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "code", [], "any", false, false, false, 132)) : (false)) || (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", [], "any", false, false, false, 132) == "color"));
                    // line 133
                    yield "                        <td class=\"";
                    yield $this->getTemplateForMacro("macro_cellClass", $context, 133, $this->getSourceContext())->macro_cellClass(...[(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 133, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true, false, 133) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", false, false, false, 133)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", false, false, false, 133)) : ([]))]);
                    yield " ";
                    if ((isset($context["isCode"]) || array_key_exists("isCode", $context) ? $context["isCode"] : (function () { throw new RuntimeError('Variable "isCode" does not exist.', 133, $this->source); })())) {
                        yield "code";
                    }
                    yield " ";
                    if ((isset($context["hasErrors"]) || array_key_exists("hasErrors", $context) ? $context["hasErrors"] : (function () { throw new RuntimeError('Variable "hasErrors" does not exist.', 133, $this->source); })())) {
                        yield "error";
                    }
                    yield "\"";
                    if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", true, true, false, 133) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", false, false, false, 133)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", false, false, false, 133)) : (false))) {
                        yield " width=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", false, false, false, 133), "html", null, true);
                        yield "\"";
                    }
                    yield ">
                            ";
                    // line 134
                    yield from $this->unwrap()->yieldBlock('tablecell', $context, $blocks);
                    // line 246
                    yield "                        </td>
                    ";
                }
                // line 248
                yield "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['colId'], $context['col'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 249
            yield "                ";
            if ((isset($context["allowReorder"]) || array_key_exists("allowReorder", $context) ? $context["allowReorder"] : (function () { throw new RuntimeError('Variable "allowReorder" does not exist.', 249, $this->source); })())) {
                // line 250
                yield "<td class=\"thin action\">
                      <div class=\"flex flex-nowrap\">
                        <a class=\"move icon\" title=\"";
                // line 252
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                yield "\"></a>
";
                // line 253
                yield craft\helpers\Cp::disclosureMenu((isset($context["actionMenuItems"]) || array_key_exists("actionMenuItems", $context) ? $context["actionMenuItems"] : (function () { throw new RuntimeError('Variable "actionMenuItems" does not exist.', 253, $this->source); })()), ["buttonAttributes" => ["aria-label" =>                 // line 255
(isset($context["actionBtnLabel"]) || array_key_exists("actionBtnLabel", $context) ? $context["actionBtnLabel"] : (function () { throw new RuntimeError('Variable "actionBtnLabel" does not exist.', 255, $this->source); })()), "class" => ["action-btn"], "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("Actions", "app"), "data" => ["disclosure-trigger" => true]]]);
                // line 262
                yield "
                      </div>
                    </td>";
            }
            // line 266
            if ((isset($context["allowDelete"]) || array_key_exists("allowDelete", $context) ? $context["allowDelete"] : (function () { throw new RuntimeError('Variable "allowDelete" does not exist.', 266, $this->source); })())) {
                // line 267
                yield "<td class=\"thin action\">
                        ";
                // line 268
                yield $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["delete", "icon", (((                // line 272
(isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 272, $this->source); })()) && ((isset($context["totalRows"]) || array_key_exists("totalRows", $context) ? $context["totalRows"] : (function () { throw new RuntimeError('Variable "totalRows" does not exist.', 272, $this->source); })()) <= (isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 272, $this->source); })())))) ? ("disabled") : (null))]), "type" => "button", "disabled" => (                // line 275
(isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 275, $this->source); })()) && ((isset($context["totalRows"]) || array_key_exists("totalRows", $context) ? $context["totalRows"] : (function () { throw new RuntimeError('Variable "totalRows" does not exist.', 275, $this->source); })()) <= (isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 275, $this->source); })()))), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Delete row {index}", "app", ["index" =>                 // line 279
(isset($context["rowNumber"]) || array_key_exists("rowNumber", $context) ? $context["rowNumber"] : (function () { throw new RuntimeError('Variable "rowNumber" does not exist.', 279, $this->source); })())])]]);
                // line 282
                yield "
                    </td>";
            }
            // line 285
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((((craft\helpers\Template::attribute($this->env, $this->source, $context["row"], "hiddenInputs", [], "any", true, true, false, 285) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["row"], "hiddenInputs", [], "any", false, false, false, 285)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["row"], "hiddenInputs", [], "any", false, false, false, 285)) : ([])));
            foreach ($context['_seq'] as $context["inputName"] => $context["value"]) {
                // line 286
                yield "                    ";
                yield craft\helpers\Html::hiddenInput(((((((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 286, $this->source); })()) . "[") . $context["rowId"]) . "][") . $context["inputName"]) . "]"), $context["value"]);
                yield "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['inputName'], $context['value'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 288
            yield "            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['rowId'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 290
        yield "    </tbody>
";
        echo craft\helpers\Html::tag("table", ob_get_clean(),         // line 81
(isset($context["tableAttributes"]) || array_key_exists("tableAttributes", $context) ? $context["tableAttributes"] : (function () { throw new RuntimeError('Variable "tableAttributes" does not exist.', 81, $this->source); })()));
        // line 292
        yield "
";
        // line 293
        if ((isset($context["allowAdd"]) || array_key_exists("allowAdd", $context) ? $context["allowAdd"] : (function () { throw new RuntimeError('Variable "allowAdd" does not exist.', 293, $this->source); })())) {
            // line 294
            yield "    ";
            $context["buttonText"] = (($context["addRowLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Add a row", "app")));
            // line 295
            yield "    <button type=\"button\" class=\"btn dashed add icon\" aria-label=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["buttonText"]) || array_key_exists("buttonText", $context) ? $context["buttonText"] : (function () { throw new RuntimeError('Variable "buttonText" does not exist.', 295, $this->source); })()), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["buttonText"]) || array_key_exists("buttonText", $context) ? $context["buttonText"] : (function () { throw new RuntimeError('Variable "buttonText" does not exist.', 295, $this->source); })()), "html", null, true);
            yield "</button>
";
        }
        // line 297
        yield "
";
        // line 298
        if ((isset($context["initJs"]) || array_key_exists("initJs", $context) ? $context["initJs"] : (function () { throw new RuntimeError('Variable "initJs" does not exist.', 298, $this->source); })())) {
            // line 299
            yield "    ";
            $context["jsId"] = $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 299, $this->source); })())), "js");
            // line 300
            yield "    ";
            $context["jsName"] = $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputName')->getCallable()((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 300, $this->source); })())), "js");
            // line 301
            yield "    ";
            $context["jsCols"] = $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 301, $this->source); })()));
            // line 302
            yield "    ";
            $context["defaultValues"] = (($context["defaultValues"]) ?? (null));
            // line 303
            yield "    ";
            ob_start();
            // line 304
            yield "        new Craft.EditableTable(\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["jsId"]) || array_key_exists("jsId", $context) ? $context["jsId"] : (function () { throw new RuntimeError('Variable "jsId" does not exist.', 304, $this->source); })()), "html", null, true);
            yield "\", \"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["jsName"]) || array_key_exists("jsName", $context) ? $context["jsName"] : (function () { throw new RuntimeError('Variable "jsName" does not exist.', 304, $this->source); })()), "html", null, true);
            yield "\", ";
            yield (isset($context["jsCols"]) || array_key_exists("jsCols", $context) ? $context["jsCols"] : (function () { throw new RuntimeError('Variable "jsCols" does not exist.', 304, $this->source); })());
            yield ", {
            defaultValues: ";
            // line 305
            yield (((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new RuntimeError('Variable "defaultValues" does not exist.', 305, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new RuntimeError('Variable "defaultValues" does not exist.', 305, $this->source); })()))) : ("{}"));
            yield ",
            allowAdd: ";
            // line 306
            yield (((isset($context["allowAdd"]) || array_key_exists("allowAdd", $context) ? $context["allowAdd"] : (function () { throw new RuntimeError('Variable "allowAdd" does not exist.', 306, $this->source); })())) ? ("true") : ("false"));
            yield ",
            allowDelete: ";
            // line 307
            yield (((isset($context["allowDelete"]) || array_key_exists("allowDelete", $context) ? $context["allowDelete"] : (function () { throw new RuntimeError('Variable "allowDelete" does not exist.', 307, $this->source); })())) ? ("true") : ("false"));
            yield ",
            allowReorder: ";
            // line 308
            yield (((isset($context["allowReorder"]) || array_key_exists("allowReorder", $context) ? $context["allowReorder"] : (function () { throw new RuntimeError('Variable "allowReorder" does not exist.', 308, $this->source); })())) ? ("true") : ("false"));
            yield ",
            minRows: ";
            // line 309
            (((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 309, $this->source); })())) ? (yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 309, $this->source); })()), "html", null, true)) : (yield "null"));
            yield ",
            maxRows: ";
            // line 310
            (((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 310, $this->source); })())) ? (yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 310, $this->source); })()), "html", null, true)) : (yield "null"));
            yield "
        });
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/editableTable.twig");
        yield from [];
    }

    // line 134
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_tablecell(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "tablecell");
        // line 135
        switch (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 135, $this->source); })()), "type", [], "any", false, false, false, 135)) {
            case "checkbox":
            {
                // line 137
                yield "<div class=\"checkbox-wrapper\">
                                            ";
                // line 138
                yield from $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/editableTable.twig", 138)->unwrap()->yield(CoreExtension::toArray(["name" =>                 // line 139
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 139, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 140
($context["col"] ?? null), "value", [], "any", true, true, false, 140) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [], "any", false, false, false, 140)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [], "any", false, false, false, 140)) : (1)), "checked" =>  !Twig\Extension\CoreExtension::testEmpty(                // line 141
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 141, $this->source); })())), "disabled" =>                 // line 142
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 142, $this->source); })()), "labelledBy" =>                 // line 143
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 143, $this->source); })()), "describedBy" =>                 // line 144
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 144, $this->source); })())]));
                // line 146
                yield "                                        </div>";
                break;
            }
            case "icon":
            {
                // line 148
                yield from $this->loadTemplate("_includes/forms/iconPicker", "_includes/forms/editableTable.twig", 148)->unwrap()->yield(CoreExtension::toArray(["name" =>                 // line 149
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 149, $this->source); })()), "value" =>                 // line 150
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 150, $this->source); })()), "small" => true, "disabled" =>                 // line 152
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 152, $this->source); })()), "labelledBy" =>                 // line 153
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 153, $this->source); })()), "describedBy" =>                 // line 154
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 154, $this->source); })())]));
                break;
            }
            case "color":
            {
                // line 157
                yield from $this->loadTemplate("_includes/forms/color", "_includes/forms/editableTable.twig", 157)->unwrap()->yield(CoreExtension::toArray(["name" =>                 // line 158
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 158, $this->source); })()), "value" =>                 // line 159
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 159, $this->source); })()), "small" => true, "disabled" =>                 // line 161
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 161, $this->source); })()), "labelledBy" =>                 // line 162
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 162, $this->source); })()), "describedBy" =>                 // line 163
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 163, $this->source); })())]));
                break;
            }
            case "date":
            {
                // line 166
                yield from $this->loadTemplate("_includes/forms/date", "_includes/forms/editableTable.twig", 166)->unwrap()->yield(CoreExtension::toArray(["name" =>                 // line 167
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 167, $this->source); })()), "value" =>                 // line 168
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 168, $this->source); })()), "disabled" =>                 // line 169
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 169, $this->source); })()), "labelledBy" =>                 // line 170
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 170, $this->source); })()), "describedBy" =>                 // line 171
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 171, $this->source); })())]));
                break;
            }
            case "lightswitch":
            {
                // line 174
                yield from $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms/editableTable.twig", 174)->unwrap()->yield(CoreExtension::toArray(["name" =>                 // line 175
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 175, $this->source); })()), "on" =>                 // line 176
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 176, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 177
($context["col"] ?? null), "value", [], "any", true, true, false, 177) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [], "any", false, false, false, 177)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [], "any", false, false, false, 177)) : (1)), "small" => true, "disabled" =>                 // line 179
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 179, $this->source); })()), "labelledBy" =>                 // line 180
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 180, $this->source); })()), "describedBy" =>                 // line 181
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 181, $this->source); })())]));
                // line 183
                yield "                                    ";
                break;
            }
            case "select":
            {
                // line 184
                yield from $this->loadTemplate("_includes/forms/select", "_includes/forms/editableTable.twig", 184)->unwrap()->yield(CoreExtension::toArray(["class" => "small", "name" =>                 // line 186
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 186, $this->source); })()), "options" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 187
($context["cell"] ?? null), "options", [], "any", true, true, false, 187) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "options", [], "any", false, false, false, 187)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "options", [], "any", false, false, false, 187)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 187, $this->source); })()), "options", [], "any", false, false, false, 187))), "value" =>                 // line 188
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 188, $this->source); })()), "disabled" =>                 // line 189
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 189, $this->source); })()), "labelledBy" =>                 // line 190
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 190, $this->source); })()), "describedBy" =>                 // line 191
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 191, $this->source); })())]));
                break;
            }
            case "time":
            {
                // line 194
                yield from $this->loadTemplate("_includes/forms/time", "_includes/forms/editableTable.twig", 194)->unwrap()->yield(CoreExtension::toArray(["name" =>                 // line 195
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 195, $this->source); })()), "value" =>                 // line 196
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 196, $this->source); })()), "disabled" =>                 // line 197
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 197, $this->source); })()), "labelledBy" =>                 // line 198
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 198, $this->source); })()), "describedBy" =>                 // line 199
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 199, $this->source); })())]));
                break;
            }
            case "email":
            case "url":
            {
                // line 202
                yield from $this->loadTemplate("_includes/forms/text", "_includes/forms/editableTable.twig", 202)->unwrap()->yield(CoreExtension::toArray(["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 203
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 203, $this->source); })()), "type", [], "any", false, false, false, 203), "name" =>                 // line 204
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 204, $this->source); })()), "placeholder" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 205
($context["col"] ?? null), "placeholder", [], "any", true, true, false, 205) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [], "any", false, false, false, 205)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [], "any", false, false, false, 205)) : (null)), "value" =>                 // line 206
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 206, $this->source); })()), "disabled" =>                 // line 207
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 207, $this->source); })()), "labelledBy" =>                 // line 208
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 208, $this->source); })()), "describedBy" =>                 // line 209
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 209, $this->source); })())]));
                break;
            }
            case "autosuggest":
            case "template":
            {
                // line 212
                yield from $this->loadTemplate("_includes/forms/autosuggest", "_includes/forms/editableTable.twig", 212)->unwrap()->yield(CoreExtension::toArray(["name" =>                 // line 213
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 213, $this->source); })()), "suggestTemplates" => (craft\helpers\Template::attribute($this->env, $this->source,                 // line 214
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 214, $this->source); })()), "type", [], "any", false, false, false, 214) == "template"), "suggestEnvVars" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 215
($context["col"] ?? null), "suggestEnvVars", [], "any", true, true, false, 215) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "suggestEnvVars", [], "any", false, false, false, 215)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "suggestEnvVars", [], "any", false, false, false, 215)) : (false)), "suggestAliases" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 216
($context["col"] ?? null), "suggestAliases", [], "any", true, true, false, 216) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "suggestAliases", [], "any", false, false, false, 216)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "suggestAliases", [], "any", false, false, false, 216)) : (false)), "value" =>                 // line 217
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 217, $this->source); })()), "disabled" =>                 // line 218
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 218, $this->source); })()), "labelledBy" =>                 // line 219
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 219, $this->source); })()), "describedBy" =>                 // line 220
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 220, $this->source); })())]));
                break;
            }
            default:
            {
                // line 223
                if ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 223, $this->source); })())) {
                    // line 224
                    yield "                                            <pre class=\"noteditable\">";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 224, $this->source); })()), "html", null, true);
                    yield "</pre>
                                        ";
                } else {
                    // line 226
                    yield "                                            ";
                    if ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 226, $this->source); })())) {
                        // line 227
                        yield "                                                <div class=\"editable-table-preview\" aria-hidden=\"true\">";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 227, $this->source); })()), "html", null, true);
                        yield "</div>
                                            ";
                    }
                    // line 229
                    yield "                                            ";
                    yield $this->extensions['craft\web\twig\Extension']->tagFunction("textarea", ["name" =>                     // line 230
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 230, $this->source); })()), "rows" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 231
($context["col"] ?? null), "rows", [], "any", true, true, false, 231) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "rows", [], "any", false, false, false, 231)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "rows", [], "any", false, false, false, 231)) : (1)), "placeholder" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 232
($context["col"] ?? null), "placeholder", [], "any", true, true, false, 232) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [], "any", false, false, false, 232)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [], "any", false, false, false, 232)) : (false)), "autocomplete" => ((                    // line 233
(isset($context["isCode"]) || array_key_exists("isCode", $context) ? $context["isCode"] : (function () { throw new RuntimeError('Variable "isCode" does not exist.', 233, $this->source); })())) ? ("off") : (false)), "autocorrect" => ((                    // line 234
(isset($context["isCode"]) || array_key_exists("isCode", $context) ? $context["isCode"] : (function () { throw new RuntimeError('Variable "isCode" does not exist.', 234, $this->source); })())) ? ("off") : (false)), "autocapitalize" => ((                    // line 235
(isset($context["isCode"]) || array_key_exists("isCode", $context) ? $context["isCode"] : (function () { throw new RuntimeError('Variable "isCode" does not exist.', 235, $this->source); })())) ? ("off") : (false)), "spellcheck" => ((                    // line 236
(isset($context["isCode"]) || array_key_exists("isCode", $context) ? $context["isCode"] : (function () { throw new RuntimeError('Variable "isCode" does not exist.', 236, $this->source); })())) ? ("false") : (false)), "aria" => ["labelledby" =>                     // line 238
(isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 238, $this->source); })()), "describedby" =>                     // line 239
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 239, $this->source); })())], "html" =>                     // line 241
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 241, $this->source); })())]);
                    // line 242
                    yield "
                                        ";
                }
            }
        }
        craft\helpers\Template::endProfile("block", "tablecell");
        yield from [];
    }

    // line 37
    public function macro_cellClass($fullWidth = null, $col = null, $class = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "fullWidth" => $fullWidth,
            "col" => $col,
            "class" => $class,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "cellClass");
            // line 38
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join($this->extensions['craft\web\twig\Extension']->mergeFilter(((is_iterable((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 38, $this->source); })()))) ? ((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 38, $this->source); })())) : ([(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 38, $this->source); })())])), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [(craft\helpers\Template::attribute($this->env, $this->source,             // line 39
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 39, $this->source); })()), "type", [], "any", false, false, false, 39) . "-cell"), ((CoreExtension::inFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 40
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 40, $this->source); })()), "type", [], "any", false, false, false, 40), ["autosuggest", "color", "date", "email", "multiline", "number", "singleline", "template", "time", "url"])) ? ("textual") : (null)), (((            // line 52
(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 52, $this->source); })()) && (((craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "thin", [], "any", true, true, false, 52) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "thin", [], "any", false, false, false, 52)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "thin", [], "any", false, false, false, 52)) : (false)))) ? ("thin") : (null)), ((craft\helpers\Template::attribute($this->env, $this->source,             // line 53
($context["col"] ?? null), "info", [], "any", true, true, false, 53)) ? ("has-info") : (null))])), " "), "html", null, true);
            craft\helpers\Template::endProfile("macro", "cellClass");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/editableTable.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  727 => 53,  726 => 52,  725 => 40,  724 => 39,  723 => 38,  708 => 37,  698 => 242,  696 => 241,  695 => 239,  694 => 238,  693 => 236,  692 => 235,  691 => 234,  690 => 233,  689 => 232,  688 => 231,  687 => 230,  685 => 229,  679 => 227,  676 => 226,  670 => 224,  668 => 223,  662 => 220,  661 => 219,  660 => 218,  659 => 217,  658 => 216,  657 => 215,  656 => 214,  655 => 213,  654 => 212,  647 => 209,  646 => 208,  645 => 207,  644 => 206,  643 => 205,  642 => 204,  641 => 203,  640 => 202,  633 => 199,  632 => 198,  631 => 197,  630 => 196,  629 => 195,  628 => 194,  622 => 191,  621 => 190,  620 => 189,  619 => 188,  618 => 187,  617 => 186,  616 => 184,  610 => 183,  608 => 181,  607 => 180,  606 => 179,  605 => 177,  604 => 176,  603 => 175,  602 => 174,  596 => 171,  595 => 170,  594 => 169,  593 => 168,  592 => 167,  591 => 166,  585 => 163,  584 => 162,  583 => 161,  582 => 159,  581 => 158,  580 => 157,  574 => 154,  573 => 153,  572 => 152,  571 => 150,  570 => 149,  569 => 148,  563 => 146,  561 => 144,  560 => 143,  559 => 142,  558 => 141,  557 => 140,  556 => 139,  555 => 138,  552 => 137,  548 => 135,  540 => 134,  529 => 310,  525 => 309,  521 => 308,  517 => 307,  513 => 306,  509 => 305,  500 => 304,  497 => 303,  494 => 302,  491 => 301,  488 => 300,  485 => 299,  483 => 298,  480 => 297,  472 => 295,  469 => 294,  467 => 293,  464 => 292,  462 => 81,  459 => 290,  444 => 288,  435 => 286,  431 => 285,  427 => 282,  425 => 279,  424 => 275,  423 => 272,  422 => 268,  419 => 267,  417 => 266,  412 => 262,  410 => 255,  409 => 253,  405 => 252,  401 => 250,  398 => 249,  384 => 248,  380 => 246,  378 => 134,  359 => 133,  356 => 132,  353 => 131,  350 => 130,  347 => 129,  333 => 127,  331 => 126,  318 => 125,  315 => 124,  312 => 123,  309 => 122,  292 => 121,  287 => 120,  284 => 119,  281 => 118,  278 => 117,  261 => 116,  258 => 115,  253 => 112,  245 => 110,  242 => 109,  227 => 107,  214 => 105,  212 => 104,  209 => 102,  206 => 100,  204 => 99,  202 => 98,  200 => 97,  194 => 96,  191 => 95,  174 => 94,  170 => 92,  167 => 91,  164 => 90,  159 => 89,  154 => 88,  150 => 86,  147 => 85,  140 => 83,  135 => 82,  133 => 81,  129 => 79,  120 => 76,  114 => 74,  110 => 72,  106 => 71,  103 => 70,  100 => 68,  98 => 67,  96 => 63,  95 => 62,  94 => 61,  93 => 58,  92 => 57,  89 => 56,  86 => 36,  80 => 34,  78 => 33,  75 => 32,  73 => 16,  70 => 15,  68 => 14,  66 => 13,  64 => 12,  62 => 11,  60 => 10,  58 => 8,  56 => 7,  54 => 6,  52 => 5,  50 => 4,  48 => 3,  46 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{%- set static = static ?? false %}
{%- set fullWidth = fullWidth ?? true %}
{%- set cols = cols ?? [] %}
{%- set rows = rows ?? [] %}
{%- set initJs = not static and (initJs ?? true) -%}
{%- set minRows = minRows ?? null %}
{%- set maxRows = maxRows ?? null %}
{%- set describedBy = describedBy ?? null %}

{%- set totalRows = rows|length %}
{%- set staticRows = static or (staticRows ?? false) or (minRows == 1 and maxRows == 1 and totalRows == 1) %}
{%- set allowAdd = (allowAdd ?? false) and not staticRows %}
{%- set allowReorder = (allowReorder ?? false) and not staticRows %}
{%- set allowDelete = (allowDelete ?? false) and not staticRows %}

{% set actionMenuItems = [
  {
    icon: 'arrow-up',
    label: 'Move up'|t('app'),
    attributes: {
      data: {action: 'moveUp'},
    },
  },
  {
    icon: 'arrow-down',
    label: 'Move down'|t('app'),
    attributes: {
      data: {action: 'moveDown'},
    },
  },
] %}

{% if not static %}
    {{ hiddenInput(name, '') }}
{% endif %}

{% macro cellClass(fullWidth, col, class) %}
    {{- (class is iterable ? class : [class])|merge([
        \"#{col.type}-cell\",
        col.type in [
            'autosuggest',
            'color',
            'date',
            'email',
            'multiline',
            'number',
            'singleline',
            'template',
            'time',
            'url',
        ] ? 'textual' : null,
        fullWidth and (col.thin ?? false) ? 'thin' : null,
        col.info is defined ? 'has-info' : null,
    ]|filter)|join(' ') -}}
{% endmacro %}

{% set tableAttributes = {
    id: id,
    class: [
        'editable',
        fullWidth ? 'fullwidth',
        static ? 'static',
        totalRows == 0 ? 'hidden',
    ]|filter,
} %}

{%- if block('attr') is defined %}
  {%- set tableAttributes = tableAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% for col in cols %}
    {%- switch col.type %}
        {%- case 'time' %}
            {%- do view.registerAssetBundle('craft\\\\web\\\\assets\\\\timepicker\\\\TimepickerAsset') %}
        {%- case 'template' %}
            {%- do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\vue\\\\VueAsset\") %}
    {%- endswitch %}
{% endfor %}

<span role=\"status\" class=\"visually-hidden\" data-status-message></span>
{% tag 'table' with tableAttributes %}
    {% for col in cols %}
        <col>
    {% endfor %}
    {% if (allowDelete and allowReorder) %}
        <colgroup span=\"2\"></colgroup>
    {% else %}
        {% if allowDelete %}<col>{% endif %}
        {% if allowReorder %}<col>{% endif %}
    {% endif %}
    {% if cols|filter(c => (c.headingHtml ?? c.heading ?? c.info ?? '') is not same as(''))|length %}
        <thead>
            <tr>
                {% for col in cols %}
                    {% set columnHeadingId = \"#{id}-heading-#{loop.index}\" %}
                    <th id=\"{{ columnHeadingId }}\" scope=\"col\" class=\"{{ _self.cellClass(fullWidth, col, col.class ?? []) }}\">
                        {%- if col.headingHtml is defined %}
                            {{- col.headingHtml|raw }}
                        {%- elseif col.heading ?? false %}
                            {{- col.heading }}
                        {%- else %}
                            &nbsp;
                        {%- endif %}
                        {%- if col.info is defined -%}
                            <span class=\"info{% if static %} disabled{% endif %}\"{% if static %} disabled=\"\"{% endif %}>{{ col.info|md|raw }}</span>
                        {%- endif -%}
                    </th>
                {% endfor %}
                {% if (allowDelete or allowReorder) %}
                    <th colspan=\"{{ not allowDelete or not allowReorder ? 1 : 2 }}\" scope=\"colgroup\"><span class=\"visually-hidden\">{{ 'Row actions'|t('app') }}</span></th>
                {% endif %}
            </tr>
        </thead>
    {% endif %}
    <tbody>
        {% for rowId, row in rows %}
            {% set rowNumber = loop.index %}
            {% set rowName = 'Row {index}'|t('app', {index: rowNumber}) %}
            {% set actionBtnLabel = \"#{rowName} #{'Actions'|t('app')}\" %}
            <tr data-id=\"{{ rowId }}\">
                {% for colId, col in cols %}
                    {% set cell = row[colId] is defined ? row[colId] : (defaultValues[colId] ?? null) %}
                    {% set value = cell.value is defined ? cell.value : cell %}
                    {% if col.type == 'heading' %}
                        <th scope=\"row\" class=\"{{ _self.cellClass(fullWidth, col, cell.class ?? col.class ?? []) }}\"{% if col.width ?? false %} width=\"{{ col.width }}\"{% endif %}>{{ value|raw }}</th>
                    {% elseif col.type == 'html' %}
                        <td class=\"{{ _self.cellClass(fullWidth, col, cell.class ?? col.class ?? []) }}\"{% if col.width ?? false %} width=\"{{ col.width }}\"{% endif %}>{{ value|raw }}</td>
                    {% else %}
                        {% set headingId = \"#{id}-heading-#{loop.index}\" %}
                        {% set hasErrors = cell.hasErrors ?? false %}
                        {% set cellName = name~'['~rowId~']['~colId~']' %}
                        {% set isCode = (col.code ?? false) or col.type == 'color' %}
                        <td class=\"{{ _self.cellClass(fullWidth, col, col.class ?? []) }} {% if isCode %}code{% endif %} {% if hasErrors %}error{% endif %}\"{% if col.width ?? false %} width=\"{{ col.width }}\"{% endif %}>
                            {% block tablecell %}
                                {%- switch col.type -%}
                                    {%- case 'checkbox' -%}
                                        <div class=\"checkbox-wrapper\">
                                            {% include \"_includes/forms/checkbox\" with {
                                                name: cellName,
                                                value:  col.value ?? 1,
                                                checked: value is not empty,
                                                disabled: static,
                                                labelledBy: headingId,
                                                describedBy: describedBy,
                                            } only %}
                                        </div>
                                    {%- case 'icon' -%}
                                        {% include '_includes/forms/iconPicker' with {
                                          name: cellName,
                                          value,
                                          small: true,
                                          disabled: static,
                                          labelledBy: headingId,
                                          describedBy: describedBy,
                                        } only %}
                                    {%- case 'color' -%}
                                        {% include \"_includes/forms/color\" with {
                                            name: cellName,
                                            value: value,
                                            small: true,
                                            disabled: static,
                                            labelledBy: headingId,
                                            describedBy: describedBy,
                                        } only %}
                                    {%- case 'date' -%}
                                        {% include \"_includes/forms/date\" with {
                                            name: cellName,
                                            value: value,
                                            disabled: static,
                                            labelledBy: headingId,
                                            describedBy: describedBy,
                                        } only %}
                                    {%- case 'lightswitch' -%}
                                        {% include \"_includes/forms/lightswitch\" with {
                                            name: cellName,
                                            on: value,
                                            value: col.value ?? 1,
                                            small: true,
                                            disabled: static,
                                            labelledBy: headingId,
                                            describedBy: describedBy,
                                        } only %}
                                    {% case 'select' -%}
                                        {% include \"_includes/forms/select\" with {
                                            class: 'small',
                                            name: cellName,
                                            options: cell.options ?? col.options,
                                            value: value,
                                            disabled: static,
                                            labelledBy: headingId,
                                            describedBy: describedBy,
                                        } only %}
                                    {%- case 'time' -%}
                                        {% include \"_includes/forms/time\" with {
                                            name: cellName,
                                            value: value,
                                            disabled: static,
                                            labelledBy: headingId,
                                            describedBy: describedBy,
                                        } only %}
                                    {%- case 'email' or 'url' -%}
                                        {% include \"_includes/forms/text\" with {
                                            type: col.type,
                                            name: cellName,
                                            placeholder: col.placeholder ?? null,
                                            value:  value,
                                            disabled: static,
                                            labelledBy: headingId,
                                            describedBy: describedBy,
                                        } only %}
                                    {%- case 'autosuggest' or 'template' -%}
                                        {% include \"_includes/forms/autosuggest\" with {
                                            name: cellName,
                                            suggestTemplates: col.type == 'template',
                                            suggestEnvVars: col.suggestEnvVars ?? false,
                                            suggestAliases: col.suggestAliases ?? false,
                                            value: value,
                                            disabled: static,
                                            labelledBy: headingId,
                                            describedBy: describedBy,
                                        } only %}
                                    {%- default -%}
                                        {% if static %}
                                            <pre class=\"noteditable\">{{ value }}</pre>
                                        {% else %}
                                            {% if value %}
                                                <div class=\"editable-table-preview\" aria-hidden=\"true\">{{ value }}</div>
                                            {% endif %}
                                            {{ tag('textarea', {
                                                name: cellName,
                                                rows: col.rows ?? 1,
                                                placeholder: col.placeholder ?? false,
                                                autocomplete: isCode ? 'off' : false,
                                                autocorrect: isCode ? 'off' : false,
                                                autocapitalize: isCode ? 'off' : false,
                                                spellcheck: isCode ? 'false' : false,
                                                aria: {
                                                    labelledby: headingId,
                                                    describedby: describedBy,
                                                },
                                                html: value,
                                            }) }}
                                        {% endif %}
                                {%- endswitch -%}
                            {% endblock %}
                        </td>
                    {% endif %}
                {% endfor %}
                {% if allowReorder -%}
                    <td class=\"thin action\">
                      <div class=\"flex flex-nowrap\">
                        <a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\"></a>
                        {{~ disclosureMenu(actionMenuItems, {
                          buttonAttributes: {
                            'aria-label': actionBtnLabel,
                            class: ['action-btn'],
                            title: 'Actions'|t('app'),
                            data: {
                              'disclosure-trigger': true,
                            },
                          },
                        }) }}
                      </div>
                    </td>
                {%- endif -%}
                {%- if allowDelete -%}
                    <td class=\"thin action\">
                        {{ tag('button', {
                            class: [
                                'delete',
                                'icon',
                                minRows and totalRows <= minRows ? 'disabled' : null,
                            ]|filter,
                            type: 'button',
                            disabled: minRows and totalRows <= minRows,
                            title: 'Delete'|t('app'),
                            aria: {
                                label: 'Delete row {index}'|t('app', {
                                    index: rowNumber,
                                }),
                            }
                        }) }}
                    </td>
                {%- endif -%}
                {% for inputName, value in row.hiddenInputs ?? [] %}
                    {{ hiddenInput(\"#{name}[#{rowId}][#{inputName}]\", value) }}
                {% endfor %}
            </tr>
        {% endfor %}
    </tbody>
{% endtag %}

{% if allowAdd %}
    {% set buttonText = addRowLabel ?? \"Add a row\"|t('app') %}
    <button type=\"button\" class=\"btn dashed add icon\" aria-label=\"{{ buttonText }}\">{{ buttonText }}</button>
{% endif %}

{% if initJs %}
    {% set jsId = id|namespaceInputId|e('js') %}
    {% set jsName = name|namespaceInputName|e('js') %}
    {% set jsCols = cols|json_encode %}
    {% set defaultValues = defaultValues ?? null %}
    {% js %}
        new Craft.EditableTable(\"{{ jsId }}\", \"{{ jsName }}\", {{ jsCols|raw }}, {
            defaultValues: {{ defaultValues ? defaultValues|json_encode|raw : '{}' }},
            allowAdd: {{ allowAdd ? 'true' : 'false' }},
            allowDelete: {{ allowDelete ? 'true' : 'false' }},
            allowReorder: {{ allowReorder ? 'true' : 'false' }},
            minRows: {{ minRows ? minRows : 'null' }},
            maxRows: {{ maxRows ? maxRows : 'null' }}
        });
    {% endjs %}
{% endif %}
", "_includes/forms/editableTable.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/editableTable.twig");
    }
}
