<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/entryTypeSelect */
class __TwigTemplate_9c1b753817e365f86c115c4712c39a28 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/entryTypeSelect");
        // line 1
        $context["allowOverrides"] = (($context["allowOverrides"]) ?? (false));
        // line 2
        yield "
";
        // line 3
        yield from $this->loadTemplate("_includes/forms/entryTypeSelect", "_includes/forms/entryTypeSelect", 3, "965938129")->unwrap()->yield(CoreExtension::merge($context, ["options" => ((        // line 4
$context["options"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", [], "any", false, false, false, 4), "entries", [], "any", false, false, false, 4), "getAllEntryTypes", [], "method", false, false, false, 4))), "showHandles" => true, "showIndicators" => ((        // line 6
$context["showIndicators"]) ?? ((isset($context["allowOverrides"]) || array_key_exists("allowOverrides", $context) ? $context["allowOverrides"] : (function () { throw new RuntimeError('Variable "allowOverrides" does not exist.', 6, $this->source); })()))), "showDescription" => ((        // line 7
$context["showDescription"]) ?? ((isset($context["allowOverrides"]) || array_key_exists("allowOverrides", $context) ? $context["allowOverrides"] : (function () { throw new RuntimeError('Variable "allowOverrides" does not exist.', 7, $this->source); })()))), "createAction" => ((((        // line 8
$context["create"]) ?? (false))) ? ("entry-types/edit") : (null)), "jsClass" => ((        // line 9
$context["jsClass"]) ?? ("Craft.EntryTypeSelectInput")), "jsSettings" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["allowOverrides" =>         // line 11
(isset($context["allowOverrides"]) || array_key_exists("allowOverrides", $context) ? $context["allowOverrides"] : (function () { throw new RuntimeError('Variable "allowOverrides" does not exist.', 11, $this->source); })())], ((        // line 12
$context["jsSettings"]) ?? ([])))]));
        craft\helpers\Template::endProfile("template", "_includes/forms/entryTypeSelect");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/entryTypeSelect";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  55 => 12,  54 => 11,  53 => 9,  52 => 8,  51 => 7,  50 => 6,  49 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set allowOverrides = allowOverrides ?? false %}

{% embed '_includes/forms/componentSelect.twig' with {
  options: options ?? craft.app.entries.getAllEntryTypes(),
  showHandles: true,
  showIndicators: showIndicators ?? allowOverrides,
  showDescription: showDescription ?? allowOverrides,
  createAction: (create ?? false) ? 'entry-types/edit' : null,
  jsClass: jsClass ?? 'Craft.EntryTypeSelectInput',
  jsSettings: {
    allowOverrides,
  }|merge(jsSettings ?? {}),
} %}
  {% block chips %}
    {% for entryType in values %}
      <li>
        {% set chip = chip(entryType, {
          inputName: inputName ?? name ?? null,
          inputValue: allowOverrides ? {
            id: entryType.id,
            name: entryType.original and entryType.name != entryType.original.name ? entryType.name : null,
            handle: entryType.original and entryType.handle != entryType.original.handle ? entryType.handle : null,
            description: entryType.original and entryType.description != entryType.original.description ? entryType.description : null,
            group: (includeGroupInValues ?? false) ? (entryType.group ?? 'General'|t('app')) : null,
          }|filter|json_encode : null,
          checkbox: selectable ?? false,
          showActionMenu: showActionMenus,
          showHandle: showHandles,
          showIndicators: showIndicators,
          showDescription: showDescription,
          hyperlink: hyperlinks,
        }) %}
        {% if disabled %}
          {% set chip = chip|removeClass('removable') %}
        {% endif %}
        {{ chip|raw }}
      </li>
    {% endfor %}
  {% endblock %}
{% endembed %}
", "_includes/forms/entryTypeSelect", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/entryTypeSelect.twig");
    }
}


/* _includes/forms/entryTypeSelect */
class __TwigTemplate_9c1b753817e365f86c115c4712c39a28___965938129 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'chips' => [$this, 'block_chips'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 3
        return "_includes/forms/componentSelect.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/entryTypeSelect");
        $this->parent = $this->loadTemplate("_includes/forms/componentSelect.twig", "_includes/forms/entryTypeSelect", 3);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_includes/forms/entryTypeSelect");
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_chips(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "chips");
        // line 15
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 15, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["entryType"]) {
            // line 16
            yield "      <li>
        ";
            // line 17
            $context["chip"] = craft\helpers\Cp::chipHtml($context["entryType"], ["inputName" => ((            // line 18
$context["inputName"]) ?? ((($context["name"]) ?? (null)))), "inputValue" => ((            // line 19
(isset($context["allowOverrides"]) || array_key_exists("allowOverrides", $context) ? $context["allowOverrides"] : (function () { throw new RuntimeError('Variable "allowOverrides" does not exist.', 19, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 20
$context["entryType"], "id", [], "any", false, false, false, 20), "name" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 21
$context["entryType"], "original", [], "any", false, false, false, 21) && (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "name", [], "any", false, false, false, 21) != craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "original", [], "any", false, false, false, 21), "name", [], "any", false, false, false, 21)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "name", [], "any", false, false, false, 21)) : (null)), "handle" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 22
$context["entryType"], "original", [], "any", false, false, false, 22) && (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "handle", [], "any", false, false, false, 22) != craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "original", [], "any", false, false, false, 22), "handle", [], "any", false, false, false, 22)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "handle", [], "any", false, false, false, 22)) : (null)), "description" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 23
$context["entryType"], "original", [], "any", false, false, false, 23) && (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "description", [], "any", false, false, false, 23) != craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "original", [], "any", false, false, false, 23), "description", [], "any", false, false, false, 23)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "description", [], "any", false, false, false, 23)) : (null)), "group" => ((((            // line 24
$context["includeGroupInValues"]) ?? (false))) ? ((((craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "group", [], "any", true, true, false, 24) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "group", [], "any", false, false, false, 24)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "group", [], "any", false, false, false, 24)) : ($this->extensions['craft\web\twig\Extension']->translateFilter("General", "app")))) : (null))]))) : (null)), "checkbox" => ((            // line 26
$context["selectable"]) ?? (false)), "showActionMenu" =>             // line 27
(isset($context["showActionMenus"]) || array_key_exists("showActionMenus", $context) ? $context["showActionMenus"] : (function () { throw new RuntimeError('Variable "showActionMenus" does not exist.', 27, $this->source); })()), "showHandle" =>             // line 28
(isset($context["showHandles"]) || array_key_exists("showHandles", $context) ? $context["showHandles"] : (function () { throw new RuntimeError('Variable "showHandles" does not exist.', 28, $this->source); })()), "showIndicators" =>             // line 29
(isset($context["showIndicators"]) || array_key_exists("showIndicators", $context) ? $context["showIndicators"] : (function () { throw new RuntimeError('Variable "showIndicators" does not exist.', 29, $this->source); })()), "showDescription" =>             // line 30
(isset($context["showDescription"]) || array_key_exists("showDescription", $context) ? $context["showDescription"] : (function () { throw new RuntimeError('Variable "showDescription" does not exist.', 30, $this->source); })()), "hyperlink" =>             // line 31
(isset($context["hyperlinks"]) || array_key_exists("hyperlinks", $context) ? $context["hyperlinks"] : (function () { throw new RuntimeError('Variable "hyperlinks" does not exist.', 31, $this->source); })())]);
            // line 33
            yield "        ";
            if ((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 33, $this->source); })())) {
                // line 34
                yield "          ";
                $context["chip"] = $this->extensions['craft\web\twig\Extension']->removeClassFilter((isset($context["chip"]) || array_key_exists("chip", $context) ? $context["chip"] : (function () { throw new RuntimeError('Variable "chip" does not exist.', 34, $this->source); })()), "removable");
                // line 35
                yield "        ";
            }
            // line 36
            yield "        ";
            yield (isset($context["chip"]) || array_key_exists("chip", $context) ? $context["chip"] : (function () { throw new RuntimeError('Variable "chip" does not exist.', 36, $this->source); })());
            yield "
      </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entryType'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        yield "  ";
        craft\helpers\Template::endProfile("block", "chips");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/entryTypeSelect";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  217 => 39,  207 => 36,  204 => 35,  201 => 34,  198 => 33,  196 => 31,  195 => 30,  194 => 29,  193 => 28,  192 => 27,  191 => 26,  190 => 24,  189 => 23,  188 => 22,  187 => 21,  186 => 20,  185 => 19,  184 => 18,  183 => 17,  180 => 16,  175 => 15,  167 => 14,  154 => 3,  55 => 12,  54 => 11,  53 => 9,  52 => 8,  51 => 7,  50 => 6,  49 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set allowOverrides = allowOverrides ?? false %}

{% embed '_includes/forms/componentSelect.twig' with {
  options: options ?? craft.app.entries.getAllEntryTypes(),
  showHandles: true,
  showIndicators: showIndicators ?? allowOverrides,
  showDescription: showDescription ?? allowOverrides,
  createAction: (create ?? false) ? 'entry-types/edit' : null,
  jsClass: jsClass ?? 'Craft.EntryTypeSelectInput',
  jsSettings: {
    allowOverrides,
  }|merge(jsSettings ?? {}),
} %}
  {% block chips %}
    {% for entryType in values %}
      <li>
        {% set chip = chip(entryType, {
          inputName: inputName ?? name ?? null,
          inputValue: allowOverrides ? {
            id: entryType.id,
            name: entryType.original and entryType.name != entryType.original.name ? entryType.name : null,
            handle: entryType.original and entryType.handle != entryType.original.handle ? entryType.handle : null,
            description: entryType.original and entryType.description != entryType.original.description ? entryType.description : null,
            group: (includeGroupInValues ?? false) ? (entryType.group ?? 'General'|t('app')) : null,
          }|filter|json_encode : null,
          checkbox: selectable ?? false,
          showActionMenu: showActionMenus,
          showHandle: showHandles,
          showIndicators: showIndicators,
          showDescription: showDescription,
          hyperlink: hyperlinks,
        }) %}
        {% if disabled %}
          {% set chip = chip|removeClass('removable') %}
        {% endif %}
        {{ chip|raw }}
      </li>
    {% endfor %}
  {% endblock %}
{% endembed %}
", "_includes/forms/entryTypeSelect", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/entryTypeSelect.twig");
    }
}
