<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/timeZone */
class __TwigTemplate_6edafefe625f9f798ed4db4d0c9db23b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/timeZone");
        // line 1
        $context["id"] = (($context["id"]) ?? (("timezone" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 2
        yield "
";
        // line 3
        yield from $this->loadTemplate("_includes/forms/selectize", "_includes/forms/timeZone", 3)->unwrap()->yield(CoreExtension::merge($context, ["options" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 4
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "cp", [], "any", false, false, false, 4), "getTimeZoneOptions", [(($context["offsetDate"]) ?? (null))], "method", false, false, false, 4), "inputAttributes" => ["aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Time Zone", "app")]]]));
        craft\helpers\Template::endProfile("template", "_includes/forms/timeZone");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/timeZone";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  49 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set id = id ?? \"timezone#{random()}\" %}

{% include '_includes/forms/selectize' with {
    options: craft.cp.getTimeZoneOptions(offsetDate ?? null),
    inputAttributes: {
        aria: {
            label: 'Time Zone'|t('app'),
        }
    }
}%}
", "_includes/forms/timeZone", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/timeZone.twig");
    }
}
