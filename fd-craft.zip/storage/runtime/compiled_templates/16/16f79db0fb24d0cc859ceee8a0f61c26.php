<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/addresses/_fields */
class __TwigTemplate_7a8fdd1c7fd15ce172bb7940eca88f11 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 3
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/addresses/_fields");
        // line 1
        Craft::$app->controller->requireAdmin();
        // line 4
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/addresses/_fields", 4)->unwrap();
        // line 6
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Address Fields", "app");
        // line 8
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 3
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/addresses/_fields", 3);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/addresses/_fields");
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 14
        yield "  <form method=\"post\" accept-charset=\"UTF-8\" data-saveshortcut data-confirm-unload>
    ";
        // line 15
        yield craft\helpers\Html::actionInput("addresses/save-field-layout");
        yield "
    ";
        // line 16
        yield craft\helpers\Html::csrfInput();
        yield "

    ";
        // line 18
        yield $macros["forms"]->getTemplateForMacro("macro_fieldLayoutDesignerField", $context, 18, $this->getSourceContext())->macro_fieldLayoutDesignerField(...[["first" => true, "fieldLayout" => ((        // line 20
$context["fieldLayout"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 20, $this->source); })()), "app", [], "any", false, false, false, 20), "addresses", [], "any", false, false, false, 20), "getFieldLayout", [], "method", false, false, false, 20))), "withGeneratedFields" => true, "withCardViewDesigner" => true]]);
        // line 23
        yield "

    <div class=\"buttons\">
      <button type=\"submit\" class=\"btn submit\">";
        // line 26
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
        yield "</button>
    </div>
  </form>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/addresses/_fields";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  90 => 26,  85 => 23,  83 => 20,  82 => 18,  77 => 16,  73 => 15,  70 => 14,  62 => 13,  56 => 3,  54 => 8,  52 => 6,  50 => 4,  48 => 1,  40 => 3,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% requireAdmin %}

{% extends \"_layouts/cp\" %}
{% import \"_includes/forms\" as forms %}

{% set title = 'Address Fields'|t('app') %}

{% set crumbs = [
  { label: 'Settings'|t('app'), url: url('settings') }
] %}


{% block content %}
  <form method=\"post\" accept-charset=\"UTF-8\" data-saveshortcut data-confirm-unload>
    {{ actionInput('addresses/save-field-layout') }}
    {{ csrfInput() }}

    {{ forms.fieldLayoutDesignerField({
      first: true,
      fieldLayout: fieldLayout ?? craft.app.addresses.getFieldLayout(),
      withGeneratedFields: true,
      withCardViewDesigner: true,
    }) }}

    <div class=\"buttons\">
      <button type=\"submit\" class=\"btn submit\">{{ 'Save'|t('app') }}</button>
    </div>
  </form>
{% endblock %}
", "settings/addresses/_fields", "/var/www/html/vendor/craftcms/cms/src/templates/settings/addresses/_fields.twig");
    }
}
