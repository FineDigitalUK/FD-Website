<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/fld/field-settings.twig */
class __TwigTemplate_9231d864660bafe4ce260fb6d40820f7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'fieldSettings' => [$this, 'block_fieldSettings'],
            'labelField' => [$this, 'block_labelField'],
            'instructionsField' => [$this, 'block_instructionsField'],
            'tipField' => [$this, 'block_tipField'],
            'warningField' => [$this, 'block_warningField'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/fld/field-settings.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_includes/forms/fld/field-settings.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context["hideLabelChangeJs"] = new Markup("if (this.checked) {
    \$(this).closest('.field').find('.text').addClass('disabled').prop('disabled', true);
  } else {
    \$(this).closest('.field').find('.text').removeClass('disabled').prop('disabled', false);
  }", $this->env->getCharset());
        // line 10
        yield "
";
        // line 11
        yield from $this->unwrap()->yieldBlock('fieldSettings', $context, $blocks);
        craft\helpers\Template::endProfile("template", "_includes/forms/fld/field-settings.twig");
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_fieldSettings(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "fieldSettings");
        // line 12
        yield "  ";
        yield from $this->unwrap()->yieldBlock('labelField', $context, $blocks);
        // line 44
        yield "
  ";
        // line 45
        yield from $this->unwrap()->yieldBlock('instructionsField', $context, $blocks);
        // line 58
        yield "
  ";
        // line 59
        yield from $this->unwrap()->yieldBlock('tipField', $context, $blocks);
        // line 72
        yield "
  ";
        // line 73
        yield from $this->unwrap()->yieldBlock('warningField', $context, $blocks);
        craft\helpers\Template::endProfile("block", "fieldSettings");
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_labelField(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "labelField");
        // line 13
        yield "    ";
        yield from $this->loadTemplate("_includes/forms/fld/field-settings.twig", "_includes/forms/fld/field-settings.twig", 13, "1402334551")->unwrap()->yield(CoreExtension::merge($context, ["id" => "label", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Label", "app"), "data" => ["error-key" => "label"]]));
        // line 43
        yield "  ";
        craft\helpers\Template::endProfile("block", "labelField");
        yield from [];
    }

    // line 45
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_instructionsField(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "instructionsField");
        // line 46
        yield "    ";
        yield $macros["forms"]->getTemplateForMacro("macro_textareaField", $context, 46, $this->getSourceContext())->macro_textareaField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "app"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 51
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 51, $this->source); })()), "instructions", [], "any", false, false, false, 51), "placeholder" =>         // line 52
(isset($context["defaultInstructions"]) || array_key_exists("defaultInstructions", $context) ? $context["defaultInstructions"] : (function () { throw new RuntimeError('Variable "defaultInstructions" does not exist.', 52, $this->source); })()), "data" => ["error-key" => "instructions"]]]);
        // line 56
        yield "
  ";
        craft\helpers\Template::endProfile("block", "instructionsField");
        yield from [];
    }

    // line 59
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_tipField(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "tipField");
        // line 60
        yield "    ";
        yield $macros["forms"]->getTemplateForMacro("macro_textareaField", $context, 60, $this->getSourceContext())->macro_textareaField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Tip", "app"), "id" => "tip", "class" => "nicetext", "name" => "tip", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 65
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 65, $this->source); })()), "tip", [], "any", false, false, false, 65), "rows" => 1, "data" => ["error-key" => "tip"]]]);
        // line 70
        yield "
  ";
        craft\helpers\Template::endProfile("block", "tipField");
        yield from [];
    }

    // line 73
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_warningField(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "warningField");
        // line 74
        yield "    ";
        yield $macros["forms"]->getTemplateForMacro("macro_textareaField", $context, 74, $this->getSourceContext())->macro_textareaField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Warning", "app"), "id" => "warning", "class" => "nicetext", "name" => "warning", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 79
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 79, $this->source); })()), "warning", [], "any", false, false, false, 79), "rows" => 1, "data" => ["error-key" => "warning"]]]);
        // line 84
        yield "
  ";
        craft\helpers\Template::endProfile("block", "warningField");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/fld/field-settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  165 => 84,  163 => 79,  161 => 74,  153 => 73,  146 => 70,  144 => 65,  142 => 60,  134 => 59,  127 => 56,  125 => 52,  124 => 51,  122 => 46,  114 => 45,  108 => 43,  105 => 13,  97 => 12,  91 => 73,  88 => 72,  86 => 59,  83 => 58,  81 => 45,  78 => 44,  75 => 12,  62 => 11,  59 => 10,  53 => 3,  50 => 2,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms' as forms %}

{% set hideLabelChangeJs -%}
  if (this.checked) {
    \$(this).closest('.field').find('.text').addClass('disabled').prop('disabled', true);
  } else {
    \$(this).closest('.field').find('.text').removeClass('disabled').prop('disabled', false);
  }
{%- endset %}

{% block fieldSettings %}
  {% block labelField %}
    {% embed '_includes/forms/field' with {
      id: 'label',
      label: 'Label'|t('app'),
      data: {
        'error-key': 'label'
      },
    } %}
      {% block heading %}
        {{ parent() }}
        <div class=\"flex-grow\"></div>
        {% include '_includes/forms/checkbox' with {
          id: 'label-toggle',
          name: 'labelHidden',
          label: 'Hide'|t('app'),
          checked: labelHidden,
          inputAttributes: {
            onchange: hideLabelChangeJs,
          },
        } %}
      {% endblock %}
      {% block input %}
        {% include '_includes/forms/text' with {
          id: 'label',
          name: 'label',
          value: not labelHidden ? field.label,
          placeholder: defaultLabel,
          disabled: labelHidden,
        } %}
      {% endblock %}
    {% endembed %}
  {% endblock %}

  {% block instructionsField %}
    {{ forms.textareaField({
      label: 'Instructions'|t('app'),
      id: 'instructions',
      class: 'nicetext',
      name: 'instructions',
      value: field.instructions,
      placeholder: defaultInstructions,
      data: {
        'error-key': 'instructions'
      },
    }) }}
  {% endblock %}

  {% block tipField %}
    {{ forms.textareaField({
      label: 'Tip'|t('app'),
      id: 'tip',
      class: 'nicetext',
      name: 'tip',
      value: field.tip,
      rows: 1,
      data: {
        'error-key': 'tip'
      },
    }) }}
  {% endblock %}

  {% block warningField %}
    {{ forms.textareaField({
      label: 'Warning'|t('app'),
      id: 'warning',
      class: 'nicetext',
      name: 'warning',
      value: field.warning,
      rows: 1,
      data: {
        'error-key': 'warning'
      },
    }) }}
  {% endblock %}
{% endblock %}
", "_includes/forms/fld/field-settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/fld/field-settings.twig");
    }
}


/* _includes/forms/fld/field-settings.twig */
class __TwigTemplate_9231d864660bafe4ce260fb6d40820f7___1402334551 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'input' => [$this, 'block_input'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 13
        return "_includes/forms/field";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/fld/field-settings.twig");
        $this->parent = $this->loadTemplate("_includes/forms/field", "_includes/forms/fld/field-settings.twig", 13);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_includes/forms/fld/field-settings.twig");
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_heading(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "heading");
        // line 21
        yield "        ";
        yield from $this->yieldParentBlock("heading", $context, $blocks);
        yield "
        <div class=\"flex-grow\"></div>
        ";
        // line 23
        yield from $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/fld/field-settings.twig", 23)->unwrap()->yield(CoreExtension::merge($context, ["id" => "label-toggle", "name" => "labelHidden", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Hide", "app"), "checked" =>         // line 27
(isset($context["labelHidden"]) || array_key_exists("labelHidden", $context) ? $context["labelHidden"] : (function () { throw new RuntimeError('Variable "labelHidden" does not exist.', 27, $this->source); })()), "inputAttributes" => ["onchange" =>         // line 29
(isset($context["hideLabelChangeJs"]) || array_key_exists("hideLabelChangeJs", $context) ? $context["hideLabelChangeJs"] : (function () { throw new RuntimeError('Variable "hideLabelChangeJs" does not exist.', 29, $this->source); })())]]));
        // line 32
        yield "      ";
        craft\helpers\Template::endProfile("block", "heading");
        yield from [];
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_input(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "input");
        // line 34
        yield "        ";
        yield from $this->loadTemplate("_includes/forms/text", "_includes/forms/fld/field-settings.twig", 34)->unwrap()->yield(CoreExtension::merge($context, ["id" => "label", "name" => "label", "value" => (( !        // line 37
(isset($context["labelHidden"]) || array_key_exists("labelHidden", $context) ? $context["labelHidden"] : (function () { throw new RuntimeError('Variable "labelHidden" does not exist.', 37, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 37, $this->source); })()), "label", [], "any", false, false, false, 37)) : ("")), "placeholder" =>         // line 38
(isset($context["defaultLabel"]) || array_key_exists("defaultLabel", $context) ? $context["defaultLabel"] : (function () { throw new RuntimeError('Variable "defaultLabel" does not exist.', 38, $this->source); })()), "disabled" =>         // line 39
(isset($context["labelHidden"]) || array_key_exists("labelHidden", $context) ? $context["labelHidden"] : (function () { throw new RuntimeError('Variable "labelHidden" does not exist.', 39, $this->source); })())]));
        // line 41
        yield "      ";
        craft\helpers\Template::endProfile("block", "input");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/fld/field-settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  363 => 41,  361 => 39,  360 => 38,  359 => 37,  357 => 34,  349 => 33,  343 => 32,  341 => 29,  340 => 27,  339 => 23,  333 => 21,  325 => 20,  312 => 13,  165 => 84,  163 => 79,  161 => 74,  153 => 73,  146 => 70,  144 => 65,  142 => 60,  134 => 59,  127 => 56,  125 => 52,  124 => 51,  122 => 46,  114 => 45,  108 => 43,  105 => 13,  97 => 12,  91 => 73,  88 => 72,  86 => 59,  83 => 58,  81 => 45,  78 => 44,  75 => 12,  62 => 11,  59 => 10,  53 => 3,  50 => 2,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms' as forms %}

{% set hideLabelChangeJs -%}
  if (this.checked) {
    \$(this).closest('.field').find('.text').addClass('disabled').prop('disabled', true);
  } else {
    \$(this).closest('.field').find('.text').removeClass('disabled').prop('disabled', false);
  }
{%- endset %}

{% block fieldSettings %}
  {% block labelField %}
    {% embed '_includes/forms/field' with {
      id: 'label',
      label: 'Label'|t('app'),
      data: {
        'error-key': 'label'
      },
    } %}
      {% block heading %}
        {{ parent() }}
        <div class=\"flex-grow\"></div>
        {% include '_includes/forms/checkbox' with {
          id: 'label-toggle',
          name: 'labelHidden',
          label: 'Hide'|t('app'),
          checked: labelHidden,
          inputAttributes: {
            onchange: hideLabelChangeJs,
          },
        } %}
      {% endblock %}
      {% block input %}
        {% include '_includes/forms/text' with {
          id: 'label',
          name: 'label',
          value: not labelHidden ? field.label,
          placeholder: defaultLabel,
          disabled: labelHidden,
        } %}
      {% endblock %}
    {% endembed %}
  {% endblock %}

  {% block instructionsField %}
    {{ forms.textareaField({
      label: 'Instructions'|t('app'),
      id: 'instructions',
      class: 'nicetext',
      name: 'instructions',
      value: field.instructions,
      placeholder: defaultInstructions,
      data: {
        'error-key': 'instructions'
      },
    }) }}
  {% endblock %}

  {% block tipField %}
    {{ forms.textareaField({
      label: 'Tip'|t('app'),
      id: 'tip',
      class: 'nicetext',
      name: 'tip',
      value: field.tip,
      rows: 1,
      data: {
        'error-key': 'tip'
      },
    }) }}
  {% endblock %}

  {% block warningField %}
    {{ forms.textareaField({
      label: 'Warning'|t('app'),
      id: 'warning',
      class: 'nicetext',
      name: 'warning',
      value: field.warning,
      rows: 1,
      data: {
        'error-key': 'warning'
      },
    }) }}
  {% endblock %}
{% endblock %}
", "_includes/forms/fld/field-settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/fld/field-settings.twig");
    }
}
