<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* verbb-base/_svg/verbb-logo.svg */
class __TwigTemplate_8a63b6c05b399274ed1a180104074aea extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "verbb-base/_svg/verbb-logo.svg");
        // line 1
        yield "<?xml version=\"1.0\" encoding=\"utf-8\"?>
<svg width=\"63.8px\" height=\"13.8px\" viewBox=\"0 0 63.8 13.8\">
<path style=\"fill:#FFFFFF;\" d=\"M14.2,0.2h-2c-0.4,0-0.9,0.3-1.1,0.7L6.7,10L5.1,1c-0.1-0.5-0.5-0.8-1-0.8H0.7C0.3,0.2-0.1,0.7,0,1.1
    l0.2,0.7c0.1,0.2,0.3,0.4,0.5,0.4h0.8l2.3,10.5c0.1,0.5,0.5,0.8,1.1,0.8h2.5c0.6,0,1.2-0.4,1.5-1l5.8-11.4C15,0.7,14.7,0.2,14.2,0.2
    z M21.4,0c-3.7,0-6.6,2.9-7.5,5.6c-1.4,4.4,1.4,8.2,5.6,8.2c2.6,0,4.9-1.1,6.3-2.4c0.6-0.6,0.2-0.9-0.2-1.2c-0.2-0.1-1-0.5-1-0.5
    c-0.4-0.2-0.9-0.2-1.3,0c-0.6,0.3-1.2,0.9-3.3,0.9c-1.7,0-3-1.2-3.2-2.7c0,0,7.1,0,9.6,0c0.8,0,1.1-0.7,1.1-1.9
    C27.5,2.4,24.9,0,21.4,0L21.4,0z M17.2,5.6c0.7-1.4,2.2-2.5,3.9-2.5c1.6,0,2.8,1,3.2,2.5H17.2z M36.6,0.2l-5.9,0
    c-0.6,0-1.1,0.5-1.2,1L28,12.5c-0.1,0.6,0.3,1,0.9,1h1.4c0.6,0,1.1-0.5,1.2-1L32,8h0.5l2.3,4.5c0.3,0.6,0.9,1,1.5,1h1.9
    c0.7,0,1.1-0.3,0.6-1.2l-3-4.6c2.3,0,4.1-2.1,4.1-4.2C39.9,1.9,38.7,0.3,36.6,0.2L36.6,0.2z M36.4,4.2C36.2,5,35.6,5.7,35,5.7h-2.6
    l0.4-3h2.6C36,2.7,36.5,3.4,36.4,4.2L36.4,4.2z M49,0.2l-6,0c-0.5,0-0.9,0.4-1,0.8l-1.7,11.7c-0.1,0.4,0.2,0.8,0.7,0.8l6.1,0
    c2.2,0,4.2-1.7,4.5-3.9c0.2-1.2-0.2-2.2-0.9-2.9c0.7-0.7,1.2-1.6,1.4-2.6C52.3,2.1,51,0.4,49,0.2z M48.3,9.5
    c-0.1,0.8-0.7,1.4-1.4,1.4h-3L44.3,8h3C48,8,48.4,8.7,48.3,9.5z M49.1,4.2C49,5,48.4,5.7,47.7,5.7h-3l0.4-3h3
    C48.8,2.7,49.2,3.4,49.1,4.2z M60.7,0.3l-6,0c-0.5,0-0.9,0.4-1,0.8l-0.1,0.4C54,2.3,54.1,3.1,54,4.1c-0.1,0.9-0.5,1.7-1,2.5
    c0.5,0.9,0.7,2,0.5,3.1c-0.2,1.2-0.7,2.2-1.4,3.1l0,0.1c-0.1,0.4,0.2,0.8,0.7,0.8l6.1,0c2.2,0,4.2-1.7,4.5-3.9
    c0.2-1.2-0.2-2.2-0.9-2.9c0.7-0.7,1.2-1.6,1.4-2.6C64.1,2.1,62.7,0.4,60.7,0.3L60.7,0.3z M60.1,9.5c-0.1,0.8-0.7,1.4-1.4,1.4h-3
    L56.1,8h3C59.7,8,60.2,8.7,60.1,9.5z M60.8,4.2c-0.1,0.8-0.7,1.5-1.4,1.5h-3l0.4-3h3C60.5,2.8,60.9,3.4,60.8,4.2z\"/>
</svg>
";
        craft\helpers\Template::endProfile("template", "verbb-base/_svg/verbb-logo.svg");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "verbb-base/_svg/verbb-logo.svg";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<?xml version=\"1.0\" encoding=\"utf-8\"?>
<svg width=\"63.8px\" height=\"13.8px\" viewBox=\"0 0 63.8 13.8\">
<path style=\"fill:#FFFFFF;\" d=\"M14.2,0.2h-2c-0.4,0-0.9,0.3-1.1,0.7L6.7,10L5.1,1c-0.1-0.5-0.5-0.8-1-0.8H0.7C0.3,0.2-0.1,0.7,0,1.1
    l0.2,0.7c0.1,0.2,0.3,0.4,0.5,0.4h0.8l2.3,10.5c0.1,0.5,0.5,0.8,1.1,0.8h2.5c0.6,0,1.2-0.4,1.5-1l5.8-11.4C15,0.7,14.7,0.2,14.2,0.2
    z M21.4,0c-3.7,0-6.6,2.9-7.5,5.6c-1.4,4.4,1.4,8.2,5.6,8.2c2.6,0,4.9-1.1,6.3-2.4c0.6-0.6,0.2-0.9-0.2-1.2c-0.2-0.1-1-0.5-1-0.5
    c-0.4-0.2-0.9-0.2-1.3,0c-0.6,0.3-1.2,0.9-3.3,0.9c-1.7,0-3-1.2-3.2-2.7c0,0,7.1,0,9.6,0c0.8,0,1.1-0.7,1.1-1.9
    C27.5,2.4,24.9,0,21.4,0L21.4,0z M17.2,5.6c0.7-1.4,2.2-2.5,3.9-2.5c1.6,0,2.8,1,3.2,2.5H17.2z M36.6,0.2l-5.9,0
    c-0.6,0-1.1,0.5-1.2,1L28,12.5c-0.1,0.6,0.3,1,0.9,1h1.4c0.6,0,1.1-0.5,1.2-1L32,8h0.5l2.3,4.5c0.3,0.6,0.9,1,1.5,1h1.9
    c0.7,0,1.1-0.3,0.6-1.2l-3-4.6c2.3,0,4.1-2.1,4.1-4.2C39.9,1.9,38.7,0.3,36.6,0.2L36.6,0.2z M36.4,4.2C36.2,5,35.6,5.7,35,5.7h-2.6
    l0.4-3h2.6C36,2.7,36.5,3.4,36.4,4.2L36.4,4.2z M49,0.2l-6,0c-0.5,0-0.9,0.4-1,0.8l-1.7,11.7c-0.1,0.4,0.2,0.8,0.7,0.8l6.1,0
    c2.2,0,4.2-1.7,4.5-3.9c0.2-1.2-0.2-2.2-0.9-2.9c0.7-0.7,1.2-1.6,1.4-2.6C52.3,2.1,51,0.4,49,0.2z M48.3,9.5
    c-0.1,0.8-0.7,1.4-1.4,1.4h-3L44.3,8h3C48,8,48.4,8.7,48.3,9.5z M49.1,4.2C49,5,48.4,5.7,47.7,5.7h-3l0.4-3h3
    C48.8,2.7,49.2,3.4,49.1,4.2z M60.7,0.3l-6,0c-0.5,0-0.9,0.4-1,0.8l-0.1,0.4C54,2.3,54.1,3.1,54,4.1c-0.1,0.9-0.5,1.7-1,2.5
    c0.5,0.9,0.7,2,0.5,3.1c-0.2,1.2-0.7,2.2-1.4,3.1l0,0.1c-0.1,0.4,0.2,0.8,0.7,0.8l6.1,0c2.2,0,4.2-1.7,4.5-3.9
    c0.2-1.2-0.2-2.2-0.9-2.9c0.7-0.7,1.2-1.6,1.4-2.6C64.1,2.1,62.7,0.4,60.7,0.3L60.7,0.3z M60.1,9.5c-0.1,0.8-0.7,1.4-1.4,1.4h-3
    L56.1,8h3C59.7,8,60.2,8.7,60.1,9.5z M60.8,4.2c-0.1,0.8-0.7,1.5-1.4,1.5h-3l0.4-3h3C60.5,2.8,60.9,3.4,60.8,4.2z\"/>
</svg>
", "verbb-base/_svg/verbb-logo.svg", "/var/www/html/vendor/verbb/base/src/templates/_svg/verbb-logo.svg");
    }
}
