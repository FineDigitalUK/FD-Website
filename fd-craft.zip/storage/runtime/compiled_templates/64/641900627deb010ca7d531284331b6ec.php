<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* navigation/navs/index */
class __TwigTemplate_d6f5e9a51935b250af9415f3c3bdc2db extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'blockContent' => [$this, 'block_blockContent'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "navigation/_layouts";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "navigation/navs/index");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "navigation/navs/index", 2)->unwrap();
        // line 4
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 4, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\admintable\\AdminTableAsset"], "method", false, false, false, 4);
        // line 6
        $context["crumbs"] = [["label" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 7
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 7, $this->source); })()), "navigation", [], "any", false, false, false, 7), "getPluginName", [], "method", false, false, false, 7), "url" => craft\helpers\UrlHelper::url("navigation")], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Navigations", "navigation"), "url" => craft\helpers\UrlHelper::url("navigation/navs")]];
        // line 11
        if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 11, $this->source); })()), "app", [], "any", false, false, false, 11), "getIsMultiSite", [], "method", false, false, false, 11) && (isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 11, $this->source); })()))) {
            // line 12
            $context["crumbs"] = $this->extensions['craft\web\twig\Extension']->unshiftFilter((isset($context["crumbs"]) || array_key_exists("crumbs", $context) ? $context["crumbs"] : (function () { throw new RuntimeError('Variable "crumbs" does not exist.', 12, $this->source); })()), ["id" => "site-crumb", "icon" => "world", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 15
(isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 15, $this->source); })()), "name", [], "any", false, false, false, 15), "site"), "menu" => ["items" => craft\helpers\Cp::siteMenuItems(null,             // line 17
(isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 17, $this->source); })())), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Select site", "site")]]);
        }
        // line 39
        $context["tableData"] = [];
        // line 40
        $context["editableNavs"] = 0;
        // line 42
        $context["canReorder"] = ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 42, $this->source); })()), "can", ["navigation-createNavs"], "method", false, false, false, 42)) ? (true) : (false));
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["navigations"]) || array_key_exists("navigations", $context) ? $context["navigations"] : (function () { throw new RuntimeError('Variable "navigations" does not exist.', 44, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["navigation"]) {
            // line 45
            $context["canDelete"] = ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 45, $this->source); })()), "can", [("navigation-deleteNav:" . craft\helpers\Template::attribute($this->env, $this->source, $context["navigation"], "uid", [], "any", false, false, false, 45))], "method", false, false, false, 45)) ? (true) : (false));
            // line 47
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 47, $this->source); })()), [["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 48
$context["navigation"], "id", [], "any", false, false, false, 48), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 49
$context["navigation"], "name", [], "any", false, false, false, 49), "site"), "url" => craft\helpers\UrlHelper::url(("navigation/navs/build/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 50
$context["navigation"], "id", [], "any", false, false, false, 50))), "name" => $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 51
$context["navigation"], "name", [], "any", false, false, false, 51), "site")), "handle" => craft\helpers\Template::attribute($this->env, $this->source,             // line 52
$context["navigation"], "handle", [], "any", false, false, false, 52), "_showDelete" =>             // line 53
(isset($context["canDelete"]) || array_key_exists("canDelete", $context) ? $context["canDelete"] : (function () { throw new RuntimeError('Variable "canDelete" does not exist.', 53, $this->source); })()), "settings" => ["label" => $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Edit Settings", "navigation")), "url" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 56
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 56, $this->source); })()), "can", [("navigation-editNav:" . craft\helpers\Template::attribute($this->env, $this->source, $context["navigation"], "uid", [], "any", false, false, false, 56))], "method", false, false, false, 56)) ? (craft\helpers\UrlHelper::url(("navigation/navs/edit/" . craft\helpers\Template::attribute($this->env, $this->source, $context["navigation"], "id", [], "any", false, false, false, 56)))) : (""))]]]);
            // line 60
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 60, $this->source); })()), "can", [("navigation-editNav:" . craft\helpers\Template::attribute($this->env, $this->source, $context["navigation"], "uid", [], "any", false, false, false, 60))], "method", false, false, false, 60)) {
                // line 61
                $context["editableNavs"] = ((isset($context["editableNavs"]) || array_key_exists("editableNavs", $context) ? $context["editableNavs"] : (function () { throw new RuntimeError('Variable "editableNavs" does not exist.', 61, $this->source); })()) + 1);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['navigation'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 65
        ob_start();
        // line 66
        yield "    var columns = [
        { name: '__slot:title', title: Craft.t('app', 'Name') },
        { name: '__slot:handle', title: Craft.t('app', 'Handle') },

        ";
        // line 70
        if (((isset($context["editable"]) || array_key_exists("editable", $context) ? $context["editable"] : (function () { throw new RuntimeError('Variable "editable" does not exist.', 70, $this->source); })()) && (isset($context["editableNavs"]) || array_key_exists("editableNavs", $context) ? $context["editableNavs"] : (function () { throw new RuntimeError('Variable "editableNavs" does not exist.', 70, $this->source); })()))) {
            // line 71
            yield "            { name: 'settings', title: Craft.t('app', 'Settings'),
                callback: function(value) {
                    if (value.url) {
                        return '<a href=\"' + value.url + '\">' + value.label + '</a>';
                    }

                    return '';
                }
            },
        ";
        }
        // line 81
        yield "    ];

    new Craft.VueAdminTable({
        columns: columns,
        container: '#navigations-vue-admin-table',
        deleteAction: '";
        // line 86
        yield (((isset($context["editable"]) || array_key_exists("editable", $context) ? $context["editable"] : (function () { throw new RuntimeError('Variable "editable" does not exist.', 86, $this->source); })())) ? ("navigation/navs/delete-nav") : (""));
        yield "',
        emptyMessage: Craft.t('navigation', 'No navigations exist yet.'),
        reorderAction: '";
        // line 88
        yield (((($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["navigations"]) || array_key_exists("navigations", $context) ? $context["navigations"] : (function () { throw new RuntimeError('Variable "navigations" does not exist.', 88, $this->source); })())) > 1) && (isset($context["canReorder"]) || array_key_exists("canReorder", $context) ? $context["canReorder"] : (function () { throw new RuntimeError('Variable "canReorder" does not exist.', 88, $this->source); })()))) ? ("navigation/navs/reorder-nav") : (""));
        yield "',
        tableData: ";
        // line 89
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 89, $this->source); })()));
        yield ",
    });

    // When changing the site select, navigate to the navigation index for that site.
    var \$siteMenuBtn = \$('#header .sitemenubtn:first');

    if (this.\$siteMenuBtn.length) {
        var siteMenu = \$siteMenuBtn.menubtn().data('menubtn').menu;

        siteMenu.on('optionselect', function(ev) {
            siteMenu.\$options.removeClass('sel');
            var \$option = \$(ev.selectedOption).addClass('sel');
            \$siteMenuBtn.html(\$option.html());
            Craft.cp.setSiteId(\$option.data('site-id'));

            location.reload();
        });
    }

";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("navigation/_layouts", "navigation/navs/index", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "navigation/navs/index");
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 24
        yield "    ";
        if (((isset($context["editable"]) || array_key_exists("editable", $context) ? $context["editable"] : (function () { throw new RuntimeError('Variable "editable" does not exist.', 24, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 24, $this->source); })()), "can", ["navigation-createNavs"], "method", false, false, false, 24))) {
            // line 25
            yield "        <div id=\"button-container\">
            <div class=\"btngroup submit\">
                <a class=\"btn submit add icon\" href=\"";
            // line 27
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("navigation/navs/new"), "html", null, true);
            yield "\">
                    ";
            // line 28
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("New navigation", "navigation"), "html", null, true);
            yield "
                </a>
            </div>
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 35
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_blockContent(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "blockContent");
        // line 36
        yield "    <div id=\"navigations-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "blockContent");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "navigation/navs/index";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  199 => 36,  191 => 35,  179 => 28,  175 => 27,  171 => 25,  168 => 24,  160 => 23,  154 => 1,  131 => 89,  127 => 88,  122 => 86,  115 => 81,  103 => 71,  101 => 70,  95 => 66,  93 => 65,  86 => 61,  84 => 60,  82 => 56,  81 => 53,  80 => 52,  79 => 51,  78 => 50,  77 => 49,  76 => 48,  75 => 47,  73 => 45,  69 => 44,  67 => 42,  65 => 40,  63 => 39,  60 => 17,  59 => 15,  58 => 12,  56 => 11,  54 => 7,  53 => 6,  51 => 4,  49 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends 'navigation/_layouts' %}
{% import '_includes/forms' as forms %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% set crumbs = [
    { label: craft.navigation.getPluginName(), url: url('navigation') },
    { label: 'Navigations' | t('navigation'), url: url('navigation/navs') },
] %}

{% if craft.app.getIsMultiSite() and requestedSite %}
    {% set crumbs = crumbs | unshift({
        id: 'site-crumb',
        icon: 'world',
        label: requestedSite.name | t('site'),
        menu: {
            items: siteMenuItems(null, requestedSite),
            label: 'Select site' | t('site')
        },
    }) %}
{% endif %}

{% block actionButton %}
    {% if editable and currentUser.can('navigation-createNavs') %}
        <div id=\"button-container\">
            <div class=\"btngroup submit\">
                <a class=\"btn submit add icon\" href=\"{{ url('navigation/navs/new') }}\">
                    {{ 'New navigation' | t('navigation') }}
                </a>
            </div>
        </div>
    {% endif %}
{% endblock %}

{% block blockContent %}
    <div id=\"navigations-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% set editableNavs = 0 %}

{% set canReorder = currentUser.can('navigation-createNavs') ? true : false %}

{% for navigation in navigations %}
    {% set canDelete = currentUser.can('navigation-deleteNav:' ~ navigation.uid) ? true : false %}

    {% set tableData = tableData | merge([{
        id: navigation.id,
        title: navigation.name | t('site'),
        url: url('navigation/navs/build/' ~ navigation.id),
        name: navigation.name | t('site') | e,
        handle: navigation.handle,
        _showDelete: canDelete,
        settings: {
            label: 'Edit Settings' | t('navigation') | e,
            url: currentUser.can('navigation-editNav:' ~ navigation.uid) ? url('navigation/navs/edit/' ~ navigation.id),
        },
    }]) %}

    {% if currentUser.can('navigation-editNav:' ~ navigation.uid) %}
        {% set editableNavs = editableNavs + 1 %}
    {% endif %}
{% endfor %}

{% js %}
    var columns = [
        { name: '__slot:title', title: Craft.t('app', 'Name') },
        { name: '__slot:handle', title: Craft.t('app', 'Handle') },

        {% if editable and editableNavs %}
            { name: 'settings', title: Craft.t('app', 'Settings'),
                callback: function(value) {
                    if (value.url) {
                        return '<a href=\"' + value.url + '\">' + value.label + '</a>';
                    }

                    return '';
                }
            },
        {% endif %}
    ];

    new Craft.VueAdminTable({
        columns: columns,
        container: '#navigations-vue-admin-table',
        deleteAction: '{{ editable ? 'navigation/navs/delete-nav' : '' }}',
        emptyMessage: Craft.t('navigation', 'No navigations exist yet.'),
        reorderAction: '{{ navigations | length > 1 and canReorder ? 'navigation/navs/reorder-nav' : '' }}',
        tableData: {{ tableData | json_encode | raw }},
    });

    // When changing the site select, navigate to the navigation index for that site.
    var \$siteMenuBtn = \$('#header .sitemenubtn:first');

    if (this.\$siteMenuBtn.length) {
        var siteMenu = \$siteMenuBtn.menubtn().data('menubtn').menu;

        siteMenu.on('optionselect', function(ev) {
            siteMenu.\$options.removeClass('sel');
            var \$option = \$(ev.selectedOption).addClass('sel');
            \$siteMenuBtn.html(\$option.html());
            Craft.cp.setSiteId(\$option.data('site-id'));

            location.reload();
        });
    }

{% endjs %}
", "navigation/navs/index", "/var/www/html/vendor/verbb/navigation/src/templates/navs/index.html");
    }
}
