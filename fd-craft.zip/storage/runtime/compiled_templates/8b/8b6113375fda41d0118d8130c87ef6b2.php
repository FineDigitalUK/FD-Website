<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/sites/_edit.twig */
class __TwigTemplate_5fedab577a10cbbb3d5632de3befc72b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/sites/_edit.twig");
        // line 3
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 4
        $context["fullPageForm"] =  !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 4, $this->source); })());
        // line 6
        $context["formActions"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"), "redirect" => $this->env->getFilter('hash')->getCallable()("settings/sites/{id}"), "shortcut" => true, "retainScroll" => true]];
        // line 15
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "settings/sites/_edit.twig", 15)->unwrap();
        // line 17
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 17, $this->source); })())) {
            // line 18
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 138
        if ((isset($context["brandNewSite"]) || array_key_exists("brandNewSite", $context) ? $context["brandNewSite"] : (function () { throw new RuntimeError('Variable "brandNewSite" does not exist.', 138, $this->source); })())) {
            // line 139
            ob_start();
            // line 140
            yield "        new Craft.HandleGenerator('#name', '#handle');
        new Craft.EnvVarGenerator('#name', '#base-url', {
          prefix: '\$',
          suffix: '_URL',
        });
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 4]);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp.twig", "settings/sites/_edit.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/sites/_edit.twig");
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 22
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 22, $this->source); })())) {
            // line 23
            yield "        ";
            yield craft\helpers\Html::actionInput("sites/save-site");
            yield "
        ";
            // line 24
            yield craft\helpers\Html::redirectInput("settings/sites");
            yield "
        ";
            // line 25
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 25, $this->source); })()), "id", [], "any", false, false, false, 25)) {
                yield craft\helpers\Html::hiddenInput("siteId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 25, $this->source); })()), "id", [], "any", false, false, false, 25));
            }
            // line 26
            yield "    ";
        }
        // line 27
        yield "
    ";
        // line 28
        yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 28, $this->getSourceContext())->macro_selectField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which group should this site belong to?", "app"), "warning" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 32
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 32, $this->source); })()), "id", [], "any", false, false, false, 32) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 32, $this->source); })()), "app", [], "any", false, false, false, 32), "isMultiSite", [], "any", false, false, false, 32))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "group", "name" => "group", "options" =>         // line 35
(isset($context["groupOptions"]) || array_key_exists("groupOptions", $context) ? $context["groupOptions"] : (function () { throw new RuntimeError('Variable "groupOptions" does not exist.', 35, $this->source); })()), "value" =>         // line 36
(isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new RuntimeError('Variable "groupId" does not exist.', 36, $this->source); })()), "disabled" =>         // line 37
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 37, $this->source); })())]]);
        // line 38
        yield "

    <div id=\"site-settings\">
        ";
        // line 41
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 41, $this->getSourceContext())->macro_autosuggestField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this site will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 47
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 47, $this->source); })()), "getName", [false], "method", false, false, false, 47), "suggestEnvVars" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 49
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 49, $this->source); })()), "getErrors", ["name"], "method", false, false, false, 49), "autofocus" => true, "required" => true, "disabled" =>         // line 52
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 52, $this->source); })())]]);
        // line 53
        yield "

        ";
        // line 55
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 55, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this site in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 63
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 63, $this->source); })()), "handle", [], "any", false, false, false, 63), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 64
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 64, $this->source); })()), "getErrors", ["handle"], "method", false, false, false, 64), "required" => true, "disabled" =>         // line 66
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 66, $this->source); })())]]);
        // line 67
        yield "

        ";
        // line 69
        yield $macros["forms"]->getTemplateForMacro("macro_languageMenuField", $context, 69, $this->getSourceContext())->macro_languageMenuField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The language content in this site will use.", "app"), "id" => "language", "name" => "language", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 74
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 74, $this->source); })()), "getLanguage", [false], "method", false, false, false, 74), "options" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 75
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 75, $this->source); })()), "cp", [], "any", false, false, false, 75), "getLanguageOptions", [true], "method", false, false, false, 75), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 76
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 76, $this->source); })()), "getErrors", ["language"], "method", false, false, false, 76), "includeEnvVars" => true, "disabled" =>         // line 78
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 78, $this->source); })())]]);
        // line 79
        yield "

        ";
        // line 81
        if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 81, $this->source); })()), "app", [], "any", false, false, false, 81), "isMultiSite", [], "any", false, false, false, 81) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 81, $this->source); })()), "id", [], "any", false, false, false, 81))) {
            // line 82
            yield "            ";
            yield $macros["forms"]->getTemplateForMacro("macro_booleanMenuField", $context, 82, $this->getSourceContext())->macro_booleanMenuField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Status", "app"), "id" => "enabled", "name" => "enabled", "yesLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "noLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Disabled", "app"), "includeEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 89
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 89, $this->source); })()), "getEnabled", [false], "method", false, false, false, 89), "disabled" => craft\helpers\Template::attribute($this->env, $this->source,             // line 90
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 90, $this->source); })()), "primary", [], "any", false, false, false, 90), "tip" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 91
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 91, $this->source); })()), "primary", [], "any", false, false, false, 91)) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("The primary site cannot be disabled.", "app")) : (null)), "disabled" =>             // line 92
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 92, $this->source); })())]]);
            // line 93
            yield "
        ";
        }
        // line 95
        yield "
        ";
        // line 96
        if (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 96, $this->source); })()), "app", [], "any", false, false, false, 96), "isMultiSite", [], "any", false, false, false, 96) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 96, $this->source); })()), "id", [], "any", false, false, false, 96)) &&  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 96, $this->source); })()), "primary", [], "any", false, false, false, 96))) {
            // line 97
            yield "            ";
            yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 97, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Make this the primary site", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The primary site will be loaded by default on the front end.", "app"), "id" => "primary", "name" => "primary", "on" => craft\helpers\Template::attribute($this->env, $this->source,             // line 102
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 102, $this->source); })()), "primary", [], "any", false, false, false, 102), "disabled" =>             // line 103
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 103, $this->source); })())]]);
            // line 104
            yield "
        ";
        } else {
            // line 106
            yield "            ";
            yield craft\helpers\Html::hiddenInput("primary", "1");
            yield "
        ";
        }
        // line 108
        yield "
        <hr>

        ";
        // line 111
        yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 111, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("This site has its own base URL", "app"), "id" => "has-urls", "name" => "hasUrls", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 115
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 115, $this->source); })()), "hasUrls", [], "any", false, false, false, 115), "toggle" => "url-settings", "disabled" =>         // line 117
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 117, $this->source); })())]]);
        // line 118
        yield "

        <div id=\"url-settings\" class=\"nested-fields";
        // line 120
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 120, $this->source); })()), "hasUrls", [], "any", false, false, false, 120)) {
            yield " hidden";
        }
        yield "\">
            ";
        // line 121
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 121, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The base URL for the site.", "app"), "id" => "base-url", "class" => "ltr", "suggestEnvVars" => true, "suggestAliases" => true, "name" => "baseUrl", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 129
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 129, $this->source); })()), "getBaseUrl", [false], "method", false, false, false, 129), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 130
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 130, $this->source); })()), "getErrors", ["baseUrl"], "method", false, false, false, 130), "disabled" =>         // line 131
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 131, $this->source); })())]]);
        // line 132
        yield "
        </div>
    </div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/sites/_edit.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  206 => 132,  204 => 131,  203 => 130,  202 => 129,  201 => 121,  195 => 120,  191 => 118,  189 => 117,  188 => 115,  187 => 111,  182 => 108,  176 => 106,  172 => 104,  170 => 103,  169 => 102,  167 => 97,  165 => 96,  162 => 95,  158 => 93,  156 => 92,  155 => 91,  154 => 90,  153 => 89,  151 => 82,  149 => 81,  145 => 79,  143 => 78,  142 => 76,  141 => 75,  140 => 74,  139 => 69,  135 => 67,  133 => 66,  132 => 64,  131 => 63,  130 => 55,  126 => 53,  124 => 52,  123 => 49,  122 => 47,  121 => 41,  116 => 38,  114 => 37,  113 => 36,  112 => 35,  111 => 32,  110 => 28,  107 => 27,  104 => 26,  100 => 25,  96 => 24,  91 => 23,  88 => 22,  80 => 21,  74 => 1,  65 => 140,  63 => 139,  61 => 138,  58 => 18,  56 => 17,  54 => 15,  52 => 6,  50 => 4,  48 => 3,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '_layouts/cp.twig' %}

{% set readOnly = readOnly ?? false %}
{% set fullPageForm = not readOnly %}

{% set formActions = [
    {
        label: 'Save and continue editing'|t('app'),
        redirect: 'settings/sites/{id}'|hash,
        shortcut: true,
        retainScroll: true,
    },
] %}

{% import '_includes/forms.twig' as forms %}

{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    {% if not readOnly %}
        {{ actionInput('sites/save-site') }}
        {{ redirectInput('settings/sites') }}
        {% if site.id %}{{ hiddenInput('siteId', site.id) }}{% endif %}
    {% endif %}

    {{ forms.selectField({
        first: true,
        label: \"Group\"|t('app'),
        instructions: \"Which group should this site belong to?\"|t('app'),
        warning: site.id and craft.app.isMultiSite ? 'Changing this may result in data loss.'|t('app'),
        id: 'group',
        name: 'group',
        options: groupOptions,
        value: groupId,
        disabled: readOnly,
    }) }}

    <div id=\"site-settings\">
        {{ forms.autosuggestField({
            first: true,
            label: \"Name\"|t('app'),
            instructions: \"What this site will be called in the control panel.\"|t('app'),
            id: 'name',
            name: 'name',
            value: site.getName(false),
            suggestEnvVars: true,
            errors: site.getErrors('name'),
            autofocus: true,
            required: true,
            disabled: readOnly,
        }) }}

        {{ forms.textField({
            label: \"Handle\"|t('app'),
            instructions: \"How you’ll refer to this site in the templates.\"|t('app'),
            id: 'handle',
            name: 'handle',
            class: 'code',
            autocorrect: false,
            autocapitalize: false,
            value: site.handle,
            errors: site.getErrors('handle'),
            required: true,
            disabled: readOnly,
        }) }}

        {{ forms.languageMenuField({
            label: \"Language\"|t('app'),
            instructions: \"The language content in this site will use.\"|t('app'),
            id: 'language',
            name: 'language',
            value: site.getLanguage(false),
            options: craft.cp.getLanguageOptions(true),
            errors: site.getErrors('language'),
            includeEnvVars: true,
            disabled: readOnly,
        }) }}

        {% if (craft.app.isMultiSite or not site.id) %}
            {{ forms.booleanMenuField({
                label: 'Status'|t('app'),
                id: 'enabled',
                name: 'enabled',
                yesLabel: 'Enabled'|t('app'),
                noLabel: 'Disabled'|t('app'),
                includeEnvVars: true,
                value: site.getEnabled(false),
                disabled: site.primary,
                tip: site.primary ? 'The primary site cannot be disabled.'|t('app') : null,
                disabled: readOnly,
            }) }}
        {% endif %}

        {% if (craft.app.isMultiSite or not site.id) and not site.primary %}
            {{ forms.lightswitchField({
                label: 'Make this the primary site'|t('app'),
                instructions: \"The primary site will be loaded by default on the front end.\"|t('app'),
                id: 'primary',
                name: 'primary',
                on: site.primary,
                disabled: readOnly,
            }) }}
        {% else %}
            {{ hiddenInput('primary', '1') }}
        {% endif %}

        <hr>

        {{ forms.lightswitchField({
            label: \"This site has its own base URL\"|t('app'),
            id: 'has-urls',
            name: 'hasUrls',
            on: site.hasUrls,
            toggle: 'url-settings',
            disabled: readOnly,
        }) }}

        <div id=\"url-settings\" class=\"nested-fields{% if not site.hasUrls %} hidden{% endif %}\">
            {{ forms.autosuggestField({
                label: \"Base URL\"|t('app'),
                instructions: \"The base URL for the site.\"|t('app'),
                id: 'base-url',
                class: 'ltr',
                suggestEnvVars: true,
                suggestAliases: true,
                name: 'baseUrl',
                value: site.getBaseUrl(false),
                errors: site.getErrors('baseUrl'),
                disabled: readOnly,
            }) }}
        </div>
    </div>
{% endblock %}


{% if brandNewSite %}
    {% js on ready %}
        new Craft.HandleGenerator('#name', '#handle');
        new Craft.EnvVarGenerator('#name', '#base-url', {
          prefix: '\$',
          suffix: '_URL',
        });
    {% endjs %}
{% endif %}
", "settings/sites/_edit.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/sites/_edit.twig");
    }
}
