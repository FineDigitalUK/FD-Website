<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _elements/list.twig */
class __TwigTemplate_cb2f8cfa9e09cba6b17e133acab8122d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/list.twig");
        // line 1
        $context["elements"] = (($context["elements"]) ?? ([]));
        // line 2
        $context["disabled"] = (($context["disabled"]) ?? (null));
        // line 3
        $context["viewMode"] = (($context["viewMode"]) ?? (null));
        // line 4
        $context["size"] = (($context["size"]) ?? (((((isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 4, $this->source); })()) == "large")) ? ("large") : ("small"))));
        // line 5
        yield "
";
        // line 6
        $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 7
            yield "  ";
            ob_start();
            // line 15
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 15, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
                // line 16
                yield "      <li>
        ";
                // line 17
                $context["element"] = craft\helpers\Cp::elementChipHtml($context["element"], ["context" => ((                // line 18
$context["context"]) ?? ("index")), "size" =>                 // line 19
(isset($context["size"]) || array_key_exists("size", $context) ? $context["size"] : (function () { throw new RuntimeError('Variable "size" does not exist.', 19, $this->source); })()), "inputName" => ((                // line 20
$context["inputName"]) ?? ((((($context["name"]) ?? (false))) ? ((((($context["single"]) ?? (false))) ? ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 20, $this->source); })())) : (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 20, $this->source); })()) . "[]")))) : (null)))), "showActionMenu" => ((                // line 21
$context["showActionMenu"]) ?? (false)), "checkbox" => ((                // line 22
$context["selectable"]) ?? (false))]);
                // line 24
                yield "        ";
                if ((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 24, $this->source); })())) {
                    // line 25
                    yield "          ";
                    $context["element"] = $this->extensions['craft\web\twig\Extension']->removeClassFilter($context["element"], "removable");
                    // line 26
                    yield "        ";
                }
                // line 27
                yield "        ";
                yield $context["element"];
                yield "
      </li>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['element'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 30
            yield "  ";
            echo craft\helpers\Html::tag("ul", ob_get_clean(), ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["elements", "chips", ("chips-" .             // line 11
(isset($context["size"]) || array_key_exists("size", $context) ? $context["size"] : (function () { throw new RuntimeError('Variable "size" does not exist.', 11, $this->source); })())), ((((            // line 12
$context["inline"]) ?? (false))) ? ("inline-chips") : (null))])]);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 6
        yield Twig\Extension\CoreExtension::spaceless($_v0);
        craft\helpers\Template::endProfile("template", "_elements/list.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_elements/list.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  100 => 6,  96 => 12,  95 => 11,  93 => 30,  83 => 27,  80 => 26,  77 => 25,  74 => 24,  72 => 22,  71 => 21,  70 => 20,  69 => 19,  68 => 18,  67 => 17,  64 => 16,  59 => 15,  56 => 7,  54 => 6,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set elements = elements ?? [] %}
{% set disabled = disabled ?? null %}
{% set viewMode = viewMode ?? null %}
{% set size = size ?? (viewMode == 'large' ? 'large' : 'small') %}

{% apply spaceless %}
  {% tag 'ul' with {
    class: [
      'elements',
      'chips',
      \"chips-#{size}\",
      (inline ?? false) ? 'inline-chips' : null,
    ]|filter,
  } %}
    {% for element in elements %}
      <li>
        {% set element = elementChip(element, {
          context: context ?? 'index',
          size,
          inputName: inputName ?? ((name ?? false) ? ((single ?? false) ? name : \"#{name}[]\") : null),
          showActionMenu: showActionMenu ?? false,
          checkbox: selectable ?? false,
        }) %}
        {% if disabled %}
          {% set element = element|removeClass('removable') %}
        {% endif %}
        {{ element|raw }}
      </li>
    {% endfor %}
  {% endtag %}
{% endapply %}
", "_elements/list.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/list.twig");
    }
}
