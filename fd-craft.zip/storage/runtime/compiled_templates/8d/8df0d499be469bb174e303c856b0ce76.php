<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/fieldtypes/PlainText/settings.twig */
class __TwigTemplate_826bec2a369bcfed9a6002e1386cd35c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/PlainText/settings.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/PlainText/settings.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 3, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("UI Mode", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How the field should be presented in the control panel.", "app"), "id" => "ui-mode", "name" => "uiMode", "options" => [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Normal", "app"), "value" => "normal"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enlarged", "app"), "value" => "enlarged"]], "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 12
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 12, $this->source); })()), "uiMode", [], "any", false, false, false, 12), "disabled" =>         // line 13
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 13, $this->source); })())]]);
        // line 14
        yield "

";
        // line 16
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 16, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Placeholder Text", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The text that will be shown if the field doesn’t have a value.", "app"), "id" => "placeholder", "name" => "placeholder", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 21
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 21, $this->source); })()), "placeholder", [], "any", false, false, false, 21), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 22
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 22, $this->source); })()), "getErrors", ["placeholder"], "method", false, false, false, 22), "disabled" =>         // line 23
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 23, $this->source); })())]]);
        // line 24
        yield "

";
        // line 26
        yield from $this->loadTemplate("_components/fieldtypes/PlainText/settings.twig", "_components/fieldtypes/PlainText/settings.twig", 26, "888282348")->unwrap()->yield(CoreExtension::merge($context, ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Limit", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of characters or bytes the field is allowed to have.", "app"), "id" => "fieldLimit", "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 30
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 30, $this->source); })()), "getErrors", [((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 30, $this->source); })()), "byteLimit", [], "any", false, false, false, 30)) ? ("byteLimit") : ("charLimit"))], "method", false, false, false, 30), "disabled" =>         // line 31
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 31, $this->source); })())]));
        // line 56
        yield "
<fieldset>
    ";
        // line 58
        yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 58, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use a monospaced font", "app"), "name" => "code", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 61
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 61, $this->source); })()), "code", [], "any", false, false, false, 61), "disabled" =>         // line 62
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 62, $this->source); })())]]);
        // line 63
        yield "

    ";
        // line 65
        yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 65, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow line breaks", "app"), "name" => "multiline", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 68
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })()), "multiline", [], "any", false, false, false, 68), "toggle" => "initialRowsContainer", "disabled" =>         // line 70
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 70, $this->source); })())]]);
        // line 71
        yield "
</fieldset>

<div id=\"initialRowsContainer\" class=\"nested-fields";
        // line 74
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 74, $this->source); })()), "multiline", [], "any", false, false, false, 74)) {
            yield " hidden";
        }
        yield "\" data-error-key=\"initialRows\">
    ";
        // line 75
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 75, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Initial Rows", "app"), "id" => "initialRows", "name" => "initialRows", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 79
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 79, $this->source); })()), "initialRows", [], "any", false, false, false, 79), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 81
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 81, $this->source); })()), "getErrors", ["initialRows"], "method", false, false, false, 81), "disabled" =>         // line 82
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 82, $this->source); })())]]);
        // line 83
        yield "
</div>
";
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/PlainText/settings.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/fieldtypes/PlainText/settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  101 => 83,  99 => 82,  98 => 81,  97 => 79,  96 => 75,  90 => 74,  85 => 71,  83 => 70,  82 => 68,  81 => 65,  77 => 63,  75 => 62,  74 => 61,  73 => 58,  69 => 56,  67 => 31,  66 => 30,  65 => 26,  61 => 24,  59 => 23,  58 => 22,  57 => 21,  56 => 16,  52 => 14,  50 => 13,  49 => 12,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{{ forms.selectField({
    label: 'UI Mode'|t('app'),
    instructions: 'How the field should be presented in the control panel.'|t('app'),
    id: 'ui-mode',
    name: 'uiMode',
    options: [
        {label: 'Normal'|t('app'), value: 'normal'},
        {label: 'Enlarged'|t('app'), value: 'enlarged'},
    ],
    value: field.uiMode,
    disabled: readOnly,
}) }}

{{ forms.textField({
    label: \"Placeholder Text\"|t('app'),
    instructions: \"The text that will be shown if the field doesn’t have a value.\"|t('app'),
    id: 'placeholder',
    name: 'placeholder',
    value: field.placeholder,
    errors: field.getErrors('placeholder'),
    disabled: readOnly,
}) }}

{% embed '_includes/forms/field' with {
    label: 'Field Limit'|t('app'),
    instructions: \"The maximum number of characters or bytes the field is allowed to have.\"|t('app'),
    id: 'fieldLimit',
    errors: field.getErrors(field.byteLimit ? 'byteLimit' : 'charLimit'),
    disabled: readOnly,
} %}
    {% import \"_includes/forms\" as forms %}
    {% block input %}
        <div class=\"flex\">
            {{ forms.text({
                id: 'fieldLimit',
                name: 'fieldLimit',
                value: field.charLimit ?? field.byteLimit,
                size: 3,
                disabled: readOnly,
            }) }}
            {{ forms.select({
                id: 'limitUnit',
                name: 'limitUnit',
                options: [
                    { value: 'chars', label: 'Characters'|t('app') },
                    { value: 'bytes', label: 'Bytes'|t('app') },
                ],
                value: field.byteLimit ? 'bytes' : 'chars',
                disabled: readOnly,
            }) }}
        </div>
    {% endblock %}
{% endembed %}

<fieldset>
    {{ forms.lightswitchField({
        label: \"Use a monospaced font\"|t('app'),
        name: 'code',
        on: field.code,
        disabled: readOnly,
    }) }}

    {{ forms.lightswitchField({
        label: \"Allow line breaks\"|t('app'),
        name: 'multiline',
        on: field.multiline,
        toggle: 'initialRowsContainer',
        disabled: readOnly,
    }) }}
</fieldset>

<div id=\"initialRowsContainer\" class=\"nested-fields{% if not field.multiline %} hidden{% endif %}\" data-error-key=\"initialRows\">
    {{ forms.textField({
        label: \"Initial Rows\"|t('app'),
        id: 'initialRows',
        name: 'initialRows',
        value: field.initialRows,
        size: 3,
        errors: field.getErrors('initialRows'),
        disabled: readOnly,
    }) }}
</div>
", "_components/fieldtypes/PlainText/settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fieldtypes/PlainText/settings.twig");
    }
}


/* _components/fieldtypes/PlainText/settings.twig */
class __TwigTemplate_826bec2a369bcfed9a6002e1386cd35c___888282348 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'input' => [$this, 'block_input'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 26
        return "_includes/forms/field";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/PlainText/settings.twig");
        // line 33
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/PlainText/settings.twig", 33)->unwrap();
        // line 26
        $this->parent = $this->loadTemplate("_includes/forms/field", "_components/fieldtypes/PlainText/settings.twig", 26);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/PlainText/settings.twig");
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_input(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "input");
        // line 35
        yield "        <div class=\"flex\">
            ";
        // line 36
        yield $macros["forms"]->getTemplateForMacro("macro_text", $context, 36, $this->getSourceContext())->macro_text(...[["id" => "fieldLimit", "name" => "fieldLimit", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 39
($context["field"] ?? null), "charLimit", [], "any", true, true, false, 39) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "charLimit", [], "any", false, false, false, 39)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "charLimit", [], "any", false, false, false, 39)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 39, $this->source); })()), "byteLimit", [], "any", false, false, false, 39))), "size" => 3, "disabled" =>         // line 41
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 41, $this->source); })())]]);
        // line 42
        yield "
            ";
        // line 43
        yield $macros["forms"]->getTemplateForMacro("macro_select", $context, 43, $this->getSourceContext())->macro_select(...[["id" => "limitUnit", "name" => "limitUnit", "options" => [["value" => "chars", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Characters", "app")], ["value" => "bytes", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Bytes", "app")]], "value" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 50
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 50, $this->source); })()), "byteLimit", [], "any", false, false, false, 50)) ? ("bytes") : ("chars")), "disabled" =>         // line 51
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 51, $this->source); })())]]);
        // line 52
        yield "
        </div>
    ";
        craft\helpers\Template::endProfile("block", "input");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/fieldtypes/PlainText/settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  284 => 52,  282 => 51,  281 => 50,  280 => 43,  277 => 42,  275 => 41,  274 => 39,  273 => 36,  270 => 35,  262 => 34,  256 => 26,  254 => 33,  246 => 26,  101 => 83,  99 => 82,  98 => 81,  97 => 79,  96 => 75,  90 => 74,  85 => 71,  83 => 70,  82 => 68,  81 => 65,  77 => 63,  75 => 62,  74 => 61,  73 => 58,  69 => 56,  67 => 31,  66 => 30,  65 => 26,  61 => 24,  59 => 23,  58 => 22,  57 => 21,  56 => 16,  52 => 14,  50 => 13,  49 => 12,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{{ forms.selectField({
    label: 'UI Mode'|t('app'),
    instructions: 'How the field should be presented in the control panel.'|t('app'),
    id: 'ui-mode',
    name: 'uiMode',
    options: [
        {label: 'Normal'|t('app'), value: 'normal'},
        {label: 'Enlarged'|t('app'), value: 'enlarged'},
    ],
    value: field.uiMode,
    disabled: readOnly,
}) }}

{{ forms.textField({
    label: \"Placeholder Text\"|t('app'),
    instructions: \"The text that will be shown if the field doesn’t have a value.\"|t('app'),
    id: 'placeholder',
    name: 'placeholder',
    value: field.placeholder,
    errors: field.getErrors('placeholder'),
    disabled: readOnly,
}) }}

{% embed '_includes/forms/field' with {
    label: 'Field Limit'|t('app'),
    instructions: \"The maximum number of characters or bytes the field is allowed to have.\"|t('app'),
    id: 'fieldLimit',
    errors: field.getErrors(field.byteLimit ? 'byteLimit' : 'charLimit'),
    disabled: readOnly,
} %}
    {% import \"_includes/forms\" as forms %}
    {% block input %}
        <div class=\"flex\">
            {{ forms.text({
                id: 'fieldLimit',
                name: 'fieldLimit',
                value: field.charLimit ?? field.byteLimit,
                size: 3,
                disabled: readOnly,
            }) }}
            {{ forms.select({
                id: 'limitUnit',
                name: 'limitUnit',
                options: [
                    { value: 'chars', label: 'Characters'|t('app') },
                    { value: 'bytes', label: 'Bytes'|t('app') },
                ],
                value: field.byteLimit ? 'bytes' : 'chars',
                disabled: readOnly,
            }) }}
        </div>
    {% endblock %}
{% endembed %}

<fieldset>
    {{ forms.lightswitchField({
        label: \"Use a monospaced font\"|t('app'),
        name: 'code',
        on: field.code,
        disabled: readOnly,
    }) }}

    {{ forms.lightswitchField({
        label: \"Allow line breaks\"|t('app'),
        name: 'multiline',
        on: field.multiline,
        toggle: 'initialRowsContainer',
        disabled: readOnly,
    }) }}
</fieldset>

<div id=\"initialRowsContainer\" class=\"nested-fields{% if not field.multiline %} hidden{% endif %}\" data-error-key=\"initialRows\">
    {{ forms.textField({
        label: \"Initial Rows\"|t('app'),
        id: 'initialRows',
        name: 'initialRows',
        value: field.initialRows,
        size: 3,
        errors: field.getErrors('initialRows'),
        disabled: readOnly,
    }) }}
</div>
", "_components/fieldtypes/PlainText/settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fieldtypes/PlainText/settings.twig");
    }
}
