<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* __string_template__d45bb153d57fd6fe0ad7a30c1f00c148 */
class __TwigTemplate_99e1d48ca7caeca290cc233cfe73a0c4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__d45bb153d57fd6fe0ad7a30c1f00c148");
        craft\helpers\Template::preloadSingles(['_variables', 'object']);
        // line 1
        yield (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["_variables"]) || array_key_exists("_variables", $context) ? $context["_variables"] : (craft\helpers\Template::fallbackExists("_variables") ? craft\helpers\Template::fallback("_variables") : null)), "url", [], "any", true, true, false, 1) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["_variables"]) || array_key_exists("_variables", $context) ? $context["_variables"] : (craft\helpers\Template::fallbackExists("_variables") ? craft\helpers\Template::fallback("_variables") : null)), "url", [], "any", false, false, false, 1)))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["_variables"]) || array_key_exists("_variables", $context) ? $context["_variables"] : (craft\helpers\Template::fallbackExists("_variables") ? craft\helpers\Template::fallback("_variables") : null)), "url", [], "any", false, false, false, 1)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (craft\helpers\Template::fallbackExists("object") ? craft\helpers\Template::fallback("object") : null)), "url", [], "any", false, false, false, 1)));
        craft\helpers\Template::endProfile("template", "__string_template__d45bb153d57fd6fe0ad7a30c1f00c148");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "__string_template__d45bb153d57fd6fe0ad7a30c1f00c148";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{{ (_variables.url ?? object.url)|raw }}", "__string_template__d45bb153d57fd6fe0ad7a30c1f00c148", "");
    }
}
