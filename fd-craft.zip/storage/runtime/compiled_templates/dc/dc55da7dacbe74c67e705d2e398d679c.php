<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* entries */
class __TwigTemplate_bf3c7ac5f1240d295a43aecef8c8b00d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/elementindex";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "entries");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Entries", "app");
        // line 3
        $context["elementType"] = "craft\\elements\\Entry";
        // line 5
        if (array_key_exists("sectionHandle", $context)) {
            // line 6
            ob_start();
            // line 7
            yield "        window.defaultSectionHandle = \"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["sectionHandle"]) || array_key_exists("sectionHandle", $context) ? $context["sectionHandle"] : (function () { throw new RuntimeError('Variable "sectionHandle" does not exist.', 7, $this->source); })()), "js"), "html", null, true);
            yield "\";
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/elementindex", "entries", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "entries");
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "entries";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  62 => 1,  55 => 7,  53 => 6,  51 => 5,  49 => 3,  47 => 2,  39 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/elementindex\" %}
{% set title = \"Entries\"|t('app') %}
{% set elementType = 'craft\\\\elements\\\\Entry' %}

{% if sectionHandle is defined %}
    {% js %}
        window.defaultSectionHandle = \"{{ sectionHandle|e('js') }}\";
    {% endjs %}
{% endif %}
", "entries", "/var/www/html/vendor/craftcms/cms/src/templates/entries/index.twig");
    }
}
