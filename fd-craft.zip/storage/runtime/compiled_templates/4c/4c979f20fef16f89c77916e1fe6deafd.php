<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/general/_index.twig */
class __TwigTemplate_bef6733181ce876c2702c0e313fe6428 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/general/_index.twig");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/general/_index.twig", 2)->unwrap();
        // line 3
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("General Settings", "app");
        // line 4
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 5
        $context["fullPageForm"] =  !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 5, $this->source); })());
        // line 7
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 11
        $context["formActions"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"), "redirect" => $this->env->getFilter('hash')->getCallable()("settings/general"), "shortcut" => true, "retainScroll" => true]];
        // line 21
        $context["system"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["name" => null, "live" => false, "retryDuration" => null, "timeZone" => "UTC"],         // line 26
(isset($context["system"]) || array_key_exists("system", $context) ? $context["system"] : (function () { throw new RuntimeError('Variable "system" does not exist.', 26, $this->source); })()));
        // line 35
        $macros["_v0"] = $this->macros["_v0"] = $this;
        // line 37
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 37, $this->source); })())) {
            // line 38
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/general/_index.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/general/_index.twig");
    }

    // line 41
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 42
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 42, $this->source); })())) {
            // line 43
            yield "        ";
            yield craft\helpers\Html::actionInput("system-settings/save-general-settings");
            yield "
        ";
            // line 44
            yield craft\helpers\Html::redirectInput("settings");
            yield "
    ";
        }
        // line 46
        yield "
    ";
        // line 47
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 47, $this->getSourceContext())->macro_autosuggestField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("System Name", "app"), "id" => "name", "suggestEnvVars" => true, "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 53
(isset($context["system"]) || array_key_exists("system", $context) ? $context["system"] : (function () { throw new RuntimeError('Variable "system" does not exist.', 53, $this->source); })()), "name", [], "any", false, false, false, 53), "disabled" =>         // line 54
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 54, $this->source); })())]]);
        // line 55
        yield "

    ";
        // line 57
        yield $macros["forms"]->getTemplateForMacro("macro_booleanMenuField", $context, 57, $this->getSourceContext())->macro_booleanMenuField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("System Status", "app"), "warning" => ((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 59
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 59, $this->source); })()), "app", [], "any", false, false, false, 59), "config", [], "any", false, false, false, 59), "general", [], "any", false, false, false, 59), "isSystemLive", [], "any", false, false, false, 59) === true) || (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 59, $this->source); })()), "app", [], "any", false, false, false, 59), "config", [], "any", false, false, false, 59), "general", [], "any", false, false, false, 59), "isSystemLive", [], "any", false, false, false, 59) === false))) ? ($macros["_v0"]->getTemplateForMacro("macro_configWarning", $context, 59, $this->getSourceContext())->macro_configWarning(...["isSystemLive"])) : ("")), "id" => "live", "name" => "live", "yesLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Online", "app"), "noLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Offline", "app"), "includeEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 65
(isset($context["system"]) || array_key_exists("system", $context) ? $context["system"] : (function () { throw new RuntimeError('Variable "system" does not exist.', 65, $this->source); })()), "live", [], "any", false, false, false, 65), "disabled" =>         // line 66
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 66, $this->source); })())]]);
        // line 67
        yield "

    ";
        // line 69
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 69, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Retry Duration", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The number of seconds that the `Retry-After` HTTP header should be set to for 503 responses when the system is offline.", "app"), "id" => "retry-duration", "name" => "retryDuration", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 74
(isset($context["system"]) || array_key_exists("system", $context) ? $context["system"] : (function () { throw new RuntimeError('Variable "system" does not exist.', 74, $this->source); })()), "retryDuration", [], "any", false, false, false, 74), "inputmode" => "numeric", "size" => 4, "disabled" =>         // line 77
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 77, $this->source); })())]]);
        // line 78
        yield "

    ";
        // line 80
        yield $macros["forms"]->getTemplateForMacro("macro_timeZoneField", $context, 80, $this->getSourceContext())->macro_timeZoneField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Time Zone", "app"), "warning" => ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 82
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 82, $this->source); })()), "app", [], "any", false, false, false, 82), "config", [], "any", false, false, false, 82), "general", [], "any", false, false, false, 82), "timezone", [], "any", false, false, false, 82)) ? ($macros["_v0"]->getTemplateForMacro("macro_configWarning", $context, 82, $this->getSourceContext())->macro_configWarning(...["timezone"])) : ("")), "id" => "time-zone", "name" => "timeZone", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 85
(isset($context["system"]) || array_key_exists("system", $context) ? $context["system"] : (function () { throw new RuntimeError('Variable "system" does not exist.', 85, $this->source); })()), "timeZone", [], "any", false, false, false, 85), "includeEnvVars" => true, "disabled" =>         // line 87
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 87, $this->source); })())]]);
        // line 88
        yield "

    ";
        // line 90
        if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 90, $this->source); })()) >= (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 90, $this->source); })()))) {
            // line 91
            yield "        <hr>

        ";
            // line 93
            craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 93, $this->source); })()), "registerTranslations", ["app", ["Are you sure you want to delete the logo?"]], "method", false, false, false, 93);
            // line 96
            yield "
        ";
            // line 97
            craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 97, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\fileupload\\FileUploadAsset"], "method", false, false, false, 97);
            // line 98
            yield "
        ";
            // line 99
            yield $macros["forms"]->getTemplateForMacro("macro_field", $context, 99, $this->getSourceContext())->macro_field(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site Icon", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Square SVG file recommended. The logo will be displayed at {size} by {size}.", "app", ["size" => "32px"]), "disabled" =>             // line 102
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 102, $this->source); })())], Twig\Extension\CoreExtension::include($this->env, $context, "settings/general/_images/icon.twig", ["disabled" =>             // line 103
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 103, $this->source); })())])]);
            yield "

        ";
            // line 105
            yield $macros["forms"]->getTemplateForMacro("macro_field", $context, 105, $this->getSourceContext())->macro_field(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Login Page Logo", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("SVG file recommended. The logo will be displayed at {size} wide.", "app", ["size" => "288px"])], Twig\Extension\CoreExtension::include($this->env, $context, "settings/general/_images/logo.twig", ["disabled" =>             // line 108
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 108, $this->source); })())])]);
            yield "

        <div class=\"clear\"></div>
    ";
        }
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    // line 29
    public function macro_configWarning($setting = null, $file = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "setting" => $setting,
            "file" => $file,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "configWarning");
            // line 30
            yield $this->extensions['craft\web\twig\Extension']->translateFilter("This is being overridden by the {setting} config setting.", "app", ["setting" => (((("<a href=\"https://craftcms.com/docs/5.x/reference/config/general.html#" . Twig\Extension\CoreExtension::lower($this->env->getCharset(),             // line 31
(isset($context["setting"]) || array_key_exists("setting", $context) ? $context["setting"] : (function () { throw new RuntimeError('Variable "setting" does not exist.', 31, $this->source); })()))) . "\" rel=\"noopener\" target=\"_blank\">") . (isset($context["setting"]) || array_key_exists("setting", $context) ? $context["setting"] : (function () { throw new RuntimeError('Variable "setting" does not exist.', 31, $this->source); })())) . "</a>")]);
            craft\helpers\Template::endProfile("macro", "configWarning");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/general/_index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  184 => 31,  183 => 30,  169 => 29,  158 => 108,  157 => 105,  152 => 103,  151 => 102,  150 => 99,  147 => 98,  145 => 97,  142 => 96,  140 => 93,  136 => 91,  134 => 90,  130 => 88,  128 => 87,  127 => 85,  126 => 82,  125 => 80,  121 => 78,  119 => 77,  118 => 74,  117 => 69,  113 => 67,  111 => 66,  110 => 65,  109 => 59,  108 => 57,  104 => 55,  102 => 54,  101 => 53,  100 => 47,  97 => 46,  92 => 44,  87 => 43,  84 => 42,  76 => 41,  70 => 1,  67 => 38,  65 => 37,  63 => 35,  61 => 26,  60 => 21,  58 => 11,  56 => 7,  54 => 5,  52 => 4,  50 => 3,  48 => 2,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% import \"_includes/forms\" as forms %}
{% set title = \"General Settings\"|t('app') %}
{% set readOnly = readOnly ?? false %}
{% set fullPageForm = not readOnly %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% set formActions = [
    {
        label: 'Save and continue editing'|t('app'),
        redirect: 'settings/general'|hash,
        shortcut: true,
        retainScroll: true,
    },
] %}

{# set defaults #}
{% set system = {
    name: null,
    live: false,
    retryDuration: null,
    timeZone: 'UTC',
}|merge(system) %}


{% macro configWarning(setting, file) -%}
    {{ \"This is being overridden by the {setting} config setting.\"|t('app', {
        setting: '<a href=\"https://craftcms.com/docs/5.x/reference/config/general.html#'~setting|lower~'\" rel=\"noopener\" target=\"_blank\">'~setting~'</a>'
    })|raw }}
{%- endmacro %}

{% from _self import configWarning %}

{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    {% if not readOnly %}
        {{ actionInput('system-settings/save-general-settings') }}
        {{ redirectInput('settings') }}
    {% endif %}

    {{ forms.autosuggestField({
        first: true,
        label: \"System Name\"|t('app'),
        id: 'name',
        suggestEnvVars: true,
        name: 'name',
        value: system.name,
        disabled: readOnly,
    }) }}

    {{ forms.booleanMenuField({
        label: \"System Status\"|t('app'),
        warning: (craft.app.config.general.isSystemLive is same as(true) or craft.app.config.general.isSystemLive is same as(false) ? configWarning('isSystemLive')),
        id: 'live',
        name: 'live',
        yesLabel: 'Online'|t('app'),
        noLabel: 'Offline'|t('app'),
        includeEnvVars: true,
        value: system.live,
        disabled: readOnly,
    }) }}

    {{ forms.textField({
        label: 'Retry Duration'|t('app'),
        instructions: 'The number of seconds that the `Retry-After` HTTP header should be set to for 503 responses when the system is offline.'|t('app'),
        id: 'retry-duration',
        name: 'retryDuration',
        value: system.retryDuration,
        inputmode: 'numeric',
        size: 4,
        disabled: readOnly,
    }) }}

    {{ forms.timeZoneField({
        label: \"Time Zone\"|t('app'),
        warning: (craft.app.config.general.timezone ? configWarning('timezone')),
        id: 'time-zone',
        name: 'timeZone',
        value: system.timeZone,
        includeEnvVars: true,
        disabled: readOnly,
    }) }}

    {% if CraftEdition >= CraftPro %}
        <hr>

        {% do view.registerTranslations('app', [
            \"Are you sure you want to delete the logo?\",
        ]) %}

        {% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\fileupload\\\\FileUploadAsset\") %}

        {{ forms.field({
            label: \"Site Icon\"|t('app'),
            instructions: \"Square SVG file recommended. The logo will be displayed at {size} by {size}.\"|t('app', { size: '32px' }),
            disabled: readOnly,
        }, include('settings/general/_images/icon.twig', {'disabled': readOnly})) }}

        {{ forms.field({
            label: \"Login Page Logo\"|t('app'),
            instructions: \"SVG file recommended. The logo will be displayed at {size} wide.\"|t('app', { size: '288px' }),
        }, include('settings/general/_images/logo.twig', {'disabled': readOnly})) }}

        <div class=\"clear\"></div>
    {% endif %}
{% endblock %}
", "settings/general/_index.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/general/_index.twig");
    }
}
