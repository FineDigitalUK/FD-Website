<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/entry-types */
class __TwigTemplate_453cc1aa9dfdc06040f392246f1fd6c7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/entry-types");
        // line 2
        $context["selectedTab"] = "entryTypes";
        // line 4
        $context["readOnly"] =  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", [], "any", false, false, false, 4), "config", [], "any", false, false, false, 4), "general", [], "any", false, false, false, 4), "allowAdminChanges", [], "any", false, false, false, 4);
        // line 6
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 6, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\admintable\\AdminTableAsset"], "method", false, false, false, 6);
        // line 8
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 8, $this->source); })()), "registerTranslations", ["app", ["Are you sure you want to delete “{name}” and all entries of that type?", "Description", "Entry Type", "Handle", "No entry types exist yet.", "No results.", "No usages", "Used by"]], "method", false, false, false, 8);
        // line 19
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Entry Types", "app");
        // line 21
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 34
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 34, $this->source); })())) {
            // line 35
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 42
        ob_start();
        // line 43
        yield "  (() => {
    const columns = [
      { name: 'chip', title: Craft.t('app', 'Entry Type'), sortField: true },
      { name: '__slot:handle', title: Craft.t('app', 'Handle'), sortField: true },
      {
        name: 'usages',
        title: Craft.t('app', 'Used by'),
        callback: (value) => value || `<i class=\"light\">\${Craft.t('app', 'No usages')}</i>`,
      },
    ];

    let config = {
        columns,
        container: '#entrytypes-vue-admin-table',
        emptyMessage: Craft.t('app', 'No entry types exist yet.'),
        tableDataEndpoint: 'entry-types/table-data',
        search: true,
    }

    ";
        // line 62
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 62, $this->source); })())) {
            // line 63
            yield "        config['deleteAction'] = 'entry-types/delete';
        config['deleteConfirmationMessage'] = Craft.t('app', 'Are you sure you want to delete “{name}” and all entries of that type?');
    ";
        }
        // line 66
        yield "
    new Craft.VueAdminTable(config);
  })();
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/entry-types", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/entry-types");
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 29
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 29, $this->source); })())) {
            // line 30
            yield "        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("settings/entry-types/new"), "html", null, true);
            yield "\" class=\"btn submit add icon\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("New entry type", "app"), "html", null, true);
            yield "</a>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 38
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 39
        yield "    <div id=\"entrytypes-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/entry-types";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  139 => 39,  131 => 38,  119 => 30,  116 => 29,  108 => 28,  102 => 1,  96 => 66,  91 => 63,  89 => 62,  68 => 43,  66 => 42,  63 => 35,  61 => 34,  59 => 21,  57 => 19,  55 => 8,  53 => 6,  51 => 4,  49 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '_layouts/cp' %}
{% set selectedTab = 'entryTypes' %}

{% set readOnly = not craft.app.config.general.allowAdminChanges %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% do view.registerTranslations('app', [
    'Are you sure you want to delete “{name}” and all entries of that type?',
    'Description',
    'Entry Type',
    'Handle',
    'No entry types exist yet.',
    'No results.',
    'No usages',
    'Used by',
]) %}

{% set title = 'Entry Types'|t('app') %}

{% set crumbs = [
    {
        label: 'Settings'|t('app'),
        url: url('settings'),
    },
] %}

{% block actionButton %}
    {% if not readOnly %}
        <a href=\"{{ url('settings/entry-types/new') }}\" class=\"btn submit add icon\">{{ \"New entry type\"|t('app') }}</a>
    {% endif %}
{% endblock %}

{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    <div id=\"entrytypes-vue-admin-table\"></div>
{% endblock %}

{% js %}
  (() => {
    const columns = [
      { name: 'chip', title: Craft.t('app', 'Entry Type'), sortField: true },
      { name: '__slot:handle', title: Craft.t('app', 'Handle'), sortField: true },
      {
        name: 'usages',
        title: Craft.t('app', 'Used by'),
        callback: (value) => value || `<i class=\"light\">\${Craft.t('app', 'No usages')}</i>`,
      },
    ];

    let config = {
        columns,
        container: '#entrytypes-vue-admin-table',
        emptyMessage: Craft.t('app', 'No entry types exist yet.'),
        tableDataEndpoint: 'entry-types/table-data',
        search: true,
    }

    {% if not readOnly %}
        config['deleteAction'] = 'entry-types/delete';
        config['deleteConfirmationMessage'] = Craft.t('app', 'Are you sure you want to delete “{name}” and all entries of that type?');
    {% endif %}

    new Craft.VueAdminTable(config);
  })();
{% endjs %}
", "settings/entry-types", "/var/www/html/vendor/craftcms/cms/src/templates/settings/entry-types/index.twig");
    }
}
