<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/widgets/Updates/body.twig */
class __TwigTemplate_f6226110802a6b07c0c999cd7295ea1a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/widgets/Updates/body.twig");
        // line 1
        if ((isset($context["total"]) || array_key_exists("total", $context) ? $context["total"] : (function () { throw new RuntimeError('Variable "total" does not exist.', 1, $this->source); })())) {
            // line 2
            yield "    <p class=\"centeralign\">
        ";
            // line 3
            if (((isset($context["total"]) || array_key_exists("total", $context) ? $context["total"] : (function () { throw new RuntimeError('Variable "total" does not exist.', 3, $this->source); })()) == 1)) {
                // line 4
                yield "            ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("One update available!", "app"), "html", null, true);
                yield "
        ";
            } else {
                // line 6
                yield "            ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("{total} updates available!", "app", ["total" => (isset($context["total"]) || array_key_exists("total", $context) ? $context["total"] : (function () { throw new RuntimeError('Variable "total" does not exist.', 6, $this->source); })())]), "html", null, true);
                yield "
        ";
            }
            // line 8
            yield "        <a class=\"go nowrap\" href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("utilities/updates"), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Go to Updates", "app"), "html", null, true);
            yield "</a>
    </p>
";
        } else {
            // line 11
            yield "    <p class=\"centeralign\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Congrats! You’re up to date.", "app"), "html", null, true);
            yield "</p>
    <p class=\"centeralign\">
        <button type=\"button\" class=\"btn\" data-icon=\"refresh\" aria-label=\"";
            // line 13
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Check again", "app"), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Check again", "app"), "html", null, true);
            yield "</button>
    </p>
";
        }
        craft\helpers\Template::endProfile("template", "_components/widgets/Updates/body.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/widgets/Updates/body.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  77 => 13,  71 => 11,  62 => 8,  56 => 6,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% if total %}
    <p class=\"centeralign\">
        {% if total == 1 %}
            {{ \"One update available!\"|t('app') }}
        {% else %}
            {{ \"{total} updates available!\"|t('app', { total: total }) }}
        {% endif %}
        <a class=\"go nowrap\" href=\"{{ url('utilities/updates') }}\">{{ \"Go to Updates\"|t('app') }}</a>
    </p>
{% else %}
    <p class=\"centeralign\">{{ \"Congrats! You’re up to date.\"|t('app') }}</p>
    <p class=\"centeralign\">
        <button type=\"button\" class=\"btn\" data-icon=\"refresh\" aria-label=\"{{ 'Check again'|t('app') }}\">{{ 'Check again'|t('app') }}</button>
    </p>
{% endif %}
", "_components/widgets/Updates/body.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/widgets/Updates/body.twig");
    }
}
