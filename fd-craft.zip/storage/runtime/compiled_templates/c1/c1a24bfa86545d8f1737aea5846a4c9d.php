<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/tabs.twig */
class __TwigTemplate_9d641839c54eae8a21bda820b99cad77 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/tabs.twig");
        // line 1
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["pane-tabs"], craft\helpers\Html::explodeClass(((        // line 2
$context["class"]) ?? ([]))))], ((        // line 3
$context["containerAttributes"]) ?? ([])), true);
        // line 4
        yield "
";
        // line 5
        $context["selectedTab"] = (($context["selectedTab"]) ?? (Twig\Extension\CoreExtension::first($this->env->getCharset(), Twig\Extension\CoreExtension::keys((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 5, $this->source); })())))));
        // line 6
        $context["tablistLabel"] = (($context["tablistLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Primary fields", "app")));
        // line 7
        $context["tabs"] = $this->extensions['craft\web\twig\Extension']->mapFilter($this->env, (isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 7, $this->source); })()), function ($__tab__, $__tabId__) use ($context, $macros) { $context["tab"] = $__tab__; $context["tabId"] = $__tabId__; return $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tab"]) || array_key_exists("tab", $context) ? $context["tab"] : (function () { throw new RuntimeError('Variable "tab" does not exist.', 7, $this->source); })()), ["selected" => (        // line 8
(isset($context["tabId"]) || array_key_exists("tabId", $context) ? $context["tabId"] : (function () { throw new RuntimeError('Variable "tabId" does not exist.', 8, $this->source); })()) == (isset($context["selectedTab"]) || array_key_exists("selectedTab", $context) ? $context["selectedTab"] : (function () { throw new RuntimeError('Variable "selectedTab" does not exist.', 8, $this->source); })())), "class" => craft\helpers\Html::explodeClass((((craft\helpers\Template::attribute($this->env, $this->source,         // line 9
($context["tab"] ?? null), "class", [], "any", true, true, false, 9) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["tab"] ?? null), "class", [], "any", false, false, false, 9)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["tab"] ?? null), "class", [], "any", false, false, false, 9)) : ([])))]); });
        // line 11
        yield "
";
        // line 12
        ob_start();
        // line 13
        yield "    ";
        $context["tabsHaveErrors"] = false;
        // line 14
        yield "    ";
        ob_start();
        // line 21
        yield "        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 21, $this->source); })()));
        foreach ($context['_seq'] as $context["containerId"] => $context["tab"]) {
            // line 22
            yield "            ";
            $context["containerId"] = $this->env->getFilter('namespaceInputId')->getCallable()($context["containerId"]);
            // line 23
            yield "            ";
            ob_start();
            // line 37
            yield "                ";
            ob_start();
            // line 40
            yield "                    ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "label", [], "any", false, false, false, 40), "html", null, true);
            yield "
                    ";
            // line 41
            if (CoreExtension::inFilter("error", craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "class", [], "any", false, false, false, 41))) {
                // line 42
                yield "                        ";
                ob_start();
                // line 47
                yield "                            ";
                yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["text" => $this->extensions['craft\web\twig\Extension']->translateFilter("This tab contains errors", "app"), "class" => "visually-hidden"]);
                // line 50
                yield "
                        ";
                echo craft\helpers\Html::tag("span", ob_get_clean(), ["data" => ["icon" => "alert"]]);
                // line 52
                yield "                        ";
                $context["tabsHaveErrors"] = true;
                // line 53
                yield "                    ";
            }
            // line 54
            yield "                ";
            echo craft\helpers\Html::tag("span", ob_get_clean(), ["class" => "tab-label"]);
            // line 55
            yield "            ";
            echo craft\helpers\Html::tag("a", ob_get_clean(), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 24
$context["tab"], "tabId", [], "any", true, true, false, 24) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "tabId", [], "any", false, false, false, 24)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "tabId", [], "any", false, false, false, 24)) : (("tab-" . $context["containerId"]))), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(((craft\helpers\Template::attribute($this->env, $this->source,             // line 25
$context["tab"], "selected", [], "any", false, false, false, 25)) ? (["sel"]) : ([])), craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "class", [], "any", false, false, false, 25)), "tabindex" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 26
$context["tab"], "selected", [], "any", false, false, false, 26)) ? ("0") : ("-1")), "href" => craft\helpers\Template::attribute($this->env, $this->source,             // line 27
$context["tab"], "url", [], "any", false, false, false, 27), "role" => "tab", "data" => ["id" =>             // line 30
$context["containerId"]], "aria" => ["controls" =>             // line 33
$context["containerId"], "selected" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 34
$context["tab"], "selected", [], "any", false, false, false, 34)) ? ("true") : ("false"))]]);
            // line 56
            yield "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['containerId'], $context['tab'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        yield "    ";
        echo craft\helpers\Html::tag("div", ob_get_clean(), ["class" => "scrollable", "role" => "tablist", "aria" => ["label" =>         // line 18
(isset($context["tablistLabel"]) || array_key_exists("tablistLabel", $context) ? $context["tablistLabel"] : (function () { throw new RuntimeError('Variable "tablistLabel" does not exist.', 18, $this->source); })())]]);
        // line 58
        yield "    ";
        ob_start();
        // line 70
        $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 71
            yield "            ";
            if ((isset($context["tabsHaveErrors"]) || array_key_exists("tabsHaveErrors", $context) ? $context["tabsHaveErrors"] : (function () { throw new RuntimeError('Variable "tabsHaveErrors" does not exist.', 71, $this->source); })())) {
                // line 72
                yield "                ";
                yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["data" => ["icon" => "alert"]]);
                // line 76
                yield "
            ";
            }
            // line 78
            yield "        ";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 70
        yield Twig\Extension\CoreExtension::spaceless($_v0);
        echo craft\helpers\Html::tag("button", ob_get_clean(), ["type" => "button", "class" => ("btn menubtn hidden" . ((        // line 60
(isset($context["tabsHaveErrors"]) || array_key_exists("tabsHaveErrors", $context) ? $context["tabsHaveErrors"] : (function () { throw new RuntimeError('Variable "tabsHaveErrors" does not exist.', 60, $this->source); })())) ? (" error") : (""))), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("List all tabs", "app"), "aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("List all tabs", "app"), "controls" => "tab-menu"], "data" => ["disclosure-trigger" => true]]);
        // line 80
        yield "    <div id=\"tab-menu\" class=\"menu menu--disclosure\">
        <ul class=\"padded\">
            ";
        // line 82
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 82, $this->source); })()));
        foreach ($context['_seq'] as $context["containerId"] => $context["tab"]) {
            // line 83
            yield "                ";
            $context["containerId"] = $this->env->getFilter('namespaceInputId')->getCallable()($context["containerId"]);
            // line 84
            yield "                <li>
                    ";
            // line 85
            ob_start();
            // line 93
            yield "                        ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "label", [], "any", false, false, false, 93), "html", null, true);
            yield "
                        ";
            // line 94
            if (CoreExtension::inFilter("error", craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "class", [], "any", false, false, false, 94))) {
                // line 95
                yield "                            ";
                ob_start();
                // line 100
                yield "                                ";
                yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["text" => $this->extensions['craft\web\twig\Extension']->translateFilter("This tab contains errors", "app"), "class" => "visually-hidden"]);
                // line 103
                yield "
                            ";
                echo craft\helpers\Html::tag("span", ob_get_clean(), ["data" => ["icon" => "alert"]]);
                // line 105
                yield "                        ";
            }
            // line 106
            yield "                    ";
            echo craft\helpers\Html::tag("a", ob_get_clean(), ["class" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 86
$context["tab"], "selected", [], "any", false, false, false, 86)) ? ("sel") : (null)) . ((CoreExtension::inFilter("error", craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "class", [], "any", false, false, false, 86))) ? (" error") : (null))), "href" => craft\helpers\Template::attribute($this->env, $this->source,             // line 87
$context["tab"], "url", [], "any", false, false, false, 87), "data" => ["id" =>             // line 89
$context["containerId"]], "role" => "button"]);
            // line 107
            yield "                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['containerId'], $context['tab'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 109
        yield "        </ul>
    </div>
";
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 12
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 12, $this->source); })()));
        craft\helpers\Template::endProfile("template", "_includes/tabs.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/tabs.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  205 => 12,  201 => 109,  194 => 107,  192 => 89,  191 => 87,  190 => 86,  188 => 106,  185 => 105,  181 => 103,  178 => 100,  175 => 95,  173 => 94,  168 => 93,  166 => 85,  163 => 84,  160 => 83,  156 => 82,  152 => 80,  150 => 60,  148 => 70,  144 => 78,  140 => 76,  137 => 72,  134 => 71,  132 => 70,  129 => 58,  127 => 18,  125 => 57,  119 => 56,  117 => 34,  116 => 33,  115 => 30,  114 => 27,  113 => 26,  112 => 25,  111 => 24,  109 => 55,  106 => 54,  103 => 53,  100 => 52,  96 => 50,  93 => 47,  90 => 42,  88 => 41,  83 => 40,  80 => 37,  77 => 23,  74 => 22,  69 => 21,  66 => 14,  63 => 13,  61 => 12,  58 => 11,  56 => 9,  55 => 8,  54 => 7,  52 => 6,  50 => 5,  47 => 4,  45 => 3,  44 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set containerAttributes = {
    class: ['pane-tabs']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{% set selectedTab = selectedTab ?? tabs|keys|first %}
{% set tablistLabel = tablistLabel ?? 'Primary fields'|t('app') %}
{% set tabs = tabs|map((tab, tabId) => tab|merge({
    selected: tabId == selectedTab,
        class: (tab.class ?? [])|explodeClass,
})) %}

{% tag 'div' with containerAttributes %}
    {% set tabsHaveErrors = false %}
    {% tag 'div'  with {
        class: 'scrollable',
        role: 'tablist',
        aria: {
            label: tablistLabel,
        },
    } %}
        {% for containerId, tab in tabs %}
            {% set containerId = containerId|namespaceInputId %}
            {% tag 'a' with {
                id: tab.tabId ?? \"tab-#{containerId}\",
                class: (tab.selected ? ['sel'] : [])|merge(tab.class),
                tabindex: tab.selected ? '0' : '-1',
                href: tab.url,
                role: 'tab',
                data: {
                    id: containerId,
                },
                aria: {
                    controls: containerId,
                    selected: tab.selected ? 'true' : 'false',
                },
            } %}
                {% tag 'span' with {
                    class: 'tab-label',
                } %}
                    {{ tab.label }}
                    {% if 'error' in tab.class %}
                        {% tag 'span' with {
                            data: {
                                icon: 'alert',
                            },
                        } %}
                            {{ tag('span', {
                                text: 'This tab contains errors'|t('app'),
                                class: 'visually-hidden',
                            }) }}
                        {% endtag %}
                        {% set tabsHaveErrors = true %}
                    {% endif %}
                {% endtag %}
            {% endtag %}
        {% endfor %}
    {%  endtag %}
    {% tag 'button' with {
        type: 'button',
        class: 'btn menubtn hidden' ~ (tabsHaveErrors ? ' error' : ''),
        title: 'List all tabs'|t('app'),
        aria: {
            label: 'List all tabs'|t('app'),
            controls: 'tab-menu',
        },
        data: {
            'disclosure-trigger': true,
        }
    } %}
        {%- apply spaceless %}
            {% if tabsHaveErrors %}
                {{ tag('span', {
                    data: {
                        icon: 'alert',
                    }
                }) }}
            {% endif %}
        {% endapply -%}
    {% endtag %}
    <div id=\"tab-menu\" class=\"menu menu--disclosure\">
        <ul class=\"padded\">
            {% for containerId, tab in tabs %}
                {% set containerId = containerId|namespaceInputId %}
                <li>
                    {% tag 'a' with {
                        class: (tab.selected ? 'sel' : null) ~ ('error' in tab.class ? ' error' : null),
                        href: tab.url,
                        data: {
                            id: containerId,
                        },
                        role: 'button'
                    } %}
                        {{ tab.label }}
                        {% if 'error' in tab.class %}
                            {% tag 'span' with {
                                data: {
                                    icon: 'alert',
                                },
                            } %}
                                {{ tag('span', {
                                    text: 'This tab contains errors'|t('app'),
                                    class: 'visually-hidden',
                                }) }}
                            {% endtag %}
                        {% endif %}
                    {% endtag %}
                </li>
            {% endfor %}
        </ul>
    </div>
{% endtag %}
", "_includes/tabs.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/tabs.twig");
    }
}
