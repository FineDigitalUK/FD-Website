<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/mailertransportadapters/Smtp/settings.twig */
class __TwigTemplate_de9ce448b7d03efd5fefe09837e5afea extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/mailertransportadapters/Smtp/settings.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/mailertransportadapters/Smtp/settings.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 4
        yield "
";
        // line 5
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 5, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Hostname", "app"), "id" => "host", "name" => "host", "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 10
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 10, $this->source); })()), "host", [], "any", false, false, false, 10), "required" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 12
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 12, $this->source); })()), "getErrors", ["host"], "method", false, false, false, 12), "disabled" =>         // line 13
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 13, $this->source); })())]]);
        // line 14
        yield "

";
        // line 16
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 16, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Port", "app"), "id" => "port", "name" => "port", "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 21
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 21, $this->source); })()), "port", [], "any", false, false, false, 21), "size" => 20, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 23
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 23, $this->source); })()), "getErrors", ["port"], "method", false, false, false, 23), "disabled" =>         // line 24
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 24, $this->source); })())]]);
        // line 25
        yield "

";
        // line 27
        yield $macros["forms"]->getTemplateForMacro("macro_booleanMenuField", $context, 27, $this->getSourceContext())->macro_booleanMenuField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use authentication", "app"), "id" => "useAuthentication", "name" => "useAuthentication", "includeEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 32
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 32, $this->source); })()), "useAuthentication", [], "any", false, false, false, 32), "toggle" => "auth-credentials", "disabled" =>         // line 34
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 34, $this->source); })())]]);
        // line 35
        yield "

<div id=\"auth-credentials\" class=\"nested-fields";
        // line 37
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 37, $this->source); })()), "useAuthentication", [], "any", false, false, false, 37)) {
            yield " hidden";
        }
        yield "\">
    ";
        // line 38
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 38, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Username", "app"), "id" => "username", "name" => "username", "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 43
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 43, $this->source); })()), "username", [], "any", false, false, false, 43), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 44
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 44, $this->source); })()), "getErrors", ["username"], "method", false, false, false, 44), "disabled" =>         // line 45
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 45, $this->source); })())]]);
        // line 46
        yield "

    ";
        // line 48
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 48, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Password", "app"), "id" => "password", "name" => "password", "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 53
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 53, $this->source); })()), "password", [], "any", false, false, false, 53), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 54, $this->source); })()), "getErrors", ["password"], "method", false, false, false, 54), "disabled" =>         // line 55
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 55, $this->source); })())]]);
        // line 56
        yield "
</div>
";
        craft\helpers\Template::endProfile("template", "_components/mailertransportadapters/Smtp/settings.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/mailertransportadapters/Smtp/settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  99 => 56,  97 => 55,  96 => 54,  95 => 53,  94 => 48,  90 => 46,  88 => 45,  87 => 44,  86 => 43,  85 => 38,  79 => 37,  75 => 35,  73 => 34,  72 => 32,  71 => 27,  67 => 25,  65 => 24,  64 => 23,  63 => 21,  62 => 16,  58 => 14,  56 => 13,  55 => 12,  54 => 10,  53 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% set readOnly = readOnly ?? false %}

{{ forms.autosuggestField({
    label: \"Hostname\"|t('app'),
    id: 'host',
    name: 'host',
    suggestEnvVars: true,
    value: adapter.host,
    required: true,
    errors: adapter.getErrors('host'),
    disabled: readOnly,
}) }}

{{ forms.autosuggestField({
    label: \"Port\"|t('app'),
    id: 'port',
    name: 'port',
    suggestEnvVars: true,
    value: adapter.port,
    size: 20,
    errors: adapter.getErrors('port'),
    disabled: readOnly,
}) }}

{{ forms.booleanMenuField({
    label: \"Use authentication\"|t('app'),
    id: 'useAuthentication',
    name: 'useAuthentication',
    includeEnvVars: true,
    value: adapter.useAuthentication,
    toggle: 'auth-credentials',
    disabled: readOnly,
}) }}

<div id=\"auth-credentials\" class=\"nested-fields{% if not adapter.useAuthentication %} hidden{% endif %}\">
    {{ forms.autosuggestField({
        label: \"Username\"|t('app'),
        id: 'username',
        name: 'username',
        suggestEnvVars: true,
        value: adapter.username,
        errors: adapter.getErrors('username'),
        disabled: readOnly,
    }) }}

    {{ forms.autosuggestField({
        label: \"Password\"|t('app'),
        id: 'password',
        name: 'password',
        suggestEnvVars: true,
        value: adapter.password,
        errors: adapter.getErrors('password'),
        disabled: readOnly,
    }) }}
</div>
", "_components/mailertransportadapters/Smtp/settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/mailertransportadapters/Smtp/settings.twig");
    }
}
