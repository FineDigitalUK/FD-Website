<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms.twig */
class __TwigTemplate_f0a7ed239274d1ed9b2e375c01fcb3a2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms.twig");
        // line 4
        yield "

";
        // line 7
        yield "

";
        // line 12
        yield "

";
        // line 21
        yield "

";
        // line 24
        yield "

";
        // line 29
        yield "

";
        // line 34
        yield "

";
        // line 39
        yield "

";
        // line 44
        yield "

";
        // line 49
        yield "

";
        // line 54
        yield "

";
        // line 59
        yield "

";
        // line 64
        yield "

";
        // line 69
        yield "

";
        // line 74
        yield "

";
        // line 79
        yield "

";
        // line 84
        yield "

";
        // line 89
        yield "

";
        // line 94
        yield "

";
        // line 99
        yield "

";
        // line 104
        yield "

";
        // line 109
        yield "

";
        // line 114
        yield "

";
        // line 119
        yield "

";
        // line 124
        yield "

";
        // line 129
        yield "

";
        // line 134
        yield "

";
        // line 139
        yield "

";
        // line 144
        yield "

";
        // line 149
        yield "

";
        // line 154
        yield "

";
        // line 159
        yield "

";
        // line 164
        yield "

";
        // line 169
        yield "

";
        // line 174
        yield "

";
        // line 179
        yield "

";
        // line 184
        yield "

";
        // line 189
        yield "

";
        // line 194
        yield "

";
        // line 199
        yield "

";
        // line 202
        yield "

";
        // line 207
        yield "

";
        // line 213
        yield "

";
        // line 219
        yield "

";
        // line 225
        yield "

";
        // line 231
        yield "

";
        // line 237
        yield "

";
        // line 246
        yield "

";
        // line 252
        yield "

";
        // line 261
        yield "

";
        // line 267
        yield "

";
        // line 273
        yield "

";
        // line 279
        yield "

";
        // line 292
        yield "

";
        // line 298
        yield "

";
        // line 311
        yield "

";
        // line 320
        yield "

";
        // line 329
        yield "

";
        // line 338
        yield "

";
        // line 347
        yield "

";
        // line 353
        yield "

";
        // line 363
        yield "

";
        // line 369
        yield "

";
        // line 375
        yield "

";
        // line 381
        yield "

";
        // line 387
        yield "

";
        // line 393
        yield "

";
        // line 422
        yield "

";
        // line 435
        yield "

";
        // line 441
        yield "

";
        // line 452
        yield "

";
        // line 463
        yield "

";
        // line 476
        yield "

";
        // line 489
        yield "

";
        // line 520
        yield "

";
        // line 526
        yield "

";
        // line 529
        yield "

";
        // line 534
        yield "
";
        craft\helpers\Template::endProfile("template", "_includes/forms.twig");
        yield from [];
    }

    // line 1
    public function macro_errorList($errors = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "errors" => $errors,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "errorList");
            // line 2
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/errorList", "_includes/forms.twig", 2)->unwrap()->yield($context);
            craft\helpers\Template::endProfile("macro", "errorList");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 9
    public function macro_button($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "button");
            // line 10
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/button", "_includes/forms.twig", 10)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 10, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "button");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 14
    public function macro_submitButton($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "submitButton");
            // line 15
            yield "    ";
            yield $this->getTemplateForMacro("macro_button", $context, 15, $this->getSourceContext())->macro_button(...[$this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 15, $this->source); })()), ["type" => "submit", "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((((craft\helpers\Template::attribute($this->env, $this->source,             // line 17
($context["config"] ?? null), "class", [], "any", true, true, false, 17) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "class", [], "any", false, false, false, 17)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "class", [], "any", false, false, false, 17)) : ([]))), ["submit"]), "label" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 18
($context["config"] ?? null), "label", [], "any", true, true, false, 18) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [], "any", false, false, false, 18)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [], "any", false, false, false, 18)) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Submit", "app")))])]);
            // line 19
            yield "
";
            craft\helpers\Template::endProfile("macro", "submitButton");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 26
    public function macro_hidden($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "hidden");
            // line 27
            yield from $this->loadTemplate("_includes/forms/hidden", "_includes/forms.twig", 27)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 27, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "hidden");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 31
    public function macro_text($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "text");
            // line 32
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/text", "_includes/forms.twig", 32)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 32, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "text");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 36
    public function macro_password($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "password");
            // line 37
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/password", "_includes/forms.twig", 37)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 37, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "password");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 41
    public function macro_copytext($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "copytext");
            // line 42
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/copytext", "_includes/forms.twig", 42)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 42, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "copytext");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 46
    public function macro_date($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "date");
            // line 47
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/date", "_includes/forms.twig", 47)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 47, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "date");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 51
    public function macro_time($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "time");
            // line 52
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/time", "_includes/forms.twig", 52)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 52, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "time");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 56
    public function macro_color($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "color");
            // line 57
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/color", "_includes/forms.twig", 57)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 57, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "color");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 61
    public function macro_colorSelect($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "colorSelect");
            // line 62
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/colorSelect", "_includes/forms.twig", 62)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 62, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "colorSelect");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 66
    public function macro_textarea($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "textarea");
            // line 67
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/textarea", "_includes/forms.twig", 67)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 67, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "textarea");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 71
    public function macro_select($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "select");
            // line 72
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/select", "_includes/forms.twig", 72)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 72, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "select");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 76
    public function macro_customSelect($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "customSelect");
            // line 77
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/customSelect", "_includes/forms.twig", 77)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 77, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "customSelect");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 81
    public function macro_selectize($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "selectize");
            // line 82
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/selectize", "_includes/forms.twig", 82)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 82, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "selectize");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 86
    public function macro_multiselect($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "multiselect");
            // line 87
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/multiselect", "_includes/forms.twig", 87)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 87, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "multiselect");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 91
    public function macro_checkbox($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "checkbox");
            // line 92
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/checkbox", "_includes/forms.twig", 92)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 92, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "checkbox");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 96
    public function macro_checkboxGroup($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "checkboxGroup");
            // line 97
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/checkboxGroup", "_includes/forms.twig", 97)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 97, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "checkboxGroup");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 101
    public function macro_checkboxSelect($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "checkboxSelect");
            // line 102
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/checkboxSelect", "_includes/forms.twig", 102)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 102, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "checkboxSelect");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 106
    public function macro_radio($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "radio");
            // line 107
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/radio", "_includes/forms.twig", 107)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 107, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "radio");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 111
    public function macro_radioGroup($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "radioGroup");
            // line 112
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/radioGroup", "_includes/forms.twig", 112)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 112, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "radioGroup");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 116
    public function macro_buttonGroup($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "buttonGroup");
            // line 117
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/buttonGroup", "_includes/forms.twig", 117)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 117, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "buttonGroup");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 121
    public function macro_file($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "file");
            // line 122
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/file", "_includes/forms.twig", 122)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 122, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "file");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 126
    public function macro_lightswitch($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "lightswitch");
            // line 127
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms.twig", 127)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 127, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "lightswitch");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 131
    public function macro_range($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "range");
            // line 132
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/range", "_includes/forms.twig", 132)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 132, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "range");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 136
    public function macro_editableTable($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "editableTable");
            // line 137
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/editableTable", "_includes/forms.twig", 137)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 137, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "editableTable");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 141
    public function macro_elementSelect($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "elementSelect");
            // line 142
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/elementSelect", "_includes/forms.twig", 142)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 142, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "elementSelect");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 146
    public function macro_componentSelect($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "componentSelect");
            // line 147
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/componentSelect", "_includes/forms.twig", 147)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 147, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "componentSelect");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 151
    public function macro_entryTypeSelect($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "entryTypeSelect");
            // line 152
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/entryTypeSelect", "_includes/forms.twig", 152)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 152, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "entryTypeSelect");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 156
    public function macro_autosuggest($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "autosuggest");
            // line 157
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/autosuggest", "_includes/forms.twig", 157)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 157, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "autosuggest");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 161
    public function macro_timeZone($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "timeZone");
            // line 162
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/timeZone", "_includes/forms.twig", 162)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 162, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "timeZone");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 166
    public function macro_iconPicker($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "iconPicker");
            // line 167
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/iconPicker", "_includes/forms.twig", 167)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 167, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "iconPicker");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 171
    public function macro_fs($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "fs");
            // line 172
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/fs", "_includes/forms.twig", 172)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 172, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "fs");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 176
    public function macro_volume($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "volume");
            // line 177
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/volume", "_includes/forms.twig", 177)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 177, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "volume");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 181
    public function macro_booleanMenu($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "booleanMenu");
            // line 182
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/booleanMenu", "_includes/forms.twig", 182)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 182, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "booleanMenu");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 186
    public function macro_languageMenu($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "languageMenu");
            // line 187
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/languageMenu", "_includes/forms.twig", 187)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 187, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "languageMenu");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 191
    public function macro_fieldLayoutDesigner($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "fieldLayoutDesigner");
            // line 192
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/fieldLayoutDesigner", "_includes/forms.twig", 192)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 192, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "fieldLayoutDesigner");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 196
    public function macro_money($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "money");
            // line 197
            yield "    ";
            yield from $this->loadTemplate("_includes/forms/money", "_includes/forms.twig", 197)->unwrap()->yield(CoreExtension::toArray((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 197, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "money");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 204
    public function macro_field($config = null, $input = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "input" => $input,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "field");
            // line 205
            yield "    ";
            yield craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 205, $this->source); })()), "cp", [], "any", false, false, false, 205), "field", [(($context["input"]) ?? ("")), (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 205, $this->source); })())], "method", false, false, false, 205);
            yield "
";
            craft\helpers\Template::endProfile("macro", "field");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 209
    public function macro_textField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "textField");
            // line 210
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 210, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 210) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 210)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 210)) : (("text" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 211
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 211, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 211, $this->source); })()), "template:_includes/forms/text"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "textField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 215
    public function macro_copytextField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "copytextField");
            // line 216
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 216, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 216) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 216)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 216)) : (("copytext" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 217
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 217, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 217, $this->source); })()), "template:_includes/forms/copytext"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "copytextField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 221
    public function macro_passwordField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "passwordField");
            // line 222
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 222, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 222) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 222)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 222)) : (("password" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 223
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 223, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 223, $this->source); })()), "template:_includes/forms/password"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "passwordField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 227
    public function macro_dateField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "dateField");
            // line 228
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 228, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 228) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 228)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 228)) : (("date" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 229
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 229, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 229, $this->source); })()), "template:_includes/forms/date"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "dateField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 233
    public function macro_timeField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "timeField");
            // line 234
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 234, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 234) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 234)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 234)) : (("time" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 235
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 235, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 235, $this->source); })()), "template:_includes/forms/time"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "timeField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 239
    public function macro_colorField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "colorField");
            // line 240
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 240, $this->source); })()), ["fieldset" => true, "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 242
($context["config"] ?? null), "id", [], "any", true, true, false, 242) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 242)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 242)) : (("color" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 244
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 244, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 244, $this->source); })()), "template:_includes/forms/color"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "colorField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 248
    public function macro_colorSelectField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "colorSelectField");
            // line 249
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 249, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 249) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 249)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 249)) : (("colorselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 250
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 250, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 250, $this->source); })()), "template:_includes/forms/colorSelect"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "colorSelectField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 254
    public function macro_dateTimeField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "dateTimeField");
            // line 255
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 255, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 256
($context["config"] ?? null), "id", [], "any", true, true, false, 256) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 256)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 256)) : (("datetime" . Twig\Extension\CoreExtension::random($this->env->getCharset())))), "fieldset" => true]);
            // line 259
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 259, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 259, $this->source); })()), "template:_includes/forms/datetime"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "dateTimeField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 263
    public function macro_textareaField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "textareaField");
            // line 264
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 264, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 264) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 264)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 264)) : (("textarea" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 265
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 265, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 265, $this->source); })()), "template:_includes/forms/textarea"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "textareaField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 269
    public function macro_selectField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "selectField");
            // line 270
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 270, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 270) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 270)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 270)) : (("select" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 271
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 271, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 271, $this->source); })()), "template:_includes/forms/select"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "selectField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 275
    public function macro_customSelectField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "customSelectField");
            // line 276
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 276, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 276) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 276)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 276)) : (("customselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 277
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 277, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 277, $this->source); })()), "template:_includes/forms/customSelect"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "customSelectField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 281
    public function macro_selectizeField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "selectizeField");
            // line 282
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 282, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 282) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 282)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 282)) : (("selectize" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 283
            yield "    ";
            if ((((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", true, true, false, 283) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 283)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 283)) : (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "tip", [], "any", true, true, false, 283)) && (Twig\Extension\CoreExtension::slice($this->env->getCharset(), (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", true, true, false, 283) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 283)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 283)) : ("")), 0, 1) != "\$"))) {
                // line 284
                yield "        ";
                $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 284, $this->source); })()), ["tip" => (((!craft\helpers\Template::attribute($this->env, $this->source,                 // line 285
($context["config"] ?? null), "allowedEnvValues", [], "any", true, true, false, 285))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("This can begin with an environment variable or alias.", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("This can begin with an environment variable.", "app")))]);
                // line 289
                yield "    ";
            }
            // line 290
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 290, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 290, $this->source); })()), "template:_includes/forms/selectize"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "selectizeField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 294
    public function macro_multiselectField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "multiselectField");
            // line 295
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 295, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 295) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 295)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 295)) : (("multiselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 296
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 296, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 296, $this->source); })()), "template:_includes/forms/multiselect"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "multiselectField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 300
    public function macro_checkboxField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "checkboxField");
            // line 301
            yield "    ";
            // line 302
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 302, $this->source); })()), ["fieldset" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 303
($context["config"] ?? null), "fieldset", [], "any", true, true, false, 303) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldset", [], "any", false, false, false, 303)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldset", [], "any", false, false, false, 303)) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLabel", [], "any", true, true, false, 303))), "fieldClass" => $this->extensions['craft\web\twig\Extension']->pushFilter(craft\helpers\Html::explodeClass((((craft\helpers\Template::attribute($this->env, $this->source,             // line 304
($context["config"] ?? null), "fieldClass", [], "any", true, true, false, 304) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [], "any", false, false, false, 304)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [], "any", false, false, false, 304)) : ([]))), "checkboxfield"), "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 305
($context["config"] ?? null), "id", [], "any", true, true, false, 305) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 305)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 305)) : (("checkbox" . Twig\Extension\CoreExtension::random($this->env->getCharset())))), "checkboxLabel" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 306
($context["config"] ?? null), "checkboxLabel", [], "any", true, true, false, 306) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "checkboxLabel", [], "any", false, false, false, 306)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "checkboxLabel", [], "any", false, false, false, 306)) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [], "any", true, true, false, 306) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [], "any", false, false, false, 306)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [], "any", false, false, false, 306)) : (null)))), "instructionsPosition" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 307
($context["config"] ?? null), "instructionsPosition", [], "any", true, true, false, 307) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructionsPosition", [], "any", false, false, false, 307)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructionsPosition", [], "any", false, false, false, 307)) : ("after"))]), "label");
            // line 309
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 309, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 309, $this->source); })()), "template:_includes/forms/checkbox"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "checkboxField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 313
    public function macro_checkboxGroupField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "checkboxGroupField");
            // line 314
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 314, $this->source); })()), ["fieldset" => true, "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 316
($context["config"] ?? null), "id", [], "any", true, true, false, 316) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 316)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 316)) : (("checkboxgroup" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 318
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 318, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 318, $this->source); })()), "template:_includes/forms/checkboxGroup"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "checkboxGroupField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 322
    public function macro_checkboxSelectField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "checkboxSelectField");
            // line 323
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 323, $this->source); })()), ["fieldset" => true, "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 325
($context["config"] ?? null), "id", [], "any", true, true, false, 325) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 325)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 325)) : (("checkboxselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 327
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 327, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 327, $this->source); })()), "template:_includes/forms/checkboxSelect"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "checkboxSelectField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 331
    public function macro_radioGroupField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "radioGroupField");
            // line 332
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 332, $this->source); })()), ["fieldset" => true, "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 334
($context["config"] ?? null), "id", [], "any", true, true, false, 334) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 334)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 334)) : (("radiogroup" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 336
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 336, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 336, $this->source); })()), "template:_includes/forms/radioGroup"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "radioGroupField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 340
    public function macro_buttonGroupField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "buttonGroupField");
            // line 341
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 341, $this->source); })()), ["fieldset" => true, "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 343
($context["config"] ?? null), "id", [], "any", true, true, false, 343) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 343)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 343)) : (("buttongroup" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 345
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 345, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 345, $this->source); })()), "template:_includes/forms/buttonGroup"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "buttonGroupField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 349
    public function macro_fileField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "fileField");
            // line 350
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 350, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 350) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 350)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 350)) : (("file" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 351
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 351, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 351, $this->source); })()), "template:_includes/forms/file"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "fileField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 355
    public function macro_lightswitchField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "lightswitchField");
            // line 356
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 356, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 357
($context["config"] ?? null), "id", [], "any", true, true, false, 357) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 357)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 357)) : (("lightswitch" . Twig\Extension\CoreExtension::random($this->env->getCharset())))), "fieldClass" => $this->extensions['craft\web\twig\Extension']->pushFilter(craft\helpers\Html::explodeClass((((craft\helpers\Template::attribute($this->env, $this->source,             // line 358
($context["config"] ?? null), "fieldClass", [], "any", true, true, false, 358) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [], "any", false, false, false, 358)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [], "any", false, false, false, 358)) : ([]))), "lightswitch-field"), "fieldLabel" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 359
($context["config"] ?? null), "fieldLabel", [], "any", true, true, false, 359) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLabel", [], "any", false, false, false, 359)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLabel", [], "any", false, false, false, 359)) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [], "any", true, true, false, 359) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [], "any", false, false, false, 359)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [], "any", false, false, false, 359)) : (null))))]), "label");
            // line 361
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 361, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 361, $this->source); })()), "template:_includes/forms/lightswitch"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "lightswitchField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 365
    public function macro_rangeField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "rangeField");
            // line 366
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 366, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 366) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 366)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 366)) : (("range" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 367
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 367, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 367, $this->source); })()), "template:_includes/forms/range"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "rangeField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 371
    public function macro_editableTableField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "editableTableField");
            // line 372
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 372, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 372) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 372)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 372)) : (("editabletable" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 373
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 373, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 373, $this->source); })()), "template:_includes/forms/editableTable"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "editableTableField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 377
    public function macro_elementSelectField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "elementSelectField");
            // line 378
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 378, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 378) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 378)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 378)) : (("elementselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 379
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 379, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 379, $this->source); })()), "template:_includes/forms/elementSelect"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "elementSelectField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 383
    public function macro_componentSelectField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "componentSelectField");
            // line 384
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 384, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 384) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 384)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 384)) : (("componentselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 385
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 385, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 385, $this->source); })()), "template:_includes/forms/componentSelect"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "componentSelectField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 389
    public function macro_entryTypeSelectField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "entryTypeSelectField");
            // line 390
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 390, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 390) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 390)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 390)) : (("entrytypeselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 391
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 391, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 391, $this->source); })()), "template:_includes/forms/entryTypeSelect"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "entryTypeSelectField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 395
    public function macro_autosuggestField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "autosuggestField");
            // line 396
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 396, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 397
($context["config"] ?? null), "id", [], "any", true, true, false, 397) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 397)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 397)) : (("autosuggest" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 399
            yield "
    ";
            // line 401
            yield "    ";
            if ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestEnvVars", [], "any", true, true, false, 401) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestEnvVars", [], "any", false, false, false, 401)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestEnvVars", [], "any", false, false, false, 401)) : (false))) {
                // line 402
                yield "        ";
                $context["value"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", true, true, false, 402) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 402)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 402)) : (""));
                // line 403
                yield "        ";
                if (( !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "tip", [], "any", true, true, false, 403) && !CoreExtension::inFilter(Twig\Extension\CoreExtension::slice($this->env->getCharset(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 403, $this->source); })()), 0, 1), ["\$", "@"]))) {
                    // line 404
                    yield "            ";
                    $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 404, $this->source); })()), ["tip" => (((((((craft\helpers\Template::attribute($this->env, $this->source,                     // line 405
($context["config"] ?? null), "suggestAliases", [], "any", true, true, false, 405) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestAliases", [], "any", false, false, false, 405)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestAliases", [], "any", false, false, false, 405)) : (false))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("This can begin with an environment variable or alias.", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("This can begin with an environment variable.", "app"))) . " ") . $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["href" => "https://craftcms.com/docs/5.x/configure.html#control-panel-settings", "class" => "go", "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("Learn more", "app")]))]);
                    // line 413
                    yield "        ";
                } elseif (( !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "warning", [], "any", true, true, false, 413) && (((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 413, $this->source); })()) == "@web") || (Twig\Extension\CoreExtension::slice($this->env->getCharset(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 413, $this->source); })()), 0, 5) == "@web/")))) {
                    // line 414
                    yield "            ";
                    $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 414, $this->source); })()), ["warning" => $this->extensions['craft\web\twig\Extension']->translateFilter("The `@web` alias is not recommended.", "app")]);
                    // line 417
                    yield "        ";
                }
                // line 418
                yield "    ";
            }
            // line 419
            yield "
    ";
            // line 420
            yield $this->getTemplateForMacro("macro_field", $context, 420, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 420, $this->source); })()), "template:_includes/forms/autosuggest"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "autosuggestField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 424
    public function macro_timeZoneField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "timeZoneField");
            // line 425
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 425, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 425) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 425)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 425)) : (("timezone" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 426
            yield "    ";
            if ((((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", true, true, false, 426) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 426)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 426)) : (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "tip", [], "any", true, true, false, 426)) && (Twig\Extension\CoreExtension::slice($this->env->getCharset(), (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", true, true, false, 426) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 426)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 426)) : ("")), 0, 1) != "\$"))) {
                // line 427
                yield "        ";
                $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 427, $this->source); })()), ["tip" => $this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable with a value of a [supported time zone]({url}).", "app", ["url" => "https://www.php.net/manual/en/timezones.php"])]);
                // line 432
                yield "    ";
            }
            // line 433
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 433, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 433, $this->source); })()), "template:_includes/forms/timeZone"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "timeZoneField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 437
    public function macro_iconPickerField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "iconPickerField");
            // line 438
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 438, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 438) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 438)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 438)) : (("iconpicker" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 439
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 439, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 439, $this->source); })()), "template:_includes/forms/iconPicker"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "iconPickerField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 443
    public function macro_fsField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "fsField");
            // line 444
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 444, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 444) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 444)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 444)) : (("fs" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 445
            yield "    ";
            if ((((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", true, true, false, 445) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 445)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 445)) : (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "tip", [], "any", true, true, false, 445)) && (Twig\Extension\CoreExtension::slice($this->env->getCharset(), (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", true, true, false, 445) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 445)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 445)) : ("")), 0, 1) != "\$"))) {
                // line 446
                yield "        ";
                $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 446, $this->source); })()), ["tip" => $this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable matching one of the option values.", "app")]);
                // line 449
                yield "    ";
            }
            // line 450
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 450, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 450, $this->source); })()), "template:_includes/forms/fs"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "fsField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 454
    public function macro_volumeField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "volumeField");
            // line 455
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 455, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 455) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 455)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 455)) : (("volume" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 456
            yield "    ";
            if ((((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", true, true, false, 456) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 456)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 456)) : (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "tip", [], "any", true, true, false, 456)) && (Twig\Extension\CoreExtension::slice($this->env->getCharset(), (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", true, true, false, 456) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 456)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 456)) : ("")), 0, 1) != "\$"))) {
                // line 457
                yield "        ";
                $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 457, $this->source); })()), ["tip" => $this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable matching one of the option values.", "app")]);
                // line 460
                yield "    ";
            }
            // line 461
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 461, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 461, $this->source); })()), "template:_includes/forms/volume"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "volumeField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 465
    public function macro_booleanMenuField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "booleanMenuField");
            // line 466
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 466, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 466) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 466)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 466)) : (("booleanmenu" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 467
            yield "    ";
            if ((((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", true, true, false, 467) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 467)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 467)) : (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "tip", [], "any", true, true, false, 467)) && (Twig\Extension\CoreExtension::slice($this->env->getCharset(), (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", true, true, false, 467) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 467)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 467)) : ("")), 0, 1) != "\$"))) {
                // line 468
                yield "        ";
                $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 468, $this->source); })()), ["tip" => $this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable with a boolean value ({examples}).", "app", ["examples" => "`yes`/`no`/`true`/`false`/`on`/`off`/`0`/`1`"])]);
                // line 473
                yield "    ";
            }
            // line 474
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 474, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 474, $this->source); })()), "template:_includes/forms/booleanMenu"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "booleanMenuField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 478
    public function macro_languageMenuField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "languageMenuField");
            // line 479
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 479, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 479) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 479)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 479)) : (("languagemenu" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 480
            yield "    ";
            if ((((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", true, true, false, 480) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 480)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "includeEnvVars", [], "any", false, false, false, 480)) : (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "tip", [], "any", true, true, false, 480)) && (Twig\Extension\CoreExtension::slice($this->env->getCharset(), (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", true, true, false, 480) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 480)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", false, false, false, 480)) : ("")), 0, 1) != "\$"))) {
                // line 481
                yield "        ";
                $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 481, $this->source); })()), ["tip" => $this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable with a valid language ID ({examples}).", "app", ["examples" => "`en`/`en-GB`"])]);
                // line 486
                yield "    ";
            }
            // line 487
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 487, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 487, $this->source); })()), "template:_includes/forms/languageMenu"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "languageMenuField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 491
    public function macro_fieldLayoutDesignerField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "fieldLayoutDesignerField");
            // line 492
            yield "    <div class=\"fld-cvd\">
    <h2 class=\"visually-hidden\">";
            // line 493
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Field Layout", "app"), "html", null, true);
            yield "</h2>
        ";
            // line 494
            yield $this->getTemplateForMacro("macro_field", $context, 494, $this->getSourceContext())->macro_field(...[$this->extensions['craft\web\twig\Extension']->mergeFilter(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Layout", "app"), "fieldset" => true, "errors" => (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 497
($context["config"] ?? null), "fieldLayout", [], "any", false, true, false, 497), "getErrors", ["customFields"], "method", true, true, false, 497) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLayout", [], "any", false, true, false, 497), "getErrors", ["customFields"], "method", false, false, false, 497)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLayout", [], "any", false, true, false, 497), "getErrors", ["customFields"], "method", false, false, false, 497)) : ([])), "data" => ["error-key" => "fieldLayout.customFields"]],             // line 499
(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 499, $this->source); })())), "template:_includes/forms/fieldLayoutDesigner"]);
            yield "

        ";
            // line 501
            if ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "withGeneratedFields", [], "any", true, true, false, 501) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "withGeneratedFields", [], "any", false, false, false, 501)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "withGeneratedFields", [], "any", false, false, false, 501)) : (false))) {
                // line 502
                yield "            ";
                yield $this->getTemplateForMacro("macro_field", $context, 502, $this->getSourceContext())->macro_field(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Generated Fields", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Define any additional values that should be saved on your elements.", "app"), "errors" => (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,                 // line 505
($context["config"] ?? null), "fieldLayout", [], "any", false, true, false, 505), "getErrors", ["generatedFields"], "method", true, true, false, 505) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLayout", [], "any", false, true, false, 505), "getErrors", ["generatedFields"], "method", false, false, false, 505)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLayout", [], "any", false, true, false, 505), "getErrors", ["generatedFields"], "method", false, false, false, 505)) : ([])), "data" => ["error-key" => "fieldLayout.generatedFields"], "fieldLayout" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 507
($context["config"] ?? null), "fieldLayout", [], "any", true, true, false, 507) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLayout", [], "any", false, false, false, 507)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLayout", [], "any", false, false, false, 507)) : (null)), "disabled" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 508
($context["config"] ?? null), "disabled", [], "any", true, true, false, 508) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "disabled", [], "any", false, false, false, 508)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "disabled", [], "any", false, false, false, 508)) : (false))], "template:_includes/forms/generatedFieldsTable"]);
                // line 509
                yield "
        ";
            }
            // line 511
            yield "
        ";
            // line 512
            if ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "withCardViewDesigner", [], "any", true, true, false, 512) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "withCardViewDesigner", [], "any", false, false, false, 512)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "withCardViewDesigner", [], "any", false, false, false, 512)) : (false))) {
                // line 513
                yield "            ";
                yield from $this->loadTemplate("_includes/forms/cardViewDesigner", "_includes/forms.twig", 513)->unwrap()->yield(CoreExtension::toArray(["fieldLayout" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 514
(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 514, $this->source); })()), "fieldLayout", [], "any", false, false, false, 514), "disabled" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 515
($context["config"] ?? null), "disabled", [], "any", true, true, false, 515) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "disabled", [], "any", false, false, false, 515)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "disabled", [], "any", false, false, false, 515)) : (false))]));
                // line 517
                yield "        ";
            }
            // line 518
            yield "    </div>
";
            craft\helpers\Template::endProfile("macro", "fieldLayoutDesignerField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 522
    public function macro_moneyField($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "moneyField");
            // line 523
            yield "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 523, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true, false, 523) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 523)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", false, false, false, 523)) : (("money" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))]);
            // line 524
            yield "    ";
            yield $this->getTemplateForMacro("macro_field", $context, 524, $this->getSourceContext())->macro_field(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 524, $this->source); })()), "template:_includes/forms/money"]);
            yield "
";
            craft\helpers\Template::endProfile("macro", "moneyField");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 531
    public function macro_optionShortcutLabel($key = null, $shift = null, $alt = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "key" => $key,
            "shift" => $shift,
            "alt" => $alt,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "optionShortcutLabel");
            // line 532
            yield "<span class=\"shortcut\">";
            yield $this->getTemplateForMacro("macro_shortcutText", $context, 532, $this->getSourceContext())->macro_shortcutText(...[(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 532, $this->source); })()), (isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new RuntimeError('Variable "shift" does not exist.', 532, $this->source); })()), (isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new RuntimeError('Variable "alt" does not exist.', 532, $this->source); })())]);
            yield "</span>";
            craft\helpers\Template::endProfile("macro", "optionShortcutLabel");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 535
    public function macro_shortcutText($key = null, $shift = null, $alt = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "key" => $key,
            "shift" => $shift,
            "alt" => $alt,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "shortcutText");
            // line 536
            switch (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 536, $this->source); })()), "app", [], "any", false, false, false, 536), "request", [], "any", false, false, false, 536), "getClientOs", [], "method", false, false, false, 536)) {
                case "Mac":
                {
                    // line 538
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((((((isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new RuntimeError('Variable "alt" does not exist.', 538, $this->source); })())) ? ("⌥") : ("")) . (((isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new RuntimeError('Variable "shift" does not exist.', 538, $this->source); })())) ? ("⇧") : (""))) . "⌘") . (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 538, $this->source); })())), "html", null, true);
                    break;
                }
                default:
                {
                    // line 540
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((("Ctrl+" . (((isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new RuntimeError('Variable "alt" does not exist.', 540, $this->source); })())) ? ("Alt+") : (""))) . (((isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new RuntimeError('Variable "shift" does not exist.', 540, $this->source); })())) ? ("Shift+") : (""))) . (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 540, $this->source); })())), "html", null, true);
                }
            }
            craft\helpers\Template::endProfile("macro", "shortcutText");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  2253 => 540,  2247 => 538,  2243 => 536,  2228 => 535,  2219 => 532,  2204 => 531,  2194 => 524,  2191 => 523,  2178 => 522,  2170 => 518,  2167 => 517,  2165 => 515,  2164 => 514,  2162 => 513,  2160 => 512,  2157 => 511,  2153 => 509,  2151 => 508,  2150 => 507,  2149 => 505,  2147 => 502,  2145 => 501,  2140 => 499,  2139 => 497,  2138 => 494,  2134 => 493,  2131 => 492,  2118 => 491,  2108 => 487,  2105 => 486,  2102 => 481,  2099 => 480,  2096 => 479,  2083 => 478,  2073 => 474,  2070 => 473,  2067 => 468,  2064 => 467,  2061 => 466,  2048 => 465,  2038 => 461,  2035 => 460,  2032 => 457,  2029 => 456,  2026 => 455,  2013 => 454,  2003 => 450,  2000 => 449,  1997 => 446,  1994 => 445,  1991 => 444,  1978 => 443,  1968 => 439,  1965 => 438,  1952 => 437,  1942 => 433,  1939 => 432,  1936 => 427,  1933 => 426,  1930 => 425,  1917 => 424,  1908 => 420,  1905 => 419,  1902 => 418,  1899 => 417,  1896 => 414,  1893 => 413,  1891 => 405,  1889 => 404,  1886 => 403,  1883 => 402,  1880 => 401,  1877 => 399,  1875 => 397,  1873 => 396,  1860 => 395,  1850 => 391,  1847 => 390,  1834 => 389,  1824 => 385,  1821 => 384,  1808 => 383,  1798 => 379,  1795 => 378,  1782 => 377,  1772 => 373,  1769 => 372,  1756 => 371,  1746 => 367,  1743 => 366,  1730 => 365,  1720 => 361,  1718 => 359,  1717 => 358,  1716 => 357,  1714 => 356,  1701 => 355,  1691 => 351,  1688 => 350,  1675 => 349,  1665 => 345,  1663 => 343,  1661 => 341,  1648 => 340,  1638 => 336,  1636 => 334,  1634 => 332,  1621 => 331,  1611 => 327,  1609 => 325,  1607 => 323,  1594 => 322,  1584 => 318,  1582 => 316,  1580 => 314,  1567 => 313,  1557 => 309,  1555 => 307,  1554 => 306,  1553 => 305,  1552 => 304,  1551 => 303,  1549 => 302,  1547 => 301,  1534 => 300,  1524 => 296,  1521 => 295,  1508 => 294,  1498 => 290,  1495 => 289,  1493 => 285,  1491 => 284,  1488 => 283,  1485 => 282,  1472 => 281,  1462 => 277,  1459 => 276,  1446 => 275,  1436 => 271,  1433 => 270,  1420 => 269,  1410 => 265,  1407 => 264,  1394 => 263,  1384 => 259,  1382 => 256,  1380 => 255,  1367 => 254,  1357 => 250,  1354 => 249,  1341 => 248,  1331 => 244,  1329 => 242,  1327 => 240,  1314 => 239,  1304 => 235,  1301 => 234,  1288 => 233,  1278 => 229,  1275 => 228,  1262 => 227,  1252 => 223,  1249 => 222,  1236 => 221,  1226 => 217,  1223 => 216,  1210 => 215,  1200 => 211,  1197 => 210,  1184 => 209,  1174 => 205,  1160 => 204,  1152 => 197,  1139 => 196,  1131 => 192,  1118 => 191,  1110 => 187,  1097 => 186,  1089 => 182,  1076 => 181,  1068 => 177,  1055 => 176,  1047 => 172,  1034 => 171,  1026 => 167,  1013 => 166,  1005 => 162,  992 => 161,  984 => 157,  971 => 156,  963 => 152,  950 => 151,  942 => 147,  929 => 146,  921 => 142,  908 => 141,  900 => 137,  887 => 136,  879 => 132,  866 => 131,  858 => 127,  845 => 126,  837 => 122,  824 => 121,  816 => 117,  803 => 116,  795 => 112,  782 => 111,  774 => 107,  761 => 106,  753 => 102,  740 => 101,  732 => 97,  719 => 96,  711 => 92,  698 => 91,  690 => 87,  677 => 86,  669 => 82,  656 => 81,  648 => 77,  635 => 76,  627 => 72,  614 => 71,  606 => 67,  593 => 66,  585 => 62,  572 => 61,  564 => 57,  551 => 56,  543 => 52,  530 => 51,  522 => 47,  509 => 46,  501 => 42,  488 => 41,  480 => 37,  467 => 36,  459 => 32,  446 => 31,  439 => 27,  426 => 26,  418 => 19,  416 => 18,  415 => 17,  413 => 15,  400 => 14,  392 => 10,  379 => 9,  371 => 2,  358 => 1,  351 => 534,  347 => 529,  343 => 526,  339 => 520,  335 => 489,  331 => 476,  327 => 463,  323 => 452,  319 => 441,  315 => 435,  311 => 422,  307 => 393,  303 => 387,  299 => 381,  295 => 375,  291 => 369,  287 => 363,  283 => 353,  279 => 347,  275 => 338,  271 => 329,  267 => 320,  263 => 311,  259 => 298,  255 => 292,  251 => 279,  247 => 273,  243 => 267,  239 => 261,  235 => 252,  231 => 246,  227 => 237,  223 => 231,  219 => 225,  215 => 219,  211 => 213,  207 => 207,  203 => 202,  199 => 199,  195 => 194,  191 => 189,  187 => 184,  183 => 179,  179 => 174,  175 => 169,  171 => 164,  167 => 159,  163 => 154,  159 => 149,  155 => 144,  151 => 139,  147 => 134,  143 => 129,  139 => 124,  135 => 119,  131 => 114,  127 => 109,  123 => 104,  119 => 99,  115 => 94,  111 => 89,  107 => 84,  103 => 79,  99 => 74,  95 => 69,  91 => 64,  87 => 59,  83 => 54,  79 => 49,  75 => 44,  71 => 39,  67 => 34,  63 => 29,  59 => 24,  55 => 21,  51 => 12,  47 => 7,  43 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% macro errorList(errors) %}
    {% include \"_includes/forms/errorList\" %}
{% endmacro %}


{# Inputs #}


{% macro button(config) %}
    {% include '_includes/forms/button' with config only %}
{% endmacro %}


{% macro submitButton(config) %}
    {{ _self.button(config|merge({
        type: 'submit',
        class: (config.class ?? [])|explodeClass|merge(['submit']),
        label: config.label ?? 'Submit'|t('app'),
    })) }}
{% endmacro %}


{# Inputs #}


{% macro hidden(config) -%}
    {% include \"_includes/forms/hidden\" with config only %}
{%- endmacro %}


{% macro text(config) %}
    {% include \"_includes/forms/text\" with config only %}
{% endmacro %}


{% macro password(config) %}
    {% include \"_includes/forms/password\" with config only %}
{% endmacro %}


{% macro copytext(config) %}
    {% include \"_includes/forms/copytext\" with config only %}
{% endmacro %}


{% macro date(config) %}
    {% include \"_includes/forms/date\" with config only %}
{% endmacro %}


{% macro time(config) %}
    {% include \"_includes/forms/time\" with config only %}
{% endmacro %}


{% macro color(config) %}
    {% include \"_includes/forms/color\" with config only %}
{% endmacro %}


{% macro colorSelect(config) %}
    {% include \"_includes/forms/colorSelect\" with config only %}
{% endmacro %}


{% macro textarea(config) %}
    {% include \"_includes/forms/textarea\" with config only %}
{% endmacro %}


{% macro select(config) %}
    {% include \"_includes/forms/select\" with config only %}
{% endmacro %}


{% macro customSelect(config) %}
    {% include \"_includes/forms/customSelect\" with config only %}
{% endmacro %}


{% macro selectize(config) %}
    {% include \"_includes/forms/selectize\" with config only %}
{% endmacro %}


{% macro multiselect(config) %}
    {% include \"_includes/forms/multiselect\" with config only %}
{% endmacro %}


{% macro checkbox(config) %}
    {% include \"_includes/forms/checkbox\" with config only %}
{% endmacro %}


{% macro checkboxGroup(config) %}
    {% include \"_includes/forms/checkboxGroup\" with config only %}
{% endmacro %}


{% macro checkboxSelect(config) %}
    {% include \"_includes/forms/checkboxSelect\" with config only %}
{% endmacro %}


{% macro radio(config) %}
    {% include \"_includes/forms/radio\" with config only %}
{% endmacro %}


{% macro radioGroup(config) %}
    {% include \"_includes/forms/radioGroup\" with config only %}
{% endmacro %}


{% macro buttonGroup(config) %}
    {% include \"_includes/forms/buttonGroup\" with config only %}
{% endmacro %}


{% macro file(config) %}
    {% include \"_includes/forms/file\" with config only %}
{% endmacro %}


{% macro lightswitch(config) %}
    {% include \"_includes/forms/lightswitch\" with config only %}
{% endmacro %}


{% macro range(config) %}
    {% include \"_includes/forms/range\" with config only %}
{% endmacro %}


{% macro editableTable(config) %}
    {% include \"_includes/forms/editableTable\" with config only %}
{% endmacro %}


{% macro elementSelect(config) %}
    {% include \"_includes/forms/elementSelect\" with config only %}
{% endmacro %}


{% macro componentSelect(config) %}
    {% include \"_includes/forms/componentSelect\" with config only %}
{% endmacro %}


{% macro entryTypeSelect(config) %}
    {% include \"_includes/forms/entryTypeSelect\" with config only %}
{% endmacro %}


{% macro autosuggest(config) %}
    {% include \"_includes/forms/autosuggest\" with config only %}
{% endmacro %}


{% macro timeZone(config) %}
    {% include \"_includes/forms/timeZone\" with config only %}
{% endmacro %}


{% macro iconPicker(config) %}
    {% include '_includes/forms/iconPicker' with config only %}
{% endmacro %}


{% macro fs(config) %}
    {% include \"_includes/forms/fs\" with config only %}
{% endmacro %}


{% macro volume(config) %}
    {% include \"_includes/forms/volume\" with config only %}
{% endmacro %}


{% macro booleanMenu(config) %}
    {% include \"_includes/forms/booleanMenu\" with config only %}
{% endmacro %}


{% macro languageMenu(config) %}
    {% include \"_includes/forms/languageMenu\" with config only %}
{% endmacro %}


{% macro fieldLayoutDesigner(config) %}
    {% include \"_includes/forms/fieldLayoutDesigner\" with config only %}
{% endmacro %}


{% macro money(config) %}
    {% include \"_includes/forms/money\" with config only %}
{% endmacro %}


{# Fields #}


{% macro field(config, input) %}
    {{ craft.cp.field(input ?? '', config)|raw }}
{% endmacro %}


{% macro textField(config) %}
    {% set config = config|merge({id: config.id ?? \"text#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/text') }}
{% endmacro %}


{% macro copytextField(config) %}
    {% set config = config|merge({id: config.id ?? \"copytext#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/copytext') }}
{% endmacro %}


{% macro passwordField(config) %}
    {% set config = config|merge({id: config.id ?? \"password#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/password') }}
{% endmacro %}


{% macro dateField(config) %}
    {% set config = config|merge({id: config.id ?? \"date#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/date') }}
{% endmacro %}


{% macro timeField(config) %}
    {% set config = config|merge({id: config.id ?? \"time#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/time') }}
{% endmacro %}


{% macro colorField(config) %}
    {% set config = config|merge({
        fieldset: true,
        id: config.id ?? \"color#{random()}\"
    }) %}
    {{ _self.field(config, 'template:_includes/forms/color') }}
{% endmacro %}


{% macro colorSelectField(config) %}
    {% set config = config|merge({id: config.id ?? \"colorselect#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/colorSelect') }}
{% endmacro %}


{% macro dateTimeField(config) %}
    {% set config = config|merge({
        id: config.id ?? \"datetime#{random()}\",
        fieldset: true,
    }) %}
    {{ _self.field(config, 'template:_includes/forms/datetime') }}
{% endmacro %}


{% macro textareaField(config) %}
    {% set config = config|merge({id: config.id ?? \"textarea#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/textarea') }}
{% endmacro %}


{% macro selectField(config) %}
    {% set config = config|merge({id: config.id ?? \"select#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/select') }}
{% endmacro %}


{% macro customSelectField(config) %}
    {% set config = config|merge({id: config.id ?? \"customselect#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/customSelect') }}
{% endmacro %}


{% macro selectizeField(config) %}
    {% set config = config|merge({id: config.id ?? \"selectize#{random()}\"}) %}
    {% if (config.includeEnvVars ?? false) and config.tip is not defined and (config.value ?? '')[0:1] != '\$' %}
        {% set config = config|merge({
            tip: (config.allowedEnvValues is not defined)
            ? 'This can begin with an environment variable or alias.'|t('app')
            : 'This can begin with an environment variable.'|t('app'),
        }) %}
    {% endif %}
    {{ _self.field(config, 'template:_includes/forms/selectize') }}
{% endmacro %}


{% macro multiselectField(config) %}
    {% set config = config|merge({id: config.id ?? \"multiselect#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/multiselect') }}
{% endmacro %}


{% macro checkboxField(config) %}
    {# label --> checkboxLabel #}
    {% set config = config|merge({
        fieldset: config.fieldset ?? (config.fieldLabel is defined),
        fieldClass: (config.fieldClass ?? [])|explodeClass|push('checkboxfield'),
        id: config.id ?? \"checkbox#{random()}\",
        checkboxLabel: config.checkboxLabel ?? config.label ?? null,
        instructionsPosition: config.instructionsPosition ?? 'after',
    })|withoutKey('label') %}
    {{ _self.field(config, 'template:_includes/forms/checkbox') }}
{% endmacro %}


{% macro checkboxGroupField(config) %}
    {% set config = config|merge({
        fieldset: true,
        id: config.id ?? \"checkboxgroup#{random()}\",
    }) %}
    {{ _self.field(config, 'template:_includes/forms/checkboxGroup') }}
{% endmacro %}


{% macro checkboxSelectField(config) %}
    {% set config = config|merge({
        fieldset: true,
        id: config.id ?? \"checkboxselect#{random()}\",
    }) %}
    {{ _self.field(config, 'template:_includes/forms/checkboxSelect') }}
{% endmacro %}


{% macro radioGroupField(config) %}
    {% set config = config|merge({
        fieldset: true,
        id: config.id ?? \"radiogroup#{random()}\",
    }) %}
    {{ _self.field(config, 'template:_includes/forms/radioGroup') }}
{% endmacro %}


{% macro buttonGroupField(config) %}
    {% set config = config|merge({
        fieldset: true,
        id: config.id ?? \"buttongroup#{random()}\",
    }) %}
    {{ _self.field(config, 'template:_includes/forms/buttonGroup') }}
{% endmacro %}


{% macro fileField(config) %}
    {% set config = config|merge({id: config.id ?? \"file#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/file') }}
{% endmacro %}


{% macro lightswitchField(config) %}
    {% set config = config|merge({
        id: config.id ?? \"lightswitch#{random()}\",
        fieldClass: (config.fieldClass ?? [])|explodeClass|push('lightswitch-field'),
        fieldLabel: config.fieldLabel ?? config.label ?? null,
    })|withoutKey('label') %}
    {{ _self.field(config, 'template:_includes/forms/lightswitch') }}
{% endmacro %}


{% macro rangeField(config) %}
    {% set config = config|merge({id: config.id ?? \"range#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/range') }}
{% endmacro %}


{% macro editableTableField(config) %}
    {% set config = config|merge({id: config.id ?? \"editabletable#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/editableTable') }}
{% endmacro %}


{% macro elementSelectField(config) %}
    {% set config = config|merge({id: config.id ?? \"elementselect#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/elementSelect') }}
{% endmacro %}


{% macro componentSelectField(config) %}
    {% set config = config|merge({id: config.id ?? \"componentselect#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/componentSelect') }}
{% endmacro %}


{% macro entryTypeSelectField(config) %}
    {% set config = config|merge({id: config.id ?? \"entrytypeselect#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/entryTypeSelect') }}
{% endmacro %}


{% macro autosuggestField(config) %}
    {% set config = config|merge({
        id: config.id ?? \"autosuggest#{random()}\",
    }) %}

    {# Suggest an environment variable / alias? #}
    {% if (config.suggestEnvVars ?? false) %}
        {% set value = config.value ?? '' %}
        {% if config.tip is not defined and value[0:1] not in ['\$', '@'] %}
            {% set config = config|merge({
                tip: ((config.suggestAliases ?? false)
                ? 'This can begin with an environment variable or alias.'|t('app')
                : 'This can begin with an environment variable.'|t('app')) ~ ' ' ~ tag('a', {
                    href: 'https://craftcms.com/docs/5.x/configure.html#control-panel-settings',
                    class: 'go',
                    text: 'Learn more'|t('app'),
                }),
            }) %}
        {% elseif config.warning is not defined and (value == '@web' or value[0:5] == '@web/') %}
            {% set config = config|merge({
                warning: 'The `@web` alias is not recommended.'|t('app'),
            }) %}
        {% endif %}
    {% endif %}

    {{ _self.field(config, 'template:_includes/forms/autosuggest') }}
{% endmacro %}


{% macro timeZoneField(config) %}
    {% set config = config|merge({id: config.id ?? \"timezone#{random()}\"}) %}
    {% if (config.includeEnvVars ?? false) and config.tip is not defined and (config.value ?? '')[0:1] != '\$' %}
        {% set config = config|merge({
            tip: 'This can be set to an environment variable with a value of a [supported time zone]({url}).'|t('app', {
                url: 'https://www.php.net/manual/en/timezones.php',
            }),
        }) %}
    {% endif %}
    {{ _self.field(config, 'template:_includes/forms/timeZone') }}
{% endmacro %}


{% macro iconPickerField(config) %}
    {% set config = config|merge({id: config.id ?? \"iconpicker#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/iconPicker') }}
{% endmacro %}


{% macro fsField(config) %}
    {% set config = config|merge({id: config.id ?? \"fs#{random()}\"}) %}
    {% if (config.includeEnvVars ?? false) and config.tip is not defined and (config.value ?? '')[0:1] != '\$' %}
        {% set config = config|merge({
            tip: 'This can be set to an environment variable matching one of the option values.'|t('app'),
        }) %}
    {% endif %}
    {{ _self.field(config, 'template:_includes/forms/fs') }}
{% endmacro %}


{% macro volumeField(config) %}
    {% set config = config|merge({id: config.id ?? \"volume#{random()}\"}) %}
    {% if (config.includeEnvVars ?? false) and config.tip is not defined and (config.value ?? '')[0:1] != '\$' %}
        {% set config = config|merge({
            tip: 'This can be set to an environment variable matching one of the option values.'|t('app'),
        }) %}
    {% endif %}
    {{ _self.field(config, 'template:_includes/forms/volume') }}
{% endmacro %}


{% macro booleanMenuField(config) %}
    {% set config = config|merge({id: config.id ?? \"booleanmenu#{random()}\"}) %}
    {% if (config.includeEnvVars ?? false) and config.tip is not defined and (config.value ?? '')[0:1] != '\$' %}
        {% set config = config|merge({
            tip: 'This can be set to an environment variable with a boolean value ({examples}).'|t('app', {
                examples: '`yes`/`no`/`true`/`false`/`on`/`off`/`0`/`1`',
            }),
        }) %}
    {% endif %}
    {{ _self.field(config, 'template:_includes/forms/booleanMenu') }}
{% endmacro %}


{% macro languageMenuField(config) %}
    {% set config = config|merge({id: config.id ?? \"languagemenu#{random()}\"}) %}
    {% if (config.includeEnvVars ?? false) and config.tip is not defined and (config.value ?? '')[0:1] != '\$' %}
        {% set config = config|merge({
            tip: 'This can be set to an environment variable with a valid language ID ({examples}).'|t('app', {
                examples: '`en`/`en-GB`',
            }),
        }) %}
    {% endif %}
    {{ _self.field(config, 'template:_includes/forms/languageMenu') }}
{% endmacro %}


{% macro fieldLayoutDesignerField(config) %}
    <div class=\"fld-cvd\">
    <h2 class=\"visually-hidden\">{{ 'Field Layout'|t('app') }}</h2>
        {{ _self.field({
            label: 'Field Layout'|t('app'),
            fieldset: true,
            errors: config.fieldLayout.getErrors('customFields') ?? [],
            data: {'error-key': 'fieldLayout.customFields'},
        }|merge(config), 'template:_includes/forms/fieldLayoutDesigner') }}

        {% if config.withGeneratedFields ?? false %}
            {{ _self.field({
                label: 'Generated Fields'|t('app'),
                instructions: 'Define any additional values that should be saved on your elements.'|t('app'),
                errors: config.fieldLayout.getErrors('generatedFields') ?? [],
                data: {'error-key': 'fieldLayout.generatedFields'},
                fieldLayout: config.fieldLayout ?? null,
                disabled: config.disabled ?? false,
            }, 'template:_includes/forms/generatedFieldsTable') }}
        {% endif %}

        {% if config.withCardViewDesigner ?? false %}
            {% include '_includes/forms/cardViewDesigner' with {
                fieldLayout: config.fieldLayout,
                disabled: config.disabled ?? false,
            } only %}
        {% endif %}
    </div>
{% endmacro %}


{% macro moneyField(config) %}
    {% set config = config|merge({id: config.id ?? \"money#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/money') }}
{% endmacro %}


{# Other #}


{% macro optionShortcutLabel(key, shift, alt) -%}
    <span class=\"shortcut\">{{ _self.shortcutText(key, shift, alt) }}</span>
{%- endmacro %}

{% macro shortcutText(key, shift, alt) %}
    {%- switch craft.app.request.getClientOs() %}
    {%- case 'Mac' %}
        {{- (alt ? '⌥') ~ (shift ? '⇧') ~ '⌘' ~ key }}
    {%- default %}
        {{- 'Ctrl+' ~ (alt ? 'Alt+') ~ (shift ? 'Shift+') ~ key }}
    {%- endswitch %}
{%- endmacro %}
", "_includes/forms.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms.twig");
    }
}
