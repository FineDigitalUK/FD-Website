<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* navigation/navs/_build */
class __TwigTemplate_70d4b4804b6d268a7cf7bfe516431bfa extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'pageTitle' => [$this, 'block_pageTitle'],
            'actionButton' => [$this, 'block_actionButton'],
            'details' => [$this, 'block_details'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 3
        return "navigation/_layouts";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "navigation/navs/_build");
        // line 1
        $context["bodyClass"] = "body-navigation-nodes-index";
        // line 4
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "navigation/navs/_build", 4)->unwrap();
        // line 6
        $context["crumbs"] = [["label" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 7
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 7, $this->source); })()), "navigation", [], "any", false, false, false, 7), "getPluginName", [], "method", false, false, false, 7), "url" => craft\helpers\UrlHelper::url("navigation")], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Navigations", "navigation"), "url" => craft\helpers\UrlHelper::url("navigation/navs")]];
        // line 11
        if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 11, $this->source); })()), "app", [], "any", false, false, false, 11), "getIsMultiSite", [], "method", false, false, false, 11) && (isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 11, $this->source); })()))) {
            // line 12
            $context["crumbs"] = $this->extensions['craft\web\twig\Extension']->unshiftFilter((isset($context["crumbs"]) || array_key_exists("crumbs", $context) ? $context["crumbs"] : (function () { throw new RuntimeError('Variable "crumbs" does not exist.', 12, $this->source); })()), ["id" => "site-crumb", "icon" => "world", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 15
(isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 15, $this->source); })()), "name", [], "any", false, false, false, 15), "site"), "menu" => ["items" => craft\helpers\Cp::siteMenuItems(craft\helpers\Template::attribute($this->env, $this->source,             // line 17
(isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 17, $this->source); })()), "getSites", [], "method", false, false, false, 17), (isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 17, $this->source); })())), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Select site", "site")]]);
        }
        // line 23
        $context["title"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 23, $this->source); })()), "name", [], "any", false, false, false, 23);
        // line 24
        $context["elementType"] = "verbb\\navigation\\elements\\Node";
        // line 25
        $context["elementInstance"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 25, $this->source); })()), "app", [], "any", false, false, false, 25), "elements", [], "any", false, false, false, 25), "createElement", [(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 25, $this->source); })())], "method", false, false, false, 25);
        // line 26
        $context["sources"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 26, $this->source); })()), "app", [], "any", false, false, false, 26), "elementSources", [], "any", false, false, false, 26), "getSources", [(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 26, $this->source); })()), "index", true], "method", false, false, false, 26);
        // line 29
        $context["sources"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, (isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 29, $this->source); })()), function ($__n__) use ($context, $macros) { $context["n"] = $__n__; return (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["n"]) || array_key_exists("n", $context) ? $context["n"] : (function () { throw new RuntimeError('Variable "n" does not exist.', 29, $this->source); })()), "key", [], "any", false, false, false, 29) == ("nav:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 29, $this->source); })()), "uid", [], "any", false, false, false, 29))); });
        // line 3
        $this->parent = $this->loadTemplate("navigation/_layouts", "navigation/navs/_build", 3);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "navigation/navs/_build");
    }

    // line 31
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_pageTitle(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "pageTitle");
        // line 32
        yield "    <h1 class=\"screen-title\" title=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 32, $this->source); })()), "html", null, true);
        yield "\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 32, $this->source); })()), "html", null, true);
        yield "</h1>

    <div id=\"toolbar\" class=\"flex flex-nowrap\">
        ";
        // line 35
        yield from $this->loadTemplate("_elements/toolbar", "navigation/navs/_build", 35)->unwrap()->yield(CoreExtension::merge($context, ["showSiteMenu" => false]));
        // line 38
        yield "    </div>

    <div id=\"actions-container\" class=\"flex\"></div>
";
        craft\helpers\Template::endProfile("block", "pageTitle");
        yield from [];
    }

    // line 43
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 44
        yield "    ";
        if (((isset($context["editable"]) || array_key_exists("editable", $context) ? $context["editable"] : (function () { throw new RuntimeError('Variable "editable" does not exist.', 44, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 44, $this->source); })()), "can", [("navigation-editNav:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 44, $this->source); })()), "uid", [], "any", false, false, false, 44))], "method", false, false, false, 44))) {
            // line 45
            yield "        <div class=\"btngroup submit\">
            <a class=\"btn settings icon\" href=\"";
            // line 46
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::cpUrl(("navigation/navs/edit/" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 46, $this->source); })()), "id", [], "any", false, false, false, 46))), "html", null, true);
            yield "\">
                ";
            // line 47
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "navigation"), "html", null, true);
            yield "
            </a>
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 53
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_details(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 54
        yield "
<div class=\"nav-sidebar navigation-nodes-sidebar\">
    <nav id=\"accordion\" data-vui-tabs>
        <ul class=\"tab-list\">
            ";
        // line 58
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 58, $this->source); })()), "navigation", [], "any", false, false, false, 58), "getBuilderTabs", [(isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 58, $this->source); })())], "method", false, false, false, 58));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["tabId"] => $context["tab"]) {
            // line 59
            yield "                ";
            $context["selected"] = craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 59);
            // line 60
            yield "
                ";
            // line 61
            $context["attributes"] = ["class" => "tab-list-item", "data-id" =>             // line 63
$context["tabId"]];
            // line 65
            yield "
                <li ";
            // line 66
            yield craft\helpers\Html::renderTagAttributes((isset($context["attributes"]) || array_key_exists("attributes", $context) ? $context["attributes"] : (function () { throw new RuntimeError('Variable "attributes" does not exist.', 66, $this->source); })()));
            yield ">
                    <a id=\"tab-";
            // line 67
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["tabId"], "html", null, true);
            yield "\" class=\"tab";
            if ((isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 67, $this->source); })())) {
                yield " sel";
            }
            yield "\" href=\"#pane-";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["tabId"], "html", null, true);
            yield "\" data-href=\"#pane-";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["tabId"], "html", null, true);
            yield "\" title=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "label", [], "any", false, false, false, 67), "html", null, true);
            yield "\">
                        ";
            // line 68
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "label", [], "any", false, false, false, 68), "html", null, true);
            yield "
                    </a>

                    <div id=\"pane-";
            // line 71
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["tabId"], "html", null, true);
            yield "\" class=\"tab-list-pane ";
            if ( !(isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 71, $this->source); })())) {
                yield "hidden";
            }
            yield "\">
                        <form class=\"form-type-";
            // line 72
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "category", [], "any", false, false, false, 72), "html", null, true);
            yield "\" method=\"post\" accept-charset=\"UTF-8\">
                            ";
            // line 73
            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "category", [], "any", false, false, false, 73) == "element")) {
                // line 74
                yield "                                ";
                if (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 74, $this->source); })()), "maxLevels", [], "any", false, false, false, 74) == "") || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 74, $this->source); })()), "maxLevels", [], "any", false, false, false, 74) > 1))) {
                    // line 75
                    yield "                                    ";
                    yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 75, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Parent", "navigation"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Select a navigation item as the parent.", "navigation"), "id" => "parentId", "name" => "parentId", "options" =>                     // line 80
(isset($context["parentOptions"]) || array_key_exists("parentOptions", $context) ? $context["parentOptions"] : (function () { throw new RuntimeError('Variable "parentOptions" does not exist.', 80, $this->source); })()), "class" => "fullwidth js-parent-node"]]);
                    // line 82
                    yield "
                                ";
                }
                // line 84
                yield "
                                ";
                // line 85
                yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 85, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Open in new window", "navigation"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether to open this navigation item in a new window.", "navigation"), "id" => "newWindow", "name" => "newWindow", "on" => false]]);
                // line 91
                yield "

                                ";
                // line 93
                yield craft\helpers\Html::hiddenInput("type", craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "type", [], "any", false, false, false, 93));
                yield "

                                <div class=\"buttons\">
                                    ";
                // line 96
                $context["attributes"] = ["type" => "submit", "class" => "btn submit add icon js-btn-element-add", "data-element-type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 99
$context["tab"], "type", [], "any", false, false, false, 99), "data-sources" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 100
$context["tab"], "sources", [], "any", false, false, false, 100)];
                // line 102
                yield "
                                    <button ";
                // line 103
                yield craft\helpers\Html::renderTagAttributes((isset($context["attributes"]) || array_key_exists("attributes", $context) ? $context["attributes"] : (function () { throw new RuntimeError('Variable "attributes" does not exist.', 103, $this->source); })()));
                yield ">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "button", [], "any", false, false, false, 103), "html", null, true);
                yield "</button>
                                    <div class=\"spinner hidden\"></div>
                                </div>
                            ";
            } elseif ((craft\helpers\Template::attribute($this->env, $this->source,             // line 106
$context["tab"], "category", [], "any", false, false, false, 106) == "nodeType")) {
                // line 107
                yield "                                ";
                if (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 107, $this->source); })()), "maxLevels", [], "any", false, false, false, 107) == "") || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 107, $this->source); })()), "maxLevels", [], "any", false, false, false, 107) > 1))) {
                    // line 108
                    yield "                                    ";
                    yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 108, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Parent", "navigation"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Select a navigation item as the parent.", "navigation"), "id" => "parentId", "name" => "parentId", "options" =>                     // line 113
(isset($context["parentOptions"]) || array_key_exists("parentOptions", $context) ? $context["parentOptions"] : (function () { throw new RuntimeError('Variable "parentOptions" does not exist.', 113, $this->source); })()), "class" => "fullwidth js-parent-node"]]);
                    // line 115
                    yield "
                                ";
                }
                // line 117
                yield "
                                ";
                // line 118
                if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "nodeType", [], "any", false, false, false, 118), "hasNewWindow", [], "method", false, false, false, 118)) {
                    // line 119
                    yield "                                    ";
                    yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 119, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Open in new window", "navigation"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether to open this navigation item in a new window.", "navigation"), "id" => "newWindow", "name" => "newWindow", "on" => false]]);
                    // line 125
                    yield "
                                ";
                }
                // line 127
                yield "
                                ";
                // line 128
                if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "nodeType", [], "any", false, false, false, 128), "hasTitle", [], "method", false, false, false, 128)) {
                    // line 129
                    yield "                                    ";
                    yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 129, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "navigation"), "id" => "title", "name" => "title", "first" => true, "required" => true, "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name of this node in the navigation.", "navigation")]]);
                    // line 136
                    yield "
                                ";
                }
                // line 138
                yield "
                                ";
                // line 139
                if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "nodeType", [], "any", false, false, false, 139), "hasUrl", [], "method", false, false, false, 139)) {
                    // line 140
                    yield "                                    ";
                    yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 140, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("URL", "navigation"), "id" => "url", "name" => "url", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The URL of this node.", "navigation")]]);
                    // line 145
                    yield "
                                ";
                }
                // line 147
                yield "
                                <div class=\"node-type-data\">
                                    ";
                // line 149
                $_namespace = "data";
                if ($_namespace !== null && $_namespace !== '') {
                    $_originalNamespace = Craft::$app->getView()->getNamespace();
                    Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                    ob_start();
                    try {
                        // line 150
                        yield "                                        ";
                        yield craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "nodeType", [], "any", false, false, false, 150), "getSettingsHtml", [], "method", false, false, false, 150);
                        yield "
                                    ";
                    } catch (Exception $e) {
                        ob_end_clean();

                        throw $e;
                    }
                    echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
                    Craft::$app->getView()->setNamespace($_originalNamespace);
                } else {
                    yield "                                        ";
                    yield craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "nodeType", [], "any", false, false, false, 150), "getSettingsHtml", [], "method", false, false, false, 150);
                    yield "
                                    ";
                }
                unset($_originalNamespace, $_namespace);
                // line 152
                yield "                                </div>

                                ";
                // line 154
                yield craft\helpers\Html::hiddenInput("type", craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "type", [], "any", false, false, false, 154));
                yield "

                                <div class=\"buttons\">
                                    <button type=\"submit\" class=\"btn submit add icon\">";
                // line 157
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "button", [], "any", false, false, false, 157), "html", null, true);
                yield "</button>
                                    <div class=\"spinner hidden\"></div>
                                </div>
                            ";
            }
            // line 161
            yield "                        </form>
                    </div>
                </li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['tabId'], $context['tab'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 165
        yield "        </ul>
    </nav>
</div>

";
        craft\helpers\Template::endProfile("block", "details");
        yield from [];
    }

    // line 171
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 172
        yield "
";
        // line 173
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 173, $this->source); })()), "instructions", [], "any", false, false, false, 173)) {
            // line 174
            yield "    <div id=\"js-navigation-nodes-instructions\" class=\"hidden\">
        <div class=\"navigation-nodes-instructions\">
            <p>";
            // line 176
            yield $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 176, $this->source); })()), "instructions", [], "any", false, false, false, 176));
            yield "</p>
        </div>
    </div>
";
        }
        // line 180
        yield "
<div id=\"navigation-nodes-index\">
    <div id=\"sidebar-container\" class=\"hidden\">
        <div id=\"sidebar\" class=\"sidebar\">
            <nav aria-label=\"";
        // line 184
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Sources", "app"), "html", null, true);
        yield "\">
                ";
        // line 185
        yield from $this->loadTemplate("_elements/sources", "navigation/navs/_build", 185)->unwrap()->yield($context);
        // line 186
        yield "            </nav>
        </div>
    </div>

    <div class=\"main element-index\">
        <div class=\"elements busy\">
            <div class=\"update-spinner spinner spinner-absolute\"></div>
        </div>
    </div>
</div>

";
        // line 197
        ob_start();
        // line 198
        yield "    Craft.elementIndex = Craft.createElementIndex('";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 198, $this->source); })()), "js"), "html", null, true);
        yield "', \$('.body-navigation-nodes-index #main-container'), {
        elementTypeName: '";
        // line 199
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 199, $this->source); })()), "displayName", [], "method", false, false, false, 199), "js"), "html", null, true);
        yield "',
        elementTypePluralName: '";
        // line 200
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 200, $this->source); })()), "pluralDisplayName", [], "method", false, false, false, 200), "js"), "html", null, true);
        yield "',
        context: 'index',
        storageKey: 'elementindex.";
        // line 202
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 202, $this->source); })()), "js"), "html", null, true);
        yield "',
        criteria: Craft.defaultIndexCriteria,
        toolbarSelector: '#toolbar',
        canHaveDrafts: false,
        hideSidebar: true,
        navId: ";
        // line 207
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 207, $this->source); })()), "id", [], "any", false, false, false, 207), "html", null, true);
        yield ",
        enabledSiteIds: ";
        // line 208
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 208, $this->source); })()), "getSiteIds", [], "method", false, false, false, 208)), "html", null, true);
        yield ",
    });
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 211
        yield "
";
        // line 212
        ob_start();
        // line 213
        yield "
#page-title {
    display: flex;
}

";
        craft\helpers\Template::css(ob_get_clean());
        // line 219
        yield "
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "navigation/navs/_build";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  479 => 219,  471 => 213,  469 => 212,  466 => 211,  460 => 208,  456 => 207,  448 => 202,  443 => 200,  439 => 199,  434 => 198,  432 => 197,  419 => 186,  417 => 185,  413 => 184,  407 => 180,  400 => 176,  396 => 174,  394 => 173,  391 => 172,  383 => 171,  373 => 165,  356 => 161,  349 => 157,  343 => 154,  339 => 152,  320 => 150,  313 => 149,  309 => 147,  305 => 145,  302 => 140,  300 => 139,  297 => 138,  293 => 136,  290 => 129,  288 => 128,  285 => 127,  281 => 125,  278 => 119,  276 => 118,  273 => 117,  269 => 115,  267 => 113,  265 => 108,  262 => 107,  260 => 106,  252 => 103,  249 => 102,  247 => 100,  246 => 99,  245 => 96,  239 => 93,  235 => 91,  233 => 85,  230 => 84,  226 => 82,  224 => 80,  222 => 75,  219 => 74,  217 => 73,  213 => 72,  205 => 71,  199 => 68,  185 => 67,  181 => 66,  178 => 65,  176 => 63,  175 => 61,  172 => 60,  169 => 59,  152 => 58,  146 => 54,  138 => 53,  127 => 47,  123 => 46,  120 => 45,  117 => 44,  109 => 43,  100 => 38,  98 => 35,  89 => 32,  81 => 31,  75 => 3,  73 => 29,  71 => 26,  69 => 25,  67 => 24,  65 => 23,  62 => 17,  61 => 15,  60 => 12,  58 => 11,  56 => 7,  55 => 6,  53 => 4,  51 => 1,  43 => 3,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set bodyClass = 'body-navigation-nodes-index' %}

{% extends 'navigation/_layouts' %}
{% import '_includes/forms' as forms %}

{% set crumbs = [
    { label: craft.navigation.getPluginName(), url: url('navigation') },
    { label: 'Navigations' | t('navigation'), url: url('navigation/navs') },
] %}

{% if craft.app.getIsMultiSite() and requestedSite %}
    {% set crumbs = crumbs | unshift({
        id: 'site-crumb',
        icon: 'world',
        label: requestedSite.name | t('site'),
        menu: {
            items: siteMenuItems(nav.getSites(), requestedSite),
            label: 'Select site' | t('site')
        },
    }) %}
{% endif %}

{% set title = nav.name %}
{% set elementType = 'verbb\\\\navigation\\\\elements\\\\Node' %}
{% set elementInstance = craft.app.elements.createElement(elementType) %}
{% set sources = craft.app.elementSources.getSources(elementType, 'index', true) %}

{# Enforce a single source #}
{% set sources = sources | filter(n => n.key == 'nav:' ~ nav.uid) %}

{% block pageTitle %}
    <h1 class=\"screen-title\" title=\"{{ title }}\">{{ title }}</h1>

    <div id=\"toolbar\" class=\"flex flex-nowrap\">
        {% include '_elements/toolbar' with {
            showSiteMenu: false,
        } %}
    </div>

    <div id=\"actions-container\" class=\"flex\"></div>
{% endblock %}

{% block actionButton %}
    {% if editable and currentUser.can('navigation-editNav:' ~ nav.uid) %}
        <div class=\"btngroup submit\">
            <a class=\"btn settings icon\" href=\"{{ cpUrl('navigation/navs/edit/' ~ nav.id) }}\">
                {{ 'Settings' | t('navigation') }}
            </a>
        </div>
    {% endif %}
{% endblock %}

{% block details %}

<div class=\"nav-sidebar navigation-nodes-sidebar\">
    <nav id=\"accordion\" data-vui-tabs>
        <ul class=\"tab-list\">
            {% for tabId, tab in craft.navigation.getBuilderTabs(nav) %}
                {% set selected = loop.first %}

                {% set attributes = {
                    class: 'tab-list-item',
                    'data-id': tabId,
                } %}

                <li {{ attr(attributes) }}>
                    <a id=\"tab-{{ tabId }}\" class=\"tab{% if selected %} sel{% endif %}\" href=\"#pane-{{ tabId }}\" data-href=\"#pane-{{ tabId }}\" title=\"{{ tab.label }}\">
                        {{ tab.label }}
                    </a>

                    <div id=\"pane-{{ tabId }}\" class=\"tab-list-pane {% if not selected %}hidden{% endif %}\">
                        <form class=\"form-type-{{ tab.category }}\" method=\"post\" accept-charset=\"UTF-8\">
                            {% if tab.category == 'element' %}
                                {% if nav.maxLevels == '' or nav.maxLevels > 1 %}
                                    {{ forms.selectField({
                                        label: 'Parent' | t('navigation'),
                                        instructions: 'Select a navigation item as the parent.' | t('navigation'),
                                        id: 'parentId',
                                        name: 'parentId',
                                        options: parentOptions,
                                        class: 'fullwidth js-parent-node',
                                    }) }}
                                {% endif %}

                                {{ forms.lightswitchField({
                                    label: 'Open in new window' | t('navigation'),
                                    instructions: 'Whether to open this navigation item in a new window.' | t('navigation'),
                                    id: 'newWindow',
                                    name: 'newWindow',
                                    on: false,
                                }) }}

                                {{ hiddenInput('type', tab.type) }}

                                <div class=\"buttons\">
                                    {% set attributes = {
                                        type: 'submit',
                                        class: 'btn submit add icon js-btn-element-add',
                                        'data-element-type': tab.type,
                                        'data-sources': tab.sources,
                                    } %}

                                    <button {{ attr(attributes) }}>{{ tab.button }}</button>
                                    <div class=\"spinner hidden\"></div>
                                </div>
                            {% elseif tab.category == 'nodeType' %}
                                {% if nav.maxLevels == '' or nav.maxLevels > 1 %}
                                    {{ forms.selectField({
                                        label: 'Parent' | t('navigation'),
                                        instructions: 'Select a navigation item as the parent.' | t('navigation'),
                                        id: 'parentId',
                                        name: 'parentId',
                                        options: parentOptions,
                                        class: 'fullwidth js-parent-node',
                                    }) }}
                                {% endif %}

                                {% if tab.nodeType.hasNewWindow() %}
                                    {{ forms.lightswitchField({
                                        label: 'Open in new window' | t('navigation'),
                                        instructions: 'Whether to open this navigation item in a new window.' | t('navigation'),
                                        id: 'newWindow',
                                        name: 'newWindow',
                                        on: false,
                                    }) }}
                                {% endif %}

                                {% if tab.nodeType.hasTitle() %}
                                    {{ forms.textField({
                                        label: 'Title' | t('navigation'),
                                        id: 'title',
                                        name: 'title',
                                        first: true,
                                        required: true,
                                        instructions: 'Name of this node in the navigation.' | t('navigation'),
                                    }) }}
                                {% endif %}

                                {% if tab.nodeType.hasUrl() %}
                                    {{ forms.textField({
                                        label: 'URL' | t('navigation'),
                                        id: 'url',
                                        name: 'url',
                                        instructions: 'The URL of this node.' | t('navigation'),
                                    }) }}
                                {% endif %}

                                <div class=\"node-type-data\">
                                    {% namespace 'data' %}
                                        {{ tab.nodeType.getSettingsHtml() | raw }}
                                    {% endnamespace %}
                                </div>

                                {{ hiddenInput('type', tab.type) }}

                                <div class=\"buttons\">
                                    <button type=\"submit\" class=\"btn submit add icon\">{{ tab.button }}</button>
                                    <div class=\"spinner hidden\"></div>
                                </div>
                            {% endif %}
                        </form>
                    </div>
                </li>
            {% endfor %}
        </ul>
    </nav>
</div>

{% endblock %}

{% block content %}

{% if nav.instructions %}
    <div id=\"js-navigation-nodes-instructions\" class=\"hidden\">
        <div class=\"navigation-nodes-instructions\">
            <p>{{ nav.instructions | md }}</p>
        </div>
    </div>
{% endif %}

<div id=\"navigation-nodes-index\">
    <div id=\"sidebar-container\" class=\"hidden\">
        <div id=\"sidebar\" class=\"sidebar\">
            <nav aria-label=\"{{ 'Sources'|t('app') }}\">
                {% include \"_elements/sources\" %}
            </nav>
        </div>
    </div>

    <div class=\"main element-index\">
        <div class=\"elements busy\">
            <div class=\"update-spinner spinner spinner-absolute\"></div>
        </div>
    </div>
</div>

{% js %}
    Craft.elementIndex = Craft.createElementIndex('{{ elementType|e(\"js\") }}', \$('.body-navigation-nodes-index #main-container'), {
        elementTypeName: '{{ elementInstance.displayName() | e(\"js\") }}',
        elementTypePluralName: '{{ elementInstance.pluralDisplayName() | e(\"js\") }}',
        context: 'index',
        storageKey: 'elementindex.{{ elementType | e(\"js\") }}',
        criteria: Craft.defaultIndexCriteria,
        toolbarSelector: '#toolbar',
        canHaveDrafts: false,
        hideSidebar: true,
        navId: {{ nav.id }},
        enabledSiteIds: {{ nav.getSiteIds() | json_encode }},
    });
{% endjs %}

{% css %}

#page-title {
    display: flex;
}

{% endcss %}

{% endblock %}
", "navigation/navs/_build", "/var/www/html/vendor/verbb/navigation/src/templates/navs/_build.html");
    }
}
