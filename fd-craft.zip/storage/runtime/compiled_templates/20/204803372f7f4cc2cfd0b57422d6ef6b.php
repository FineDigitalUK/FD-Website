<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _elements/sources */
class __TwigTemplate_9c457c34489fcf00dbbe7c74182e025a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/sources");
        // line 1
        $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "
";
            // line 3
            echo \Craft::$app->getView()->invokeHook("cp.elements.sources", $context);

            // line 4
            yield "
";
            // line 48
            yield "
";
            // line 81
            yield "
";
            // line 82
            $context["nestedUnderHeading"] = false;
            // line 83
            yield "
";
            // line 84
            ob_start();
            // line 88
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 88, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["source"]) {
                // line 89
                yield "        ";
                if (((((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "type", [], "any", true, true, false, 89) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "type", [], "any", false, false, false, 89)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "type", [], "any", false, false, false, 89)) : (null)) == "heading")) {
                    // line 90
                    yield "            ";
                    $context["key"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "key", [], "any", true, true, false, 90) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "key", [], "any", false, false, false, 90)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "key", [], "any", false, false, false, 90)) : ($this->extensions['craft\web\twig\Extension']->kebabFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "heading", [], "any", false, false, false, 90))));
                    // line 91
                    yield "            ";
                    if ((isset($context["nestedUnderHeading"]) || array_key_exists("nestedUnderHeading", $context) ? $context["nestedUnderHeading"] : (function () { throw new RuntimeError('Variable "nestedUnderHeading" does not exist.', 91, $this->source); })())) {
                        // line 92
                        yield "                    </ul>
                </li>
            ";
                    }
                    // line 95
                    yield "            <li class=\"heading\">
                <div class=\"source-item source-item--heading\">
                    <span class=\"type-heading-small\">";
                    // line 97
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "heading", [], "any", false, false, false, 97), "site"), "html", null, true);
                    yield "</span>
                    ";
                    // line 99
                    yield "                    ";
                    if ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "heading", [], "any", false, false, false, 99))) {
                        // line 100
                        yield "                        ";
                        yield from $this->loadTemplate("_elements/sources", "_elements/sources", 100, "1783378951")->unwrap()->yield(CoreExtension::merge($context, ["persist" => true, "storageKey" => ("sources-list:" .                         // line 102
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 102, $this->source); })())), "storageMode" => "cookies", "controls" =>                         // line 104
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 104, $this->source); })()), "attributes" => ["class" => "source-item__toggle"]]));
                        // line 118
                        yield "                    ";
                    }
                    // line 119
                    yield "                </div>
                <ul id=\"";
                    // line 120
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 120, $this->source); })()), "html", null, true);
                    yield "\" class=\"sources-list\">
            ";
                    // line 121
                    $context["nestedUnderHeading"] = true;
                    // line 122
                    yield "        ";
                } elseif ( !((((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "sites", [], "any", true, true, false, 122) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "sites", [], "any", false, false, false, 122)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "sites", [], "any", false, false, false, 122)) : (null)) === [])) {
                    // line 123
                    yield "            ";
                    $context["key"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [], "any", true, true, false, 123) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [], "any", false, false, false, 123)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [], "any", false, false, false, 123)) : (((isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 123, $this->source); })()) . craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "key", [], "any", false, false, false, 123))));
                    // line 124
                    yield "            ";
                    ob_start();
                    // line 130
                    yield "                <div class=\"source-item source-item--link\">
                    ";
                    // line 131
                    yield $this->getTemplateForMacro("macro_sourceLink", $context, 131, $this->getSourceContext())->macro_sourceLink(...[(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 131, $this->source); })()), $context["source"], (isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 131, $this->source); })()), (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 131, $this->source); })()), (($context["sortOptions"]) ?? (null)), (($context["baseSortOptions"]) ?? (null)), (($context["tableColumns"]) ?? (null)), (($context["defaultTableColumns"]) ?? (null)), (($context["viewModes"]) ?? (null))]);
                    yield "
                    ";
                    // line 132
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", true, true, false, 132) &&  !Twig\Extension\CoreExtension::testEmpty(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", false, false, false, 132)))) {
                        // line 133
                        yield "                        ";
                        yield from $this->loadTemplate("_elements/sources", "_elements/sources", 133, "1698501450")->unwrap()->yield(CoreExtension::merge($context, ["persist" => true, "storageKey" => ("sources-list:" .                         // line 135
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 135, $this->source); })())), "controls" =>                         // line 136
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 136, $this->source); })()), "attributes" => ["class" => "source-item__toggle"]]));
                        // line 150
                        yield "                    ";
                    }
                    // line 151
                    yield "                </div>
                ";
                    // line 152
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", true, true, false, 152) &&  !Twig\Extension\CoreExtension::testEmpty(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", false, false, false, 152)))) {
                        // line 153
                        yield "                    ";
                        yield from $this->loadTemplate("_elements/sources", "_elements/sources", 153)->unwrap()->yield(CoreExtension::merge($context, ["keyPrefix" => (                        // line 154
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 154, $this->source); })()) . "/"), "id" =>                         // line 155
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 155, $this->source); })()), "sources" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 156
$context["source"], "nested", [], "any", false, false, false, 156)]));
                        // line 158
                        yield "                ";
                    }
                    // line 159
                    yield "            ";
                    echo craft\helpers\Html::tag("li", ob_get_clean(), ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [(((((craft\helpers\Template::attribute($this->env, $this->source,                     // line 126
$context["source"], "nested", [], "any", true, true, false, 126) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", false, false, false, 126)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", false, false, false, 126)) : (false))) ? ("collapsible") : (null)), (((((craft\helpers\Template::attribute($this->env, $this->source,                     // line 127
$context["source"], "disabled", [], "any", true, true, false, 127) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "disabled", [], "any", false, false, false, 127)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "disabled", [], "any", false, false, false, 127)) : (false))) ? ("hidden") : (null))])]);
                    // line 160
                    yield "        ";
                }
                // line 161
                yield "    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['source'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 162
            yield "    ";
            if ((isset($context["nestedUnderHeading"]) || array_key_exists("nestedUnderHeading", $context) ? $context["nestedUnderHeading"] : (function () { throw new RuntimeError('Variable "nestedUnderHeading" does not exist.', 162, $this->source); })())) {
                // line 163
                yield "            </ul>
        </li>
    ";
            }
            echo craft\helpers\Html::tag("ul", ob_get_clean(), ["class" => ((            // line 85
(isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 85, $this->source); })())) ? ("nested sources-list") : ("sources-list")), "id" => ((            // line 86
$context["id"]) ?? (""))]);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        yield Twig\Extension\CoreExtension::spaceless($_v0);
        craft\helpers\Template::endProfile("template", "_elements/sources");
        yield from [];
    }

    // line 5
    public function macro_sourceLink($key = null, $source = null, $isTopLevel = null, $elementType = null, $sortOptions = null, $baseSortOptions = null, $tableColumns = null, $defaultTableColumns = null, $viewModes = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "key" => $key,
            "source" => $source,
            "isTopLevel" => $isTopLevel,
            "elementType" => $elementType,
            "sortOptions" => $sortOptions,
            "baseSortOptions" => $baseSortOptions,
            "tableColumns" => $tableColumns,
            "defaultTableColumns" => $defaultTableColumns,
            "viewModes" => $viewModes,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "sourceLink");
            // line 6
            yield "    ";
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["role" => "button", "tabindex" => "0", "data" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["key" =>             // line 10
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 10, $this->source); })()), "label" => craft\helpers\Template::attribute($this->env, $this->source,             // line 11
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 11, $this->source); })()), "label", [], "any", false, false, false, 11), "has-thumbs" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 12
($context["source"] ?? null), "hasThumbs", [], "any", true, true, false, 12) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "hasThumbs", [], "any", false, false, false, 12)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "hasThumbs", [], "any", false, false, false, 12)) : (false))) ? (true) : (false)), "has-structure" => boolval((((craft\helpers\Template::attribute($this->env, $this->source,             // line 13
($context["source"] ?? null), "structureId", [], "any", true, true, false, 13) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "structureId", [], "any", false, false, false, 13)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "structureId", [], "any", false, false, false, 13)) : (null))), "default-sort" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 14
($context["source"] ?? null), "defaultSort", [], "any", true, true, false, 14) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSort", [], "any", false, false, false, 14)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSort", [], "any", false, false, false, 14)) : (false)), "sort-opts" => ((            // line 15
(isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 15, $this->source); })())) ? (((            // line 16
$context["sortOptions"]) ?? ($this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["baseSortOptions"]) || array_key_exists("baseSortOptions", $context) ? $context["baseSortOptions"] : (function () { throw new RuntimeError('Variable "baseSortOptions" does not exist.', 16, $this->source); })()), array_values($this->extensions['craft\web\twig\Extension']->mapFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 17
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "app", [], "any", false, false, false, 17), "elementSources", [], "any", false, false, false, 17), "getSourceSortOptions", [(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 17, $this->source); })()), (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 17, $this->source); })())], "method", false, false, false, 17), function ($__option__) use ($context, $macros) { $context["option"] = $__option__; return ["label" => craft\helpers\Template::attribute($this->env, $this->source,             // line 18
(isset($context["option"]) || array_key_exists("option", $context) ? $context["option"] : (function () { throw new RuntimeError('Variable "option" does not exist.', 18, $this->source); })()), "label", [], "any", false, false, false, 18), "attr" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 19
($context["option"] ?? null), "attribute", [], "any", true, true, false, 19) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "attribute", [], "any", false, false, false, 19)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "attribute", [], "any", false, false, false, 19)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["option"]) || array_key_exists("option", $context) ? $context["option"] : (function () { throw new RuntimeError('Variable "option" does not exist.', 19, $this->source); })()), "orderBy", [], "any", false, false, false, 19))), "defaultDir" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 20
($context["option"] ?? null), "defaultDir", [], "any", true, true, false, 20) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "defaultDir", [], "any", false, false, false, 20)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "defaultDir", [], "any", false, false, false, 20)) : ("asc"))]; })))))) : (false)), "source-item" => true, "table-col-opts" => ((            // line 24
(isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 24, $this->source); })())) ? (array_values($this->extensions['craft\web\twig\Extension']->mapFilter($this->env, $this->extensions['craft\web\twig\Extension']->mergeFilter(            // line 25
(isset($context["tableColumns"]) || array_key_exists("tableColumns", $context) ? $context["tableColumns"] : (function () { throw new RuntimeError('Variable "tableColumns" does not exist.', 25, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 26
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 26, $this->source); })()), "app", [], "any", false, false, false, 26), "elementSources", [], "any", false, false, false, 26), "getSourceTableAttributes", [(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 26, $this->source); })()), (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 26, $this->source); })())], "method", false, false, false, 26)),             // line 27
function ($__a__, $__key__) use ($context, $macros) { $context["a"] = $__a__; $context["key"] = $__key__; return $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 27, $this->source); })()), ["attr" => (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 27, $this->source); })())]); }))) : (false)), "default-table-cols" => ((            // line 30
(isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 30, $this->source); })())) ? (array_values($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, $this->extensions['craft\web\twig\Extension']->mapFilter($this->env, ((            // line 31
$context["defaultTableColumns"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 31, $this->source); })()), "app", [], "any", false, false, false, 31), "elementSources", [], "any", false, false, false, 31), "getTableAttributes", [(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 31, $this->source); })()), (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 31, $this->source); })())], "method", false, false, false, 31))),             // line 32
function ($__a__) use ($context, $macros) { $context["a"] = $__a__; return craft\helpers\Template::attribute($this->env, $this->source, (isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 32, $this->source); })()), 0, [], "array", false, false, false, 32); }),             // line 33
function ($__a__) use ($context, $macros) { $context["a"] = $__a__; return ((isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 33, $this->source); })()) != "title"); }))) : (false)), "default-source-path" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 36
($context["source"] ?? null), "defaultSourcePath", [], "any", true, true, false, 36) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSourcePath", [], "any", false, false, false, 36)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSourcePath", [], "any", false, false, false, 36)) : (false))) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 36, $this->source); })()), "defaultSourcePath", [], "any", false, false, false, 36))) : (false)), "sites" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 37
($context["source"] ?? null), "sites", [], "any", true, true, false, 37) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "sites", [], "any", false, false, false, 37)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "sites", [], "any", false, false, false, 37)) : (false))) ? (Twig\Extension\CoreExtension::join(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 37, $this->source); })()), "sites", [], "any", false, false, false, 37), ",")) : (false)), "criteria" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 38
($context["source"] ?? null), "criteria", [], "any", true, true, false, 38) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "criteria", [], "any", false, false, false, 38)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "criteria", [], "any", false, false, false, 38)) : ([])), "disabled" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 39
($context["source"] ?? null), "disabled", [], "any", true, true, false, 39) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "disabled", [], "any", false, false, false, 39)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "disabled", [], "any", false, false, false, 39)) : (false)), "default-filter" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 40
($context["source"] ?? null), "defaultFilter", [], "any", true, true, false, 40) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultFilter", [], "any", false, false, false, 40)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultFilter", [], "any", false, false, false, 40)) : (false)), "default-view-mode" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 41
($context["source"] ?? null), "defaultViewMode", [], "any", true, true, false, 41) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultViewMode", [], "any", false, false, false, 41)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultViewMode", [], "any", false, false, false, 41)) : (false)), "view-modes" => ((            // line 42
$context["viewModes"]) ?? ([])), "field-layouts" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 43
($context["source"] ?? null), "fieldLayouts", [], "any", true, true, false, 43)) ? ($this->extensions['craft\web\twig\Extension']->mapFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 43, $this->source); })()), "fieldLayouts", [], "any", false, false, false, 43), function ($__layout__) use ($context, $macros) { $context["layout"] = $__layout__; return craft\helpers\Template::attribute($this->env, $this->source, (isset($context["layout"]) || array_key_exists("layout", $context) ? $context["layout"] : (function () { throw new RuntimeError('Variable "layout" does not exist.', 43, $this->source); })()), "getConfig", [], "method", false, false, false, 43); })) : (false))], (((craft\helpers\Template::attribute($this->env, $this->source,             // line 44
($context["source"] ?? null), "data", [], "any", true, true, false, 44) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "data", [], "any", false, false, false, 44)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "data", [], "any", false, false, false, 44)) : ([]))), "html" => $this->getTemplateForMacro("macro_sourceInnerHtml", $context, 45, $this->getSourceContext())->macro_sourceInnerHtml(...[            // line 45
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 45, $this->source); })())])]);
            // line 46
            yield "
";
            craft\helpers\Template::endProfile("macro", "sourceLink");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 49
    public function macro_sourceInnerHtml($source = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "source" => $source,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "sourceInnerHtml");
            // line 50
            yield "    ";
            if (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "status", [], "any", true, true, false, 50)) {
                // line 51
                yield "        <span class=\"status ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 51, $this->source); })()), "status", [], "any", false, false, false, 51), "html", null, true);
                yield "\"></span>
    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 52
($context["source"] ?? null), "icon", [], "any", true, true, false, 52)) {
                // line 53
                yield "        <span class=\"icon\">
            ";
                // line 54
                yield (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 54, $this->source); })()), "icon", [], "any", false, false, false, 54), true, true)) ?: ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 54, $this->source); })()), "icon", [], "any", false, false, false, 54)) . "'></span>")));
                yield "
        </span>
    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 56
($context["source"] ?? null), "iconMask", [], "any", true, true, false, 56)) {
                // line 57
                yield "        <span class=\"icon icon-mask\">
            ";
                // line 58
                yield (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 58, $this->source); })()), "iconMask", [], "any", false, false, false, 58), true, true)) ?: ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 58, $this->source); })()), "iconMask", [], "any", false, false, false, 58)) . "'></span>")));
                yield "
        </span>
    ";
            }
            // line 61
            yield "    <span class=\"label\">
        ";
            // line 62
            if ( !(Twig\Extension\CoreExtension::trim(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 62, $this->source); })()), "label", [], "any", false, false, false, 62)) === "")) {
                // line 63
                yield "            ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((((((craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "type", [], "any", true, true, false, 63) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "type", [], "any", false, false, false, 63)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "type", [], "any", false, false, false, 63)) : (null)) == "custom")) ? ($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 63, $this->source); })()), "label", [], "any", false, false, false, 63), "site")) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 63, $this->source); })()), "label", [], "any", false, false, false, 63))), "html", null, true);
                yield "
        ";
            } else {
                // line 65
                yield "            ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("(blank)", "app"), "html", null, true);
                yield "
        ";
            }
            // line 67
            yield "    </span>
    ";
            // line 68
            if ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "badgeCount", [], "any", true, true, false, 68) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "badgeCount", [], "any", false, false, false, 68)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "badgeCount", [], "any", false, false, false, 68)) : (false))) {
                // line 69
                yield "        <span class=\"badge\" aria-hidden=\"true\">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->numberFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 69, $this->source); })()), "badgeCount", [], "any", false, false, false, 69), 0), "html", null, true);
                yield "</span>
        ";
                // line 70
                yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "visually-hidden", "data" => ["notification" => true], "text" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 75
($context["source"] ?? null), "badgeLabel", [], "any", true, true, false, 75) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "badgeLabel", [], "any", false, false, false, 75)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "badgeLabel", [], "any", false, false, false, 75)) : ($this->extensions['craft\web\twig\Extension']->translateFilter("{num, number} {num, plural, =1{notification} other{notifications}}", "app", ["num" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 76
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 76, $this->source); })()), "badgeCount", [], "any", false, false, false, 76)])))]);
                // line 78
                yield "
    ";
            }
            craft\helpers\Template::endProfile("macro", "sourceInnerHtml");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_elements/sources";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  342 => 78,  340 => 76,  339 => 75,  338 => 70,  333 => 69,  331 => 68,  328 => 67,  322 => 65,  316 => 63,  314 => 62,  311 => 61,  305 => 58,  302 => 57,  300 => 56,  295 => 54,  292 => 53,  290 => 52,  285 => 51,  282 => 50,  269 => 49,  261 => 46,  259 => 45,  258 => 44,  257 => 43,  256 => 42,  255 => 41,  254 => 40,  253 => 39,  252 => 38,  251 => 37,  250 => 36,  249 => 33,  248 => 32,  247 => 31,  246 => 30,  245 => 27,  244 => 26,  243 => 25,  242 => 24,  241 => 20,  240 => 19,  239 => 18,  238 => 17,  237 => 16,  236 => 15,  235 => 14,  234 => 13,  233 => 12,  232 => 11,  231 => 10,  229 => 6,  208 => 5,  202 => 1,  198 => 86,  197 => 85,  192 => 163,  189 => 162,  175 => 161,  172 => 160,  170 => 127,  169 => 126,  167 => 159,  164 => 158,  162 => 156,  161 => 155,  160 => 154,  158 => 153,  156 => 152,  153 => 151,  150 => 150,  148 => 136,  147 => 135,  145 => 133,  143 => 132,  139 => 131,  136 => 130,  133 => 124,  130 => 123,  127 => 122,  125 => 121,  121 => 120,  118 => 119,  115 => 118,  113 => 104,  112 => 102,  110 => 100,  107 => 99,  103 => 97,  99 => 95,  94 => 92,  91 => 91,  88 => 90,  85 => 89,  67 => 88,  65 => 84,  62 => 83,  60 => 82,  57 => 81,  54 => 48,  51 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% apply spaceless %}

{% hook 'cp.elements.sources' %}

{% macro sourceLink(key, source, isTopLevel, elementType, sortOptions, baseSortOptions, tableColumns, defaultTableColumns, viewModes) %}
    {{ tag('a', {
        role: 'button',
        tabindex: '0',
        data: {
            key: key,
            'label': source.label,
            'has-thumbs': (source.hasThumbs ?? false) ? true : false,
            'has-structure': (source.structureId ?? null)|boolean,
            'default-sort': source.defaultSort ?? false,
            'sort-opts': isTopLevel
                ? sortOptions ?? (baseSortOptions
                    |merge(craft.app.elementSources.getSourceSortOptions(elementType, key)|map(option => {
                        label: option.label,
                        attr: option.attribute ?? option.orderBy,
                        defaultDir: option.defaultDir ?? 'asc'
                    })|values))
                : false,
            'source-item': true,
            'table-col-opts': isTopLevel
                ? tableColumns
                    |merge(craft.app.elementSources.getSourceTableAttributes(elementType, key))
                    |map((a, key) => a|merge({attr: key}))
                    |values
                : false,
            'default-table-cols': isTopLevel
                ? (defaultTableColumns ?? craft.app.elementSources.getTableAttributes(elementType, key))
                    |map(a => a[0])
                    |filter(a => a != 'title')
                    |values
                : false,
            'default-source-path': (source.defaultSourcePath ?? false) ? source.defaultSourcePath|json_encode : false,
            sites: (source.sites ?? false) ? source.sites|join(',') : false,
            criteria: source.criteria ?? {},
            disabled: source.disabled ?? false,
            'default-filter': source.defaultFilter ?? false,
            'default-view-mode': source.defaultViewMode ?? false,
            'view-modes': viewModes ?? [],
            'field-layouts': source.fieldLayouts is defined ? source.fieldLayouts|map(layout => layout.getConfig()) : false,
        }|merge(source.data ?? {}),
        html: _self.sourceInnerHtml(source)
    }) }}
{% endmacro %}

{% macro sourceInnerHtml(source) %}
    {% if source.status is defined %}
        <span class=\"status {{ source.status }}\"></span>
    {% elseif source.icon is defined %}
        <span class=\"icon\">
            {{ (svg(source.icon, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.icon}'></span>\")|raw }}
        </span>
    {% elseif source.iconMask is defined %}
        <span class=\"icon icon-mask\">
            {{ (svg(source.iconMask, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.iconMask}'></span>\")|raw }}
        </span>
    {% endif %}
    <span class=\"label\">
        {% if source.label|trim is not same as('') %}
            {{ (source.type ?? null) == 'custom' ? source.label|t('site') : source.label }}
        {% else %}
            {{ '(blank)'|t('app') }}
        {% endif %}
    </span>
    {% if source.badgeCount ?? false %}
        <span class=\"badge\" aria-hidden=\"true\">{{ source.badgeCount|number(decimals=0) }}</span>
        {{ tag('span', {
            class: 'visually-hidden',
            data: {
                notification: true,
            },
            text: source.badgeLabel ?? '{num, number} {num, plural, =1{notification} other{notifications}}'|t('app', {
                num: source.badgeCount,
            }),
        }) }}
    {% endif %}
{% endmacro %}

{% set nestedUnderHeading = false %}

{% tag 'ul' with {
    class: keyPrefix ? 'nested sources-list' : 'sources-list',
    id: id ?? ''
} %}
    {% for source in sources %}
        {% if (source.type ?? null) == 'heading' %}
            {% set key = source.key ?? (source.heading | kebab) %}
            {% if nestedUnderHeading %}
                    </ul>
                </li>
            {% endif %}
            <li class=\"heading\">
                <div class=\"source-item source-item--heading\">
                    <span class=\"type-heading-small\">{{ source.heading|t('site') }}</span>
                    {# Don't toggle blank headings #}
                    {% if source.heading | length %}
                        {% embed '_includes/disclosure-toggle' with {
                            persist: true,
                            storageKey: 'sources-list:'~ key,
                            storageMode: 'cookies',
                            controls: key,
                            attributes: {
                                class: 'source-item__toggle'
                            }
                        } %}
                            {% block content %}
                                <span class=\"cp-icon puny\">
                                    {{ iconSvg('angle-down') }}
                                </span>
                                <span class=\"visually-hidden\">{{ 'Expand {heading} sources' | t('app', {
                                        heading: source.heading
                                    }) }}</span>
                            {% endblock %}
                        {% endembed %}
                    {% endif %}
                </div>
                <ul id=\"{{ key }}\" class=\"sources-list\">
            {% set nestedUnderHeading = true %}
        {% elseif (source.sites ?? null) is not same as([]) %}
            {% set key = source.keyPath ?? (keyPrefix ~ source.key) %}
            {% tag 'li' with {
                class: [
                    (source.nested ?? false) ? 'collapsible' : null,
                    (source.disabled ?? false) ? 'hidden' : null,
                ]|filter,
            } %}
                <div class=\"source-item source-item--link\">
                    {{ _self.sourceLink(key, source, isTopLevel, elementType, sortOptions ?? null, baseSortOptions ?? null, tableColumns ?? null, defaultTableColumns ?? null, viewModes ?? null) }}
                    {% if source.nested is defined and source.nested is not empty %}
                        {% embed '_includes/disclosure-toggle' with {
                            persist: true,
                            storageKey: 'sources-list:'~ key,
                            controls: key,
                            attributes: {
                                class: 'source-item__toggle'
                            }
                        } %}
                            {% block content %}
                                <span class=\"cp-icon puny\">
                                    {{ iconSvg('angle-down') }}
                                </span>
                                <span class=\"visually-hidden\">{{ 'Expand {heading} sources' | t('app', {
                                        heading: source.label
                                    }) }}</span>
                            {% endblock %}
                        {% endembed %}
                    {% endif %}
                </div>
                {% if source.nested is defined and source.nested is not empty %}
                    {% include \"_elements/sources\" with {
                        keyPrefix: key ~ '/',
                        id: key,
                        sources: source.nested
                    } %}
                {% endif %}
            {% endtag %}
        {% endif %}
    {% endfor %}
    {% if nestedUnderHeading %}
            </ul>
        </li>
    {% endif %}
{% endtag %}
{% endapply %}
", "_elements/sources", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/sources.twig");
    }
}


/* _elements/sources */
class __TwigTemplate_9c457c34489fcf00dbbe7c74182e025a___1783378951 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 100
        return "_includes/disclosure-toggle";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/sources");
        $this->parent = $this->loadTemplate("_includes/disclosure-toggle", "_elements/sources", 100);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_elements/sources");
    }

    // line 109
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 110
        yield "                                <span class=\"cp-icon puny\">
                                    ";
        // line 111
        yield craft\helpers\Cp::iconSvg("angle-down");
        yield "
                                </span>
                                <span class=\"visually-hidden\">";
        // line 113
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Expand {heading} sources", "app", ["heading" => craft\helpers\Template::attribute($this->env, $this->source,         // line 114
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 114, $this->source); })()), "heading", [], "any", false, false, false, 114)]), "html", null, true);
        // line 115
        yield "</span>
                            ";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_elements/sources";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  603 => 115,  601 => 114,  600 => 113,  595 => 111,  592 => 110,  584 => 109,  571 => 100,  342 => 78,  340 => 76,  339 => 75,  338 => 70,  333 => 69,  331 => 68,  328 => 67,  322 => 65,  316 => 63,  314 => 62,  311 => 61,  305 => 58,  302 => 57,  300 => 56,  295 => 54,  292 => 53,  290 => 52,  285 => 51,  282 => 50,  269 => 49,  261 => 46,  259 => 45,  258 => 44,  257 => 43,  256 => 42,  255 => 41,  254 => 40,  253 => 39,  252 => 38,  251 => 37,  250 => 36,  249 => 33,  248 => 32,  247 => 31,  246 => 30,  245 => 27,  244 => 26,  243 => 25,  242 => 24,  241 => 20,  240 => 19,  239 => 18,  238 => 17,  237 => 16,  236 => 15,  235 => 14,  234 => 13,  233 => 12,  232 => 11,  231 => 10,  229 => 6,  208 => 5,  202 => 1,  198 => 86,  197 => 85,  192 => 163,  189 => 162,  175 => 161,  172 => 160,  170 => 127,  169 => 126,  167 => 159,  164 => 158,  162 => 156,  161 => 155,  160 => 154,  158 => 153,  156 => 152,  153 => 151,  150 => 150,  148 => 136,  147 => 135,  145 => 133,  143 => 132,  139 => 131,  136 => 130,  133 => 124,  130 => 123,  127 => 122,  125 => 121,  121 => 120,  118 => 119,  115 => 118,  113 => 104,  112 => 102,  110 => 100,  107 => 99,  103 => 97,  99 => 95,  94 => 92,  91 => 91,  88 => 90,  85 => 89,  67 => 88,  65 => 84,  62 => 83,  60 => 82,  57 => 81,  54 => 48,  51 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% apply spaceless %}

{% hook 'cp.elements.sources' %}

{% macro sourceLink(key, source, isTopLevel, elementType, sortOptions, baseSortOptions, tableColumns, defaultTableColumns, viewModes) %}
    {{ tag('a', {
        role: 'button',
        tabindex: '0',
        data: {
            key: key,
            'label': source.label,
            'has-thumbs': (source.hasThumbs ?? false) ? true : false,
            'has-structure': (source.structureId ?? null)|boolean,
            'default-sort': source.defaultSort ?? false,
            'sort-opts': isTopLevel
                ? sortOptions ?? (baseSortOptions
                    |merge(craft.app.elementSources.getSourceSortOptions(elementType, key)|map(option => {
                        label: option.label,
                        attr: option.attribute ?? option.orderBy,
                        defaultDir: option.defaultDir ?? 'asc'
                    })|values))
                : false,
            'source-item': true,
            'table-col-opts': isTopLevel
                ? tableColumns
                    |merge(craft.app.elementSources.getSourceTableAttributes(elementType, key))
                    |map((a, key) => a|merge({attr: key}))
                    |values
                : false,
            'default-table-cols': isTopLevel
                ? (defaultTableColumns ?? craft.app.elementSources.getTableAttributes(elementType, key))
                    |map(a => a[0])
                    |filter(a => a != 'title')
                    |values
                : false,
            'default-source-path': (source.defaultSourcePath ?? false) ? source.defaultSourcePath|json_encode : false,
            sites: (source.sites ?? false) ? source.sites|join(',') : false,
            criteria: source.criteria ?? {},
            disabled: source.disabled ?? false,
            'default-filter': source.defaultFilter ?? false,
            'default-view-mode': source.defaultViewMode ?? false,
            'view-modes': viewModes ?? [],
            'field-layouts': source.fieldLayouts is defined ? source.fieldLayouts|map(layout => layout.getConfig()) : false,
        }|merge(source.data ?? {}),
        html: _self.sourceInnerHtml(source)
    }) }}
{% endmacro %}

{% macro sourceInnerHtml(source) %}
    {% if source.status is defined %}
        <span class=\"status {{ source.status }}\"></span>
    {% elseif source.icon is defined %}
        <span class=\"icon\">
            {{ (svg(source.icon, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.icon}'></span>\")|raw }}
        </span>
    {% elseif source.iconMask is defined %}
        <span class=\"icon icon-mask\">
            {{ (svg(source.iconMask, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.iconMask}'></span>\")|raw }}
        </span>
    {% endif %}
    <span class=\"label\">
        {% if source.label|trim is not same as('') %}
            {{ (source.type ?? null) == 'custom' ? source.label|t('site') : source.label }}
        {% else %}
            {{ '(blank)'|t('app') }}
        {% endif %}
    </span>
    {% if source.badgeCount ?? false %}
        <span class=\"badge\" aria-hidden=\"true\">{{ source.badgeCount|number(decimals=0) }}</span>
        {{ tag('span', {
            class: 'visually-hidden',
            data: {
                notification: true,
            },
            text: source.badgeLabel ?? '{num, number} {num, plural, =1{notification} other{notifications}}'|t('app', {
                num: source.badgeCount,
            }),
        }) }}
    {% endif %}
{% endmacro %}

{% set nestedUnderHeading = false %}

{% tag 'ul' with {
    class: keyPrefix ? 'nested sources-list' : 'sources-list',
    id: id ?? ''
} %}
    {% for source in sources %}
        {% if (source.type ?? null) == 'heading' %}
            {% set key = source.key ?? (source.heading | kebab) %}
            {% if nestedUnderHeading %}
                    </ul>
                </li>
            {% endif %}
            <li class=\"heading\">
                <div class=\"source-item source-item--heading\">
                    <span class=\"type-heading-small\">{{ source.heading|t('site') }}</span>
                    {# Don't toggle blank headings #}
                    {% if source.heading | length %}
                        {% embed '_includes/disclosure-toggle' with {
                            persist: true,
                            storageKey: 'sources-list:'~ key,
                            storageMode: 'cookies',
                            controls: key,
                            attributes: {
                                class: 'source-item__toggle'
                            }
                        } %}
                            {% block content %}
                                <span class=\"cp-icon puny\">
                                    {{ iconSvg('angle-down') }}
                                </span>
                                <span class=\"visually-hidden\">{{ 'Expand {heading} sources' | t('app', {
                                        heading: source.heading
                                    }) }}</span>
                            {% endblock %}
                        {% endembed %}
                    {% endif %}
                </div>
                <ul id=\"{{ key }}\" class=\"sources-list\">
            {% set nestedUnderHeading = true %}
        {% elseif (source.sites ?? null) is not same as([]) %}
            {% set key = source.keyPath ?? (keyPrefix ~ source.key) %}
            {% tag 'li' with {
                class: [
                    (source.nested ?? false) ? 'collapsible' : null,
                    (source.disabled ?? false) ? 'hidden' : null,
                ]|filter,
            } %}
                <div class=\"source-item source-item--link\">
                    {{ _self.sourceLink(key, source, isTopLevel, elementType, sortOptions ?? null, baseSortOptions ?? null, tableColumns ?? null, defaultTableColumns ?? null, viewModes ?? null) }}
                    {% if source.nested is defined and source.nested is not empty %}
                        {% embed '_includes/disclosure-toggle' with {
                            persist: true,
                            storageKey: 'sources-list:'~ key,
                            controls: key,
                            attributes: {
                                class: 'source-item__toggle'
                            }
                        } %}
                            {% block content %}
                                <span class=\"cp-icon puny\">
                                    {{ iconSvg('angle-down') }}
                                </span>
                                <span class=\"visually-hidden\">{{ 'Expand {heading} sources' | t('app', {
                                        heading: source.label
                                    }) }}</span>
                            {% endblock %}
                        {% endembed %}
                    {% endif %}
                </div>
                {% if source.nested is defined and source.nested is not empty %}
                    {% include \"_elements/sources\" with {
                        keyPrefix: key ~ '/',
                        id: key,
                        sources: source.nested
                    } %}
                {% endif %}
            {% endtag %}
        {% endif %}
    {% endfor %}
    {% if nestedUnderHeading %}
            </ul>
        </li>
    {% endif %}
{% endtag %}
{% endapply %}
", "_elements/sources", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/sources.twig");
    }
}


/* _elements/sources */
class __TwigTemplate_9c457c34489fcf00dbbe7c74182e025a___1698501450 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 133
        return "_includes/disclosure-toggle";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/sources");
        $this->parent = $this->loadTemplate("_includes/disclosure-toggle", "_elements/sources", 133);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_elements/sources");
    }

    // line 141
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 142
        yield "                                <span class=\"cp-icon puny\">
                                    ";
        // line 143
        yield craft\helpers\Cp::iconSvg("angle-down");
        yield "
                                </span>
                                <span class=\"visually-hidden\">";
        // line 145
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Expand {heading} sources", "app", ["heading" => craft\helpers\Template::attribute($this->env, $this->source,         // line 146
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 146, $this->source); })()), "label", [], "any", false, false, false, 146)]), "html", null, true);
        // line 147
        yield "</span>
                            ";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_elements/sources";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  862 => 147,  860 => 146,  859 => 145,  854 => 143,  851 => 142,  843 => 141,  830 => 133,  603 => 115,  601 => 114,  600 => 113,  595 => 111,  592 => 110,  584 => 109,  571 => 100,  342 => 78,  340 => 76,  339 => 75,  338 => 70,  333 => 69,  331 => 68,  328 => 67,  322 => 65,  316 => 63,  314 => 62,  311 => 61,  305 => 58,  302 => 57,  300 => 56,  295 => 54,  292 => 53,  290 => 52,  285 => 51,  282 => 50,  269 => 49,  261 => 46,  259 => 45,  258 => 44,  257 => 43,  256 => 42,  255 => 41,  254 => 40,  253 => 39,  252 => 38,  251 => 37,  250 => 36,  249 => 33,  248 => 32,  247 => 31,  246 => 30,  245 => 27,  244 => 26,  243 => 25,  242 => 24,  241 => 20,  240 => 19,  239 => 18,  238 => 17,  237 => 16,  236 => 15,  235 => 14,  234 => 13,  233 => 12,  232 => 11,  231 => 10,  229 => 6,  208 => 5,  202 => 1,  198 => 86,  197 => 85,  192 => 163,  189 => 162,  175 => 161,  172 => 160,  170 => 127,  169 => 126,  167 => 159,  164 => 158,  162 => 156,  161 => 155,  160 => 154,  158 => 153,  156 => 152,  153 => 151,  150 => 150,  148 => 136,  147 => 135,  145 => 133,  143 => 132,  139 => 131,  136 => 130,  133 => 124,  130 => 123,  127 => 122,  125 => 121,  121 => 120,  118 => 119,  115 => 118,  113 => 104,  112 => 102,  110 => 100,  107 => 99,  103 => 97,  99 => 95,  94 => 92,  91 => 91,  88 => 90,  85 => 89,  67 => 88,  65 => 84,  62 => 83,  60 => 82,  57 => 81,  54 => 48,  51 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% apply spaceless %}

{% hook 'cp.elements.sources' %}

{% macro sourceLink(key, source, isTopLevel, elementType, sortOptions, baseSortOptions, tableColumns, defaultTableColumns, viewModes) %}
    {{ tag('a', {
        role: 'button',
        tabindex: '0',
        data: {
            key: key,
            'label': source.label,
            'has-thumbs': (source.hasThumbs ?? false) ? true : false,
            'has-structure': (source.structureId ?? null)|boolean,
            'default-sort': source.defaultSort ?? false,
            'sort-opts': isTopLevel
                ? sortOptions ?? (baseSortOptions
                    |merge(craft.app.elementSources.getSourceSortOptions(elementType, key)|map(option => {
                        label: option.label,
                        attr: option.attribute ?? option.orderBy,
                        defaultDir: option.defaultDir ?? 'asc'
                    })|values))
                : false,
            'source-item': true,
            'table-col-opts': isTopLevel
                ? tableColumns
                    |merge(craft.app.elementSources.getSourceTableAttributes(elementType, key))
                    |map((a, key) => a|merge({attr: key}))
                    |values
                : false,
            'default-table-cols': isTopLevel
                ? (defaultTableColumns ?? craft.app.elementSources.getTableAttributes(elementType, key))
                    |map(a => a[0])
                    |filter(a => a != 'title')
                    |values
                : false,
            'default-source-path': (source.defaultSourcePath ?? false) ? source.defaultSourcePath|json_encode : false,
            sites: (source.sites ?? false) ? source.sites|join(',') : false,
            criteria: source.criteria ?? {},
            disabled: source.disabled ?? false,
            'default-filter': source.defaultFilter ?? false,
            'default-view-mode': source.defaultViewMode ?? false,
            'view-modes': viewModes ?? [],
            'field-layouts': source.fieldLayouts is defined ? source.fieldLayouts|map(layout => layout.getConfig()) : false,
        }|merge(source.data ?? {}),
        html: _self.sourceInnerHtml(source)
    }) }}
{% endmacro %}

{% macro sourceInnerHtml(source) %}
    {% if source.status is defined %}
        <span class=\"status {{ source.status }}\"></span>
    {% elseif source.icon is defined %}
        <span class=\"icon\">
            {{ (svg(source.icon, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.icon}'></span>\")|raw }}
        </span>
    {% elseif source.iconMask is defined %}
        <span class=\"icon icon-mask\">
            {{ (svg(source.iconMask, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.iconMask}'></span>\")|raw }}
        </span>
    {% endif %}
    <span class=\"label\">
        {% if source.label|trim is not same as('') %}
            {{ (source.type ?? null) == 'custom' ? source.label|t('site') : source.label }}
        {% else %}
            {{ '(blank)'|t('app') }}
        {% endif %}
    </span>
    {% if source.badgeCount ?? false %}
        <span class=\"badge\" aria-hidden=\"true\">{{ source.badgeCount|number(decimals=0) }}</span>
        {{ tag('span', {
            class: 'visually-hidden',
            data: {
                notification: true,
            },
            text: source.badgeLabel ?? '{num, number} {num, plural, =1{notification} other{notifications}}'|t('app', {
                num: source.badgeCount,
            }),
        }) }}
    {% endif %}
{% endmacro %}

{% set nestedUnderHeading = false %}

{% tag 'ul' with {
    class: keyPrefix ? 'nested sources-list' : 'sources-list',
    id: id ?? ''
} %}
    {% for source in sources %}
        {% if (source.type ?? null) == 'heading' %}
            {% set key = source.key ?? (source.heading | kebab) %}
            {% if nestedUnderHeading %}
                    </ul>
                </li>
            {% endif %}
            <li class=\"heading\">
                <div class=\"source-item source-item--heading\">
                    <span class=\"type-heading-small\">{{ source.heading|t('site') }}</span>
                    {# Don't toggle blank headings #}
                    {% if source.heading | length %}
                        {% embed '_includes/disclosure-toggle' with {
                            persist: true,
                            storageKey: 'sources-list:'~ key,
                            storageMode: 'cookies',
                            controls: key,
                            attributes: {
                                class: 'source-item__toggle'
                            }
                        } %}
                            {% block content %}
                                <span class=\"cp-icon puny\">
                                    {{ iconSvg('angle-down') }}
                                </span>
                                <span class=\"visually-hidden\">{{ 'Expand {heading} sources' | t('app', {
                                        heading: source.heading
                                    }) }}</span>
                            {% endblock %}
                        {% endembed %}
                    {% endif %}
                </div>
                <ul id=\"{{ key }}\" class=\"sources-list\">
            {% set nestedUnderHeading = true %}
        {% elseif (source.sites ?? null) is not same as([]) %}
            {% set key = source.keyPath ?? (keyPrefix ~ source.key) %}
            {% tag 'li' with {
                class: [
                    (source.nested ?? false) ? 'collapsible' : null,
                    (source.disabled ?? false) ? 'hidden' : null,
                ]|filter,
            } %}
                <div class=\"source-item source-item--link\">
                    {{ _self.sourceLink(key, source, isTopLevel, elementType, sortOptions ?? null, baseSortOptions ?? null, tableColumns ?? null, defaultTableColumns ?? null, viewModes ?? null) }}
                    {% if source.nested is defined and source.nested is not empty %}
                        {% embed '_includes/disclosure-toggle' with {
                            persist: true,
                            storageKey: 'sources-list:'~ key,
                            controls: key,
                            attributes: {
                                class: 'source-item__toggle'
                            }
                        } %}
                            {% block content %}
                                <span class=\"cp-icon puny\">
                                    {{ iconSvg('angle-down') }}
                                </span>
                                <span class=\"visually-hidden\">{{ 'Expand {heading} sources' | t('app', {
                                        heading: source.label
                                    }) }}</span>
                            {% endblock %}
                        {% endembed %}
                    {% endif %}
                </div>
                {% if source.nested is defined and source.nested is not empty %}
                    {% include \"_elements/sources\" with {
                        keyPrefix: key ~ '/',
                        id: key,
                        sources: source.nested
                    } %}
                {% endif %}
            {% endtag %}
        {% endif %}
    {% endfor %}
    {% if nestedUnderHeading %}
            </ul>
        </li>
    {% endif %}
{% endtag %}
{% endapply %}
", "_elements/sources", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/sources.twig");
    }
}
