<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/disclosure-toggle */
class __TwigTemplate_3f9801b5f9053ca67f0f52bcf812b81b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/disclosure-toggle");
        // line 1
        $context["attributes"] = (($context["attributes"]) ?? ([]));
        // line 2
        $context["id"] = (($context["id"]) ?? (null));
        // line 3
        $context["controls"] = (($context["controls"]) ?? (null));
        // line 4
        $context["expanded"] = (($context["expanded"]) ?? ("true"));
        // line 5
        $context["content"] = Twig\Extension\CoreExtension::trim((($context["content"]) ?? (((        $this->unwrap()->hasBlock("content", $context, $blocks)) ? (        $this->unwrap()->renderBlock("content", $context, $blocks)) : ("")))));
        // line 6
        $context["persist"] = (($context["persist"]) ?? (false));
        // line 7
        $context["storageMode"] = (($context["storageMode"]) ?? ("localStorage"));
        // line 8
        $context["storageKey"] = (($context["storageKey"]) ?? (null));
        // line 9
        yield "
";
        // line 10
        $context["cookieState"] = null;
        // line 11
        if ((((isset($context["persist"]) || array_key_exists("persist", $context) ? $context["persist"] : (function () { throw new RuntimeError('Variable "persist" does not exist.', 11, $this->source); })()) && ((isset($context["storageMode"]) || array_key_exists("storageMode", $context) ? $context["storageMode"] : (function () { throw new RuntimeError('Variable "storageMode" does not exist.', 11, $this->source); })()) == "cookies")) && (isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 11, $this->source); })()))) {
            // line 12
            yield "    ";
            $context["cookieState"] = (((isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 12, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 12, $this->source); })()), "app", [], "any", false, false, false, 12), "request", [], "any", false, false, false, 12), "rawCookies", [], "any", false, false, false, 12), "value", [((("Craft-" . craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 12, $this->source); })()), "app", [], "any", false, false, false, 12), "systemUid", [], "any", false, false, false, 12)) . ":") . (isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 12, $this->source); })()))], "method", false, false, false, 12)) : (null));
        }
        // line 14
        yield "
";
        // line 15
        $context["state"] = (($context["state"]) ?? ((isset($context["cookieState"]) || array_key_exists("cookieState", $context) ? $context["cookieState"] : (function () { throw new RuntimeError('Variable "cookieState" does not exist.', 15, $this->source); })())));
        // line 16
        yield "
";
        // line 17
        if ((isset($context["controls"]) || array_key_exists("controls", $context) ? $context["controls"] : (function () { throw new RuntimeError('Variable "controls" does not exist.', 17, $this->source); })())) {
            // line 18
            yield "    <craft-disclosure
        ";
            // line 19
            if ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 19, $this->source); })())) {
                yield "id=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 19, $this->source); })()), "html", null, true);
                yield "\"";
            }
            // line 20
            yield "        ";
            if ((isset($context["persist"]) || array_key_exists("persist", $context) ? $context["persist"] : (function () { throw new RuntimeError('Variable "persist" does not exist.', 20, $this->source); })())) {
                yield "persist";
            }
            // line 21
            yield "        ";
            if (((isset($context["persist"]) || array_key_exists("persist", $context) ? $context["persist"] : (function () { throw new RuntimeError('Variable "persist" does not exist.', 21, $this->source); })()) && (isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 21, $this->source); })()))) {
                yield "storage-key=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 21, $this->source); })()), "html", null, true);
                yield "\"";
            }
            // line 22
            yield "        ";
            if (((isset($context["persist"]) || array_key_exists("persist", $context) ? $context["persist"] : (function () { throw new RuntimeError('Variable "persist" does not exist.', 22, $this->source); })()) && (isset($context["storageMode"]) || array_key_exists("storageMode", $context) ? $context["storageMode"] : (function () { throw new RuntimeError('Variable "storageMode" does not exist.', 22, $this->source); })()))) {
                yield "storage-mode=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["storageMode"]) || array_key_exists("storageMode", $context) ? $context["storageMode"] : (function () { throw new RuntimeError('Variable "storageMode" does not exist.', 22, $this->source); })()), "html", null, true);
                yield "\"";
            }
            // line 23
            yield "        ";
            if ((isset($context["state"]) || array_key_exists("state", $context) ? $context["state"] : (function () { throw new RuntimeError('Variable "state" does not exist.', 23, $this->source); })())) {
                yield "state=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["state"]) || array_key_exists("state", $context) ? $context["state"] : (function () { throw new RuntimeError('Variable "state" does not exist.', 23, $this->source); })()), "html", null, true);
                yield "\"";
            }
            // line 24
            yield "    >
        <button
            type=\"button\"
            aria-controls=\"";
            // line 27
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["controls"]) || array_key_exists("controls", $context) ? $context["controls"] : (function () { throw new RuntimeError('Variable "controls" does not exist.', 27, $this->source); })()), "html", null, true);
            yield "\"
            aria-expanded=\"";
            // line 28
            yield ((((isset($context["state"]) || array_key_exists("state", $context) ? $context["state"] : (function () { throw new RuntimeError('Variable "state" does not exist.', 28, $this->source); })()) == "expanded")) ? ("true") : ("false"));
            yield "\"
            ";
            // line 29
            yield craft\helpers\Html::renderTagAttributes((isset($context["attributes"]) || array_key_exists("attributes", $context) ? $context["attributes"] : (function () { throw new RuntimeError('Variable "attributes" does not exist.', 29, $this->source); })()));
            yield "
        >
            ";
            // line 31
            yield (isset($context["content"]) || array_key_exists("content", $context) ? $context["content"] : (function () { throw new RuntimeError('Variable "content" does not exist.', 31, $this->source); })());
            yield "
        </button>
    </craft-disclosure>
";
        }
        craft\helpers\Template::endProfile("template", "_includes/disclosure-toggle");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/disclosure-toggle";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  133 => 31,  128 => 29,  124 => 28,  120 => 27,  115 => 24,  108 => 23,  101 => 22,  94 => 21,  89 => 20,  83 => 19,  80 => 18,  78 => 17,  75 => 16,  73 => 15,  70 => 14,  66 => 12,  64 => 11,  62 => 10,  59 => 9,  57 => 8,  55 => 7,  53 => 6,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set attributes = attributes ?? {} %}
{% set id = id ?? null %}
{% set controls = controls ?? null %}
{% set expanded = expanded ?? 'true' %}
{% set content = (content ?? block('content') ?? '')|trim %}
{% set persist = persist ?? false %}
{% set storageMode = storageMode ?? 'localStorage' %}
{% set storageKey = storageKey ?? null %}

{% set cookieState = null %}
{% if persist and storageMode == 'cookies' and storageKey %}
    {% set cookieState = storageKey ? craft.app.request.rawCookies.value('Craft-' ~ craft.app.systemUid ~  ':' ~ storageKey) : null %}
{% endif %}

{% set state = state ?? cookieState %}

{% if controls %}
    <craft-disclosure
        {% if id %}id=\"{{ id }}\"{% endif %}
        {% if persist %}persist{% endif %}
        {% if persist and storageKey %}storage-key=\"{{ storageKey }}\"{% endif %}
        {% if persist and storageMode %}storage-mode=\"{{ storageMode }}\"{% endif %}
        {% if state %}state=\"{{ state }}\"{% endif %}
    >
        <button
            type=\"button\"
            aria-controls=\"{{ controls }}\"
            aria-expanded=\"{{ state == 'expanded' ? 'true' : 'false' }}\"
            {{ attr(attributes) }}
        >
            {{ content | raw }}
        </button>
    </craft-disclosure>
{% endif %}
", "_includes/disclosure-toggle", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/disclosure-toggle.twig");
    }
}
