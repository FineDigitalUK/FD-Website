<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* assets/_index */
class __TwigTemplate_89c4506aa36a5d6ebb46a1b383e6cc45 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/elementindex.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "assets/_index");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Assets", "app");
        // line 3
        $context["elementType"] = "craft\\elements\\Asset";
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\fileupload\\FileUploadAsset"], "method", false, false, false, 5);
        // line 6
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 6, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\prismjs\\PrismJsAsset"], "method", false, false, false, 6);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/elementindex.twig", "assets/_index", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "assets/_index");
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "assets/_index";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  55 => 1,  53 => 6,  51 => 5,  49 => 3,  47 => 2,  39 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '_layouts/elementindex.twig' %}
{% set title = \"Assets\"|t('app') %}
{% set elementType = 'craft\\\\elements\\\\Asset' %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\fileupload\\\\FileUploadAsset\") %}
{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\prismjs\\\\PrismJsAsset\") %}
", "assets/_index", "/var/www/html/vendor/craftcms/cms/src/templates/assets/_index.twig");
    }
}
