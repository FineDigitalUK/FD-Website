<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/elementactions/SetStatus/trigger.twig */
class __TwigTemplate_fb0aa1b47dabdd642f1be62732b4bfd3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/elementactions/SetStatus/trigger.twig");
        // line 1
        yield "<button type=\"button\" class=\"btn menubtn\" aria-label=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Set status", "app"), "html", null, true);
        yield "\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Set status", "app"), "html", null, true);
        yield "</button>
<div class=\"menu\">
    <ul>
        <li><a class=\"formsubmit\" data-param=\"status\" data-value=\"enabled\"><span class=\"status enabled\"></span> ";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "html", null, true);
        yield "</a></li>
        <li><a class=\"formsubmit\" data-param=\"status\" data-value=\"disabled\"><span class=\"status disabled\"></span> ";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Disabled", "app"), "html", null, true);
        yield "</a></li>
    </ul>
</div>
";
        craft\helpers\Template::endProfile("template", "_components/elementactions/SetStatus/trigger.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/elementactions/SetStatus/trigger.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  56 => 5,  52 => 4,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<button type=\"button\" class=\"btn menubtn\" aria-label=\"{{ \"Set status\"|t('app') }}\">{{ \"Set status\"|t('app') }}</button>
<div class=\"menu\">
    <ul>
        <li><a class=\"formsubmit\" data-param=\"status\" data-value=\"enabled\"><span class=\"status enabled\"></span> {{ \"Enabled\"|t('app') }}</a></li>
        <li><a class=\"formsubmit\" data-param=\"status\" data-value=\"disabled\"><span class=\"status disabled\"></span> {{ \"Disabled\"|t('app') }}</a></li>
    </ul>
</div>
", "_components/elementactions/SetStatus/trigger.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/elementactions/SetStatus/trigger.twig");
    }
}
