<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/textarea */
class __TwigTemplate_6e2693a59540e7cad34a538e8062696b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/textarea");
        // line 1
        $context["class"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["text", (( !((        // line 3
$context["cols"]) ?? (false))) ? ("fullwidth") : (""))]));
        // line 6
        $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 7
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 7, $this->source); })()), "id" => ((        // line 8
$context["id"]) ?? (false)), "inputmode" => ((        // line 9
$context["inputmode"]) ?? (false)), "rows" => ((        // line 10
$context["rows"]) ?? (2)), "cols" => ((        // line 11
$context["cols"]) ?? (50)), "name" => ((        // line 12
$context["name"]) ?? (false)), "maxlength" => ((        // line 13
$context["maxlength"]) ?? (false)), "autofocus" => (((        // line 14
$context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 14, $this->source); })()), "app", [], "any", false, false, false, 14), "request", [], "any", false, false, false, 14), "isMobileBrowser", [true], "method", false, false, false, 14)), "disabled" => ((        // line 15
$context["disabled"]) ?? (false)), "readonly" => ((        // line 16
$context["readonly"]) ?? (false)), "title" => ((        // line 17
$context["title"]) ?? (false)), "placeholder" => ((        // line 18
$context["placeholder"]) ?? (false)), "text" => ((        // line 19
$context["value"]) ?? ("")), "aria" => ["describedby" => ((        // line 21
$context["describedBy"]) ?? (false))], "data" => ["show-chars-left" => ((        // line 24
$context["showCharsLeft"]) ?? (false))]], ((        // line 26
$context["inputAttributes"]) ?? ([])), true);
        // line 28
        if (        $this->unwrap()->hasBlock("attr", $context, $blocks)) {
            // line 29
            $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 29, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 32
        yield $this->extensions['craft\web\twig\Extension']->tagFunction("textarea", (isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 32, $this->source); })()));
        yield "
";
        craft\helpers\Template::endProfile("template", "_includes/forms/textarea");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/textarea";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  69 => 32,  66 => 29,  64 => 28,  62 => 26,  61 => 24,  60 => 21,  59 => 19,  58 => 18,  57 => 17,  56 => 16,  55 => 15,  54 => 14,  53 => 13,  52 => 12,  51 => 11,  50 => 10,  49 => 9,  48 => 8,  47 => 7,  46 => 6,  44 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{%- set class = (class ?? [])|explodeClass|merge([
    'text',
    not (cols ?? false) ? 'fullwidth',
]|filter) %}

{%- set inputAttributes = {
    class: class,
    id: id ?? false,
    inputmode: inputmode ?? false,
    rows: rows ?? 2,
    cols: cols ?? 50,
    name: name ?? false,
    maxlength: maxlength ?? false,
    autofocus: (autofocus ?? false) and not craft.app.request.isMobileBrowser(true),
    disabled: disabled ?? false,
    readonly: readonly ?? false,
    title: title ?? false,
    placeholder: placeholder ?? false,
    text: value ?? '',
    aria: {
        describedby: describedBy ?? false,
    },
    data: {
        'show-chars-left': showCharsLeft ?? false,
    },
}|merge(inputAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set inputAttributes = inputAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{%- endif %}

{{- tag('textarea', inputAttributes) }}
", "_includes/forms/textarea", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/textarea.twig");
    }
}
