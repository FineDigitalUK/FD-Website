<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/filesystems/_edit.twig */
class __TwigTemplate_41f0cbb04135a8a71f22b78dbfc1dae4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/filesystems/_edit.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "settings/filesystems/_edit.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 4
        yield "
";
        // line 5
        if (( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 5, $this->source); })()) && (isset($context["oldHandle"]) || array_key_exists("oldHandle", $context) ? $context["oldHandle"] : (function () { throw new RuntimeError('Variable "oldHandle" does not exist.', 5, $this->source); })()))) {
            // line 6
            yield "    ";
            yield craft\helpers\Html::hiddenInput("oldHandle", (isset($context["oldHandle"]) || array_key_exists("oldHandle", $context) ? $context["oldHandle"] : (function () { throw new RuntimeError('Variable "oldHandle" does not exist.', 6, $this->source); })()));
            yield "
";
        }
        // line 8
        yield "
";
        // line 9
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 9, $this->getSourceContext())->macro_textField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "id" => "name", "name" => "name", "value" => ((        // line 14
array_key_exists("filesystem", $context)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 14, $this->source); })()), "name", [], "any", false, false, false, 14)) : (null)), "autofocus" => true, "required" => true, "errors" => ((        // line 17
array_key_exists("filesystem", $context)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 17, $this->source); })()), "getErrors", ["name"], "method", false, false, false, 17)) : (null)), "data" => ["error-key" => "name"], "disabled" =>         // line 19
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 19, $this->source); })())]]);
        // line 20
        yield "

";
        // line 22
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 22, $this->getSourceContext())->macro_textField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => ((        // line 30
array_key_exists("filesystem", $context)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 30, $this->source); })()), "handle", [], "any", false, false, false, 30)) : (null)), "required" => true, "errors" => ((        // line 32
array_key_exists("filesystem", $context)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 32, $this->source); })()), "getErrors", ["handle"], "method", false, false, false, 32)) : (null)), "data" => ["error-key" => "handle"], "disabled" =>         // line 34
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 34, $this->source); })())]]);
        // line 35
        yield "

<hr>

";
        // line 39
        if ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["fsOptions"]) || array_key_exists("fsOptions", $context) ? $context["fsOptions"] : (function () { throw new RuntimeError('Variable "fsOptions" does not exist.', 39, $this->source); })()))) {
            // line 40
            yield "    ";
            yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 40, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Filesystem Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of filesystem is this?", "app"), "id" => "type", "name" => "type", "options" =>             // line 45
(isset($context["fsOptions"]) || array_key_exists("fsOptions", $context) ? $context["fsOptions"] : (function () { throw new RuntimeError('Variable "fsOptions" does not exist.', 45, $this->source); })()), "value" => get_class(            // line 46
(isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 46, $this->source); })())), "toggle" => true, "disabled" =>             // line 48
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 48, $this->source); })())]]);
            // line 49
            yield "
";
        }
        // line 51
        yield "
";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["fsTypes"]) || array_key_exists("fsTypes", $context) ? $context["fsTypes"] : (function () { throw new RuntimeError('Variable "fsTypes" does not exist.', 52, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["fsType"]) {
            // line 53
            yield "    ";
            $context["isCurrent"] = ($context["fsType"] == get_class((isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 53, $this->source); })())));
            // line 54
            yield "    ";
            $context["fs"] = (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 54, $this->source); })())) ? ((isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 54, $this->source); })())) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fsInstances"]) || array_key_exists("fsInstances", $context) ? $context["fsInstances"] : (function () { throw new RuntimeError('Variable "fsInstances" does not exist.', 54, $this->source); })()), $context["fsType"], [], "array", false, false, false, 54)));
            // line 55
            yield "    ";
            $context["classes"] = [];
            // line 56
            yield "    ";
            if ( !(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 56, $this->source); })())) {
                // line 57
                yield "        ";
                $context["classes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["classes"]) || array_key_exists("classes", $context) ? $context["classes"] : (function () { throw new RuntimeError('Variable "classes" does not exist.', 57, $this->source); })()), ["hidden"]);
                // line 58
                yield "    ";
            }
            // line 59
            yield "
    ";
            // line 60
            ob_start();
            // line 64
            yield "        ";
            $_namespace = (("types[" . craft\helpers\Html::id($context["fsType"])) . "]");
            if ($_namespace !== null && $_namespace !== '') {
                $_originalNamespace = Craft::$app->getView()->getNamespace();
                Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                ob_start();
                try {
                    // line 65
                    yield "            ";
                    // line 66
                    yield "                ";
                    yield $this->getTemplateForMacro("macro_fsUrlFields", $context, 66, $this->getSourceContext())->macro_fsUrlFields(...[(isset($context["fs"]) || array_key_exists("fs", $context) ? $context["fs"] : (function () { throw new RuntimeError('Variable "fs" does not exist.', 66, $this->source); })()), (isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 66, $this->source); })())]);
                    yield "
                ";
                    // line 67
                    yield (((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 67, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fs"]) || array_key_exists("fs", $context) ? $context["fs"] : (function () { throw new RuntimeError('Variable "fs" does not exist.', 67, $this->source); })()), "getReadOnlySettingsHtml", [], "method", false, false, false, 67)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fs"]) || array_key_exists("fs", $context) ? $context["fs"] : (function () { throw new RuntimeError('Variable "fs" does not exist.', 67, $this->source); })()), "getSettingsHtml", [], "method", false, false, false, 67)));
                    yield "
            ";
                    // line 69
                    yield "        ";
                } catch (Exception $e) {
                    ob_end_clean();

                    throw $e;
                }
                echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
                Craft::$app->getView()->setNamespace($_originalNamespace);
            } else {
                // line 65
                yield "            ";
                // line 66
                yield "                ";
                yield $this->getTemplateForMacro("macro_fsUrlFields", $context, 66, $this->getSourceContext())->macro_fsUrlFields(...[(isset($context["fs"]) || array_key_exists("fs", $context) ? $context["fs"] : (function () { throw new RuntimeError('Variable "fs" does not exist.', 66, $this->source); })()), (isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 66, $this->source); })())]);
                yield "
                ";
                // line 67
                yield (((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 67, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fs"]) || array_key_exists("fs", $context) ? $context["fs"] : (function () { throw new RuntimeError('Variable "fs" does not exist.', 67, $this->source); })()), "getReadOnlySettingsHtml", [], "method", false, false, false, 67)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fs"]) || array_key_exists("fs", $context) ? $context["fs"] : (function () { throw new RuntimeError('Variable "fs" does not exist.', 67, $this->source); })()), "getSettingsHtml", [], "method", false, false, false, 67)));
                yield "
            ";
                // line 69
                yield "        ";
            }
            unset($_originalNamespace, $_namespace);
            // line 70
            yield "    ";
            echo craft\helpers\Html::tag("div", ob_get_clean(), ["id" => craft\helpers\Html::id(            // line 61
$context["fsType"]), "class" =>             // line 62
(isset($context["classes"]) || array_key_exists("classes", $context) ? $context["classes"] : (function () { throw new RuntimeError('Variable "classes" does not exist.', 62, $this->source); })())]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['fsType'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 72
        yield "

";
        // line 74
        if (( !array_key_exists("filesystem", $context) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 74, $this->source); })()), "handle", [], "any", false, false, false, 74))) {
            // line 75
            yield "    ";
            ob_start();
            // line 76
            yield "        new Craft.HandleGenerator(\"#";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()("name"), "html", null, true);
            yield "\", \"#";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()("handle"), "html", null, true);
            yield "\");
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 79
        yield "

";
        craft\helpers\Template::endProfile("template", "settings/filesystems/_edit.twig");
        yield from [];
    }

    // line 81
    public function macro_fsUrlFields($filesystem = null, $disabled = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "filesystem" => $filesystem,
            "disabled" => $disabled,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "fsUrlFields");
            // line 82
            yield "    ";
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 82, $this->source); })()), "getShowHasUrlSetting", [], "method", false, false, false, 82)) {
                // line 83
                yield "        ";
                yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 83, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Files in this filesystem have public URLs", "app"), "name" => "hasUrls", "id" => "has-urls", "on" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 87
(isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 87, $this->source); })()), "hasUrls", [], "any", false, false, false, 87), "toggle" => ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 88
(isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 88, $this->source); })()), "getShowUrlSetting", [], "method", false, false, false, 88)) ? ("url-field-container") : (null)), "disabled" =>                 // line 89
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 89, $this->source); })())]]);
                // line 90
                yield "
    ";
            }
            // line 92
            yield "
    ";
            // line 93
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 93, $this->source); })()), "getShowUrlSetting", [], "method", false, false, false, 93)) {
                // line 94
                yield "        <div id=\"url-field-container\" class=\"";
                if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 94, $this->source); })()), "hasUrls", [], "any", false, false, false, 94)) {
                    yield "hidden";
                }
                yield "\">
            ";
                // line 95
                yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 95, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The base URL to the files in this filesystem.", "app"), "id" => "url", "class" => ["ltr", "fs-url"], "name" => "url", "suggestEnvVars" => true, "suggestAliases" => true, "value" => ((                // line 103
array_key_exists("filesystem", $context)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 103, $this->source); })()), "url", [], "any", false, false, false, 103)) : (null)), "required" => true, "placeholder" => "//example.com/path/to/folder", "errors" => ((                // line 106
array_key_exists("filesystem", $context)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["filesystem"]) || array_key_exists("filesystem", $context) ? $context["filesystem"] : (function () { throw new RuntimeError('Variable "filesystem" does not exist.', 106, $this->source); })()), "getErrors", ["url"], "method", false, false, false, 106)) : (null)), "data" => ["error-key" => "url"], "disabled" =>                 // line 108
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 108, $this->source); })())]]);
                // line 109
                yield "
        </div>
    ";
            }
            // line 112
            yield "
    <hr />
";
            craft\helpers\Template::endProfile("macro", "fsUrlFields");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/filesystems/_edit.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  254 => 112,  249 => 109,  247 => 108,  246 => 106,  245 => 103,  244 => 95,  237 => 94,  235 => 93,  232 => 92,  228 => 90,  226 => 89,  225 => 88,  224 => 87,  222 => 83,  219 => 82,  205 => 81,  197 => 79,  188 => 76,  185 => 75,  183 => 74,  179 => 72,  173 => 62,  172 => 61,  170 => 70,  166 => 69,  162 => 67,  157 => 66,  155 => 65,  145 => 69,  141 => 67,  136 => 66,  134 => 65,  126 => 64,  124 => 60,  121 => 59,  118 => 58,  115 => 57,  112 => 56,  109 => 55,  106 => 54,  103 => 53,  99 => 52,  96 => 51,  92 => 49,  90 => 48,  89 => 46,  88 => 45,  86 => 40,  84 => 39,  78 => 35,  76 => 34,  75 => 32,  74 => 30,  73 => 22,  69 => 20,  67 => 19,  66 => 17,  65 => 14,  64 => 9,  61 => 8,  55 => 6,  53 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms.twig' as forms %}

{% set readOnly = readOnly ?? false %}

{% if not readOnly and oldHandle %}
    {{ hiddenInput('oldHandle', oldHandle) }}
{% endif %}

{{ forms.textField({
    first: true,
    label: \"Name\"|t('app'),
    id: 'name',
    name: 'name',
    value: (filesystem is defined ? filesystem.name : null),
    autofocus: true,
    required: true,
    errors: (filesystem is defined ? filesystem.getErrors('name') : null),
    data: {'error-key': 'name'},
    disabled: readOnly,
}) }}

{{ forms.textField({
    first: true,
    label: \"Handle\"|t('app'),
    id: 'handle',
    name: 'handle',
    class: 'code',
    autocorrect: false,
    autocapitalize: false,
    value: (filesystem is defined ? filesystem.handle : null),
    required: true,
    errors: (filesystem is defined ? filesystem.getErrors('handle') : null),
    data: {'error-key': 'handle'},
    disabled: readOnly,
}) }}

<hr>

{% if fsOptions|length %}
    {{ forms.selectField({
        label: 'Filesystem Type'|t('app'),
        instructions: \"What type of filesystem is this?\"|t('app'),
        id: 'type',
        name: 'type',
        options: fsOptions,
        value: className(filesystem),
        toggle: true,
        disabled: readOnly,
    }) }}
{% endif %}

{% for fsType in fsTypes %}
    {% set isCurrent = (fsType == className(filesystem)) %}
    {% set fs = isCurrent ? filesystem : fsInstances[fsType] %}
    {% set classes = [] %}
    {% if not isCurrent %}
        {% set classes = classes|merge(['hidden']) %}
    {% endif %}

    {% tag 'div' with {
        id: fsType|id,
        class: classes,
    } %}
        {% namespace 'types['~fsType|id~']' %}
            {% autoescape false %}
                {{ _self.fsUrlFields(fs, readOnly) }}
                {{ readOnly ? fs.getReadOnlySettingsHtml() : fs.getSettingsHtml() }}
            {% endautoescape %}
        {% endnamespace %}
    {% endtag %}
{% endfor %}


{% if filesystem is not defined or not filesystem.handle %}
    {% js %}
        new Craft.HandleGenerator(\"#{{ 'name'|namespaceInputId }}\", \"#{{ 'handle'|namespaceInputId }}\");
    {% endjs %}
{% endif %}


{% macro fsUrlFields(filesystem, disabled) %}
    {% if filesystem.getShowHasUrlSetting() %}
        {{ forms.lightswitchField({
            label: 'Files in this filesystem have public URLs'|t('app'),
            name: 'hasUrls',
            id: 'has-urls',
            on:   filesystem.hasUrls,
            toggle: filesystem.getShowUrlSetting() ? \"url-field-container\" : null,
            disabled: disabled,
        }) }}
    {% endif %}

    {% if filesystem.getShowUrlSetting() %}
        <div id=\"url-field-container\" class=\"{% if not filesystem.hasUrls %}hidden{% endif %}\">
            {{ forms.autosuggestField({
                label: \"Base URL\"|t('app'),
                instructions: \"The base URL to the files in this filesystem.\"|t('app'),
                id: 'url',
                class: ['ltr', 'fs-url'],
                name: 'url',
                suggestEnvVars: true,
                suggestAliases: true,
                value: (filesystem is defined ? filesystem.url : null),
                required: true,
                placeholder: \"//example.com/path/to/folder\",
                errors: (filesystem is defined ? filesystem.getErrors('url') : null),
                data: {'error-key': 'url'},
                disabled: disabled,
            }) }}
        </div>
    {% endif %}

    <hr />
{% endmacro %}
", "settings/filesystems/_edit.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/filesystems/_edit.twig");
    }
}
