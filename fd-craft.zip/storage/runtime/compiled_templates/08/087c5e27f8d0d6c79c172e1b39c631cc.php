<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* login.twig */
class __TwigTemplate_146ae52fa96188ff4c541c8deaefe3bf extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/basecp.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "login.twig");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Sign In", "app");
        // line 3
        $context["bodyClass"] = "login";
        // line 5
        $context["hasLogo"] = (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 5, $this->source); })()) >= (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 5, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "rebrand", [], "any", false, false, false, 5), "isLogoUploaded", [], "any", false, false, false, 5));
        // line 7
        if ((isset($context["hasLogo"]) || array_key_exists("hasLogo", $context) ? $context["hasLogo"] : (function () { throw new RuntimeError('Variable "hasLogo" does not exist.', 7, $this->source); })())) {
            // line 8
            $context["logo"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 8, $this->source); })()), "rebrand", [], "any", false, false, false, 8), "logo", [], "any", false, false, false, 8);
        }
        // line 11
        $context["formHtml"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 12
            yield "  <main>
    ";
            // line 13
            if ((isset($context["hasLogo"]) || array_key_exists("hasLogo", $context) ? $context["hasLogo"] : (function () { throw new RuntimeError('Variable "hasLogo" does not exist.', 13, $this->source); })())) {
                // line 14
                yield "      <h1>
        ";
                // line 15
                yield $this->extensions['craft\web\twig\Extension']->tagFunction("img", ["id" => "login-logo", "src" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 17
(isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 17, $this->source); })()), "url", [], "any", false, false, false, 17), "alt" =>                 // line 18
(isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 18, $this->source); })()), "width" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 19
(isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 19, $this->source); })()), "width", [], "any", false, false, false, 19), "height" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 20
(isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 20, $this->source); })()), "height", [], "any", false, false, false, 20)]);
                // line 21
                yield "
      </h1>
    ";
            }
            // line 24
            yield "
    ";
            // line 25
            yield from $this->loadTemplate("_special/login.twig", "login.twig", 25)->unwrap()->yield(CoreExtension::merge($context, ["showResetPassword" => true, "showRememberMeCheckbox" => true]));
            // line 29
            yield "
    ";
            // line 30
            if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 30, $this->source); })()), "app", [], "any", false, false, false, 30), "request", [], "any", false, false, false, 30), "isCpRequest", [], "any", false, false, false, 30)) {
                // line 31
                yield "      <a id=\"poweredby\" href=\"http://craftcms.com/\" title=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Powered by Craft CMS", "app"), "html", null, true);
                yield "\" aria-label=\"Craft CMS\">
        ";
                // line 32
                yield $this->extensions['craft\web\twig\Extension']->svgFunction("@app/web/assets/cp/dist/images/craftcms.svg");
                yield "
      </a>
    ";
            }
            // line 35
            yield "  </main>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 38
        $context["noCookiesHtml"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 39
            yield "  <main class=\"message-container\">
    <div class=\"modal-shade visible\"></div>
    <div class=\"modal\">
      <div class=\"body\">
        <p>";
            // line 43
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Cookies must be enabled to access the Craft CMS control panel.", "app"), "html", null, true);
            yield "</p>
      </div>
    </div>
  </main>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 71
        ob_start();
        // line 72
        yield "  html {
    height: 100%;
  }
";
        craft\helpers\Template::css(ob_get_clean());
        // line 77
        ob_start();
        // line 78
        yield "  (() => {
    const loginForm = new Craft.LoginForm(\$('.login-container'));

    ";
        // line 81
        if (array_key_exists("authFormData", $context)) {
            // line 82
            yield "      loginForm.show2faForm(";
            yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["authFormData"]) || array_key_exists("authFormData", $context) ? $context["authFormData"] : (function () { throw new RuntimeError('Variable "authFormData" does not exist.', 82, $this->source); })()));
            yield ");
    ";
        }
        // line 84
        yield "  })();
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/basecp.twig", "login.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "login.twig");
    }

    // line 49
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 50
        yield "  <header>
    ";
        // line 51
        yield from $this->loadTemplate("_layouts/components/system-info", "login.twig", 51)->unwrap()->yield($context);
        // line 52
        yield "  </header>

  <script type=\"text/javascript\">
    var cookieTest = 'CraftCookieTest='+Math.floor(Math.random() * 1000000);
    document.cookie = cookieTest;
    if (document.cookie.search(cookieTest) != -1) {
      document.cookie = cookieTest + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
      document.write(";
        // line 59
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["formHtml"]) || array_key_exists("formHtml", $context) ? $context["formHtml"] : (function () { throw new RuntimeError('Variable "formHtml" does not exist.', 59, $this->source); })()));
        yield ");
    } else {
      document.write(";
        // line 61
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["noCookiesHtml"]) || array_key_exists("noCookiesHtml", $context) ? $context["noCookiesHtml"] : (function () { throw new RuntimeError('Variable "noCookiesHtml" does not exist.', 61, $this->source); })()));
        yield ");
      setTimeout(() => {
        if (document.activeElement !== document.body) {
          \$(document.activeElement).blur();
        }
      }, 50);
    }
  </script>
";
        craft\helpers\Template::endProfile("block", "body");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "login.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  183 => 61,  178 => 59,  169 => 52,  167 => 51,  164 => 50,  156 => 49,  150 => 1,  146 => 84,  140 => 82,  138 => 81,  133 => 78,  131 => 77,  125 => 72,  123 => 71,  114 => 43,  108 => 39,  106 => 38,  101 => 35,  95 => 32,  90 => 31,  88 => 30,  85 => 29,  83 => 25,  80 => 24,  75 => 21,  73 => 20,  72 => 19,  71 => 18,  70 => 17,  69 => 15,  66 => 14,  64 => 13,  61 => 12,  59 => 11,  56 => 8,  54 => 7,  52 => 5,  50 => 3,  48 => 2,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '_layouts/basecp.twig' %}
{% set title = \"Sign In\"|t('app') %}
{% set bodyClass = 'login' %}

{% set hasLogo = CraftEdition >= CraftPro and craft.rebrand.isLogoUploaded %}

{% if hasLogo %}
  {% set logo = craft.rebrand.logo %}
{% endif %}

{% set formHtml %}
  <main>
    {% if hasLogo %}
      <h1>
        {{ tag('img', {
          id: 'login-logo',
          src: logo.url,
          alt: systemName,
          width: logo.width,
          height: logo.height,
        }) }}
      </h1>
    {% endif %}

    {% include '_special/login.twig' with {
      showResetPassword: true,
      showRememberMeCheckbox: true,
    } %}

    {% if craft.app.request.isCpRequest %}
      <a id=\"poweredby\" href=\"http://craftcms.com/\" title=\"{{ 'Powered by Craft CMS'|t('app') }}\" aria-label=\"Craft CMS\">
        {{ svg('@app/web/assets/cp/dist/images/craftcms.svg') }}
      </a>
    {% endif %}
  </main>
{% endset %}

{% set noCookiesHtml %}
  <main class=\"message-container\">
    <div class=\"modal-shade visible\"></div>
    <div class=\"modal\">
      <div class=\"body\">
        <p>{{ 'Cookies must be enabled to access the Craft CMS control panel.'|t('app') }}</p>
      </div>
    </div>
  </main>
{% endset %}

{% block body %}
  <header>
    {% include '_layouts/components/system-info' %}
  </header>

  <script type=\"text/javascript\">
    var cookieTest = 'CraftCookieTest='+Math.floor(Math.random() * 1000000);
    document.cookie = cookieTest;
    if (document.cookie.search(cookieTest) != -1) {
      document.cookie = cookieTest + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
      document.write({{ formHtml|json_encode|raw }});
    } else {
      document.write({{ noCookiesHtml|json_encode|raw }});
      setTimeout(() => {
        if (document.activeElement !== document.body) {
          \$(document.activeElement).blur();
        }
      }, 50);
    }
  </script>
{% endblock %}

{% css %}
  html {
    height: 100%;
  }
{% endcss %}

{% js %}
  (() => {
    const loginForm = new Craft.LoginForm(\$('.login-container'));

    {% if authFormData is defined %}
      loginForm.show2faForm({{ authFormData|json_encode|raw }});
    {% endif %}
  })();
{% endjs %}
", "login.twig", "/var/www/html/vendor/craftcms/cms/src/templates/login.twig");
    }
}
