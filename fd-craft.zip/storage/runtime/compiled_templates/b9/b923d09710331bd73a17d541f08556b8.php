<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/categories/index.twig */
class __TwigTemplate_cc1458fd1054bc7d8742ef11d4c9d0f9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/categories/index.twig");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Category Groups", "app");
        // line 3
        $context["readOnly"] =  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "app", [], "any", false, false, false, 3), "config", [], "any", false, false, false, 3), "general", [], "any", false, false, false, 3), "allowAdminChanges", [], "any", false, false, false, 3);
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\admintable\\AdminTableAsset"], "method", false, false, false, 5);
        // line 7
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 7, $this->source); })()), "registerTranslations", ["app", ["Name", "Handle", "Manage categories", "No category groups exist yet."]], "method", false, false, false, 7);
        // line 21
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 25
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 25, $this->source); })())) {
            // line 26
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 33
        $context["tableData"] = [];
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["categoryGroups"]) || array_key_exists("categoryGroups", $context) ? $context["categoryGroups"] : (function () { throw new RuntimeError('Variable "categoryGroups" does not exist.', 34, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 35
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 35, $this->source); })()), [["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 36
$context["group"], "id", [], "any", false, false, false, 36), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 37
$context["group"], "name", [], "any", false, false, false, 37), "site"), "url" => craft\helpers\UrlHelper::url(("settings/categories/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 38
$context["group"], "id", [], "any", false, false, false, 38))), "name" => $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 39
$context["group"], "name", [], "any", false, false, false, 39), "site")), "handle" => craft\helpers\Template::attribute($this->env, $this->source,             // line 40
$context["group"], "handle", [], "any", false, false, false, 40), "manageCategories" => craft\helpers\UrlHelper::url(("categories/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 41
$context["group"], "handle", [], "any", false, false, false, 41)))]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['group'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        ob_start();
        // line 46
        yield "    var columns = [
        {
            name: '__slot:title',
            title: Craft.t('app', 'Name'),
        },
        {
            name: '__slot:handle',
            title: Craft.t('app', 'Handle'),
        },
        {
            name: 'manageCategories',
            title: \"\",
            callback: function(value) {
                return '<a href=\"'+value+'\">' + Craft.escapeHtml(Craft.t('app', \"Manage categories\")) + '</a>';
            }
        },
    ];

    let config = {
        columns: columns,
        container: '#categorygroups-vue-admin-table',
        emptyMessage: Craft.t('app', 'No category groups exist yet.'),
        tableData: ";
        // line 68
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 68, $this->source); })()));
        yield "
    };

    ";
        // line 71
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 71, $this->source); })())) {
            // line 72
            yield "        config['deleteAction'] = 'categories/delete-category-group';
    ";
        }
        // line 74
        yield "
    new Craft.VueAdminTable(config);
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/categories/index.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/categories/index.twig");
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 15
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 15, $this->source); })())) {
            // line 16
            yield "        ";
            $context["buttonLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("New category group", "app");
            // line 17
            yield "        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("settings/categories/new"), "html", null, true);
            yield "\" class=\"btn submit add icon\" aria-label=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["buttonLabel"]) || array_key_exists("buttonLabel", $context) ? $context["buttonLabel"] : (function () { throw new RuntimeError('Variable "buttonLabel" does not exist.', 17, $this->source); })()), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["buttonLabel"]) || array_key_exists("buttonLabel", $context) ? $context["buttonLabel"] : (function () { throw new RuntimeError('Variable "buttonLabel" does not exist.', 17, $this->source); })()), "html", null, true);
            yield "</a>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 30
        yield "    <div id=\"categorygroups-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/categories/index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  167 => 30,  159 => 29,  145 => 17,  142 => 16,  139 => 15,  131 => 14,  125 => 1,  120 => 74,  116 => 72,  114 => 71,  108 => 68,  84 => 46,  82 => 45,  76 => 41,  75 => 40,  74 => 39,  73 => 38,  72 => 37,  71 => 36,  70 => 35,  66 => 34,  64 => 33,  61 => 26,  59 => 25,  57 => 21,  55 => 7,  53 => 5,  51 => 3,  49 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"Category Groups\"|t('app') %}
{% set readOnly = not craft.app.config.general.allowAdminChanges %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% do view.registerTranslations('app', [
    \"Name\",
    \"Handle\",
    \"Manage categories\",
    \"No category groups exist yet.\",
]) %}

{% block actionButton %}
    {% if not readOnly %}
        {% set buttonLabel = \"New category group\"|t('app') %}
        <a href=\"{{ url('settings/categories/new') }}\" class=\"btn submit add icon\" aria-label=\"{{ buttonLabel }}\">{{ buttonLabel }}</a>
    {% endif %}
{% endblock %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    <div id=\"categorygroups-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% for group in categoryGroups %}
    {% set tableData = tableData|merge([{
        id: group.id,
        title: group.name|t('site'),
        url: url('settings/categories/' ~ group.id),
        name: group.name|t('site')|e,
        handle: group.handle,
        manageCategories: url('categories/'~group.handle),
    }]) %}
{% endfor %}

{% js %}
    var columns = [
        {
            name: '__slot:title',
            title: Craft.t('app', 'Name'),
        },
        {
            name: '__slot:handle',
            title: Craft.t('app', 'Handle'),
        },
        {
            name: 'manageCategories',
            title: \"\",
            callback: function(value) {
                return '<a href=\"'+value+'\">' + Craft.escapeHtml(Craft.t('app', \"Manage categories\")) + '</a>';
            }
        },
    ];

    let config = {
        columns: columns,
        container: '#categorygroups-vue-admin-table',
        emptyMessage: Craft.t('app', 'No category groups exist yet.'),
        tableData: {{ tableData|json_encode|raw }}
    };

    {% if not readOnly %}
        config['deleteAction'] = 'categories/delete-category-group';
    {% endif %}

    new Craft.VueAdminTable(config);
{% endjs %}
", "settings/categories/index.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/categories/index.twig");
    }
}
