<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/checkbox */
class __TwigTemplate_695705ab6b56e18faa92f0112aa476c7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/checkbox");
        // line 1
        $macros["_v0"] = $this->macros["_v0"] = $this->loadTemplate("_includes/forms", "_includes/forms/checkbox", 1)->unwrap();
        // line 2
        $_v1 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 3
            yield "
";
            // line 4
            $context["id"] = (($context["id"]) ?? (("checkbox" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
            // line 5
            $context["label"] = (($context["checkboxLabel"]) ?? ((($context["label"]) ?? (null))));
            // line 6
            $context["labelId"] = (($context["labelId"]) ?? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 6, $this->source); })()) . "-label")));
            // line 7
            $context["color"] = (($context["color"]) ?? (null));
            // line 8
            $context["icon"] = (($context["icon"]) ?? (null));
            // line 9
            yield "
";
            // line 10
            $context["aria"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((((craft\helpers\Template::attribute($this->env, $this->source, ($context["inputAttributes"] ?? null), "aria", [], "any", true, true, false, 10) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["inputAttributes"] ?? null), "aria", [], "any", false, false, false, 10)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["inputAttributes"] ?? null), "aria", [], "any", false, false, false, 10)) : ([])), (($context["aria"]) ?? ([])));
            // line 11
            $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>             // line 12
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 12, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass(((            // line 13
$context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [((((            // line 14
$context["targetPrefix"]) ?? ((($context["toggle"]) ?? ((($context["reverseToggle"]) ?? (false))))))) ? ("fieldtoggle") : (null)), "checkbox"])), "checked" => (((            // line 17
$context["checked"]) ?? (false)) && (isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 17, $this->source); })())), "autofocus" => (((            // line 18
$context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 18, $this->source); })()), "app", [], "any", false, false, false, 18), "request", [], "any", false, false, false, 18), "isMobileBrowser", [true], "method", false, false, false, 18)), "disabled" => ((((            // line 19
$context["disabled"]) ?? (false))) ? (true) : (false)), "aria" => $this->extensions['craft\web\twig\Extension']->mergeFilter(            // line 20
(isset($context["aria"]) || array_key_exists("aria", $context) ? $context["aria"] : (function () { throw new RuntimeError('Variable "aria" does not exist.', 20, $this->source); })()), ["labelledby" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 21
($context["aria"] ?? null), "label", [], "any", true, true, false, 21) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["aria"] ?? null), "label", [], "any", false, false, false, 21)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["aria"] ?? null), "label", [], "any", false, false, false, 21)) : (false))) ? (false) : ((($context["labelledBy"]) ?? (false)))), "describedby" => ((            // line 22
$context["describedBy"]) ?? ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["aria"] ?? null), "describedby", [], "any", true, true, false, 22) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["aria"] ?? null), "describedby", [], "any", false, false, false, 22)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["aria"] ?? null), "describedby", [], "any", false, false, false, 22)) : (false))))]), "data" => $this->extensions['craft\web\twig\Extension']->mergeFilter(((            // line 24
$context["data"]) ?? ([])), ["target-prefix" => ((            // line 25
$context["targetPrefix"]) ?? (false)), "target" => ((            // line 26
$context["toggle"]) ?? (false)), "reverse-target" => ((            // line 27
$context["reverseToggle"]) ?? (false))])], ((            // line 29
$context["inputAttributes"]) ?? ([])), true);
            // line 30
            yield "
";
            // line 31
            if (            $this->unwrap()->hasBlock("attr", $context, $blocks)) {
                // line 32
                $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 32, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .                 $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
            }
            // line 34
            yield "
";
            // line 35
            if ((array_key_exists("name", $context) && (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 35, $this->source); })())) < 3) || (Twig\Extension\CoreExtension::slice($this->env->getCharset(), (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 35, $this->source); })()),  -2) != "[]")))) {
                // line 36
                yield "    ";
                yield craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 36, $this->source); })()), "");
                yield "
";
            }
            // line 38
            yield "
";
            // line 39
            yield craft\helpers\Html::input("checkbox", (($context["name"]) ?? (null)), (($context["value"]) ?? (1)), (isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 39, $this->source); })()));
            yield "

";
            // line 41
            ob_start();
            // line 45
            yield "    ";
            if ((($context["custom"]) ?? (false))) {
                // line 46
                yield "        ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Custom:", "app"), "html", null, true);
                yield "
    ";
            } else {
                // line 48
                yield "        ";
                if (((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 48, $this->source); })()) || (isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 48, $this->source); })()))) {
                    // line 49
                    yield "            <div class=\"flex flex-nowrap gap-xs\">
                ";
                    // line 50
                    if ((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 50, $this->source); })())) {
                        // line 51
                        yield "                    ";
                        $context["style"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["--icon-color" =>                         // line 52
(isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 52, $this->source); })())]);
                        // line 54
                        yield "                    ";
                        yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "cp-icon puny", "style" =>                         // line 56
(isset($context["style"]) || array_key_exists("style", $context) ? $context["style"] : (function () { throw new RuntimeError('Variable "style" does not exist.', 56, $this->source); })()), "html" => craft\helpers\Cp::iconSvg(                        // line 57
(isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 57, $this->source); })()))]);
                        // line 58
                        yield "
                ";
                    } else {
                        // line 60
                        yield "                    <div class=\"color small\">
                        <div class=\"color-preview\" style=\"background-color: ";
                        // line 61
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 61, $this->source); })()), "html", null, true);
                        yield "\"></div>
                    </div>
                ";
                    }
                    // line 64
                    yield "                <span>";
                    yield (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 64, $this->source); })());
                    yield "</span>
            </div>
        ";
                } else {
                    // line 67
                    yield "            ";
                    yield (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 67, $this->source); })());
                    yield "
        ";
                }
                // line 69
                yield "
    ";
            }
            // line 71
            yield "    ";
            if ((($context["info"]) ?? (null))) {
                // line 72
                yield "        <span class=\"info\">";
                yield $this->extensions['craft\web\twig\Extension']->markdownFilter((isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new RuntimeError('Variable "info" does not exist.', 72, $this->source); })()));
                yield "</span>
    ";
            }
            echo craft\helpers\Html::tag("label", ob_get_clean(), ["for" =>             // line 42
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 42, $this->source); })()), "id" =>             // line 43
(isset($context["labelId"]) || array_key_exists("labelId", $context) ? $context["labelId"] : (function () { throw new RuntimeError('Variable "labelId" does not exist.', 43, $this->source); })())]);
            // line 75
            yield "
";
            // line 76
            if ((($context["custom"]) ?? (false))) {
                // line 77
                yield "    <div class=\"custom-option-wrapper\">
        ";
                // line 78
                yield $macros["_v0"]->getTemplateForMacro("macro_text", $context, 78, $this->getSourceContext())->macro_text(...[["value" => ((                // line 79
$context["value"]) ?? (null)), "class" => "small custom-option-input", "labelledBy" =>                 // line 81
(isset($context["labelId"]) || array_key_exists("labelId", $context) ? $context["labelId"] : (function () { throw new RuntimeError('Variable "labelId" does not exist.', 81, $this->source); })())]]);
                // line 82
                yield "
    </div>
";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 2
        yield Twig\Extension\CoreExtension::spaceless($_v1);
        craft\helpers\Template::endProfile("template", "_includes/forms/checkbox");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/checkbox";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  197 => 2,  190 => 82,  188 => 81,  187 => 79,  186 => 78,  183 => 77,  181 => 76,  178 => 75,  176 => 43,  175 => 42,  169 => 72,  166 => 71,  162 => 69,  156 => 67,  149 => 64,  143 => 61,  140 => 60,  136 => 58,  134 => 57,  133 => 56,  131 => 54,  129 => 52,  127 => 51,  125 => 50,  122 => 49,  119 => 48,  113 => 46,  110 => 45,  108 => 41,  103 => 39,  100 => 38,  94 => 36,  92 => 35,  89 => 34,  86 => 32,  84 => 31,  81 => 30,  79 => 29,  78 => 27,  77 => 26,  76 => 25,  75 => 24,  74 => 22,  73 => 21,  72 => 20,  71 => 19,  70 => 18,  69 => 17,  68 => 14,  67 => 13,  66 => 12,  65 => 11,  63 => 10,  60 => 9,  58 => 8,  56 => 7,  54 => 6,  52 => 5,  50 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% from '_includes/forms' import text %}
{%- apply spaceless %}

{% set id = id ?? \"checkbox#{random()}\" %}
{% set label = checkboxLabel ?? label ?? null %}
{% set labelId = labelId ?? \"#{id}-label\" %}
{% set color = color ?? null %}
{% set icon = icon ?? null %}

{% set aria = (inputAttributes.aria ?? {})|merge(aria ?? {}) %}
{% set inputAttributes = {
    id: id,
    class: (class ?? [])|explodeClass|merge([
        (targetPrefix ?? toggle ?? reverseToggle ?? false) ? 'fieldtoggle' : null,
        'checkbox'
    ]|filter),
    checked: (checked ?? false) and checked,
    autofocus: (autofocus ?? false) and not craft.app.request.isMobileBrowser(true),
    disabled: (disabled ?? false) ? true : false,
    aria: aria|merge({
        labelledby: (aria.label ?? false) ? false : (labelledBy ?? false),
        describedby: describedBy ?? aria.describedby ?? false,
    }),
    data: (data ?? {})|merge({
        'target-prefix': targetPrefix ?? false,
        target: toggle ?? false,
        'reverse-target': reverseToggle ?? false,
    }),
}|merge(inputAttributes ?? [], recursive=true) %}

{% if block('attr') is defined %}
    {%- set inputAttributes = inputAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% if name is defined and (name|length < 3 or name|slice(-2) != '[]') %}
    {{ hiddenInput(name, '') }}
{% endif %}

{{ input('checkbox', name ?? null, value ?? 1, inputAttributes) }}

{% tag 'label' with {
    for: id,
    id: labelId,
} %}
    {% if custom ?? false %}
        {{ 'Custom:'|t('app') }}
    {% else %}
        {% if icon or color %}
            <div class=\"flex flex-nowrap gap-xs\">
                {% if icon %}
                    {% set style = {
                        '--icon-color': color,
                    }|filter %}
                    {{ tag('span', {
                        class: 'cp-icon puny',
                        style,
                        html: iconSvg(icon),
                    }) }}
                {% else %}
                    <div class=\"color small\">
                        <div class=\"color-preview\" style=\"background-color: {{ color }}\"></div>
                    </div>
                {% endif %}
                <span>{{ label|raw }}</span>
            </div>
        {% else %}
            {{ label|raw }}
        {% endif %}

    {% endif %}
    {% if info ?? null %}
        <span class=\"info\">{{ info|md|raw }}</span>
    {% endif %}
{% endtag %}

{% if custom ?? false %}
    <div class=\"custom-option-wrapper\">
        {{ text({
            value: value ?? null,
            class: 'small custom-option-input',
            labelledBy: labelId,
        }) }}
    </div>
{% endif %}
{% endapply -%}
", "_includes/forms/checkbox", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/checkbox.twig");
    }
}
