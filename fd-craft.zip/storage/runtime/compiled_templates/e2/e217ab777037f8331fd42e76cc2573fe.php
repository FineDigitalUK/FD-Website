<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/widgets/CraftSupport/body.twig */
class __TwigTemplate_7d2b018c242d858b7afceefa660148dc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/widgets/CraftSupport/body.twig");
        // line 1
        $macros["links"] = $this->macros["links"] = $this->loadTemplate("_includes/links", "_components/widgets/CraftSupport/body.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 11
        yield "
";
        // line 149
        yield "
";
        // line 150
        $macros["_v0"] = $this->macros["_v0"] = $this;
        // line 151
        yield "

<div class=\"cs-screen cs-screen-home\">
    <button type=\"button\" class=\"cs-opt\" data-screen=\"help\" aria-controls=\"cs-screen-help\" aria-expanded=\"false\">
        <div class=\"cs-opt-icon\">";
        // line 155
        yield craft\helpers\Cp::iconSvg("life-ring");
        yield "</div>
        <h2>";
        // line 156
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Get help", "app"), "html", null, true);
        yield "</h2>
        <p>";
        // line 157
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("How-to’s and other questions", "app"), "html", null, true);
        yield "</p>
    </button>
    <button type=\"button\" class=\"cs-opt\" data-screen=\"feedback\" aria-controls=\"cs-screen-feedback\" aria-expanded=\"false\">
        <div class=\"cs-opt-icon\">";
        // line 160
        yield craft\helpers\Cp::iconSvg("bullhorn");
        yield "</div>
        <h2>";
        // line 161
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Give feedback", "app"), "html", null, true);
        yield "</h2>
        <p>";
        // line 162
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Bug reports and feature requests", "app"), "html", null, true);
        yield "</p>
    </button>
</div>

";
        // line 166
        yield $macros["_v0"]->getTemplateForMacro("macro_screen", $context, 166, $this->getSourceContext())->macro_screen(...[        // line 167
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 167, $this->source); })()),         // line 168
(isset($context["showBackupOption"]) || array_key_exists("showBackupOption", $context) ? $context["showBackupOption"] : (function () { throw new RuntimeError('Variable "showBackupOption" does not exist.', 168, $this->source); })()),         // line 169
(isset($context["bundleUrl"]) || array_key_exists("bundleUrl", $context) ? $context["bundleUrl"] : (function () { throw new RuntimeError('Variable "bundleUrl" does not exist.', 169, $this->source); })()), "help", $this->extensions['craft\web\twig\Extension']->translateFilter("Briefly describe your question.", "app"), craft\helpers\Cp::iconSvg("craft-stack-exchange"), $this->extensions['craft\web\twig\Extension']->translateFilter("Similar questions on Stack Exchange", "app"), "https://craftcms.stackexchange.com/questions/ask", $this->extensions['craft\web\twig\Extension']->translateFilter("Ask on Stack Exchange", "app")]);
        // line 176
        yield "

";
        // line 178
        yield $macros["_v0"]->getTemplateForMacro("macro_screen", $context, 178, $this->getSourceContext())->macro_screen(...[        // line 179
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 179, $this->source); })()),         // line 180
(isset($context["showBackupOption"]) || array_key_exists("showBackupOption", $context) ? $context["showBackupOption"] : (function () { throw new RuntimeError('Variable "showBackupOption" does not exist.', 180, $this->source); })()),         // line 181
(isset($context["bundleUrl"]) || array_key_exists("bundleUrl", $context) ? $context["bundleUrl"] : (function () { throw new RuntimeError('Variable "bundleUrl" does not exist.', 181, $this->source); })()), "feedback", $this->extensions['craft\web\twig\Extension']->translateFilter("Briefly describe your issue or idea.", "app"), craft\helpers\Cp::iconSvg("github"), $this->extensions['craft\web\twig\Extension']->translateFilter("Similar issues on GitHub", "app"), "https://github.com/craftcms/cms/issues/new", $this->extensions['craft\web\twig\Extension']->translateFilter("Post on GitHub", "app")]);
        // line 188
        yield "
";
        craft\helpers\Template::endProfile("template", "_components/widgets/CraftSupport/body.twig");
        yield from [];
    }

    // line 3
    public function macro_resourceLink($config = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "config" => $config,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "resourceLink");
            // line 4
            yield "    <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 4, $this->source); })()), "link", [], "any", false, false, false, 4), "html", null, true);
            yield "\" target=\"_blank\" rel=\"noopener\">
        <h4 class=\"cs-resource-heading\">
            <img class=\"cs-logo-image\" src=\"";
            // line 6
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 6, $this->source); })()), "bundleUrl", [], "any", false, false, false, 6), "html", null, true);
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 6, $this->source); })()), "iconPath", [], "any", false, false, false, 6), "html", null, true);
            yield "\" alt=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 6, $this->source); })()), "title", [], "any", false, false, false, 6), "html", null, true);
            yield "\">
        </h4>
        <p>";
            // line 8
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 8, $this->source); })()), "description", [], "any", false, false, false, 8), "html", null, true);
            yield " ";
            yield $macros["links"]->getTemplateForMacro("macro_externalLinkIcon", $context, 8, $this->getSourceContext())->macro_externalLinkIcon(...[]);
            yield "</p>
    </a>
";
            craft\helpers\Template::endProfile("macro", "resourceLink");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 12
    public function macro_screen($widget = null, $showBackupOption = null, $bundleUrl = null, $screen = null, $placeholder = null, $resultsIcon = null, $resultsHeading = null, $formAction = null, $submitText = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "widget" => $widget,
            "showBackupOption" => $showBackupOption,
            "bundleUrl" => $bundleUrl,
            "screen" => $screen,
            "placeholder" => $placeholder,
            "resultsIcon" => $resultsIcon,
            "resultsHeading" => $resultsHeading,
            "formAction" => $formAction,
            "submitText" => $submitText,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "screen");
            // line 13
            yield "    ";
            $macros["forms"] = $this->loadTemplate("_includes/forms", "_components/widgets/CraftSupport/body.twig", 13)->unwrap();
            // line 14
            yield "    ";
            $context["idPrefix"] = (("cs-" . (isset($context["screen"]) || array_key_exists("screen", $context) ? $context["screen"] : (function () { throw new RuntimeError('Variable "screen" does not exist.', 14, $this->source); })())) . Twig\Extension\CoreExtension::random($this->env->getCharset()));
            // line 15
            yield "
    <div id=\"cs-screen-";
            // line 16
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["screen"]) || array_key_exists("screen", $context) ? $context["screen"] : (function () { throw new RuntimeError('Variable "screen" does not exist.', 16, $this->source); })()), "html", null, true);
            yield "\" class=\"cs-screen cs-screen-2 cs-screen-";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["screen"]) || array_key_exists("screen", $context) ? $context["screen"] : (function () { throw new RuntimeError('Variable "screen" does not exist.', 16, $this->source); })()), "html", null, true);
            yield "\" action=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["formAction"]) || array_key_exists("formAction", $context) ? $context["formAction"] : (function () { throw new RuntimeError('Variable "formAction" does not exist.', 16, $this->source); })()), "html", null, true);
            yield "\" method=\"get\" target=\"_blank\" rel=\"noopener\">
        ";
            // line 17
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("h2", ["text" =>             // line 18
(isset($context["submitText"]) || array_key_exists("submitText", $context) ? $context["submitText"] : (function () { throw new RuntimeError('Variable "submitText" does not exist.', 18, $this->source); })()), "class" => "cs-heading"]);
            // line 20
            yield "
        ";
            // line 21
            yield $macros["forms"]->getTemplateForMacro("macro_textareaField", $context, 21, $this->getSourceContext())->macro_textareaField(...[["first" => true, "class" => "cs-body-text", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter(            // line 24
(isset($context["placeholder"]) || array_key_exists("placeholder", $context) ? $context["placeholder"] : (function () { throw new RuntimeError('Variable "placeholder" does not exist.', 24, $this->source); })()), "app"), "rows" => 5]]);
            // line 26
            yield "
        <div class=\"cs-search-results-container hidden\">
            <div class=\"cs-search-icon\">";
            // line 28
            yield $this->extensions['craft\web\twig\Extension']->svgFunction((isset($context["resultsIcon"]) || array_key_exists("resultsIcon", $context) ? $context["resultsIcon"] : (function () { throw new RuntimeError('Variable "resultsIcon" does not exist.', 28, $this->source); })()), false);
            yield "</div>
            <h2>";
            // line 29
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["resultsHeading"]) || array_key_exists("resultsHeading", $context) ? $context["resultsHeading"] : (function () { throw new RuntimeError('Variable "resultsHeading" does not exist.', 29, $this->source); })()), "html", null, true);
            yield "</h2>
            <ul class=\"cs-search-results\"></ul>
        </div>
        <div class=\"cs-forms\">
            <form class=\"cs-search-form\" action=\"";
            // line 33
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["formAction"]) || array_key_exists("formAction", $context) ? $context["formAction"] : (function () { throw new RuntimeError('Variable "formAction" does not exist.', 33, $this->source); })()), "html", null, true);
            yield "\" method=\"get\" target=\"_blank\" rel=\"noopener\">
                <div class=\"cs-search-params\"></div>
                ";
            // line 35
            ob_start();
            // line 36
            yield "                    <button type=\"submit\" class=\"btn submit fullwidth disabled\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["submitText"]) || array_key_exists("submitText", $context) ? $context["submitText"] : (function () { throw new RuntimeError('Variable "submitText" does not exist.', 36, $this->source); })()), "html", null, true);
            yield "</button>
                    ";
            // line 37
            if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 37, $this->source); })()) >= (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 37, $this->source); })()))) {
                // line 38
                yield "                        <p>";
                yield $this->extensions['craft\web\twig\Extension']->translateFilter("or <a>send to Developer Support</a>", "app");
                yield "</p>
                    ";
            }
            // line 40
            yield "                    ";
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["class" => "btn fullwidth cancel", "type" => "button", "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("Cancel", "app")]);
            // line 44
            yield "
                ";
            echo craft\helpers\Html::tag("div", ob_get_clean(), ["class" => "cs-button-wrapper"]);
            // line 46
            yield "                <hr>
                <h3 class=\"cs-more-resources-heading\">";
            // line 47
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("More Resources", "app"), "html", null, true);
            yield "</h3>
                <div class=\"cs-logo-resources\">
                    ";
            // line 49
            yield $this->getTemplateForMacro("macro_resourceLink", $context, 49, $this->getSourceContext())->macro_resourceLink(...[["link" => "https://craftcms.com/partners", "iconPath" => "/logos/craft-partners.svg", "title" => "Craft Partners", "description" => $this->extensions['craft\web\twig\Extension']->translateFilter("Find an official Craft Partner", "app"), "bundleUrl" =>             // line 54
(isset($context["bundleUrl"]) || array_key_exists("bundleUrl", $context) ? $context["bundleUrl"] : (function () { throw new RuntimeError('Variable "bundleUrl" does not exist.', 54, $this->source); })())]]);
            // line 55
            yield "
                    ";
            // line 56
            yield $this->getTemplateForMacro("macro_resourceLink", $context, 56, $this->getSourceContext())->macro_resourceLink(...[["link" => "https://craftcms.com/discord", "iconPath" => "/logos/discord.svg", "title" => "Discord", "description" => $this->extensions['craft\web\twig\Extension']->translateFilter("Meet the Craft community", "app"), "bundleUrl" =>             // line 61
(isset($context["bundleUrl"]) || array_key_exists("bundleUrl", $context) ? $context["bundleUrl"] : (function () { throw new RuntimeError('Variable "bundleUrl" does not exist.', 61, $this->source); })())]]);
            // line 62
            yield "
                    ";
            // line 63
            yield $this->getTemplateForMacro("macro_resourceLink", $context, 63, $this->getSourceContext())->macro_resourceLink(...[["link" => "https://craftquest.io", "iconPath" => "/logos/craftquest.svg", "title" => "CraftQuest", "description" => $this->extensions['craft\web\twig\Extension']->translateFilter("Unlimited video training", "app"), "bundleUrl" =>             // line 68
(isset($context["bundleUrl"]) || array_key_exists("bundleUrl", $context) ? $context["bundleUrl"] : (function () { throw new RuntimeError('Variable "bundleUrl" does not exist.', 68, $this->source); })())]]);
            // line 69
            yield "
                </div>
                <div class=\"cs-icon-resources\">
                    ";
            // line 72
            $context["documentationLinkHtml"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 73
                yield "                        ";
                yield craft\helpers\Cp::iconSvg("book");
                yield "
                        <span>";
                // line 74
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Documentation", "app"), "html", null, true);
                yield "</span>
                    ";
                yield from [];
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 76
            yield "                    ";
            $context["knowledgeBaseLinkHtml"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 77
                yield "                        ";
                yield craft\helpers\Cp::iconSvg("magnifying-glass");
                yield "
                        <span>";
                // line 78
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Knowledge Base", "app"), "html", null, true);
                yield "</span>
                    ";
                yield from [];
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 80
            yield "                    ";
            yield $macros["links"]->getTemplateForMacro("macro_externalLink", $context, 80, $this->getSourceContext())->macro_externalLink(...[["link" => "https://craftcms.com/docs/5.x/", "html" =>             // line 82
(isset($context["documentationLinkHtml"]) || array_key_exists("documentationLinkHtml", $context) ? $context["documentationLinkHtml"] : (function () { throw new RuntimeError('Variable "documentationLinkHtml" does not exist.', 82, $this->source); })())]]);
            // line 83
            yield "
                    ";
            // line 84
            yield $macros["links"]->getTemplateForMacro("macro_externalLink", $context, 84, $this->getSourceContext())->macro_externalLink(...[["link" => "https://craftcms.com/knowledge-base", "html" =>             // line 86
(isset($context["knowledgeBaseLinkHtml"]) || array_key_exists("knowledgeBaseLinkHtml", $context) ? $context["knowledgeBaseLinkHtml"] : (function () { throw new RuntimeError('Variable "knowledgeBaseLinkHtml" does not exist.', 86, $this->source); })())]]);
            // line 87
            yield "
                </div>
            </form>
            <form class=\"cs-support-form hidden\" action=\"";
            // line 90
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::actionUrl("dashboard/send-support-request"), "html", null, true);
            yield "\" method=\"post\" target=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 90, $this->source); })()), "html", null, true);
            yield "-iframe\" accept-charset=\"UTF-8\" enctype=\"multipart/form-data\">
                ";
            // line 91
            yield craft\helpers\Html::csrfInput();
            yield "
                ";
            // line 92
            yield craft\helpers\Html::hiddenInput("widgetId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 92, $this->source); })()), "id", [], "any", false, false, false, 92));
            yield "
                ";
            // line 93
            yield craft\helpers\Html::hiddenInput("message", "", ["class" => "cs-support-message"]);
            yield "

                ";
            // line 95
            $context["email"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 95, $this->source); })()), "email", [], "any", false, false, false, 95);
            // line 96
            yield "                ";
            if (CoreExtension::inFilter((isset($context["email"]) || array_key_exists("email", $context) ? $context["email"] : (function () { throw new RuntimeError('Variable "email" does not exist.', 96, $this->source); })()), ["support@pixelandtonic.com", "support@craftcms.com"])) {
                // line 97
                yield "                    ";
                $context["email"] = "";
                // line 98
                yield "                ";
            }
            // line 99
            yield "
                ";
            // line 100
            yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 100, $this->getSourceContext())->macro_textField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Your Email", "app"), "name" => "fromEmail", "value" =>             // line 104
(isset($context["email"]) || array_key_exists("email", $context) ? $context["email"] : (function () { throw new RuntimeError('Variable "email" does not exist.', 104, $this->source); })())]]);
            // line 105
            yield "

                <button type=\"button\" class=\"fieldtoggle\" data-target=\"";
            // line 107
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 107, $this->source); })()), "html", null, true);
            yield "-support-more\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("More", "app"), "html", null, true);
            yield "</button>

                <div id=\"";
            // line 109
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 109, $this->source); })()), "html", null, true);
            yield "-support-more\" class=\"cs-support-more hidden\">
                    <fieldset>
                        ";
            // line 111
            yield $macros["forms"]->getTemplateForMacro("macro_checkboxField", $context, 111, $this->getSourceContext())->macro_checkboxField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Attach error logs", "app"), "name" => "attachLogs", "checked" => true]]);
            // line 115
            yield "

                        ";
            // line 117
            if ((isset($context["showBackupOption"]) || array_key_exists("showBackupOption", $context) ? $context["showBackupOption"] : (function () { throw new RuntimeError('Variable "showBackupOption" does not exist.', 117, $this->source); })())) {
                // line 118
                yield "                            ";
                yield $macros["forms"]->getTemplateForMacro("macro_checkboxField", $context, 118, $this->getSourceContext())->macro_checkboxField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Attach a database backup", "app"), "name" => "attachDbBackup", "checked" => true]]);
                // line 122
                yield "
                        ";
            }
            // line 124
            yield "
                        ";
            // line 125
            yield $macros["forms"]->getTemplateForMacro("macro_checkboxField", $context, 125, $this->getSourceContext())->macro_checkboxField(...[["name" => "attachTemplates", "checked" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Include your template files", "app")]]);
            // line 129
            yield "
                    </fieldset>

                    ";
            // line 132
            yield $macros["forms"]->getTemplateForMacro("macro_fileField", $context, 132, $this->getSourceContext())->macro_fileField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Attach an additional file", "app"), "class" => "cs-support-attachment", "name" => "attachAdditionalFile"]]);
            // line 136
            yield "
                </div>

                ";
            // line 139
            yield $macros["forms"]->getTemplateForMacro("macro_submitButton", $context, 139, $this->getSourceContext())->macro_submitButton(...[["class" => ["fullwidth", "disabled"], "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Send", "app"), "spinner" => true]]);
            // line 143
            yield "
            </form>
        </div>
        <iframe id=\"";
            // line 146
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 146, $this->source); })()), "html", null, true);
            yield "-iframe\" name=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 146, $this->source); })()), "html", null, true);
            yield "-iframe\" class=\"hidden\"></iframe>
    </div>
";
            craft\helpers\Template::endProfile("macro", "screen");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/widgets/CraftSupport/body.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  401 => 146,  396 => 143,  394 => 139,  389 => 136,  387 => 132,  382 => 129,  380 => 125,  377 => 124,  373 => 122,  370 => 118,  368 => 117,  364 => 115,  362 => 111,  357 => 109,  350 => 107,  346 => 105,  344 => 104,  343 => 100,  340 => 99,  337 => 98,  334 => 97,  331 => 96,  329 => 95,  324 => 93,  320 => 92,  316 => 91,  310 => 90,  305 => 87,  303 => 86,  302 => 84,  299 => 83,  297 => 82,  295 => 80,  289 => 78,  284 => 77,  281 => 76,  275 => 74,  270 => 73,  268 => 72,  263 => 69,  261 => 68,  260 => 63,  257 => 62,  255 => 61,  254 => 56,  251 => 55,  249 => 54,  248 => 49,  243 => 47,  240 => 46,  236 => 44,  233 => 40,  227 => 38,  225 => 37,  220 => 36,  218 => 35,  213 => 33,  206 => 29,  202 => 28,  198 => 26,  196 => 24,  195 => 21,  192 => 20,  190 => 18,  189 => 17,  181 => 16,  178 => 15,  175 => 14,  172 => 13,  151 => 12,  139 => 8,  131 => 6,  125 => 4,  112 => 3,  105 => 188,  103 => 181,  102 => 180,  101 => 179,  100 => 178,  96 => 176,  94 => 169,  93 => 168,  92 => 167,  91 => 166,  84 => 162,  80 => 161,  76 => 160,  70 => 157,  66 => 156,  62 => 155,  56 => 151,  54 => 150,  51 => 149,  48 => 11,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/links\" as links %}

{% macro resourceLink(config) %}
    <a href=\"{{ config.link }}\" target=\"_blank\" rel=\"noopener\">
        <h4 class=\"cs-resource-heading\">
            <img class=\"cs-logo-image\" src=\"{{ config.bundleUrl }}{{ config.iconPath }}\" alt=\"{{ config.title }}\">
        </h4>
        <p>{{ config.description }} {{ links.externalLinkIcon() }}</p>
    </a>
{% endmacro %}

{% macro screen(widget, showBackupOption, bundleUrl, screen, placeholder, resultsIcon, resultsHeading, formAction, submitText) %}
    {% import \"_includes/forms\" as forms %}
    {% set idPrefix = 'cs-'~screen~random() %}

    <div id=\"cs-screen-{{ screen }}\" class=\"cs-screen cs-screen-2 cs-screen-{{ screen }}\" action=\"{{ formAction }}\" method=\"get\" target=\"_blank\" rel=\"noopener\">
        {{ tag('h2', {
            text: submitText,
            class: 'cs-heading'
        }) }}
        {{ forms.textareaField({
            first: true,
            class: 'cs-body-text',
            label: placeholder|t('app'),
            rows: 5
        }) }}
        <div class=\"cs-search-results-container hidden\">
            <div class=\"cs-search-icon\">{{ svg(resultsIcon, sanitize=false) }}</div>
            <h2>{{ resultsHeading }}</h2>
            <ul class=\"cs-search-results\"></ul>
        </div>
        <div class=\"cs-forms\">
            <form class=\"cs-search-form\" action=\"{{ formAction }}\" method=\"get\" target=\"_blank\" rel=\"noopener\">
                <div class=\"cs-search-params\"></div>
                {% tag 'div' with { class: 'cs-button-wrapper' }%}
                    <button type=\"submit\" class=\"btn submit fullwidth disabled\">{{ submitText }}</button>
                    {% if CraftEdition >= CraftPro %}
                        <p>{{ \"or <a>send to Developer Support</a>\"|t('app')|raw }}</p>
                    {% endif %}
                    {{ tag('button', {
                        class: 'btn fullwidth cancel',
                        type: 'button',
                        text: 'Cancel'|t('app'),
                    }) }}
                {% endtag %}
                <hr>
                <h3 class=\"cs-more-resources-heading\">{{ 'More Resources'|t('app') }}</h3>
                <div class=\"cs-logo-resources\">
                    {{ _self.resourceLink({
                        link: 'https://craftcms.com/partners',
                        iconPath: '/logos/craft-partners.svg',
                        title: 'Craft Partners',
                        description: 'Find an official Craft Partner'|t('app'),
                        bundleUrl: bundleUrl,
                    }) }}
                    {{ _self.resourceLink({
                        link: 'https://craftcms.com/discord',
                        iconPath: '/logos/discord.svg',
                        title: 'Discord',
                        description: 'Meet the Craft community'|t('app'),
                        bundleUrl: bundleUrl,
                    }) }}
                    {{ _self.resourceLink({
                        link: 'https://craftquest.io',
                        iconPath: '/logos/craftquest.svg',
                        title: 'CraftQuest',
                        description: 'Unlimited video training'|t('app'),
                        bundleUrl: bundleUrl,
                    }) }}
                </div>
                <div class=\"cs-icon-resources\">
                    {% set documentationLinkHtml %}
                        {{ iconSvg('book') }}
                        <span>{{ 'Documentation'|t('app') }}</span>
                    {% endset %}
                    {% set knowledgeBaseLinkHtml %}
                        {{ iconSvg('magnifying-glass') }}
                        <span>{{ 'Knowledge Base'|t('app') }}</span>
                    {% endset %}
                    {{ links.externalLink({
                        link: 'https://craftcms.com/docs/5.x/',
                        html: documentationLinkHtml
                    }) }}
                    {{ links.externalLink({
                        link: 'https://craftcms.com/knowledge-base',
                        html: knowledgeBaseLinkHtml
                    }) }}
                </div>
            </form>
            <form class=\"cs-support-form hidden\" action=\"{{ actionUrl('dashboard/send-support-request') }}\" method=\"post\" target=\"{{ idPrefix }}-iframe\" accept-charset=\"UTF-8\" enctype=\"multipart/form-data\">
                {{ csrfInput() }}
                {{ hiddenInput('widgetId', widget.id) }}
                {{ hiddenInput('message', '', {class: 'cs-support-message'}) }}

                {% set email = currentUser.email %}
                {% if email in ['support@pixelandtonic.com', 'support@craftcms.com'] %}
                    {% set email = '' %}
                {% endif %}

                {{ forms.textField({
                    first: true,
                    label: \"Your Email\"|t('app'),
                    name: 'fromEmail',
                    value: email
                }) }}

                <button type=\"button\" class=\"fieldtoggle\" data-target=\"{{ idPrefix }}-support-more\">{{ \"More\"|t('app') }}</button>

                <div id=\"{{ idPrefix }}-support-more\" class=\"cs-support-more hidden\">
                    <fieldset>
                        {{ forms.checkboxField({
                            label: 'Attach error logs'|t('app'),
                            name: 'attachLogs',
                            checked: true
                        }) }}

                        {% if showBackupOption %}
                            {{ forms.checkboxField({
                                label: 'Attach a database backup'|t('app'),
                                name: 'attachDbBackup',
                                checked: true
                            }) }}
                        {% endif %}

                        {{ forms.checkboxField({
                            name: 'attachTemplates',
                            checked: true,
                            label: 'Include your template files'|t('app'),
                        }) }}
                    </fieldset>

                    {{ forms.fileField({
                        label: 'Attach an additional file'|t('app'),
                        class: 'cs-support-attachment',
                        name: 'attachAdditionalFile',
                    }) }}
                </div>

                {{ forms.submitButton({
                    class: ['fullwidth', 'disabled'],
                    label: 'Send'|t('app'),
                    spinner: true,
                }) }}
            </form>
        </div>
        <iframe id=\"{{ idPrefix }}-iframe\" name=\"{{ idPrefix }}-iframe\" class=\"hidden\"></iframe>
    </div>
{% endmacro %}

{% from _self import screen %}


<div class=\"cs-screen cs-screen-home\">
    <button type=\"button\" class=\"cs-opt\" data-screen=\"help\" aria-controls=\"cs-screen-help\" aria-expanded=\"false\">
        <div class=\"cs-opt-icon\">{{ iconSvg('life-ring') }}</div>
        <h2>{{ \"Get help\"|t('app') }}</h2>
        <p>{{ \"How-to’s and other questions\"|t('app') }}</p>
    </button>
    <button type=\"button\" class=\"cs-opt\" data-screen=\"feedback\" aria-controls=\"cs-screen-feedback\" aria-expanded=\"false\">
        <div class=\"cs-opt-icon\">{{ iconSvg('bullhorn') }}</div>
        <h2>{{ \"Give feedback\"|t('app') }}</h2>
        <p>{{ \"Bug reports and feature requests\"|t('app') }}</p>
    </button>
</div>

{{ screen(
    widget,
    showBackupOption,
    bundleUrl,
    'help',
    'Briefly describe your question.'|t('app'),
    iconSvg('craft-stack-exchange'),
    'Similar questions on Stack Exchange'|t('app'),
    'https://craftcms.stackexchange.com/questions/ask',
    'Ask on Stack Exchange'|t('app'),
) }}

{{ screen(
    widget,
    showBackupOption,
    bundleUrl,
    'feedback',
    'Briefly describe your issue or idea.'|t('app'),
    iconSvg('github'),
    'Similar issues on GitHub'|t('app'),
    'https://github.com/craftcms/cms/issues/new',
    'Post on GitHub'|t('app'),
) }}
", "_components/widgets/CraftSupport/body.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/widgets/CraftSupport/body.twig");
    }
}
