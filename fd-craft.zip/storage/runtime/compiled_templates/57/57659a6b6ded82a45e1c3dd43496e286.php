<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/checkboxSelect.twig */
class __TwigTemplate_9c189289043d9107e841bf3c615da879 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/checkboxSelect.twig");
        // line 1
        $context["id"] = (($context["id"]) ?? (("checkbox-select-" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 2
        $context["options"] = (($context["options"]) ?? ([]));
        // line 3
        $context["values"] = (($context["values"]) ?? ([]));
        // line 4
        $context["disabled"] = (($context["disabled"]) ?? (false));
        // line 5
        $context["sortable"] = (($context["sortable"]) ?? (false));
        // line 6
        yield "
";
        // line 7
        $context["options"] = $this->extensions['craft\web\twig\Extension']->mapFilter($this->env, (isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 7, $this->source); })()), function ($__value__, $__key__) use ($context, $macros) { $context["value"] = $__value__; $context["key"] = $__key__; return ((is_iterable((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 7, $this->source); })()))) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 7, $this->source); })())) : (["label" =>         // line 8
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 8, $this->source); })()), "value" =>         // line 9
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 9, $this->source); })())])); });
        // line 11
        yield "
";
        // line 12
        if (((isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 12, $this->source); })()) && $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 12, $this->source); })())))) {
            // line 13
            yield "    ";
            $context["options"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $this->extensions['craft\web\twig\Extension']->collectFunction((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 13, $this->source); })())), "sortBy", [            // line 14
function ($__o__) use ($context, $macros) { $context["o"] = $__o__; return $this->extensions['craft\web\twig\Extension']->indexOfFilter((isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 14, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 14, $this->source); })()), "value", [], "any", false, false, false, 14), (isset($context["PHP_INT_MAX"]) || array_key_exists("PHP_INT_MAX", $context) ? $context["PHP_INT_MAX"] : (function () { throw new RuntimeError('Variable "PHP_INT_MAX" does not exist.', 14, $this->source); })())); }], "method", false, false, false, 13), "all", [], "method", false, false, false, 14);
        }
        // line 18
        $context["showAllOption"] = (($context["showAllOption"]) ?? (false));
        // line 19
        if ((isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 19, $this->source); })())) {
            // line 20
            $context["allLabel"] = (($context["allLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("All", "app")));
            // line 21
            $context["allValue"] = (($context["allValue"]) ?? ("*"));
            // line 22
            $context["allChecked"] = ((isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 22, $this->source); })()) == (isset($context["allValue"]) || array_key_exists("allValue", $context) ? $context["allValue"] : (function () { throw new RuntimeError('Variable "allValue" does not exist.', 22, $this->source); })()));
        }
        // line 24
        yield "
";
        // line 25
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>         // line 26
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 26, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["checkbox-select"], craft\helpers\Html::explodeClass(((        // line 27
$context["class"]) ?? ([]))))], ((        // line 28
$context["containerAttributes"]) ?? ([])), true);
        // line 30
        if (        $this->unwrap()->hasBlock("attr", $context, $blocks)) {
            // line 31
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 31, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 33
        yield "
";
        // line 34
        ob_start();
        // line 35
        if ((isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 35, $this->source); })())) {
            // line 36
            yield "        <div>
            ";
            // line 37
            yield from $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/checkboxSelect.twig", 37)->unwrap()->yield(CoreExtension::toArray(["describedBy" => ((            // line 38
$context["describedBy"]) ?? (false)), "class" => ["checkbox-select-item", "all"], "label" => craft\helpers\Template::raw((("<b>" .             // line 40
(isset($context["allLabel"]) || array_key_exists("allLabel", $context) ? $context["allLabel"] : (function () { throw new RuntimeError('Variable "allLabel" does not exist.', 40, $this->source); })())) . "</b>")), "name" => ((            // line 41
$context["name"]) ?? (null)), "value" =>             // line 42
(isset($context["allValue"]) || array_key_exists("allValue", $context) ? $context["allValue"] : (function () { throw new RuntimeError('Variable "allValue" does not exist.', 42, $this->source); })()), "checked" =>             // line 43
(isset($context["allChecked"]) || array_key_exists("allChecked", $context) ? $context["allChecked"] : (function () { throw new RuntimeError('Variable "allChecked" does not exist.', 43, $this->source); })()), "autofocus" => (((            // line 44
$context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 44, $this->source); })()), "app", [], "any", false, false, false, 44), "request", [], "any", false, false, false, 44), "isMobileBrowser", [true], "method", false, false, false, 44)), "targetPrefix" => ((            // line 45
$context["targetPrefix"]) ?? (null)), "disabled" =>             // line 46
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 46, $this->source); })())]));
            // line 48
            yield "        </div>";
        } elseif ((        // line 49
array_key_exists("name", $context) && (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 49, $this->source); })())) < 3) || (Twig\Extension\CoreExtension::slice($this->env->getCharset(), (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 49, $this->source); })()),  -2) != "[]")))) {
            // line 50
            yield craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 50, $this->source); })()), "");
        }
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 52, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["option"]) {
            // line 53
            yield "        ";
            if ((( !(isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 53, $this->source); })()) ||  !craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", true, true, false, 53)) || (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", false, false, false, 53) != (isset($context["allValue"]) || array_key_exists("allValue", $context) ? $context["allValue"] : (function () { throw new RuntimeError('Variable "allValue" does not exist.', 53, $this->source); })())))) {
                // line 54
                yield "            <div class=\"checkbox-select-item\">
                ";
                // line 55
                $context["selected"] = (((isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 55, $this->source); })()) && (isset($context["allChecked"]) || array_key_exists("allChecked", $context) ? $context["allChecked"] : (function () { throw new RuntimeError('Variable "allChecked" does not exist.', 55, $this->source); })())) || (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", true, true, false, 55) && CoreExtension::inFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", false, false, false, 55), (isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 55, $this->source); })()))));
                // line 56
                yield "                ";
                if (((isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 56, $this->source); })()) &&  !(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 56, $this->source); })()))) {
                    // line 57
                    yield "                    ";
                    yield $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["move" => true, "icon" => true, "draggable-handle" => true, "disabled" =>  !                    // line 62
(isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 62, $this->source); })())]))]);
                    // line 64
                    yield "
                ";
                }
                // line 66
                yield "                ";
                yield from $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/checkboxSelect.twig", 66)->unwrap()->yield(CoreExtension::toArray($this->extensions['craft\web\twig\Extension']->mergeFilter(["name" => ((((                // line 67
$context["name"]) ?? (false))) ? (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 67, $this->source); })()) . "[]")) : (null)), "checked" =>                 // line 68
(isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 68, $this->source); })()), "disabled" => ((                // line 69
(isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 69, $this->source); })()) && (isset($context["allChecked"]) || array_key_exists("allChecked", $context) ? $context["allChecked"] : (function () { throw new RuntimeError('Variable "allChecked" does not exist.', 69, $this->source); })())) || (isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 69, $this->source); })())), "targetPrefix" => ((                // line 70
$context["targetPrefix"]) ?? (null))],                 // line 71
$context["option"])));
                // line 72
                yield "            </div>
        ";
            }
            // line 74
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['key'], $context['option'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo craft\helpers\Html::tag("fieldset", ob_get_clean(),         // line 34
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 34, $this->source); })()));
        // line 76
        yield "
";
        // line 77
        if (((isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 77, $this->source); })()) &&  !(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 77, $this->source); })()))) {
            // line 78
            yield "    ";
            ob_start();
            // line 79
            yield "        new Craft.SortableCheckboxSelect(\$('#";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 79, $this->source); })())), "html", null, true);
            yield "'));
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/checkboxSelect.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/checkboxSelect.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  172 => 79,  169 => 78,  167 => 77,  164 => 76,  162 => 34,  156 => 74,  152 => 72,  150 => 71,  149 => 70,  148 => 69,  147 => 68,  146 => 67,  144 => 66,  140 => 64,  138 => 62,  136 => 57,  133 => 56,  131 => 55,  128 => 54,  125 => 53,  121 => 52,  118 => 50,  116 => 49,  114 => 48,  112 => 46,  111 => 45,  110 => 44,  109 => 43,  108 => 42,  107 => 41,  106 => 40,  105 => 38,  104 => 37,  101 => 36,  99 => 35,  97 => 34,  94 => 33,  91 => 31,  89 => 30,  87 => 28,  86 => 27,  85 => 26,  84 => 25,  81 => 24,  78 => 22,  76 => 21,  74 => 20,  72 => 19,  70 => 18,  67 => 14,  65 => 13,  63 => 12,  60 => 11,  58 => 9,  57 => 8,  56 => 7,  53 => 6,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{%- set id = id ?? \"checkbox-select-#{random()}\" %}
{%- set options = options ?? [] %}
{%- set values = values ?? [] %}
{%- set disabled = disabled ?? false %}
{%- set sortable = sortable ?? false %}

{% set options = options|map((value, key) => value is iterable ? value : {
    label: value,
    value: key,
}) %}

{% if sortable and values|length %}
    {% set options = collect(options)
        .sortBy(o => values|indexOf(o.value, PHP_INT_MAX))
        .all() %}
{% endif %}

{%- set showAllOption = showAllOption ?? false %}
{%- if showAllOption %}
    {%- set allLabel = allLabel ?? \"All\"|t('app') %}
    {%- set allValue = allValue ?? '*' %}
    {%- set allChecked = (values == allValue) %}
{%- endif %}

{% set containerAttributes = {
    id,
    class: ['checkbox-select']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% tag 'fieldset' with containerAttributes %}
    {%- if showAllOption %}
        <div>
            {% include \"_includes/forms/checkbox\" with {
                describedBy: describedBy ?? false,
                class: ['checkbox-select-item', 'all'],
                label: raw(\"<b>#{allLabel}</b>\"),
                name: name ?? null,
                value: allValue,
                checked: allChecked,
                autofocus: (autofocus ?? false) and not craft.app.request.isMobileBrowser(true),
                targetPrefix: targetPrefix ?? null,
                disabled: disabled
            } only %}
        </div>
    {%- elseif name is defined and (name|length < 3 or name|slice(-2) != '[]') %}
        {{- hiddenInput(name, '') }}
    {%- endif %}
    {%- for key, option in options %}
        {% if not showAllOption or option.value is not defined or option.value != allValue %}
            <div class=\"checkbox-select-item\">
                {% set selected = (showAllOption and allChecked) or (option.value is defined and option.value in values) %}
                {% if sortable and not disabled %}
                    {{ tag('a', {
                        class: {
                            move: true,
                            icon: true,
                            'draggable-handle': true,
                            disabled: not selected,
                        }|filter|keys,
                    }) }}
                {% endif %}
                {% include \"_includes/forms/checkbox\" with {
                    name: (name ?? false) ? \"#{name}[]\" : null,
                    checked: selected,
                    disabled: (showAllOption and allChecked) or disabled,
                    targetPrefix: targetPrefix ?? null,
                }|merge(option) only %}
            </div>
        {% endif %}
    {% endfor %}
{% endtag %}

{% if sortable and not disabled %}
    {% js %}
        new Craft.SortableCheckboxSelect(\$('#{{ id|namespaceInputId }}'));
    {% endjs %}
{% endif %}
", "_includes/forms/checkboxSelect.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/checkboxSelect.twig");
    }
}
