<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/button */
class __TwigTemplate_a9304093e56223b4aab51d1b76216526 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/button");
        // line 1
        $context["spinner"] = (($context["spinner"]) ?? (false));
        // line 2
        $context["busyMessage"] = (($context["busyMessage"]) ?? (false));
        // line 3
        $context["failureMessage"] = (($context["failureMessage"]) ?? (false));
        // line 4
        $context["retryMessage"] = (($context["retryMessage"]) ?? (false));
        // line 5
        $context["successMessage"] = (($context["successMessage"]) ?? (false));
        // line 6
        $context["enableLiveRegion"] = ((((isset($context["busyMessage"]) || array_key_exists("busyMessage", $context) ? $context["busyMessage"] : (function () { throw new RuntimeError('Variable "busyMessage" does not exist.', 6, $this->source); })()) || (isset($context["failureMessage"]) || array_key_exists("failureMessage", $context) ? $context["failureMessage"] : (function () { throw new RuntimeError('Variable "failureMessage" does not exist.', 6, $this->source); })())) || (isset($context["retryMessage"]) || array_key_exists("retryMessage", $context) ? $context["retryMessage"] : (function () { throw new RuntimeError('Variable "retryMessage" does not exist.', 6, $this->source); })())) || (isset($context["successMessage"]) || array_key_exists("successMessage", $context) ? $context["successMessage"] : (function () { throw new RuntimeError('Variable "successMessage" does not exist.', 6, $this->source); })()));
        // line 7
        $context["icon"] = (($context["icon"]) ?? (null));
        // line 8
        $context["iconHtml"] = (($context["iconHtml"]) ?? (null));
        // line 9
        $context["label"] = (($context["label"]) ?? (null));
        // line 10
        $context["labelHtml"] = (($context["labelHtml"]) ?? (null));
        // line 11
        yield "
";
        // line 14
        $context["hasIcon"] = ((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 14, $this->source); })()) || ((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 14, $this->source); })()) === "0"));
        // line 15
        $context["hasLabel"] = ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 15, $this->source); })()) || ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 15, $this->source); })()) === "0"));
        // line 16
        $context["hasLabelHtml"] = ((isset($context["labelHtml"]) || array_key_exists("labelHtml", $context) ? $context["labelHtml"] : (function () { throw new RuntimeError('Variable "labelHtml" does not exist.', 16, $this->source); })()) || ((isset($context["labelHtml"]) || array_key_exists("labelHtml", $context) ? $context["labelHtml"] : (function () { throw new RuntimeError('Variable "labelHtml" does not exist.', 16, $this->source); })()) === "0"));
        // line 17
        yield "
";
        // line 18
        $context["attributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["type" => ((        // line 19
$context["type"]) ?? ("button")), "id" => ((        // line 20
$context["id"]) ?? (false)), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass(((        // line 21
$context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["btn", (( !((        // line 23
(isset($context["hasIcon"]) || array_key_exists("hasIcon", $context) ? $context["hasIcon"] : (function () { throw new RuntimeError('Variable "hasIcon" does not exist.', 23, $this->source); })()) || (isset($context["hasLabel"]) || array_key_exists("hasLabel", $context) ? $context["hasLabel"] : (function () { throw new RuntimeError('Variable "hasLabel" does not exist.', 23, $this->source); })())) || (isset($context["hasLabelHtml"]) || array_key_exists("hasLabelHtml", $context) ? $context["hasLabelHtml"] : (function () { throw new RuntimeError('Variable "hasLabelHtml" does not exist.', 23, $this->source); })()))) ? ("btn-empty") : (null)), ((((        // line 24
$context["disabled"]) ?? ((($context["readOnly"]) ?? (false))))) ? ("disabled") : ("")), ((((        // line 25
$context["readOnly"]) ?? (false))) ? ("read-only") : (""))])), "data" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["busy-message" =>         // line 28
(isset($context["busyMessage"]) || array_key_exists("busyMessage", $context) ? $context["busyMessage"] : (function () { throw new RuntimeError('Variable "busyMessage" does not exist.', 28, $this->source); })()), "failure-message" =>         // line 29
(isset($context["failureMessage"]) || array_key_exists("failureMessage", $context) ? $context["failureMessage"] : (function () { throw new RuntimeError('Variable "failureMessage" does not exist.', 29, $this->source); })()), "retry-message" =>         // line 30
(isset($context["retryMessage"]) || array_key_exists("retryMessage", $context) ? $context["retryMessage"] : (function () { throw new RuntimeError('Variable "retryMessage" does not exist.', 30, $this->source); })()), "success-message" =>         // line 31
(isset($context["successMessage"]) || array_key_exists("successMessage", $context) ? $context["successMessage"] : (function () { throw new RuntimeError('Variable "successMessage" does not exist.', 31, $this->source); })())], (((craft\helpers\Template::attribute($this->env, $this->source,         // line 32
($context["attributes"] ?? null), "data", [], "any", true, true, false, 32) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["attributes"] ?? null), "data", [], "any", false, false, false, 32)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["attributes"] ?? null), "data", [], "any", false, false, false, 32)) : ([])))], ((        // line 33
$context["attributes"]) ?? ([])));
        // line 35
        $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 36
            yield "    ";
            if (((isset($context["spinner"]) || array_key_exists("spinner", $context) ? $context["spinner"] : (function () { throw new RuntimeError('Variable "spinner" does not exist.', 36, $this->source); })()) && (isset($context["enableLiveRegion"]) || array_key_exists("enableLiveRegion", $context) ? $context["enableLiveRegion"] : (function () { throw new RuntimeError('Variable "enableLiveRegion" does not exist.', 36, $this->source); })()))) {
                // line 37
                yield "        <div role=\"status\" class=\"visually-hidden\"></div>
    ";
            }
            // line 39
            yield "    ";
            ob_start();
            // line 40
            yield "        ";
            if ((((isset($context["hasIcon"]) || array_key_exists("hasIcon", $context) ? $context["hasIcon"] : (function () { throw new RuntimeError('Variable "hasIcon" does not exist.', 40, $this->source); })()) || (isset($context["hasLabel"]) || array_key_exists("hasLabel", $context) ? $context["hasLabel"] : (function () { throw new RuntimeError('Variable "hasLabel" does not exist.', 40, $this->source); })())) || (isset($context["hasLabelHtml"]) || array_key_exists("hasLabelHtml", $context) ? $context["hasLabelHtml"] : (function () { throw new RuntimeError('Variable "hasLabelHtml" does not exist.', 40, $this->source); })()))) {
                // line 41
                yield "            <div class=\"inline-flex\">
                ";
                // line 42
                if (((isset($context["hasIcon"]) || array_key_exists("hasIcon", $context) ? $context["hasIcon"] : (function () { throw new RuntimeError('Variable "hasIcon" does not exist.', 42, $this->source); })()) || (isset($context["iconHtml"]) || array_key_exists("iconHtml", $context) ? $context["iconHtml"] : (function () { throw new RuntimeError('Variable "iconHtml" does not exist.', 42, $this->source); })()))) {
                    // line 43
                    yield "                    ";
                    if ((isset($context["hasIcon"]) || array_key_exists("hasIcon", $context) ? $context["hasIcon"] : (function () { throw new RuntimeError('Variable "hasIcon" does not exist.', 43, $this->source); })())) {
                        // line 44
                        yield "                        <div class=\"cp-icon\">";
                        yield craft\helpers\Cp::iconSvg((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 44, $this->source); })()));
                        yield "</div>
                    ";
                    } elseif (                    // line 45
(isset($context["iconHtml"]) || array_key_exists("iconHtml", $context) ? $context["iconHtml"] : (function () { throw new RuntimeError('Variable "iconHtml" does not exist.', 45, $this->source); })())) {
                        // line 46
                        yield "                        ";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["iconHtml"]) || array_key_exists("iconHtml", $context) ? $context["iconHtml"] : (function () { throw new RuntimeError('Variable "iconHtml" does not exist.', 46, $this->source); })()), "html", null, true);
                        yield "
                    ";
                    }
                    // line 48
                    yield "                ";
                }
                // line 49
                yield "                ";
                if (((isset($context["hasLabel"]) || array_key_exists("hasLabel", $context) ? $context["hasLabel"] : (function () { throw new RuntimeError('Variable "hasLabel" does not exist.', 49, $this->source); })()) || (isset($context["hasLabelHtml"]) || array_key_exists("hasLabelHtml", $context) ? $context["hasLabelHtml"] : (function () { throw new RuntimeError('Variable "hasLabelHtml" does not exist.', 49, $this->source); })()))) {
                    // line 50
                    yield "                    ";
                    yield $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => "label", "text" => ((                    // line 52
(isset($context["hasLabel"]) || array_key_exists("hasLabel", $context) ? $context["hasLabel"] : (function () { throw new RuntimeError('Variable "hasLabel" does not exist.', 52, $this->source); })())) ? ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 52, $this->source); })())) : (null)), "html" => ((                    // line 53
(isset($context["hasLabelHtml"]) || array_key_exists("hasLabelHtml", $context) ? $context["hasLabelHtml"] : (function () { throw new RuntimeError('Variable "hasLabelHtml" does not exist.', 53, $this->source); })())) ? ((isset($context["labelHtml"]) || array_key_exists("labelHtml", $context) ? $context["labelHtml"] : (function () { throw new RuntimeError('Variable "labelHtml" does not exist.', 53, $this->source); })())) : (null))]);
                    // line 54
                    yield "
                ";
                }
                // line 56
                yield "            </div>
        ";
            }
            // line 58
            yield "        ";
            if ((isset($context["spinner"]) || array_key_exists("spinner", $context) ? $context["spinner"] : (function () { throw new RuntimeError('Variable "spinner" does not exist.', 58, $this->source); })())) {
                // line 59
                yield "            <div class=\"spinner spinner-absolute\">
                <span class=\"visually-hidden\">";
                // line 60
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Loading", "app"), "html", null, true);
                yield "</span>
            </div>
        ";
            }
            // line 63
            yield "    ";
            echo craft\helpers\Html::tag("button", ob_get_clean(),             // line 39
(isset($context["attributes"]) || array_key_exists("attributes", $context) ? $context["attributes"] : (function () { throw new RuntimeError('Variable "attributes" does not exist.', 39, $this->source); })()));
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 35
        yield Twig\Extension\CoreExtension::spaceless($_v0);
        craft\helpers\Template::endProfile("template", "_includes/forms/button");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/button";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  162 => 35,  158 => 39,  156 => 63,  150 => 60,  147 => 59,  144 => 58,  140 => 56,  136 => 54,  134 => 53,  133 => 52,  131 => 50,  128 => 49,  125 => 48,  119 => 46,  117 => 45,  112 => 44,  109 => 43,  107 => 42,  104 => 41,  101 => 40,  98 => 39,  94 => 37,  91 => 36,  89 => 35,  87 => 33,  86 => 32,  85 => 31,  84 => 30,  83 => 29,  82 => 28,  81 => 25,  80 => 24,  79 => 23,  78 => 21,  77 => 20,  76 => 19,  75 => 18,  72 => 17,  70 => 16,  68 => 15,  66 => 14,  63 => 11,  61 => 10,  59 => 9,  57 => 8,  55 => 7,  53 => 6,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set spinner = spinner ?? false -%}
{% set busyMessage = busyMessage ?? false %}
{% set failureMessage = failureMessage ?? false %}
{% set retryMessage = retryMessage ?? false %}
{% set successMessage = successMessage ?? false %}
{% set enableLiveRegion = busyMessage or failureMessage or retryMessage or successMessage %}
{% set icon = icon ?? null %}
{% set iconHtml = iconHtml ?? null %}
{% set label = label ?? null %}
{% set labelHtml = labelHtml ?? null %}

{# the \"disabled\" class takes care of disabling the button,
   but the \"read-only\" class is needed so that it is allowed to have custom tabindex attribute #}
{% set hasIcon = icon or icon is same as('0') %}
{% set hasLabel = label or label is same as('0') %}
{% set hasLabelHtml = labelHtml or labelHtml is same as('0') %}

{% set attributes = {
    type: type ?? 'button',
    id: id ?? false,
    class: (class ?? [])|explodeClass|merge([
        'btn',
        not (hasIcon or hasLabel or hasLabelHtml) ? 'btn-empty' : null,
        (disabled ?? readOnly ?? false) ? 'disabled',
        (readOnly ?? false) ? 'read-only',
    ]|filter),
    data: {
        'busy-message': busyMessage,
        'failure-message': failureMessage,
        'retry-message': retryMessage,
        'success-message': successMessage,
    }|merge(attributes.data ?? {}),
}|merge(attributes ?? {}) -%}

{% apply spaceless %}
    {% if spinner and enableLiveRegion %}
        <div role=\"status\" class=\"visually-hidden\"></div>
    {% endif %}
    {% tag 'button' with attributes %}
        {% if hasIcon or hasLabel or hasLabelHtml %}
            <div class=\"inline-flex\">
                {% if hasIcon or iconHtml %}
                    {% if hasIcon %}
                        <div class=\"cp-icon\">{{ iconSvg(icon) }}</div>
                    {% elseif iconHtml %}
                        {{ iconHtml }}
                    {% endif %}
                {% endif %}
                {% if hasLabel or hasLabelHtml %}
                    {{ tag('div', {
                        class: 'label',
                        text: hasLabel ? label : null,
                        html: hasLabelHtml ? labelHtml : null,
                    }) }}
                {% endif %}
            </div>
        {% endif %}
        {% if spinner %}
            <div class=\"spinner spinner-absolute\">
                <span class=\"visually-hidden\">{{ 'Loading'|t('app') }}</span>
            </div>
        {% endif %}
    {% endtag %}
{% endapply -%}
", "_includes/forms/button", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/button.twig");
    }
}
