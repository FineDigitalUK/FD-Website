<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/colorSelect */
class __TwigTemplate_135fc58e511977d50b9aeab8f9d769d9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/colorSelect");
        // line 1
        $context["id"] = (($context["id"]) ?? (("fs" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 2
        $context["value"] = (($context["value"]) ?? (null));
        // line 3
        $context["withBlankOption"] = (($context["withBlankOption"]) ?? (true));
        // line 4
        yield "
";
        // line 5
        $context["options"] = $this->extensions['craft\web\twig\Extension']->mapFilter($this->env, (($context["options"]) ?? ([["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Red", "app"), "value" => "red"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Orange", "app"), "value" => "orange"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Amber", "app"), "value" => "amber"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Yellow", "app"), "value" => "yellow"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Lime", "app"), "value" => "lime"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Green", "app"), "value" => "green"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Emerald", "app"), "value" => "emerald"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Teal", "app"), "value" => "teal"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Cyan", "app"), "value" => "cyan"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sky", "app"), "value" => "sky"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Blue", "app"), "value" => "blue"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Indigo", "app"), "value" => "indigo"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Violet", "app"), "value" => "violet"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Purple", "app"), "value" => "purple"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Fuchsia", "app"), "value" => "fuchsia"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Pink", "app"), "value" => "pink"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Rose", "app"), "value" => "rose"]])),         // line 23
function ($__o__) use ($context, $macros) { $context["o"] = $__o__; return (( !(is_string($_v0 = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 23, $this->source); })()), "value", [], "any", false, false, false, 23)) && is_string($_v1 = "_") && str_starts_with($_v0, $_v1))) ? ($this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 23, $this->source); })()), ["data" => ["color" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 23, $this->source); })()), "value", [], "any", false, false, false, 23)]])) : ((isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 23, $this->source); })()))); });
        // line 24
        yield "
";
        // line 25
        if ((isset($context["withBlankOption"]) || array_key_exists("withBlankOption", $context) ? $context["withBlankOption"] : (function () { throw new RuntimeError('Variable "withBlankOption" does not exist.', 25, $this->source); })())) {
            // line 26
            yield "  ";
            $context["options"] = $this->extensions['craft\web\twig\Extension']->unshiftFilter((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 26, $this->source); })()), ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("No color", "app"), "value" => "__blank__", "data" => ["color" => ""]]);
        }
        // line 28
        yield "
";
        // line 29
        if ($this->env->getTest('instance of')->getCallable()((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 29, $this->source); })()), "craft\\enums\\Color")) {
            // line 30
            yield "  ";
            $context["value"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 30, $this->source); })()), "value", [], "any", false, false, false, 30);
        }
        // line 32
        yield "
";
        // line 33
        yield from $this->loadTemplate("_includes/forms/selectize", "_includes/forms/colorSelect", 33)->unwrap()->yield(CoreExtension::merge($context, ["options" =>         // line 34
(isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 34, $this->source); })()), "selectizeOptions" => ["allowEmptyOption" =>         // line 36
(isset($context["withBlankOption"]) || array_key_exists("withBlankOption", $context) ? $context["withBlankOption"] : (function () { throw new RuntimeError('Variable "withBlankOption" does not exist.', 36, $this->source); })())], "value" => ((        // line 38
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 38, $this->source); })())) ?: ((((isset($context["withBlankOption"]) || array_key_exists("withBlankOption", $context) ? $context["withBlankOption"] : (function () { throw new RuntimeError('Variable "withBlankOption" does not exist.', 38, $this->source); })())) ? ("__blank__") : (null))))]));
        craft\helpers\Template::endProfile("template", "_includes/forms/colorSelect");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/colorSelect";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  79 => 38,  78 => 36,  77 => 34,  76 => 33,  73 => 32,  69 => 30,  67 => 29,  64 => 28,  60 => 26,  58 => 25,  55 => 24,  53 => 23,  52 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set id = id ?? \"fs#{random()}\" %}
{% set value = value ?? null %}
{% set withBlankOption = withBlankOption ?? true %}

{% set options = (options ?? [
  {label: 'Red'|t('app'), value: 'red'},
  {label: 'Orange'|t('app'), value: 'orange'},
  {label: 'Amber'|t('app'), value: 'amber'},
  {label: 'Yellow'|t('app'), value: 'yellow'},
  {label: 'Lime'|t('app'), value: 'lime'},
  {label: 'Green'|t('app'), value: 'green'},
  {label: 'Emerald'|t('app'), value: 'emerald'},
  {label: 'Teal'|t('app'), value: 'teal'},
  {label: 'Cyan'|t('app'), value: 'cyan'},
  {label: 'Sky'|t('app'), value: 'sky'},
  {label: 'Blue'|t('app'), value: 'blue'},
  {label: 'Indigo'|t('app'), value: 'indigo'},
  {label: 'Violet'|t('app'), value: 'violet'},
  {label: 'Purple'|t('app'), value: 'purple'},
  {label: 'Fuchsia'|t('app'), value: 'fuchsia'},
  {label: 'Pink'|t('app'), value: 'pink'},
  {label: 'Rose'|t('app'), value: 'rose'},
])|map(o => not (o.value starts with('_')) ? o|merge({data: {color: o.value}}) : o) %}

{% if withBlankOption %}
  {% set options = options|unshift({label: 'No color'|t('app'), value: '__blank__', data: {color: ''}}) %}
{% endif %}

{% if value is instance of ('craft\\\\enums\\\\Color') %}
  {% set value = value.value %}
{% endif %}

{% include '_includes/forms/selectize' with {
  options,
  selectizeOptions: {
    allowEmptyOption: withBlankOption,
  },
  value: value ?: (withBlankOption ? '__blank__' : null),
} %}
", "_includes/forms/colorSelect", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/colorSelect.twig");
    }
}
