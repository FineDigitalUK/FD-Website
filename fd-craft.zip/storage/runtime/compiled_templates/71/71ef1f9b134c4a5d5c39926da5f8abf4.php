<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _layouts/components/global-sidebar */
class __TwigTemplate_41be1fdba1a5b5160ce222f8b63b149e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/components/global-sidebar");
        // line 1
        $macros["links"] = $this->macros["links"] = $this->loadTemplate("_includes/links", "_layouts/components/global-sidebar", 1)->unwrap();
        // line 2
        yield "
";
        // line 61
        yield "
<craft-global-sidebar>
    <header id=\"global-sidebar\" class=\"global-sidebar\">
        <div class=\"global-sidebar__header\">
            ";
        // line 65
        yield from $this->loadTemplate("_layouts/components/system-info", "_layouts/components/global-sidebar", 65)->unwrap()->yield($context);
        // line 66
        yield "        </div>

        <div class=\"global-sidebar__nav\">

            <nav id=\"nav\" class=\"global-nav\" aria-label=\"";
        // line 70
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Primary", "app"), "html", null, true);
        yield "\">
                <ul>
                    ";
        // line 72
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 72, $this->source); })()), "cp", [], "any", false, false, false, 72), "nav", [], "method", false, false, false, 72));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 73
            yield "                        ";
            $context["itemAttributes"] = ["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 74
$context["item"], "id", [], "any", false, false, false, 74), "class" => [((craft\helpers\Template::attribute($this->env, $this->source,             // line 76
$context["item"], "subnav", [], "any", false, false, false, 76)) ? ("has-subnav") : (""))]];
            // line 79
            yield "                        <li ";
            yield craft\helpers\Html::renderTagAttributes((isset($context["itemAttributes"]) || array_key_exists("itemAttributes", $context) ? $context["itemAttributes"] : (function () { throw new RuntimeError('Variable "itemAttributes" does not exist.', 79, $this->source); })()));
            yield ">
                            <div class=\"nav-item ";
            // line 80
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "sel", [], "any", false, false, false, 80)) {
                yield "sel";
            }
            yield "\">
                                ";
            // line 81
            yield $this->getTemplateForMacro("macro_action", $context, 81, $this->getSourceContext())->macro_action(...[$context["item"]]);
            yield "

                                ";
            // line 83
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "subnav", [], "any", false, false, false, 83)) {
                // line 84
                yield "                                    <craft-disclosure
                                        class=\"nav-item__trigger\"
                                        state=\"";
                // line 86
                yield ((craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "sel", [], "any", false, false, false, 86)) ? ("expanded") : ("collapsed"));
                yield "\"
                                    >
                                        <button
                                            type=\"button\"
                                            class=\"btn menubtn hairline\"
                                            aria-controls=\"";
                // line 91
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 91), "html", null, true);
                yield "-subnav\"
                                            aria-describedby=\"";
                // line 92
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 92), "html", null, true);
                yield "-link\"
                                            aria-expanded=\"";
                // line 93
                yield ((craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "sel", [], "any", false, false, false, 93)) ? ("true") : ("false"));
                yield "\"
                                        >
                                            <span class=\"visually-hidden\">";
                // line 95
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Open subnavigation", "app"), "html", null, true);
                yield "</span>
                                        </button>
                                    </craft-disclosure>
                                ";
            }
            // line 99
            yield "                            </div>

                            ";
            // line 101
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "subnav", [], "any", false, false, false, 101)) {
                // line 102
                yield "                                <ul class=\"nav-item__subnav\" id=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 102), "html", null, true);
                yield "-subnav\" data-state=\"";
                yield ((craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "sel", [], "any", false, false, false, 102)) ? ("expanded") : ("collapsed"));
                yield "\">
                                    ";
                // line 103
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "subnav", [], "any", false, false, false, 103));
                foreach ($context['_seq'] as $context["itemId"] => $context["item"]) {
                    // line 104
                    yield "                                        ";
                    $context["itemIsSelected"] = ((array_key_exists("selectedSubnavItem", $context) && ((isset($context["selectedSubnavItem"]) || array_key_exists("selectedSubnavItem", $context) ? $context["selectedSubnavItem"] : (function () { throw new RuntimeError('Variable "selectedSubnavItem" does not exist.', 104, $this->source); })()) == $context["itemId"])) && CoreExtension::inFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, false, 104), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 104, $this->source); })()), "app", [], "any", false, false, false, 104), "request", [], "any", false, false, false, 104), "fullPath", [], "any", false, false, false, 104)));
                    // line 106
                    yield "<li>
                                            <div class=\"nav-item nav-item--sub ";
                    // line 107
                    if ((isset($context["itemIsSelected"]) || array_key_exists("itemIsSelected", $context) ? $context["itemIsSelected"] : (function () { throw new RuntimeError('Variable "itemIsSelected" does not exist.', 107, $this->source); })())) {
                        yield "sel";
                    }
                    yield "\">
                                                ";
                    // line 108
                    yield $this->getTemplateForMacro("macro_action", $context, 108, $this->getSourceContext())->macro_action(...[$this->extensions['craft\web\twig\Extension']->mergeFilter($context["item"], ["linkAttributes" => ["class" => ["sidebar-action--sub"], "aria" => ["current" => ((                    // line 112
(isset($context["itemIsSelected"]) || array_key_exists("itemIsSelected", $context) ? $context["itemIsSelected"] : (function () { throw new RuntimeError('Variable "itemIsSelected" does not exist.', 112, $this->source); })())) ? ("page") : (false))]]], true),                     // line 115
(isset($context["itemIsSelected"]) || array_key_exists("itemIsSelected", $context) ? $context["itemIsSelected"] : (function () { throw new RuntimeError('Variable "itemIsSelected" does not exist.', 115, $this->source); })()), false]);
                    yield "
                                            </div>
                                        </li>
                                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['itemId'], $context['item'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 119
                yield "                                </ul>
                            ";
            }
            // line 121
            yield "                        </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 123
        yield "                </ul>
            </nav>
        </div>

        <div class=\"global-sidebar__footer\">
            <div class=\"sidebar-actions\">
                ";
        // line 129
        $context["toggleContent"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 130
            yield "                    <span class=\"sidebar-action__prefix\">
                        <span class=\"nav-icon\" aria-hidden=\"true\" id=\"sidebar-toggle-icon\">
                            ";
            // line 132
            if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 132, $this->source); })()), "app", [], "any", false, false, false, 132), "locale", [], "any", false, false, false, 132), "getOrientation", [], "method", false, false, false, 132) == "rtl")) {
                // line 133
                yield "                                ";
                yield craft\helpers\Cp::iconSvg("angle-left");
                yield "
                            ";
            } else {
                // line 135
                yield "                                ";
                yield craft\helpers\Cp::iconSvg("angle-right");
                yield "
                            ";
            }
            // line 137
            yield "                        </span>
                    </span>
                    <span class=\"sidebar-action__label\">
                        <span class=\"label\">";
            // line 140
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Toggle sidebar", "app"), "html", null, true);
            yield "</span>
                    </span>
                ";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 143
        yield "
                ";
        // line 144
        yield from $this->loadTemplate("_includes/disclosure-toggle", "_layouts/components/global-sidebar", 144)->unwrap()->yield(CoreExtension::merge($context, ["id" => "sidebar-trigger", "controls" => "global-sidebar", "state" =>         // line 147
(isset($context["sidebarState"]) || array_key_exists("sidebarState", $context) ? $context["sidebarState"] : (function () { throw new RuntimeError('Variable "sidebarState" does not exist.', 147, $this->source); })()), "content" =>         // line 148
(isset($context["toggleContent"]) || array_key_exists("toggleContent", $context) ? $context["toggleContent"] : (function () { throw new RuntimeError('Variable "toggleContent" does not exist.', 148, $this->source); })()), "attributes" => ["class" => "sidebar-action"]]));
        // line 153
        yield "            </div>

            ";
        // line 155
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 155, $this->source); })()), "admin", [], "any", false, false, false, 155) && (isset($context["devMode"]) || array_key_exists("devMode", $context) ? $context["devMode"] : (function () { throw new RuntimeError('Variable "devMode" does not exist.', 155, $this->source); })()))) {
            // line 156
            yield "                ";
            $context["devModeText"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Craft CMS is running in Dev Mode.", "app");
            // line 157
            yield "                <div id=\"devmode\">
                    ";
            // line 158
            ob_start();
            // line 161
            yield "                        ";
            yield (isset($context["devModeText"]) || array_key_exists("devModeText", $context) ? $context["devModeText"] : (function () { throw new RuntimeError('Variable "devModeText" does not exist.', 161, $this->source); })());
            yield "
                    ";
            echo craft\helpers\Html::tag("span", ob_get_clean(), ["class" => "visually-hidden"]);
            // line 163
            yield "                </div>
            ";
        }
        // line 165
        yield "        </div>
    </header>
</craft-global-sidebar>
";
        craft\helpers\Template::endProfile("template", "_layouts/components/global-sidebar");
        yield from [];
    }

    // line 3
    public function macro_action($item = null, $isSelected = null, $showIcon = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "item" => $item,
            "isSelected" => $isSelected,
            "showIcon" => $showIcon,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "action");
            // line 4
            yield "    ";
            $context["showIcon"] = (($context["showIcon"]) ?? (true));
            // line 5
            yield "    ";
            $context["selected"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "sel", [], "any", true, true, false, 5) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "sel", [], "any", false, false, false, 5)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "sel", [], "any", false, false, false, 5)) : ((($context["isSelected"]) ?? (false))));
            // line 6
            yield "    ";
            $context["badgeCount"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "badgeCount", [], "any", true, true, false, 6) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "badgeCount", [], "any", false, false, false, 6)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "badgeCount", [], "any", false, false, false, 6)) : (false));
            // line 7
            yield "    ";
            $context["external"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "external", [], "any", true, true, false, 7) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "external", [], "any", false, false, false, 7)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "external", [], "any", false, false, false, 7)) : (false));
            // line 8
            yield "
    ";
            // line 9
            $context["linkAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 10
($context["item"] ?? null), "id", [], "any", true, true, false, 10) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "id", [], "any", false, false, false, 10)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "id", [], "any", false, false, false, 10)) : (null))) ? ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 10, $this->source); })()), "id", [], "any", false, false, false, 10) . "-link")) : (null)), "href" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 11
($context["item"] ?? null), "url", [], "any", true, true, false, 11) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, false, 11)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, false, 11)) : (false))) ? (craft\helpers\UrlHelper::url(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 11, $this->source); })()), "url", [], "any", false, false, false, 11))) : (null)), "class" => ["sidebar-action", ((            // line 14
(isset($context["external"]) || array_key_exists("external", $context) ? $context["external"] : (function () { throw new RuntimeError('Variable "external" does not exist.', 14, $this->source); })())) ? ("external") : ("")), ((            // line 15
(isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 15, $this->source); })())) ? ("sel") : (""))], "target" => ((            // line 17
(isset($context["external"]) || array_key_exists("external", $context) ? $context["external"] : (function () { throw new RuntimeError('Variable "external" does not exist.', 17, $this->source); })())) ? ("_blank") : ("")), "aria" => ["label" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 19
($context["item"] ?? null), "ariaLabel", [], "any", true, true, false, 19) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "ariaLabel", [], "any", false, false, false, 19)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "ariaLabel", [], "any", false, false, false, 19)) : (false))]], (((craft\helpers\Template::attribute($this->env, $this->source,             // line 21
($context["item"] ?? null), "linkAttributes", [], "any", true, true, false, 21) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "linkAttributes", [], "any", false, false, false, 21)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "linkAttributes", [], "any", false, false, false, 21)) : ([])), true);
            // line 22
            yield "
    ";
            // line 23
            ob_start();
            // line 24
            yield "        <span class=\"sidebar-action__prefix\">
            ";
            // line 25
            if ((isset($context["showIcon"]) || array_key_exists("showIcon", $context) ? $context["showIcon"] : (function () { throw new RuntimeError('Variable "showIcon" does not exist.', 25, $this->source); })())) {
                // line 26
                yield "                <span class=\"nav-icon\" aria-hidden=\"true\">";
                // line 27
                if (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", true, true, false, 27)) {
                    // line 28
                    yield craft\helpers\Cp::iconSvg(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 28, $this->source); })()), "icon", [], "any", false, false, false, 28));
                } elseif (craft\helpers\Template::attribute($this->env, $this->source,                 // line 29
($context["item"] ?? null), "fontIcon", [], "any", true, true, false, 29)) {
                    // line 30
                    yield "<span data-icon=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 30, $this->source); })()), "fontIcon", [], "any", false, false, false, 30), "html", null, true);
                    yield "\"></span>";
                } else {
                    // line 32
                    yield from $this->loadTemplate("_includes/fallback-icon.svg.twig", "_layouts/components/global-sidebar", 32)->unwrap()->yield(CoreExtension::merge($context, ["label" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 32, $this->source); })()), "label", [], "any", false, false, false, 32)]));
                }
                // line 34
                yield "</span>
            ";
            }
            // line 36
            yield "        </span>

        <span class=\"sidebar-action__label\">
            <span class=\"label\">";
            // line 39
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 39, $this->source); })()), "label", [], "any", false, false, false, 39), "html", null, true);
            yield "</span>
            ";
            // line 40
            if ((isset($context["external"]) || array_key_exists("external", $context) ? $context["external"] : (function () { throw new RuntimeError('Variable "external" does not exist.', 40, $this->source); })())) {
                // line 41
                yield "                ";
                yield $macros["links"]->getTemplateForMacro("macro_externalLinkIcon", $context, 41, $this->getSourceContext())->macro_externalLinkIcon(...[]);
                yield "
            ";
            }
            // line 43
            yield "        </span>";
            // line 45
            if ((isset($context["badgeCount"]) || array_key_exists("badgeCount", $context) ? $context["badgeCount"] : (function () { throw new RuntimeError('Variable "badgeCount" does not exist.', 45, $this->source); })())) {
                // line 46
                yield "<span class=\"sidebar-action__badge\">
                <span class=\"badge\" aria-hidden=\"true\">";
                // line 47
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->numberFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 47, $this->source); })()), "badgeCount", [], "any", false, false, false, 47), 0), "html", null, true);
                yield "</span>
                ";
                // line 48
                yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "visually-hidden", "data" => ["notification" => true], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("{num, number} {num, plural, =1{notification} other{notifications}}", "app", ["num" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 54
(isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 54, $this->source); })()), "badgeCount", [], "any", false, false, false, 54)])]);
                // line 56
                yield "
            </span>";
            }
            echo craft\helpers\Html::tag("a", ob_get_clean(),             // line 23
(isset($context["linkAttributes"]) || array_key_exists("linkAttributes", $context) ? $context["linkAttributes"] : (function () { throw new RuntimeError('Variable "linkAttributes" does not exist.', 23, $this->source); })()));
            craft\helpers\Template::endProfile("macro", "action");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_layouts/components/global-sidebar";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  362 => 23,  358 => 56,  356 => 54,  355 => 48,  351 => 47,  348 => 46,  346 => 45,  344 => 43,  338 => 41,  336 => 40,  332 => 39,  327 => 36,  323 => 34,  320 => 32,  315 => 30,  313 => 29,  311 => 28,  309 => 27,  307 => 26,  305 => 25,  302 => 24,  300 => 23,  297 => 22,  295 => 21,  294 => 19,  293 => 17,  292 => 15,  291 => 14,  290 => 11,  289 => 10,  288 => 9,  285 => 8,  282 => 7,  279 => 6,  276 => 5,  273 => 4,  258 => 3,  249 => 165,  245 => 163,  239 => 161,  237 => 158,  234 => 157,  231 => 156,  229 => 155,  225 => 153,  223 => 148,  222 => 147,  221 => 144,  218 => 143,  211 => 140,  206 => 137,  200 => 135,  194 => 133,  192 => 132,  188 => 130,  186 => 129,  178 => 123,  171 => 121,  167 => 119,  157 => 115,  156 => 112,  155 => 108,  149 => 107,  146 => 106,  143 => 104,  139 => 103,  132 => 102,  130 => 101,  126 => 99,  119 => 95,  114 => 93,  110 => 92,  106 => 91,  98 => 86,  94 => 84,  92 => 83,  87 => 81,  81 => 80,  76 => 79,  74 => 76,  73 => 74,  71 => 73,  67 => 72,  62 => 70,  56 => 66,  54 => 65,  48 => 61,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/links\" as links %}

{% macro action(item, isSelected, showIcon) %}
    {% set showIcon = showIcon ?? true %}
    {% set selected = item.sel ?? isSelected ?? false %}
    {% set badgeCount = item.badgeCount ?? false %}
    {% set external = item.external ?? false %}

    {% set linkAttributes = {
        id: (item.id ?? null) ? \"#{item.id}-link\" : null,
        href: (item.url ?? false) ? url(item.url) : null,
        class: [
            'sidebar-action',
            (external ? 'external'),
            (selected ? 'sel'),
        ],
        target: external ? '_blank',
        aria: {
            label: item.ariaLabel ?? false,
        },
    }|merge(item.linkAttributes ?? {}, recursive=true) %}

    {% tag 'a' with linkAttributes %}
        <span class=\"sidebar-action__prefix\">
            {% if showIcon %}
                <span class=\"nav-icon\" aria-hidden=\"true\">
                    {%- if item.icon is defined -%}
                        {{ iconSvg(item.icon) }}
                    {%- elseif item.fontIcon is defined -%}
                        <span data-icon=\"{{ item.fontIcon }}\"></span>
                    {%- else -%}
                        {% include \"_includes/fallback-icon.svg.twig\" with { label: item.label } %}
                    {%- endif -%}
                </span>
            {% endif %}
        </span>

        <span class=\"sidebar-action__label\">
            <span class=\"label\">{{ item.label }}</span>
            {% if external %}
                {{ links.externalLinkIcon() }}
            {% endif %}
        </span>

        {%- if badgeCount -%}
            <span class=\"sidebar-action__badge\">
                <span class=\"badge\" aria-hidden=\"true\">{{ item.badgeCount|number(decimals=0) }}</span>
                {{ tag('span', {
                    class: 'visually-hidden',
                    data: {
                        notification: true,
                    },
                    text: '{num, number} {num, plural, =1{notification} other{notifications}}'|t('app', {
                        num: item.badgeCount,
                    }),
                }) }}
            </span>
        {%- endif -%}
    {% endtag %}
{% endmacro %}

<craft-global-sidebar>
    <header id=\"global-sidebar\" class=\"global-sidebar\">
        <div class=\"global-sidebar__header\">
            {% include '_layouts/components/system-info' %}
        </div>

        <div class=\"global-sidebar__nav\">

            <nav id=\"nav\" class=\"global-nav\" aria-label=\"{{ 'Primary'|t('app') }}\">
                <ul>
                    {% for item in craft.cp.nav() %}
                        {% set itemAttributes = {
                            id: item.id,
                            class: [
                                item.subnav ? 'has-subnav'
                            ],
                        } %}
                        <li {{ attr(itemAttributes) }}>
                            <div class=\"nav-item {% if item.sel %}sel{% endif %}\">
                                {{ _self.action(item) }}

                                {% if item.subnav %}
                                    <craft-disclosure
                                        class=\"nav-item__trigger\"
                                        state=\"{{ item.sel ? 'expanded' : 'collapsed' }}\"
                                    >
                                        <button
                                            type=\"button\"
                                            class=\"btn menubtn hairline\"
                                            aria-controls=\"{{ item.id }}-subnav\"
                                            aria-describedby=\"{{ item.id }}-link\"
                                            aria-expanded=\"{{ item.sel ?  'true' : 'false' }}\"
                                        >
                                            <span class=\"visually-hidden\">{{ 'Open subnavigation' |t('app') }}</span>
                                        </button>
                                    </craft-disclosure>
                                {% endif %}
                            </div>

                            {% if item.subnav %}
                                <ul class=\"nav-item__subnav\" id=\"{{ item.id }}-subnav\" data-state=\"{{ item.sel ?  'expanded' : 'collapsed' }}\">
                                    {% for itemId, item in item.subnav %}
                                        {% set itemIsSelected = selectedSubnavItem is defined and selectedSubnavItem == itemId and item.url in craft.app.request.fullPath -%}

                                        <li>
                                            <div class=\"nav-item nav-item--sub {% if itemIsSelected %}sel{% endif %}\">
                                                {{ _self.action(item|merge({
                                                    linkAttributes:  {
                                                        class: ['sidebar-action--sub'],
                                                        aria: {
                                                            current: itemIsSelected ? 'page' : false,
                                                        },
                                                    }
                                                }, recursive=true), itemIsSelected, false) }}
                                            </div>
                                        </li>
                                    {% endfor %}
                                </ul>
                            {% endif %}
                        </li>
                    {% endfor %}
                </ul>
            </nav>
        </div>

        <div class=\"global-sidebar__footer\">
            <div class=\"sidebar-actions\">
                {% set toggleContent %}
                    <span class=\"sidebar-action__prefix\">
                        <span class=\"nav-icon\" aria-hidden=\"true\" id=\"sidebar-toggle-icon\">
                            {% if craft.app.locale.getOrientation() == 'rtl' %}
                                {{ iconSvg('angle-left') }}
                            {% else %}
                                {{ iconSvg('angle-right') }}
                            {% endif %}
                        </span>
                    </span>
                    <span class=\"sidebar-action__label\">
                        <span class=\"label\">{{ 'Toggle sidebar'|t('app') }}</span>
                    </span>
                {% endset %}

                {% include '_includes/disclosure-toggle' with {
                    id: 'sidebar-trigger',
                    controls: 'global-sidebar',
                    state: sidebarState,
                    content: toggleContent,
                    attributes: {
                        class: 'sidebar-action',
                    },
                } %}
            </div>

            {% if currentUser.admin and devMode %}
                {% set devModeText = 'Craft CMS is running in Dev Mode.'|t('app') %}
                <div id=\"devmode\">
                    {% tag 'span' with {
                        class: 'visually-hidden',
                    } %}
                        {{ devModeText|raw }}
                    {% endtag %}
                </div>
            {% endif %}
        </div>
    </header>
</craft-global-sidebar>
", "_layouts/components/global-sidebar", "/var/www/html/vendor/craftcms/cms/src/templates/_layouts/components/global-sidebar.twig");
    }
}
