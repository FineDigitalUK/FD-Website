<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/fields */
class __TwigTemplate_fd0ed7feaf682cc4fbb4c1406ab3cdd0 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 3
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/fields");
        // line 1
        Craft::$app->controller->requireAdmin(false);
        // line 4
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Fields", "app");
        // line 6
        $context["readOnly"] =  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", [], "any", false, false, false, 6), "config", [], "any", false, false, false, 6), "general", [], "any", false, false, false, 6), "allowAdminChanges", [], "any", false, false, false, 6);
        // line 8
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 8, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\admintable\\AdminTableAsset"], "method", false, false, false, 8);
        // line 10
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 10, $this->source); })()), "registerTranslations", ["app", ["Handle", "Name", "No fields exist yet.", "No results.", "No usages", "This field’s values are used as search keywords.", "Type", "Used by"]], "method", false, false, false, 10);
        // line 21
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 25
        $context["emptyMessage"] = $this->extensions['craft\web\twig\Extension']->translateFilter("No fields exist yet.", "app");
        // line 35
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 35, $this->source); })())) {
            // line 36
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 43
        ob_start();
        // line 44
        yield "  ((info) => {
    const columns = [
      { name: '__slot:title', title: Craft.t('app', 'Name'), sortField: true },
      {
        name: 'searchable',
        titleClass: 'thin',
        callback: value => {
          if (!value) {
            return null;
          }
          return `<div class=\"badge-icon\" data-icon=\"search\" title=\"\${Craft.t('app', 'This field’s values are used as search keywords.')}\" aria-label=\"\${Craft.t('app', 'This field’s values are used as search keywords.')}\" role=\"img\"></div>`;
        }
      },
    ];

    if (info.isMultiSite) {
      columns.push({
        name: 'translatable',
        titleClass: 'thin',
        callback: value => {
          if (!value) {
            return null;
          }
          return `<div class=\"badge-icon\" data-icon=\"language\" title=\"\${value}\" aria-label=\"\${value}\" role=\"img\"></div>`;
        }
      });
    }

    columns.push({
      name: '__slot:handle',
      title: Craft.t('app', 'Handle'),
      sortField: true,
    });

    columns.push({
      name: 'type',
      title: Craft.t('app', 'Type'),
      callback: (value) => {
        let label = '<div class=\"flex flex-nowrap gap-s\">' +
          `<div class=\"cp-icon small\">\${value.icon}</div>`;
        if (value.isMissing) {
          label += `<span class=\"error\">\${value.label}</span>`;
        } else {
          label += `<span>\${value.label}</span>`;
        }
        label += '</div>';
        return label;
      },
      sortField: true,
    });

    columns.push({
      name: 'usages',
      title: Craft.t('app', 'Used by'),
      callback: (value) => value || `<i class=\"light\">\${Craft.t('app', 'No usages')}</i>`,
    });

    let config = {
      columns,
      container: '#fields-vue-admin-table',
      emptyMessage: info.emptyMessage,
      tableDataEndpoint: 'fields/table-data',
      search: true,
    };

  ";
        // line 109
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 109, $this->source); })())) {
            // line 110
            yield "    config['deleteAction'] = 'fields/delete-field';
  ";
        }
        // line 112
        yield "
    new Craft.VueAdminTable(config);
  })(";
        // line 114
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(["isMultiSite" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 116
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 116, $this->source); })()), "app", [], "any", false, false, false, 116), "isMultiSite", [], "any", false, false, false, 116), "emptyMessage" =>         // line 117
(isset($context["emptyMessage"]) || array_key_exists("emptyMessage", $context) ? $context["emptyMessage"] : (function () { throw new RuntimeError('Variable "emptyMessage" does not exist.', 117, $this->source); })())]);
        // line 119
        yield ");
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 3
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/fields", 3);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/fields");
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 29
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 29, $this->source); })())) {
            // line 30
            yield "        ";
            $context["newFieldUrl"] = craft\helpers\UrlHelper::url("settings/fields/new");
            // line 31
            yield "        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["newFieldUrl"]) || array_key_exists("newFieldUrl", $context) ? $context["newFieldUrl"] : (function () { throw new RuntimeError('Variable "newFieldUrl" does not exist.', 31, $this->source); })()), "html", null, true);
            yield "\" class=\"submit btn add icon\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("New field", "app"), "html", null, true);
            yield "</a>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 39
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 40
        yield "    <div id=\"fields-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/fields";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  195 => 40,  187 => 39,  175 => 31,  172 => 30,  169 => 29,  161 => 28,  155 => 3,  151 => 119,  149 => 117,  148 => 116,  147 => 114,  143 => 112,  139 => 110,  137 => 109,  70 => 44,  68 => 43,  65 => 36,  63 => 35,  61 => 25,  59 => 21,  57 => 10,  55 => 8,  53 => 6,  51 => 4,  49 => 1,  41 => 3,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% requireAdmin false %}

{% extends \"_layouts/cp\" %}
{% set title = \"Fields\"|t('app') %}

{% set readOnly = not craft.app.config.general.allowAdminChanges %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% do view.registerTranslations('app', [
    'Handle',
    'Name',
    'No fields exist yet.',
    'No results.',
    'No usages',
    'This field’s values are used as search keywords.',
    'Type',
    'Used by',
]) %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% set emptyMessage = \"No fields exist yet.\"|t('app') %}


{% block actionButton %}
    {% if not readOnly %}
        {% set newFieldUrl = url('settings/fields/new') %}
        <a href=\"{{ newFieldUrl }}\" class=\"submit btn add icon\">{{ \"New field\"|t('app') }}</a>
    {% endif %}
{% endblock %}

{% if readOnly %}
  {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    <div id=\"fields-vue-admin-table\"></div>
{% endblock %}

{% js %}
  ((info) => {
    const columns = [
      { name: '__slot:title', title: Craft.t('app', 'Name'), sortField: true },
      {
        name: 'searchable',
        titleClass: 'thin',
        callback: value => {
          if (!value) {
            return null;
          }
          return `<div class=\"badge-icon\" data-icon=\"search\" title=\"\${Craft.t('app', 'This field’s values are used as search keywords.')}\" aria-label=\"\${Craft.t('app', 'This field’s values are used as search keywords.')}\" role=\"img\"></div>`;
        }
      },
    ];

    if (info.isMultiSite) {
      columns.push({
        name: 'translatable',
        titleClass: 'thin',
        callback: value => {
          if (!value) {
            return null;
          }
          return `<div class=\"badge-icon\" data-icon=\"language\" title=\"\${value}\" aria-label=\"\${value}\" role=\"img\"></div>`;
        }
      });
    }

    columns.push({
      name: '__slot:handle',
      title: Craft.t('app', 'Handle'),
      sortField: true,
    });

    columns.push({
      name: 'type',
      title: Craft.t('app', 'Type'),
      callback: (value) => {
        let label = '<div class=\"flex flex-nowrap gap-s\">' +
          `<div class=\"cp-icon small\">\${value.icon}</div>`;
        if (value.isMissing) {
          label += `<span class=\"error\">\${value.label}</span>`;
        } else {
          label += `<span>\${value.label}</span>`;
        }
        label += '</div>';
        return label;
      },
      sortField: true,
    });

    columns.push({
      name: 'usages',
      title: Craft.t('app', 'Used by'),
      callback: (value) => value || `<i class=\"light\">\${Craft.t('app', 'No usages')}</i>`,
    });

    let config = {
      columns,
      container: '#fields-vue-admin-table',
      emptyMessage: info.emptyMessage,
      tableDataEndpoint: 'fields/table-data',
      search: true,
    };

  {% if not readOnly %}
    config['deleteAction'] = 'fields/delete-field';
  {% endif %}

    new Craft.VueAdminTable(config);
  })({{
    {
      isMultiSite: craft.app.isMultiSite,
      emptyMessage: emptyMessage,
    }|json_encode|raw
  }});
{% endjs %}
", "settings/fields", "/var/www/html/vendor/craftcms/cms/src/templates/settings/fields/index.twig");
    }
}
