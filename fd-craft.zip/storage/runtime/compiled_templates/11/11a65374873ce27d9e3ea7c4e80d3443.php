<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/filesystems/_index.twig */
class __TwigTemplate_e61863a07b6cbbc0b99a779fcb57a201 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/filesystems/_index.twig");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Filesystems", "app");
        // line 3
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 4
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 8
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 8, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\admintable\\AdminTableAsset"], "method", false, false, false, 8);
        // line 10
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 10, $this->source); })()), "registerTranslations", ["app", ["Name", "Handle", "Type", "No filesystems exist yet."]], "method", false, false, false, 10);
        // line 23
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 23, $this->source); })())) {
            // line 24
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 31
        $context["tableData"] = [];
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["filesystems"]) || array_key_exists("filesystems", $context) ? $context["filesystems"] : (function () { throw new RuntimeError('Variable "filesystems" does not exist.', 32, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["filesystem"]) {
            // line 33
            $context["filesystemIsMissing"] = false;
            // line 35
            if ($this->env->getTest('missing')->getCallable()($context["filesystem"])) {
                // line 36
                $context["filesystemIsMissing"] = true;
            }
            // line 39
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 39, $this->source); })()), [["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 40
$context["filesystem"], "handle", [], "any", false, false, false, 40), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 41
$context["filesystem"], "name", [], "any", false, false, false, 41), "site"), "url" => craft\helpers\UrlHelper::url(("settings/filesystems/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 42
$context["filesystem"], "handle", [], "any", false, false, false, 42))), "name" => $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 43
$context["filesystem"], "name", [], "any", false, false, false, 43), "site")), "handle" => craft\helpers\Template::attribute($this->env, $this->source,             // line 44
$context["filesystem"], "handle", [], "any", false, false, false, 44), "type" => ["isMissing" =>             // line 46
(isset($context["filesystemIsMissing"]) || array_key_exists("filesystemIsMissing", $context) ? $context["filesystemIsMissing"] : (function () { throw new RuntimeError('Variable "filesystemIsMissing" does not exist.', 46, $this->source); })()), "label" => ((            // line 47
(isset($context["filesystemIsMissing"]) || array_key_exists("filesystemIsMissing", $context) ? $context["filesystemIsMissing"] : (function () { throw new RuntimeError('Variable "filesystemIsMissing" does not exist.', 47, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["filesystem"], "expectedType", [], "any", false, false, false, 47)) : (craft\helpers\Template::attribute($this->env, $this->source, $context["filesystem"], "displayName", [], "method", false, false, false, 47)))]]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['filesystem'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        ob_start();
        // line 53
        yield "var columns = [
    { name: '__slot:title', title: Craft.t('app', 'Name') },
    { name: '__slot:handle', title: Craft.t('app', 'Handle') },
    { name: 'type', title: Craft.t('app', 'Type'), callback: function(value) {
            if (value.isMissing) {
                return '<span class=\"error\">' + value.label + '</span>'
            }

            return value.label
        }
    },
];

let config = {
    columns: columns,
    container: '#fs-vue-admin-table',
    emptyMessage: Craft.t('app', 'No filesystems exist yet.'),
    tableData: ";
        // line 70
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 70, $this->source); })()));
        yield "
};

";
        // line 73
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 73, $this->source); })())) {
            // line 74
            yield "    config['deleteAction'] = 'fs/remove';
";
        }
        // line 76
        yield "
new Craft.VueAdminTable(config);
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/filesystems/_index.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/filesystems/_index.twig");
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 18
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 18, $this->source); })())) {
            // line 19
            yield "        <a class=\"btn submit add icon\" href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("settings/filesystems/new"), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("New filesystem", "app"), "html", null, true);
            yield "</a>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 28
        yield "    <div id=\"fs-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/filesystems/_index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  165 => 28,  157 => 27,  145 => 19,  142 => 18,  134 => 17,  128 => 1,  123 => 76,  119 => 74,  117 => 73,  111 => 70,  92 => 53,  90 => 52,  84 => 47,  83 => 46,  82 => 44,  81 => 43,  80 => 42,  79 => 41,  78 => 40,  77 => 39,  74 => 36,  72 => 35,  70 => 33,  66 => 32,  64 => 31,  61 => 24,  59 => 23,  57 => 10,  55 => 8,  53 => 4,  51 => 3,  49 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = 'Filesystems'|t('app') %}
{% set readOnly = readOnly ?? false %}
{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% do view.registerTranslations('app', [
    \"Name\",
    \"Handle\",
    \"Type\",
    \"No filesystems exist yet.\"
]) %}

{% block actionButton %}
    {% if not readOnly %}
        <a class=\"btn submit add icon\" href=\"{{ url('settings/filesystems/new') }}\">{{ \"New filesystem\"|t('app') }}</a>
    {% endif %}
{% endblock %}

{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    <div id=\"fs-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% for filesystem in filesystems %}
    {% set filesystemIsMissing = false %}

    {% if filesystem is missing %}
        {% set filesystemIsMissing = true %}
    {% endif %}

    {% set tableData = tableData|merge([{
        id: filesystem.handle,
        title: filesystem.name|t('site'),
        url: url('settings/filesystems/' ~ filesystem.handle),
        name: filesystem.name|t('site')|e,
        handle: filesystem.handle,
        type: {
            isMissing: filesystemIsMissing,
            label: filesystemIsMissing ? filesystem.expectedType : filesystem.displayName()
        },
    }]) %}
{% endfor %}

{% js %}
var columns = [
    { name: '__slot:title', title: Craft.t('app', 'Name') },
    { name: '__slot:handle', title: Craft.t('app', 'Handle') },
    { name: 'type', title: Craft.t('app', 'Type'), callback: function(value) {
            if (value.isMissing) {
                return '<span class=\"error\">' + value.label + '</span>'
            }

            return value.label
        }
    },
];

let config = {
    columns: columns,
    container: '#fs-vue-admin-table',
    emptyMessage: Craft.t('app', 'No filesystems exist yet.'),
    tableData: {{ tableData|json_encode|raw }}
};

{% if not readOnly %}
    config['deleteAction'] = 'fs/remove';
{% endif %}

new Craft.VueAdminTable(config);
{% endjs %}
", "settings/filesystems/_index.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/filesystems/_index.twig");
    }
}
