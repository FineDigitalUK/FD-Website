<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _elements/tableview/elements */
class __TwigTemplate_aa6ee502cee858426029b33bc11d5ec5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/tableview/elements");
        // line 1
        $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "
";
            // line 3
            $context["structure"] = ((array_key_exists("structure", $context)) ? ((isset($context["structure"]) || array_key_exists("structure", $context) ? $context["structure"] : (function () { throw new RuntimeError('Variable "structure" does not exist.', 3, $this->source); })())) : (null));
            // line 4
            $context["structureEditable"] = (((array_key_exists("structureEditable", $context) &&  !(isset($context["inlineEditing"]) || array_key_exists("inlineEditing", $context) ? $context["inlineEditing"] : (function () { throw new RuntimeError('Variable "inlineEditing" does not exist.', 4, $this->source); })()))) ? ((isset($context["structureEditable"]) || array_key_exists("structureEditable", $context) ? $context["structureEditable"] : (function () { throw new RuntimeError('Variable "structureEditable" does not exist.', 4, $this->source); })())) : (false));
            // line 5
            $context["padding"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", [], "any", false, false, false, 5), "locale", [], "any", false, false, false, 5), "getOrientation", [], "method", false, false, false, 5) == "ltr")) ? ("left") : ("right"));
            // line 6
            $context["elementsService"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", [], "any", false, false, false, 6), "elements", [], "any", false, false, false, 6);
            // line 7
            $context["hasStatusCol"] = craft\helpers\ArrayHelper::contains((isset($context["attributes"]) || array_key_exists("attributes", $context) ? $context["attributes"] : (function () { throw new RuntimeError('Variable "attributes" does not exist.', 7, $this->source); })()), 0, "status");
            // line 8
            $context["showHeaderColumn"] = (($context["showHeaderColumn"]) ?? (false));
            // line 9
            yield "
";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 10, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
                // line 11
                yield "    ";
                $context["totalDescendants"] = (((isset($context["structure"]) || array_key_exists("structure", $context) ? $context["structure"] : (function () { throw new RuntimeError('Variable "structure" does not exist.', 11, $this->source); })())) ? ((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $this->extensions['craft\web\twig\Extension']->cloneFunction(                // line 12
(isset($context["elementQuery"]) || array_key_exists("elementQuery", $context) ? $context["elementQuery"] : (function () { throw new RuntimeError('Variable "elementQuery" does not exist.', 12, $this->source); })())), "structureId", [craft\helpers\Template::attribute($this->env, $this->source,                 // line 13
$context["element"], "structureId", [], "any", false, false, false, 13)], "method", false, true, false, 12), "descendantOf", [                // line 14
$context["element"]], "method", false, true, false, 13), "siteId", [craft\helpers\Template::attribute($this->env, $this->source,                 // line 15
$context["element"], "siteId", [], "any", false, false, false, 15)], "method", false, true, false, 14), "status", [null], "method", false, true, false, 15), "drafts", [null], "method", false, true, false, 16), "draftOf", [false], "method", false, true, false, 17), "savedDraftsOnly", [], "method", false, true, false, 18), "withCustomFields", [false], "method", false, true, false, 19), "count", [], "method", true, true, false, 20) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $this->extensions['craft\web\twig\Extension']->cloneFunction(                // line 12
(isset($context["elementQuery"]) || array_key_exists("elementQuery", $context) ? $context["elementQuery"] : (function () { throw new RuntimeError('Variable "elementQuery" does not exist.', 12, $this->source); })())), "structureId", [craft\helpers\Template::attribute($this->env, $this->source,                 // line 13
$context["element"], "structureId", [], "any", false, false, false, 13)], "method", false, true, false, 12), "descendantOf", [                // line 14
$context["element"]], "method", false, true, false, 13), "siteId", [craft\helpers\Template::attribute($this->env, $this->source,                 // line 15
$context["element"], "siteId", [], "any", false, false, false, 15)], "method", false, true, false, 14), "status", [null], "method", false, true, false, 15), "drafts", [null], "method", false, true, false, 16), "draftOf", [false], "method", false, true, false, 17), "savedDraftsOnly", [], "method", false, true, false, 18), "withCustomFields", [false], "method", false, true, false, 19), "count", [], "method", false, false, false, 20)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $this->extensions['craft\web\twig\Extension']->cloneFunction(                // line 12
(isset($context["elementQuery"]) || array_key_exists("elementQuery", $context) ? $context["elementQuery"] : (function () { throw new RuntimeError('Variable "elementQuery" does not exist.', 12, $this->source); })())), "structureId", [craft\helpers\Template::attribute($this->env, $this->source,                 // line 13
$context["element"], "structureId", [], "any", false, false, false, 13)], "method", false, true, false, 12), "descendantOf", [                // line 14
$context["element"]], "method", false, true, false, 13), "siteId", [craft\helpers\Template::attribute($this->env, $this->source,                 // line 15
$context["element"], "siteId", [], "any", false, false, false, 15)], "method", false, true, false, 14), "status", [null], "method", false, true, false, 15), "drafts", [null], "method", false, true, false, 16), "draftOf", [false], "method", false, true, false, 17), "savedDraftsOnly", [], "method", false, true, false, 18), "withCustomFields", [false], "method", false, true, false, 19), "count", [], "method", false, false, false, 20)) : (0))) : (0));
                // line 23
                yield "    ";
                $context["elementTitle"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "title", [], "any", false, false, false, 23)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "title", [], "any", false, false, false, 23)) : (craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "id", [], "any", false, false, false, 23)));
                // line 24
                yield "    ";
                $context["showInputs"] = ((($context["inlineEditing"]) ?? (false)) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementsService"]) || array_key_exists("elementsService", $context) ? $context["elementsService"] : (function () { throw new RuntimeError('Variable "elementsService" does not exist.', 24, $this->source); })()), "canSave", [$context["element"], (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 24, $this->source); })())], "method", false, false, false, 24));
                // line 25
                yield "    ";
                ob_start();
                // line 36
                yield "        ";
                if ((isset($context["selectable"]) || array_key_exists("selectable", $context) ? $context["selectable"] : (function () { throw new RuntimeError('Variable "selectable" does not exist.', 36, $this->source); })())) {
                    // line 37
                    yield "            ";
                    $context["checkboxLabelId"] = ("checkbox-label-" . Twig\Extension\CoreExtension::random($this->env->getCharset()));
                    // line 38
                    yield "            <td class=\"checkbox-cell\">
                ";
                    // line 39
                    yield $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => "checkbox", "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("Select", "app"), "tabindex" => "0", "aria" => ["checked" => "false", "labelledby" =>                     // line 45
(isset($context["checkboxLabelId"]) || array_key_exists("checkboxLabelId", $context) ? $context["checkboxLabelId"] : (function () { throw new RuntimeError('Variable "checkboxLabelId" does not exist.', 45, $this->source); })())]]);
                    // line 47
                    yield "
                ";
                    // line 48
                    yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["id" =>                     // line 49
(isset($context["checkboxLabelId"]) || array_key_exists("checkboxLabelId", $context) ? $context["checkboxLabelId"] : (function () { throw new RuntimeError('Variable "checkboxLabelId" does not exist.', 49, $this->source); })()), "class" => "visually-hidden", "text" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 51
$context["element"], "getUiLabel", [], "method", false, false, false, 51), "aria" => ["hidden" => "true"]]);
                    // line 55
                    yield "
            </td>
        ";
                }
                // line 58
                yield "        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable((isset($context["attributes"]) || array_key_exists("attributes", $context) ? $context["attributes"] : (function () { throw new RuntimeError('Variable "attributes" does not exist.', 58, $this->source); })()));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["attribute"]) {
                    // line 59
                    yield "            ";
                    if (craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 59)) {
                        // line 60
                        yield "                ";
                        ob_start();
                        // line 67
                        yield "                    ";
                        ob_start();
                        // line 72
                        if ((((isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 72, $this->source); })()) || (isset($context["structureEditable"]) || array_key_exists("structureEditable", $context) ? $context["structureEditable"] : (function () { throw new RuntimeError('Variable "structureEditable" does not exist.', 72, $this->source); })())) &&  !(isset($context["inlineEditing"]) || array_key_exists("inlineEditing", $context) ? $context["inlineEditing"] : (function () { throw new RuntimeError('Variable "inlineEditing" does not exist.', 72, $this->source); })()))) {
                            // line 73
                            yield "                            <a class=\"move icon\" title=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                            yield "\">&nbsp;</a>
                        ";
                        }
                        // line 75
                        if (((isset($context["structure"]) || array_key_exists("structure", $context) ? $context["structure"] : (function () { throw new RuntimeError('Variable "structure" does not exist.', 75, $this->source); })()) && (isset($context["totalDescendants"]) || array_key_exists("totalDescendants", $context) ? $context["totalDescendants"] : (function () { throw new RuntimeError('Variable "totalDescendants" does not exist.', 75, $this->source); })()))) {
                            // line 76
                            yield "                            ";
                            $context["toggleLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Show {title} children", "app", ["title" => (isset($context["elementTitle"]) || array_key_exists("elementTitle", $context) ? $context["elementTitle"] : (function () { throw new RuntimeError('Variable "elementTitle" does not exist.', 76, $this->source); })())]);
                            // line 77
                            yield "                            <button type=\"button\" class=\"toggle";
                            if (!CoreExtension::inFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "id", [], "any", false, false, false, 77), (isset($context["collapsedElementIds"]) || array_key_exists("collapsedElementIds", $context) ? $context["collapsedElementIds"] : (function () { throw new RuntimeError('Variable "collapsedElementIds" does not exist.', 77, $this->source); })()))) {
                                yield " expanded";
                            }
                            // line 78
                            yield "\" title=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Show/hide children", "app"), "html", null, true);
                            yield "\" aria-label=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["toggleLabel"]) || array_key_exists("toggleLabel", $context) ? $context["toggleLabel"] : (function () { throw new RuntimeError('Variable "toggleLabel" does not exist.', 78, $this->source); })()), "html", null, true);
                            yield "\"
                            aria-expanded=\"";
                            // line 79
                            yield ((!CoreExtension::inFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "id", [], "any", false, false, false, 79), (isset($context["collapsedElementIds"]) || array_key_exists("collapsedElementIds", $context) ? $context["collapsedElementIds"] : (function () { throw new RuntimeError('Variable "collapsedElementIds" does not exist.', 79, $this->source); })()))) ? ("true") : ("false"));
                            yield "\"></button>
                        ";
                        }
                        // line 81
                        yield "                        ";
                        $context["chip"] = craft\helpers\Cp::elementChipHtml($context["element"], ["context" => ((                        // line 82
$context["context"]) ?? ("index")), "showThumb" =>                         // line 83
(isset($context["showHeaderColumn"]) || array_key_exists("showHeaderColumn", $context) ? $context["showHeaderColumn"] : (function () { throw new RuntimeError('Variable "showHeaderColumn" does not exist.', 83, $this->source); })()), "showLabel" =>                         // line 84
(isset($context["showHeaderColumn"]) || array_key_exists("showHeaderColumn", $context) ? $context["showHeaderColumn"] : (function () { throw new RuntimeError('Variable "showHeaderColumn" does not exist.', 84, $this->source); })()), "showProvisionalDraftLabel" => true, "showStatus" => (                        // line 86
(isset($context["showHeaderColumn"]) || array_key_exists("showHeaderColumn", $context) ? $context["showHeaderColumn"] : (function () { throw new RuntimeError('Variable "showHeaderColumn" does not exist.', 86, $this->source); })()) &&  !(isset($context["hasStatusCol"]) || array_key_exists("hasStatusCol", $context) ? $context["hasStatusCol"] : (function () { throw new RuntimeError('Variable "hasStatusCol" does not exist.', 86, $this->source); })())), "attributes" => ["class" => ["chromeless"]]]);
                        // line 91
                        yield "                        ";
                        if ( !(isset($context["showHeaderColumn"]) || array_key_exists("showHeaderColumn", $context) ? $context["showHeaderColumn"] : (function () { throw new RuntimeError('Variable "showHeaderColumn" does not exist.', 91, $this->source); })())) {
                            // line 92
                            yield "                            ";
                            $context["chip"] = $this->extensions['craft\web\twig\Extension']->attrFilter((isset($context["chip"]) || array_key_exists("chip", $context) ? $context["chip"] : (function () { throw new RuntimeError('Variable "chip" does not exist.', 92, $this->source); })()), ["class" => "hide-label"]);
                            // line 93
                            yield "                        ";
                        }
                        // line 94
                        yield "                        ";
                        yield (isset($context["chip"]) || array_key_exists("chip", $context) ? $context["chip"] : (function () { throw new RuntimeError('Variable "chip" does not exist.', 94, $this->source); })());
                        // line 96
                        if ((isset($context["structure"]) || array_key_exists("structure", $context) ? $context["structure"] : (function () { throw new RuntimeError('Variable "structure" does not exist.', 96, $this->source); })())) {
                            // line 97
                            yield "                            ";
                            $context["textAlternative"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Level {num}", "app", ["num" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 98
$context["element"], "level", [], "any", false, false, false, 98)]);
                            // line 100
                            yield "                            ";
                            yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "visually-hidden", "data" => ["text-alternative" => true], "text" =>                             // line 105
(isset($context["textAlternative"]) || array_key_exists("textAlternative", $context) ? $context["textAlternative"] : (function () { throw new RuntimeError('Variable "textAlternative" does not exist.', 105, $this->source); })())]);
                            // line 106
                            yield "
                        ";
                        }
                        // line 108
                        yield "                    ";
                        echo craft\helpers\Html::tag("div", ob_get_clean(), ["style" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [("padding-" .                         // line 69
(isset($context["padding"]) || array_key_exists("padding", $context) ? $context["padding"] : (function () { throw new RuntimeError('Variable "padding" does not exist.', 69, $this->source); })())) => ((((isset($context["structure"]) || array_key_exists("structure", $context) ? $context["structure"] : (function () { throw new RuntimeError('Variable "structure" does not exist.', 69, $this->source); })()) || (isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 69, $this->source); })()))) ? ((((((isset($context["inlineEditing"]) || array_key_exists("inlineEditing", $context) ? $context["inlineEditing"] : (function () { throw new RuntimeError('Variable "inlineEditing" does not exist.', 69, $this->source); })())) ? (0) : (24)) + (44 * (((craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "level", [], "any", false, false, false, 69)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "level", [], "any", false, false, false, 69)) : (1)) - 1))) . "px")) : (null))])]);
                        // line 109
                        yield "                ";
                        echo craft\helpers\Html::tag("th", ob_get_clean(), ["data" => ["title" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,                         // line 62
$context["attribute"], 1, [], "array", false, false, false, 62), "label", [], "any", false, false, false, 62), "titlecell" => ""], "scope" => "row"]);
                        // line 110
                        yield "            ";
                    } else {
                        // line 111
                        yield "                <td data-title=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 1, [], "array", false, false, false, 111), "label", [], "any", false, false, false, 111), "html", null, true);
                        yield "\" data-attr=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 0, [], "array", false, false, false, 111), "html", null, true);
                        yield "\">
                    ";
                        // line 112
                        if ((isset($context["showInputs"]) || array_key_exists("showInputs", $context) ? $context["showInputs"] : (function () { throw new RuntimeError('Variable "showInputs" does not exist.', 112, $this->source); })())) {
                            // line 113
                            yield "                        ";
                            $context["namespace"] = ((((isset($context["nestedInputNamespace"]) || array_key_exists("nestedInputNamespace", $context) ? $context["nestedInputNamespace"] : (function () { throw new RuntimeError('Variable "nestedInputNamespace" does not exist.', 113, $this->source); })()) . "[element-") . craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "id", [], "any", false, false, false, 113)) . "]");
                            // line 114
                            yield "                        ";
                            if (((is_string($_v1 = craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 0, [], "array", false, false, false, 114)) && is_string($_v2 = "field:") && str_starts_with($_v1, $_v2)) || (is_string($_v3 = craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 0, [], "array", false, false, false, 114)) && is_string($_v4 = "fieldInstance:") && str_starts_with($_v3, $_v4)))) {
                                // line 115
                                yield "                            ";
                                $context["namespace"] = ((isset($context["namespace"]) || array_key_exists("namespace", $context) ? $context["namespace"] : (function () { throw new RuntimeError('Variable "namespace" does not exist.', 115, $this->source); })()) . "[fields]");
                                // line 116
                                yield "                        ";
                            }
                            // line 117
                            yield "                        ";
                            $_namespace = (isset($context["namespace"]) || array_key_exists("namespace", $context) ? $context["namespace"] : (function () { throw new RuntimeError('Variable "namespace" does not exist.', 117, $this->source); })());
                            if ($_namespace !== null && $_namespace !== '') {
                                $_originalNamespace = Craft::$app->getView()->getNamespace();
                                Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                                ob_start();
                                try {
                                    // line 118
                                    yield craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "getInlineAttributeInputHtml", [craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 0, [], "array", false, false, false, 118)], "method", false, false, false, 118);
                                } catch (Exception $e) {
                                    ob_end_clean();

                                    throw $e;
                                }
                                echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
                                Craft::$app->getView()->setNamespace($_originalNamespace);
                            } else {
                                yield craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "getInlineAttributeInputHtml", [craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 0, [], "array", false, false, false, 118)], "method", false, false, false, 118);
                            }
                            unset($_originalNamespace, $_namespace);
                            // line 120
                            yield "                    ";
                        } else {
                            // line 121
                            yield craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "getAttributeHtml", [craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 0, [], "array", false, false, false, 121)], "method", false, false, false, 121);
                        }
                        // line 123
                        yield "                </td>
            ";
                    }
                    // line 125
                    yield "        ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['attribute'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 126
                yield "    ";
                echo craft\helpers\Html::tag("tr", ob_get_clean(), ["data" => ["id" => ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 27
$context["element"], "isProvisionalDraft", [], "any", false, false, false, 27)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "getCanonicalId", [], "method", false, false, false, 27)) : (craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "id", [], "any", false, false, false, 27))), "title" =>                 // line 28
(isset($context["elementTitle"]) || array_key_exists("elementTitle", $context) ? $context["elementTitle"] : (function () { throw new RuntimeError('Variable "elementTitle" does not exist.', 28, $this->source); })()), "level" => ((                // line 29
(isset($context["structure"]) || array_key_exists("structure", $context) ? $context["structure"] : (function () { throw new RuntimeError('Variable "structure" does not exist.', 29, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "level", [], "any", false, false, false, 29)) : (false)), "descendants" => ((                // line 30
(isset($context["structure"]) || array_key_exists("structure", $context) ? $context["structure"] : (function () { throw new RuntimeError('Variable "structure" does not exist.', 30, $this->source); })())) ? ((isset($context["totalDescendants"]) || array_key_exists("totalDescendants", $context) ? $context["totalDescendants"] : (function () { throw new RuntimeError('Variable "totalDescendants" does not exist.', 30, $this->source); })())) : (false))], "class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["disabled" => CoreExtension::inFilter(((craft\helpers\Template::attribute($this->env, $this->source,                 // line 33
$context["element"], "isProvisionalDraft", [], "any", false, false, false, 33)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "getCanonicalId", [], "method", false, false, false, 33)) : (craft\helpers\Template::attribute($this->env, $this->source, $context["element"], "id", [], "any", false, false, false, 33))), (isset($context["disabledElementIds"]) || array_key_exists("disabledElementIds", $context) ? $context["disabledElementIds"] : (function () { throw new RuntimeError('Variable "disabledElementIds" does not exist.', 33, $this->source); })()))]))]);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['element'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 128
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        yield Twig\Extension\CoreExtension::spaceless($_v0);
        craft\helpers\Template::endProfile("template", "_elements/tableview/elements");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_elements/tableview/elements";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  299 => 1,  294 => 128,  288 => 33,  287 => 30,  286 => 29,  285 => 28,  284 => 27,  282 => 126,  268 => 125,  264 => 123,  261 => 121,  258 => 120,  245 => 118,  237 => 117,  234 => 116,  231 => 115,  228 => 114,  225 => 113,  223 => 112,  216 => 111,  213 => 110,  211 => 62,  209 => 109,  207 => 69,  205 => 108,  201 => 106,  199 => 105,  197 => 100,  195 => 98,  193 => 97,  191 => 96,  188 => 94,  185 => 93,  182 => 92,  179 => 91,  177 => 86,  176 => 84,  175 => 83,  174 => 82,  172 => 81,  167 => 79,  160 => 78,  155 => 77,  152 => 76,  150 => 75,  144 => 73,  142 => 72,  139 => 67,  136 => 60,  133 => 59,  115 => 58,  110 => 55,  108 => 51,  107 => 49,  106 => 48,  103 => 47,  101 => 45,  100 => 39,  97 => 38,  94 => 37,  91 => 36,  88 => 25,  85 => 24,  82 => 23,  80 => 15,  79 => 14,  78 => 13,  77 => 12,  76 => 15,  75 => 14,  74 => 13,  73 => 12,  72 => 15,  71 => 14,  70 => 13,  69 => 12,  67 => 11,  63 => 10,  60 => 9,  58 => 8,  56 => 7,  54 => 6,  52 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% apply spaceless %}

{% set structure = structure is defined ? structure : null -%}
{% set structureEditable = structureEditable is defined and not inlineEditing ? structureEditable : false -%}
{% set padding = craft.app.locale.getOrientation() == 'ltr' ? 'left' : 'right' -%}
{% set elementsService = craft.app.elements %}
{% set hasStatusCol = attributes|contains(0, 'status') %}
{% set showHeaderColumn = showHeaderColumn ?? false %}

{% for element in elements %}
    {% set totalDescendants = structure
        ? (clone(elementQuery)
            .structureId(element.structureId)
            .descendantOf(element)
            .siteId(element.siteId)
            .status(null)
            .drafts(null)
            .draftOf(false)
            .savedDraftsOnly()
            .withCustomFields(false)
            .count() ?? 0)
        : 0 %}
    {% set elementTitle = element.title ?: element.id %}
    {% set showInputs = (inlineEditing ?? false) and elementsService.canSave(element, currentUser) %}
    {% tag 'tr' with {
      data: {
        id: element.isProvisionalDraft ? element.getCanonicalId() : element.id,
        title: elementTitle,
        level: structure ? element.level : false,
        descendants: structure ? totalDescendants : false,
      },
      class: {
        disabled: (element.isProvisionalDraft ? element.getCanonicalId() : element.id) in disabledElementIds,
      }|filter|keys,
    } %}
        {% if selectable %}
            {% set checkboxLabelId = \"checkbox-label-#{random()}\" %}
            <td class=\"checkbox-cell\">
                {{ tag('div', {
                    class: 'checkbox',
                    title: 'Select'|t('app'),
                    tabindex: '0',
                    aria: {
                        checked: 'false',
                        labelledby: checkboxLabelId,
                    },
                }) }}
                {{ tag('span', {
                    id: checkboxLabelId,
                    class: 'visually-hidden',
                    text: element.getUiLabel(),
                    aria: {
                        hidden: 'true',
                    }
                }) }}
            </td>
        {% endif %}
        {% for attribute in attributes %}
            {% if loop.first %}
                {% tag 'th' with {
                    data: {
                        title: attribute[1].label,
                        titlecell: '',
                    },
                    scope: 'row',
                } %}
                    {% tag 'div' with {
                        style: {
                            (\"padding-#{padding}\"): structure or sortable ? \"#{(inlineEditing ? 0 : 24) + 44 * ((element.level ?: 1) - 1)}px\" : null,
                        }|filter,
                    } %}
                        {%- if (sortable or structureEditable) and not inlineEditing %}
                            <a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\">&nbsp;</a>
                        {% endif %}
                        {%- if structure and totalDescendants %}
                            {% set toggleLabel = 'Show {title} children'|t('app', {title: elementTitle}) %}
                            <button type=\"button\" class=\"toggle{% if element.id not in collapsedElementIds %} expanded{% endif
                            %}\" title=\"{{ 'Show/hide children'|t('app') }}\" aria-label=\"{{ toggleLabel }}\"
                            aria-expanded=\"{{  element.id not in collapsedElementIds ? 'true' : 'false' }}\"></button>
                        {% endif %}
                        {% set chip = elementChip(element, {
                            context: context ?? 'index',
                            showThumb: showHeaderColumn,
                            showLabel: showHeaderColumn,
                            showProvisionalDraftLabel: true,
                            showStatus: showHeaderColumn and not hasStatusCol,
                            attributes: {
                                class: ['chromeless'],
                            }
                        }) %}
                        {% if not showHeaderColumn %}
                            {% set chip = chip|attr({class: 'hide-label'}) %}
                        {% endif %}
                        {{ chip|raw }}

                        {%- if structure %}
                            {% set textAlternative = 'Level {num}'|t('app', {
                                num: element.level,
                            }) %}
                            {{ tag('span', {
                                class: 'visually-hidden',
                                data: {
                                    'text-alternative': true,
                                },
                                text: textAlternative,
                            }) }}
                        {% endif  %}
                    {% endtag %}
                {% endtag %}
            {% else %}
                <td data-title=\"{{ attribute[1].label }}\" data-attr=\"{{ attribute[0] }}\">
                    {% if showInputs %}
                        {% set namespace = \"#{nestedInputNamespace}[element-#{element.id}]\" %}
                        {% if attribute[0] starts with 'field:' or attribute[0] starts with 'fieldInstance:' %}
                            {% set namespace = \"#{namespace}[fields]\" %}
                        {% endif %}
                        {% namespace namespace %}
                            {{- element.getInlineAttributeInputHtml(attribute[0])|raw -}}
                        {% endnamespace %}
                    {% else %}
                        {{- element.getAttributeHtml(attribute[0])|raw -}}
                    {% endif %}
                </td>
            {% endif %}
        {% endfor %}
    {% endtag %}
{% endfor %}

{% endapply -%}
", "_elements/tableview/elements", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/tableview/elements.twig");
    }
}
