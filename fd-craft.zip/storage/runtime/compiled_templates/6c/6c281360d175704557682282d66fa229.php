<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/fld/custom-field-settings.twig */
class __TwigTemplate_6e6c0c72a9b4ab02c39368a802e19d5c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'fieldSettings' => [$this, 'block_fieldSettings'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_includes/forms/fld/field-settings.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/fld/custom-field-settings.twig");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_includes/forms/fld/custom-field-settings.twig", 2)->unwrap();
        // line 4
        $context["originalField"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", [], "any", false, false, false, 4), "fields", [], "any", false, false, false, 4), "getFieldByUid", [craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 4, $this->source); })()), "getField", [], "method", false, false, false, 4), "uid", [], "any", false, false, false, 4)], "method", false, false, false, 4);
        // line 1
        $this->parent = $this->loadTemplate("_includes/forms/fld/field-settings.twig", "_includes/forms/fld/custom-field-settings.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_includes/forms/fld/custom-field-settings.twig");
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_fieldSettings(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "fieldSettings");
        // line 7
        yield "  ";
        if ((isset($context["originalField"]) || array_key_exists("originalField", $context) ? $context["originalField"] : (function () { throw new RuntimeError('Variable "originalField" does not exist.', 7, $this->source); })())) {
            // line 8
            yield "    ";
            $context["fieldChipId"] = ("chip" . Twig\Extension\CoreExtension::random($this->env->getCharset()));
            // line 9
            yield "    <div class=\"pane no-border p-m\">
      ";
            // line 10
            yield craft\helpers\Cp::chipHtml((isset($context["originalField"]) || array_key_exists("originalField", $context) ? $context["originalField"] : (function () { throw new RuntimeError('Variable "originalField" does not exist.', 10, $this->source); })()), ["id" =>             // line 11
(isset($context["fieldChipId"]) || array_key_exists("fieldChipId", $context) ? $context["fieldChipId"] : (function () { throw new RuntimeError('Variable "fieldChipId" does not exist.', 11, $this->source); })()), "class" => "hairline", "showActionMenu" => true, "showHandle" => true, "hyperlink" => false]);
            // line 16
            yield "
    </div>

    ";
            // line 19
            ob_start();
            // line 20
            yield "      (() => {
        const \$chip = \$('#";
            // line 21
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["fieldChipId"]) || array_key_exists("fieldChipId", $context) ? $context["fieldChipId"] : (function () { throw new RuntimeError('Variable "fieldChipId" does not exist.', 21, $this->source); })())), "html", null, true);
            yield "');
        \$chip.on('dblclick taphold', (ev) => {
          \$chip.find('.btn').data('disclosureMenu').\$container.find('[data-edit-action]').click();
        });
      })();
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
            // line 27
            yield "  ";
        }
        // line 28
        yield "
  ";
        // line 29
        yield from         $this->unwrap()->yieldBlock("labelField", $context, $blocks);
        yield "

  ";
        // line 31
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 31, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 39
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 39, $this->source); })()), "handle", [], "any", false, false, false, 39), "placeholder" =>         // line 40
(isset($context["defaultHandle"]) || array_key_exists("defaultHandle", $context) ? $context["defaultHandle"] : (function () { throw new RuntimeError('Variable "defaultHandle" does not exist.', 40, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 41
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 41, $this->source); })()), "getErrors", ["handle"], "method", false, false, false, 41), "required" => true, "data" => ["error-key" => "handle"]]]);
        // line 46
        yield "

  ";
        // line 48
        yield from         $this->unwrap()->yieldBlock("instructionsField", $context, $blocks);
        yield "
  ";
        // line 49
        yield from         $this->unwrap()->yieldBlock("tipField", $context, $blocks);
        yield "
  ";
        // line 50
        yield from         $this->unwrap()->yieldBlock("warningField", $context, $blocks);
        yield "
";
        craft\helpers\Template::endProfile("block", "fieldSettings");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/fld/custom-field-settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  125 => 50,  121 => 49,  117 => 48,  113 => 46,  111 => 41,  110 => 40,  109 => 39,  108 => 31,  103 => 29,  100 => 28,  97 => 27,  88 => 21,  85 => 20,  83 => 19,  78 => 16,  76 => 11,  75 => 10,  72 => 9,  69 => 8,  66 => 7,  58 => 6,  52 => 1,  50 => 4,  48 => 2,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '_includes/forms/fld/field-settings.twig' %}
{% import '_includes/forms' as forms %}

{% set originalField = craft.app.fields.getFieldByUid(field.getField().uid) %}

{% block fieldSettings %}
  {% if originalField %}
    {% set fieldChipId = \"chip#{random()}\" %}
    <div class=\"pane no-border p-m\">
      {{ chip(originalField, {
        id: fieldChipId,
        class: 'hairline',
        showActionMenu: true,
        showHandle: true,
        hyperlink: false,
      }) }}
    </div>

    {% js %}
      (() => {
        const \$chip = \$('#{{ fieldChipId|namespaceInputId }}');
        \$chip.on('dblclick taphold', (ev) => {
          \$chip.find('.btn').data('disclosureMenu').\$container.find('[data-edit-action]').click();
        });
      })();
    {% endjs %}
  {% endif %}

  {{ block('labelField') }}

  {{ forms.textField({
    label: 'Handle'|t('app'),
    id: 'handle',
    name: 'handle',
    class: 'code',
    autocorrect: false,
    autocapitalize: false,
    maxlength: 64,
    value: field.handle,
    placeholder: defaultHandle,
    errors: field.getErrors('handle'),
    required: true,
    data: {
      'error-key': 'handle'
    },
  }) }}

  {{ block('instructionsField') }}
  {{ block('tipField') }}
  {{ block('warningField') }}
{% endblock %}
", "_includes/forms/fld/custom-field-settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/fld/custom-field-settings.twig");
    }
}
