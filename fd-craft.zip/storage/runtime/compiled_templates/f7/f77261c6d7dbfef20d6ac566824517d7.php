<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* navigation/_types/custom/modal */
class __TwigTemplate_cc51d8f1d5fef97e0c1b3a95a0204db6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "navigation/_types/custom/modal");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "navigation/_types/custom/modal", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 3, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("URL", "navigation"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The URL for this navigation item.", "navigation"), "id" => "url", "name" => "url", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 8
(isset($context["node"]) || array_key_exists("node", $context) ? $context["node"] : (function () { throw new RuntimeError('Variable "node" does not exist.', 8, $this->source); })()), "getRawUrl", [], "method", false, false, false, 8)]]);
        craft\helpers\Template::endProfile("template", "navigation/_types/custom/modal");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "navigation/_types/custom/modal";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  49 => 8,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms' as forms %}

{{ forms.textField({
    label: 'URL' | t('navigation'),
    instructions: 'The URL for this navigation item.' | t('navigation'),
    id: 'url',
    name: 'url',
    value: node.getRawUrl(),
}) }}", "navigation/_types/custom/modal", "/var/www/html/vendor/verbb/navigation/src/templates/_types/custom/modal.html");
    }
}
