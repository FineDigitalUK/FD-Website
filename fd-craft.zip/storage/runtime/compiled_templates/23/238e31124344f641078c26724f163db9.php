<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/elementSelect.twig */
class __TwigTemplate_299d3077a12ed43a02e21f84256cd97b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/elementSelect.twig");
        // line 1
        $context["name"] = (($context["name"]) ?? (false));
        // line 2
        if ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 2, $this->source); })())) {
            // line 3
            yield "    ";
            yield craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 3, $this->source); })()), "");
            yield "
";
        }
        // line 6
        $context["id"] = (($context["id"]) ?? (("elementselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 7
        $context["elements"] = (($context["elements"]) ?? ([]));
        // line 8
        $context["jsClass"] = (($context["jsClass"]) ?? ("Craft.BaseElementSelectInput"));
        // line 9
        $context["sources"] = (($context["sources"]) ?? (null));
        // line 10
        $context["condition"] = (($context["condition"]) ?? (null));
        // line 11
        $context["criteria"] = (($context["criteria"]) ?? (null));
        // line 12
        $context["searchCriteria"] = (($context["searchCriteria"]) ?? (null));
        // line 13
        $context["sourceElementId"] = (($context["sourceElementId"]) ?? (null));
        // line 14
        $context["storageKey"] = (($context["storageKey"]) ?? (null));
        // line 15
        $context["defaultPlacement"] = (($context["defaultPlacement"]) ?? ("end"));
        // line 16
        $context["viewMode"] = (($context["viewMode"]) ?? ("list"));
        // line 17
        $context["prevalidate"] = (($context["prevalidate"]) ?? (false));
        // line 18
        $context["fieldId"] = (($context["fieldId"]) ?? (null));
        // line 19
        $context["single"] = (($context["single"]) ?? (false));
        // line 20
        $context["limit"] = (((isset($context["single"]) || array_key_exists("single", $context) ? $context["single"] : (function () { throw new RuntimeError('Variable "single" does not exist.', 20, $this->source); })())) ? (1) : ((($context["limit"]) ?? (null))));
        // line 21
        $context["showActionMenu"] = (($context["showActionMenu"]) ?? (true));
        // line 22
        $context["sortable"] = (( !(isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 22, $this->source); })()) || ((isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 22, $this->source); })()) > 1)) && (($context["sortable"]) ?? (true)));
        // line 23
        $context["disabled"] = (((($context["disabled"]) ?? (false))) ? (true) : (false));
        // line 24
        $context["maintainHierarchy"] = (($context["maintainHierarchy"]) ?? (false));
        // line 25
        $context["registerJs"] = (($context["registerJs"]) ?? (true));
        // line 26
        yield "
";
        // line 27
        $context["allowAdd"] = (($context["allowAdd"]) ?? (true));
        // line 28
        $context["allowRemove"] = (($context["allowRemove"]) ?? (true));
        // line 29
        yield "
";
        // line 30
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>         // line 31
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 31, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["elementselect"], craft\helpers\Html::explodeClass(((        // line 32
$context["class"]) ?? ([]))))], ((        // line 33
$context["containerAttributes"]) ?? ([])), true);
        // line 34
        yield "
";
        // line 35
        $context["modalSettings"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["modalTitle" => ((        // line 36
$context["selectionLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app")))], ((        // line 37
$context["modalSettings"]) ?? ([])), true);
        // line 39
        if (        $this->unwrap()->hasBlock("attr", $context, $blocks)) {
            // line 40
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 40, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 42
        yield "
";
        // line 43
        $macros["_v0"] = $this->macros["_v0"] = $this->loadTemplate("_includes/forms", "_includes/forms/elementSelect.twig", 43)->unwrap();
        // line 44
        yield "
";
        // line 45
        ob_start();
        // line 46
        yield "    ";
        if ((isset($context["maintainHierarchy"]) || array_key_exists("maintainHierarchy", $context) ? $context["maintainHierarchy"] : (function () { throw new RuntimeError('Variable "maintainHierarchy" does not exist.', 46, $this->source); })())) {
            // line 47
            yield "        ";
            yield Twig\Extension\CoreExtension::include($this->env, $context, "_elements/structurelist.twig", ["id" =>             // line 48
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 48, $this->source); })()), "elements" =>             // line 49
(isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 49, $this->source); })()), "context" => "field", "sortable" => false]);
            // line 52
            yield "
    ";
        } elseif ((        // line 53
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 53, $this->source); })()) == "cards")) {
            // line 54
            yield "        ";
            yield Twig\Extension\CoreExtension::include($this->env, $context, "_elements/cards.twig", ["elements" =>             // line 55
(isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 55, $this->source); })()), "viewMode" =>             // line 56
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 56, $this->source); })()), "showInGrid" => ((            // line 57
$context["showCardsInGrid"]) ?? (false)), "disabled" =>             // line 58
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 58, $this->source); })()), "context" => "field", "sortable" => false]);
            // line 61
            yield "
    ";
        } else {
            // line 63
            yield "        ";
            yield Twig\Extension\CoreExtension::include($this->env, $context, "_elements/list.twig", ["elements" =>             // line 64
(isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 64, $this->source); })()), "viewMode" =>             // line 65
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 65, $this->source); })()), "disabled" =>             // line 66
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 66, $this->source); })()), "context" => "field", "sortable" => false]);
            // line 69
            yield "
    ";
        }
        // line 71
        yield "
    <div class=\"flex\">
        ";
        // line 73
        if ((isset($context["allowAdd"]) || array_key_exists("allowAdd", $context) ? $context["allowAdd"] : (function () { throw new RuntimeError('Variable "allowAdd" does not exist.', 73, $this->source); })())) {
            // line 74
            yield "            ";
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["type" => "button", "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["btn", "add", "icon", "dashed", "wrap", ((            // line 82
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 82, $this->source); })())) ? ("disabled") : ("")), (((            // line 83
(isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 83, $this->source); })()) && ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 83, $this->source); })())) >= (isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 83, $this->source); })())))) ? ("hidden") : (""))]), "text" => ((            // line 85
$context["selectionLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"))), "disabled" =>             // line 86
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 86, $this->source); })()), "aria" => ["label" => ((            // line 88
$context["selectionLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"))), "describedby" => ((            // line 89
$context["describedBy"]) ?? (false))]]);
            // line 91
            yield "
            ";
            // line 92
            if ((isset($context["searchCriteria"]) || array_key_exists("searchCriteria", $context) ? $context["searchCriteria"] : (function () { throw new RuntimeError('Variable "searchCriteria" does not exist.', 92, $this->source); })())) {
                // line 93
                yield "                <div class=\"texticon search icon elementselect__search-input-wrapper\">
                    ";
                // line 94
                yield $macros["_v0"]->getTemplateForMacro("macro_text", $context, 94, $this->getSourceContext())->macro_text(...[["width" => "auto", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Search", "app"), "describedBy" => ((                // line 97
$context["describedBy"]) ?? (false)), "role" => "combobox", "labelledBy" => ((                // line 99
$context["labelId"]) ?? (false))]]);
                // line 100
                yield "
                    <div class=\"spinner hidden\"></div>
                </div>
            ";
            }
            // line 104
            yield "        ";
        }
        // line 105
        yield "        <div class=\"spinner hidden\"></div>
    </div>
";
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 45
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 45, $this->source); })()));
        // line 108
        yield "
";
        // line 109
        if (( !(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 109, $this->source); })()) && (isset($context["registerJs"]) || array_key_exists("registerJs", $context) ? $context["registerJs"] : (function () { throw new RuntimeError('Variable "registerJs" does not exist.', 109, $this->source); })()))) {
            // line 110
            yield "    ";
            $context["jsSettings"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => $this->env->getFilter('namespaceInputId')->getCallable()(            // line 111
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 111, $this->source); })())), "name" => ((            // line 112
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 112, $this->source); })())) ? ($this->env->getFilter('namespaceInputName')->getCallable()((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 112, $this->source); })()))) : (null)), "elementType" =>             // line 113
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 113, $this->source); })()), "sources" =>             // line 114
(isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 114, $this->source); })()), "condition" => ((            // line 115
(isset($context["condition"]) || array_key_exists("condition", $context) ? $context["condition"] : (function () { throw new RuntimeError('Variable "condition" does not exist.', 115, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["condition"]) || array_key_exists("condition", $context) ? $context["condition"] : (function () { throw new RuntimeError('Variable "condition" does not exist.', 115, $this->source); })()), "getConfig", [], "method", false, false, false, 115)) : (null)), "referenceElementId" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 116
($context["referenceElement"] ?? null), "id", [], "any", true, true, false, 116) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["referenceElement"] ?? null), "id", [], "any", false, false, false, 116)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["referenceElement"] ?? null), "id", [], "any", false, false, false, 116)) : (null)), "referenceElementOwnerId" => (($this->env->getTest('instance of')->getCallable()(((            // line 117
$context["referenceElement"]) ?? (null)), "craft\\base\\NestedElementInterface")) ? (craft\helpers\Template::attribute($this->env, $this->source,             // line 118
(isset($context["referenceElement"]) || array_key_exists("referenceElement", $context) ? $context["referenceElement"] : (function () { throw new RuntimeError('Variable "referenceElement" does not exist.', 118, $this->source); })()), "getOwnerId", [], "method", false, false, false, 118)) : (null)), "referenceElementSiteId" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 120
($context["referenceElement"] ?? null), "siteId", [], "any", true, true, false, 120) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["referenceElement"] ?? null), "siteId", [], "any", false, false, false, 120)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["referenceElement"] ?? null), "siteId", [], "any", false, false, false, 120)) : (null)), "criteria" =>             // line 121
(isset($context["criteria"]) || array_key_exists("criteria", $context) ? $context["criteria"] : (function () { throw new RuntimeError('Variable "criteria" does not exist.', 121, $this->source); })()), "searchCriteria" =>             // line 122
(isset($context["searchCriteria"]) || array_key_exists("searchCriteria", $context) ? $context["searchCriteria"] : (function () { throw new RuntimeError('Variable "searchCriteria" does not exist.', 122, $this->source); })()), "allowAdd" =>             // line 123
(isset($context["allowAdd"]) || array_key_exists("allowAdd", $context) ? $context["allowAdd"] : (function () { throw new RuntimeError('Variable "allowAdd" does not exist.', 123, $this->source); })()), "allowRemove" =>             // line 124
(isset($context["allowRemove"]) || array_key_exists("allowRemove", $context) ? $context["allowRemove"] : (function () { throw new RuntimeError('Variable "allowRemove" does not exist.', 124, $this->source); })()), "allowSelfRelations" => ((            // line 125
$context["allowSelfRelations"]) ?? (false)), "maintainHierarchy" =>             // line 126
(isset($context["maintainHierarchy"]) || array_key_exists("maintainHierarchy", $context) ? $context["maintainHierarchy"] : (function () { throw new RuntimeError('Variable "maintainHierarchy" does not exist.', 126, $this->source); })()), "branchLimit" => ((            // line 127
$context["branchLimit"]) ?? (null)), "sourceElementId" =>             // line 128
(isset($context["sourceElementId"]) || array_key_exists("sourceElementId", $context) ? $context["sourceElementId"] : (function () { throw new RuntimeError('Variable "sourceElementId" does not exist.', 128, $this->source); })()), "disabledElementIds" => ((            // line 129
$context["disabledElementIds"]) ?? (null)), "defaultPlacement" =>             // line 130
(isset($context["defaultPlacement"]) || array_key_exists("defaultPlacement", $context) ? $context["defaultPlacement"] : (function () { throw new RuntimeError('Variable "defaultPlacement" does not exist.', 130, $this->source); })()), "viewMode" =>             // line 131
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 131, $this->source); })()), "single" =>             // line 132
(isset($context["single"]) || array_key_exists("single", $context) ? $context["single"] : (function () { throw new RuntimeError('Variable "single" does not exist.', 132, $this->source); })()), "limit" =>             // line 133
(isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 133, $this->source); })()), "showSiteMenu" => ((            // line 134
$context["showSiteMenu"]) ?? (false)), "modalStorageKey" =>             // line 135
(isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 135, $this->source); })()), "fieldId" =>             // line 136
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 136, $this->source); })()), "sortable" =>             // line 137
(isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 137, $this->source); })()), "showActionMenu" =>             // line 138
(isset($context["showActionMenu"]) || array_key_exists("showActionMenu", $context) ? $context["showActionMenu"] : (function () { throw new RuntimeError('Variable "showActionMenu" does not exist.', 138, $this->source); })()), "prevalidate" =>             // line 139
(isset($context["prevalidate"]) || array_key_exists("prevalidate", $context) ? $context["prevalidate"] : (function () { throw new RuntimeError('Variable "prevalidate" does not exist.', 139, $this->source); })()), "modalSettings" => ((            // line 140
$context["modalSettings"]) ?? ([]))], ((            // line 141
$context["jsSettings"]) ?? ([])));
            // line 142
            yield "
    ";
            // line 143
            ob_start();
            // line 144
            yield "        new ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 144, $this->source); })()), "html", null, true);
            yield "(";
            yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["jsSettings"]) || array_key_exists("jsSettings", $context) ? $context["jsSettings"] : (function () { throw new RuntimeError('Variable "jsSettings" does not exist.', 144, $this->source); })()));
            yield ");
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/elementSelect.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/elementSelect.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  249 => 144,  247 => 143,  244 => 142,  242 => 141,  241 => 140,  240 => 139,  239 => 138,  238 => 137,  237 => 136,  236 => 135,  235 => 134,  234 => 133,  233 => 132,  232 => 131,  231 => 130,  230 => 129,  229 => 128,  228 => 127,  227 => 126,  226 => 125,  225 => 124,  224 => 123,  223 => 122,  222 => 121,  221 => 120,  220 => 118,  219 => 117,  218 => 116,  217 => 115,  216 => 114,  215 => 113,  214 => 112,  213 => 111,  211 => 110,  209 => 109,  206 => 108,  204 => 45,  200 => 105,  197 => 104,  191 => 100,  189 => 99,  188 => 97,  187 => 94,  184 => 93,  182 => 92,  179 => 91,  177 => 89,  176 => 88,  175 => 86,  174 => 85,  173 => 83,  172 => 82,  170 => 74,  168 => 73,  164 => 71,  160 => 69,  158 => 66,  157 => 65,  156 => 64,  154 => 63,  150 => 61,  148 => 58,  147 => 57,  146 => 56,  145 => 55,  143 => 54,  141 => 53,  138 => 52,  136 => 49,  135 => 48,  133 => 47,  130 => 46,  128 => 45,  125 => 44,  123 => 43,  120 => 42,  117 => 40,  115 => 39,  113 => 37,  112 => 36,  111 => 35,  108 => 34,  106 => 33,  105 => 32,  104 => 31,  103 => 30,  100 => 29,  98 => 28,  96 => 27,  93 => 26,  91 => 25,  89 => 24,  87 => 23,  85 => 22,  83 => 21,  81 => 20,  79 => 19,  77 => 18,  75 => 17,  73 => 16,  71 => 15,  69 => 14,  67 => 13,  65 => 12,  63 => 11,  61 => 10,  59 => 9,  57 => 8,  55 => 7,  53 => 6,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set name = name ?? false %}
{% if name %}
    {{ hiddenInput(name, '') }}
{% endif -%}

{% set id = id ?? \"elementselect#{random()}\" -%}
{% set elements = elements ?? [] -%}
{% set jsClass = jsClass ?? 'Craft.BaseElementSelectInput' -%}
{% set sources = sources ?? null -%}
{% set condition = condition ?? null -%}
{% set criteria = criteria ?? null -%}
{% set searchCriteria = searchCriteria ?? null %}
{% set sourceElementId = sourceElementId ?? null -%}
{% set storageKey = storageKey ?? null -%}
{% set defaultPlacement = defaultPlacement ?? 'end' %}
{% set viewMode = viewMode ?? 'list' %}
{% set prevalidate = prevalidate ?? false %}
{% set fieldId = fieldId ?? null %}
{% set single = single ?? false %}
{% set limit = single ? 1 : (limit ?? null) %}
{% set showActionMenu = showActionMenu ?? true %}
{% set sortable = (not limit or limit > 1) and (sortable ?? true) %}
{% set disabled = (disabled ?? false) ? true : false %}
{% set maintainHierarchy = maintainHierarchy ?? false %}
{% set registerJs = registerJs ?? true %}

{% set allowAdd = allowAdd ?? true %}
{% set allowRemove = allowRemove ?? true %}

{% set containerAttributes = {
    id: id,
    class: ['elementselect']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{% set modalSettings = {
    modalTitle: selectionLabel ?? 'Choose'|t('app'),
}|merge(modalSettings ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% from \"_includes/forms\" import text %}

{% tag 'div' with containerAttributes %}
    {% if maintainHierarchy %}
        {{ include('_elements/structurelist.twig', {
            id,
            elements,
            context: 'field',
            sortable: false,
        }) }}
    {% elseif viewMode == 'cards' %}
        {{ include('_elements/cards.twig', {
            elements,
            viewMode,
            showInGrid: showCardsInGrid ?? false,
            disabled,
            context: 'field',
            sortable: false,
        }) }}
    {% else %}
        {{ include('_elements/list.twig', {
            elements,
            viewMode,
            disabled,
            context: 'field',
            sortable: false,
        }) }}
    {% endif %}

    <div class=\"flex\">
        {% if allowAdd %}
            {{ tag('button', {
                type: 'button',
                class: [
                    'btn',
                    'add',
                    'icon',
                    'dashed',
                    'wrap',
                    disabled ? 'disabled',
                    limit and elements|length >= limit ? 'hidden',
                ]|filter,
                text: selectionLabel ?? 'Choose'|t('app'),
                disabled: disabled,
                aria: {
                    label: selectionLabel ?? 'Choose'|t('app'),
                    describedby: describedBy ?? false,
                }
            }) }}
            {% if searchCriteria %}
                <div class=\"texticon search icon elementselect__search-input-wrapper\">
                    {{ text({
                        width: 'auto',
                        placeholder: 'Search'|t('app'),
                        describedBy: describedBy ?? false,
                        role: 'combobox',
                        labelledBy: labelId ?? false,
                    }) }}
                    <div class=\"spinner hidden\"></div>
                </div>
            {% endif %}
        {% endif %}
        <div class=\"spinner hidden\"></div>
    </div>
{% endtag %}

{% if not disabled and registerJs %}
    {% set jsSettings = {
        id: id|namespaceInputId,
        name: name ? name|namespaceInputName : null,
        elementType: elementType,
        sources: sources,
        condition: condition ? condition.getConfig() : null,
        referenceElementId: referenceElement.id ?? null,
        referenceElementOwnerId: (referenceElement ?? null) is instance of('craft\\\\base\\\\NestedElementInterface')
            ? referenceElement.getOwnerId()
            : null,
        referenceElementSiteId: referenceElement.siteId ?? null,
        criteria: criteria,
        searchCriteria,
        allowAdd: allowAdd,
        allowRemove: allowRemove,
        allowSelfRelations: allowSelfRelations ?? false,
        maintainHierarchy: maintainHierarchy,
        branchLimit: branchLimit ?? null,
        sourceElementId: sourceElementId,
        disabledElementIds: disabledElementIds ?? null,
        defaultPlacement,
        viewMode: viewMode,
        single: single,
        limit: limit,
        showSiteMenu: showSiteMenu ?? false,
        modalStorageKey: storageKey,
        fieldId: fieldId,
        sortable: sortable,
        showActionMenu: showActionMenu,
        prevalidate: prevalidate,
        modalSettings: modalSettings ?? {},
    }|merge(jsSettings ?? {}) %}

    {% js %}
        new {{ jsClass }}({{ jsSettings|json_encode|raw }});
    {% endjs %}
{% endif %}
", "_includes/forms/elementSelect.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/elementSelect.twig");
    }
}
