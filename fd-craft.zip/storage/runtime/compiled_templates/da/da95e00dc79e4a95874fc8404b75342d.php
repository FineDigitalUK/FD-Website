<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/autosuggest */
class __TwigTemplate_c64a98d2315828d5af2f3acc4df24808 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'data' => [$this, 'block_data'],
            'methods' => [$this, 'block_methods'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/autosuggest");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "_includes/forms/autosuggest", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 3, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\vue\\VueAsset"], "method", false, false, false, 3);
        // line 4
        yield "
";
        // line 5
        $context["suggestions"] = $this->extensions['craft\web\twig\Extension']->mergeFilter($this->extensions['craft\web\twig\Extension']->mergeFilter((($context["suggestions"]) ?? ([])), ((((        // line 6
$context["suggestTemplates"]) ?? (false))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "cp", [], "any", false, false, false, 6), "getTemplateSuggestions", [], "method", false, false, false, 6)) : ([]))), ((((        // line 7
$context["suggestEnvVars"]) ?? (false))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 7, $this->source); })()), "cp", [], "any", false, false, false, 7), "getEnvSuggestions", [((        // line 8
$context["suggestAliases"]) ?? (false)), ((        // line 9
$context["suggestionFilter"]) ?? (null))], "method", false, false, false, 7)) : ([])));
        // line 12
        $context["id"] = (($context["id"]) ?? (("autosuggest" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 13
        $context["previewInputId"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 13, $this->source); })()) . "-preview");
        // line 14
        $context["containerId"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 14, $this->source); })()) . "-container");
        // line 15
        $context["autosuggestId"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 15, $this->source); })()) . "-autosuggest");
        // line 16
        $context["describedBy"] = (($context["describedBy"]) ?? (null));
        // line 17
        $context["labelledBy"] = (($context["labelledBy"]) ?? (null));
        // line 19
        $context["class"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["text", (( !((        // line 21
$context["size"]) ?? (false))) ? ("fullwidth") : (null))]));
        // line 23
        yield "
<div id=\"";
        // line 24
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["containerId"]) || array_key_exists("containerId", $context) ? $context["containerId"] : (function () { throw new RuntimeError('Variable "containerId" does not exist.', 24, $this->source); })()), "html", null, true);
        yield "\" class=\"autosuggest-container\">
    ";
        // line 25
        yield $macros["forms"]->getTemplateForMacro("macro_text", $context, 25, $this->getSourceContext())->macro_text(...[["id" =>         // line 26
(isset($context["previewInputId"]) || array_key_exists("previewInputId", $context) ? $context["previewInputId"] : (function () { throw new RuntimeError('Variable "previewInputId" does not exist.', 26, $this->source); })()), "class" => Twig\Extension\CoreExtension::join(        // line 27
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 27, $this->source); })()), " "), "value" => ((        // line 28
$context["value"]) ?? ("")), "style" => ((        // line 29
$context["style"]) ?? ("")), "size" => ((        // line 30
$context["size"]) ?? ("")), "disabled" => true, "title" => ((        // line 32
$context["title"]) ?? ("")), "placeholder" => ((        // line 33
$context["placeholder"]) ?? (""))]]);
        // line 34
        yield "

    ";
        // line 54
        yield "
    <vue-autosuggest
        :suggestions=\"filteredOptions\"
        :get-suggestion-value=\"getSuggestionValue\"
        :input-props=\"inputProps\"
        :limit=\"limit\"
        :component-attr-id-autosuggest=\"id\"
        @selected=\"onSelected\"
        @focus=\"updateFilteredOptions\"
        @blur=\"onBlur\"
        @input=\"onInputChange\"
        v-model=\"inputProps.initialValue\"
    >
        <template slot-scope=\"{suggestion}\">
            {{suggestion.item.name || suggestion.item}}
            <span v-if=\"suggestion.item.hint\" class=\"light\">– {{suggestion.item.hint}}</span>
        </template>
    </vue-autosuggest>
    ";
        yield "
</div>

";
        // line 57
        ob_start();
        // line 58
        yield "(() => {
\$(\"#";
        // line 59
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["previewInputId"]) || array_key_exists("previewInputId", $context) ? $context["previewInputId"] : (function () { throw new RuntimeError('Variable "previewInputId" does not exist.', 59, $this->source); })())), "js"), "html", null, true);
        yield "\").remove();

new Vue({
    el: \"#";
        // line 62
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["containerId"]) || array_key_exists("containerId", $context) ? $context["containerId"] : (function () { throw new RuntimeError('Variable "containerId" does not exist.', 62, $this->source); })())), "js"), "html", null, true);
        yield "\",

    data() {
        ";
        // line 65
        yield from $this->unwrap()->yieldBlock('data', $context, $blocks);
        // line 90
        yield "        return data;
    },

    methods: {
        ";
        // line 94
        yield from $this->unwrap()->yieldBlock('methods', $context, $blocks);
        // line 172
        yield "    }
});
})();
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_includes/forms/autosuggest");
        yield from [];
    }

    // line 65
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_data(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "data");
        // line 66
        yield "        var data = ";
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(["query" => Twig\Extension\CoreExtension::lower($this->env->getCharset(), ((        // line 67
$context["value"]) ?? (""))), "selected" => "", "filteredOptions" => [], "suggestions" =>         // line 70
(isset($context["suggestions"]) || array_key_exists("suggestions", $context) ? $context["suggestions"] : (function () { throw new RuntimeError('Variable "suggestions" does not exist.', 70, $this->source); })()), "id" =>         // line 71
(isset($context["autosuggestId"]) || array_key_exists("autosuggestId", $context) ? $context["autosuggestId"] : (function () { throw new RuntimeError('Variable "autosuggestId" does not exist.', 71, $this->source); })()), "inputProps" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => Twig\Extension\CoreExtension::join(        // line 73
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 73, $this->source); })()), " "), "initialValue" => ((        // line 74
$context["value"]) ?? ("")), "style" => ((        // line 75
$context["style"]) ?? ("")), "id" => $this->env->getFilter('namespaceInputId')->getCallable()(        // line 76
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 76, $this->source); })())), "name" => $this->env->getFilter('namespaceInputName')->getCallable()(((        // line 77
$context["name"]) ?? (""))), "size" => ((        // line 78
$context["size"]) ?? ("")), "maxlength" => ((        // line 79
$context["maxlength"]) ?? ("")), "autofocus" => (((((        // line 80
$context["autofocus"]) ?? (false)) && (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 80, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 80, $this->source); })()), "getAutofocusPreferred", [], "method", false, false, false, 80)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 80, $this->source); })()), "app", [], "any", false, false, false, 80), "request", [], "any", false, false, false, 80), "isMobileBrowser", [true], "method", false, false, false, 80)), "disabled" => ((        // line 81
$context["disabled"]) ?? (false)), "title" => ((        // line 82
$context["title"]) ?? ("")), "placeholder" => ((        // line 83
$context["placeholder"]) ?? ("")), "aria-describedby" => ((        // line 84
(isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 84, $this->source); })())) ? (Twig\Extension\CoreExtension::join($this->extensions['craft\web\twig\Extension']->mapFilter($this->env, Twig\Extension\CoreExtension::split($this->env->getCharset(), (isset($context["describedBy"]) || array_key_exists("describedBy", $context) ? $context["describedBy"] : (function () { throw new RuntimeError('Variable "describedBy" does not exist.', 84, $this->source); })()), " "), function ($__id__) use ($context, $macros) { $context["id"] = $__id__; return $this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 84, $this->source); })())); }), " ")) : (false)), "aria-labelledby" => ((        // line 85
(isset($context["labelledBy"]) || array_key_exists("labelledBy", $context) ? $context["labelledBy"] : (function () { throw new RuntimeError('Variable "labelledBy" does not exist.', 85, $this->source); })())) ? (Twig\Extension\CoreExtension::join($this->extensions['craft\web\twig\Extension']->mapFilter($this->env, Twig\Extension\CoreExtension::split($this->env->getCharset(), (isset($context["labelledBy"]) || array_key_exists("labelledBy", $context) ? $context["labelledBy"] : (function () { throw new RuntimeError('Variable "labelledBy" does not exist.', 85, $this->source); })()), " "), function ($__id__) use ($context, $macros) { $context["id"] = $__id__; return $this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 85, $this->source); })())); }), " ")) : (false))], ((        // line 86
$context["inputProps"]) ?? ((($context["inputAttributes"]) ?? ([])))), true)), "limit" => ((        // line 87
$context["limit"]) ?? (5))]);
        // line 88
        yield ";
        ";
        craft\helpers\Template::endProfile("block", "data");
        yield from [];
    }

    // line 94
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_methods(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "methods");
        // line 95
        yield "        onInputChange(q) {
            this.query = (q || '').toLowerCase();
            this.updateFilteredOptions();
        },
        updateFilteredOptions() {
            if (this.query === '') {
                this.filteredOptions = this.suggestions;
                return;
            }

            var filtered = [];
            var i, j, sectionFilter, item, name;
            var that = this;

            for (i = 0; i < this.suggestions.length; i++) {
                sectionFilter = [];
                for (j = 0; j < this.suggestions[i].data.length; j++) {
                    item = this.suggestions[i].data[j];
                    if (
                        (item.name || item).toLowerCase().indexOf(this.query) !== -1 ||
                        (item.hint && item.hint.toLowerCase().indexOf(this.query) !== -1)
                    ) {
                        sectionFilter.push(item.name ? item : {name: item});
                    }
                }
                if (sectionFilter.length) {
                    sectionFilter.sort(function(a, b) {
                        var scoreA = that.scoreItem(a, this.query);
                        var scoreB = that.scoreItem(b, this.query);
                        if (scoreA === scoreB) {
                            return 0;
                        }
                        return scoreA < scoreB ? 1 : -1;
                    });
                    filtered.push({
                        label: this.suggestions[i].label || null,
                        data: sectionFilter.slice(0, this.limit)
                    });
                }
            }

            this.filteredOptions = filtered;
        },
        scoreItem(item) {
            var score = 0;
            if (item.name.toLowerCase().indexOf(this.query) !== -1) {
                score += 100 + this.query.length / item.name.length;
            }
            if (item.hint && item.hint.toLowerCase().indexOf(this.query) !== -1) {
                score += this.query.length / item.hint.length;
            }
            return score;
        },
        onSelected(option) {
            if (!option) {
                return;
            }

            this.selected = option.item;

            // Bring focus back to the input if they selected an alias
            if (option.item.name[0] == '@') {
                var input = this.\$el.querySelector('input');
                input.focus();
                input.selectionStart = input.selectionEnd = input.value.length;
            }
        },
        getSuggestionValue(suggestion) {
            return suggestion.item.name || suggestion.item;
        },
        onBlur(e) {
            // Clear out the autosuggestions if the focus has shifted to a new element
            if (e.relatedTarget) {
                this.filteredOptions = [];
            }
        },
        ";
        craft\helpers\Template::endProfile("block", "methods");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/autosuggest";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  201 => 95,  193 => 94,  186 => 88,  184 => 87,  183 => 86,  182 => 85,  181 => 84,  180 => 83,  179 => 82,  178 => 81,  177 => 80,  176 => 79,  175 => 78,  174 => 77,  173 => 76,  172 => 75,  171 => 74,  170 => 73,  169 => 71,  168 => 70,  167 => 67,  165 => 66,  157 => 65,  147 => 172,  145 => 94,  139 => 90,  137 => 65,  131 => 62,  125 => 59,  122 => 58,  120 => 57,  96 => 54,  92 => 34,  90 => 33,  89 => 32,  88 => 30,  87 => 29,  86 => 28,  85 => 27,  84 => 26,  83 => 25,  79 => 24,  76 => 23,  74 => 21,  73 => 19,  71 => 17,  69 => 16,  67 => 15,  65 => 14,  63 => 13,  61 => 12,  59 => 9,  58 => 8,  57 => 7,  56 => 6,  55 => 5,  52 => 4,  50 => 3,  47 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms.twig' as forms %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\vue\\\\VueAsset\") %}

{% set suggestions = (suggestions ?? [])
    |merge((suggestTemplates ?? false) ? craft.cp.getTemplateSuggestions() : [])
    |merge((suggestEnvVars ?? false) ? craft.cp.getEnvSuggestions(
        suggestAliases ?? false,
        suggestionFilter ?? null
    ) : []) %}

{%- set id = id ?? \"autosuggest#{random()}\" %}
{%- set previewInputId = \"#{id}-preview\" %}
{%- set containerId = \"#{id}-container\" %}
{%- set autosuggestId = \"#{id}-autosuggest\" %}
{%- set describedBy = describedBy ?? null -%}
{%- set labelledBy = labelledBy ?? null -%}

{%- set class = (class ?? [])|explodeClass|merge([
    'text',
    not (size ?? false) ? 'fullwidth' : null,
]|filter) %}

<div id=\"{{ containerId }}\" class=\"autosuggest-container\">
    {{ forms.text({
        id: previewInputId,
        class: class|join(' '),
        value: value ?? '',
        style: style ?? '',
        size: size ?? '',
        disabled: true,
        title: title ?? '',
        placeholder: placeholder ?? '',
    }) }}

    {% verbatim %}
    <vue-autosuggest
        :suggestions=\"filteredOptions\"
        :get-suggestion-value=\"getSuggestionValue\"
        :input-props=\"inputProps\"
        :limit=\"limit\"
        :component-attr-id-autosuggest=\"id\"
        @selected=\"onSelected\"
        @focus=\"updateFilteredOptions\"
        @blur=\"onBlur\"
        @input=\"onInputChange\"
        v-model=\"inputProps.initialValue\"
    >
        <template slot-scope=\"{suggestion}\">
            {{suggestion.item.name || suggestion.item}}
            <span v-if=\"suggestion.item.hint\" class=\"light\">– {{suggestion.item.hint}}</span>
        </template>
    </vue-autosuggest>
    {% endverbatim %}
</div>

{% js %}
(() => {
\$(\"#{{ previewInputId|namespaceInputId|e('js') }}\").remove();

new Vue({
    el: \"#{{ containerId|namespaceInputId|e('js') }}\",

    data() {
        {% block data %}
        var data = {{ {
            query: (value ?? '')|lower,
            selected: '',
            filteredOptions: [],
            suggestions,
            id: autosuggestId,
            inputProps: {
                class: class|join(' '),
                initialValue: value ?? '',
                style: style ?? '',
                id: id|namespaceInputId,
                name: (name ?? '')|namespaceInputName,
                size: size ?? '',
                maxlength: maxlength ?? '',
                autofocus: (autofocus ?? false) and currentUser and currentUser.getAutofocusPreferred() and not craft.app.request.isMobileBrowser(true),
                disabled: disabled ?? false,
                title: title ?? '',
                placeholder: placeholder ?? '',
                'aria-describedby': describedBy ? describedBy|split(' ')|map(id => id|namespaceInputId)|join(' ') : false,
                'aria-labelledby': labelledBy ? labelledBy|split(' ')|map(id => id|namespaceInputId)|join(' ') : false,
            }|merge(inputProps ?? inputAttributes ?? [], recursive=true)|filter,
            limit: limit ?? 5
        }|json_encode|raw }};
        {% endblock %}
        return data;
    },

    methods: {
        {% block methods %}
        onInputChange(q) {
            this.query = (q || '').toLowerCase();
            this.updateFilteredOptions();
        },
        updateFilteredOptions() {
            if (this.query === '') {
                this.filteredOptions = this.suggestions;
                return;
            }

            var filtered = [];
            var i, j, sectionFilter, item, name;
            var that = this;

            for (i = 0; i < this.suggestions.length; i++) {
                sectionFilter = [];
                for (j = 0; j < this.suggestions[i].data.length; j++) {
                    item = this.suggestions[i].data[j];
                    if (
                        (item.name || item).toLowerCase().indexOf(this.query) !== -1 ||
                        (item.hint && item.hint.toLowerCase().indexOf(this.query) !== -1)
                    ) {
                        sectionFilter.push(item.name ? item : {name: item});
                    }
                }
                if (sectionFilter.length) {
                    sectionFilter.sort(function(a, b) {
                        var scoreA = that.scoreItem(a, this.query);
                        var scoreB = that.scoreItem(b, this.query);
                        if (scoreA === scoreB) {
                            return 0;
                        }
                        return scoreA < scoreB ? 1 : -1;
                    });
                    filtered.push({
                        label: this.suggestions[i].label || null,
                        data: sectionFilter.slice(0, this.limit)
                    });
                }
            }

            this.filteredOptions = filtered;
        },
        scoreItem(item) {
            var score = 0;
            if (item.name.toLowerCase().indexOf(this.query) !== -1) {
                score += 100 + this.query.length / item.name.length;
            }
            if (item.hint && item.hint.toLowerCase().indexOf(this.query) !== -1) {
                score += this.query.length / item.hint.length;
            }
            return score;
        },
        onSelected(option) {
            if (!option) {
                return;
            }

            this.selected = option.item;

            // Bring focus back to the input if they selected an alias
            if (option.item.name[0] == '@') {
                var input = this.\$el.querySelector('input');
                input.focus();
                input.selectionStart = input.selectionEnd = input.value.length;
            }
        },
        getSuggestionValue(suggestion) {
            return suggestion.item.name || suggestion.item;
        },
        onBlur(e) {
            // Clear out the autosuggestions if the focus has shifted to a new element
            if (e.relatedTarget) {
                this.filteredOptions = [];
            }
        },
        {% endblock %}
    }
});
})();
{% endjs %}
", "_includes/forms/autosuggest", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/autosuggest.twig");
    }
}
