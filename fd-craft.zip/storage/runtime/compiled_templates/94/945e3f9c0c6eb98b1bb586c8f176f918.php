<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* plugin-store/_index.twig */
class __TwigTemplate_8fe59d34e94a88c74fb622db719fa595 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "plugin-store/_index.twig");
        // line 3
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Plugin Store", "app");
        // line 42
        $context["content"] = new Markup("    <div id=\"app\"></div>
", $this->env->getCharset());
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "plugin-store/_index.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "plugin-store/_index.twig");
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 6
        yield "    <div id=\"pluginstore-actions-spinner\" class=\"spinner lg hidden\"></div>

    <div id=\"pluginstore-actions\" class=\"hidden\">

        <a id=\"cart-button\" role=\"button\" tabindex=\"0\">";
        // line 10
        yield craft\helpers\Cp::iconSvg("cart-shopping");
        yield " <span class=\"badge\">0</span></a>

        <a id=\"craftid-account\" class=\"menubtn hidden\"><span class=\"photo\">";
        // line 12
        yield $this->extensions['craft\web\twig\Extension']->svgFunction("@appicons/craftid.svg", null, true);
        yield "</span><span class=\"label\">Account</span></a>

        <div class=\"menu\">
            <ul>
                <li><a href=\"";
        // line 16
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 16, $this->source); })()), "cp", [], "any", false, false, false, 16), "craftIdAccountUrl", [], "method", false, false, false, 16), "html", null, true);
        yield "\" rel=\"noopener\" target=\"_blank\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Manage your Craft Console account", "app"), "html", null, true);
        yield "</a></li>
                ";
        // line 26
        yield "            </ul>
        </div>

        ";
        // line 39
        yield "    </div>
";
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "plugin-store/_index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  96 => 39,  91 => 26,  85 => 16,  78 => 12,  73 => 10,  67 => 6,  59 => 5,  53 => 1,  50 => 42,  48 => 3,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set title = 'Plugin Store'|t('app') %}

{% block actionButton %}
    <div id=\"pluginstore-actions-spinner\" class=\"spinner lg hidden\"></div>

    <div id=\"pluginstore-actions\" class=\"hidden\">

        <a id=\"cart-button\" role=\"button\" tabindex=\"0\">{{ iconSvg('cart-shopping') }} <span class=\"badge\">0</span></a>

        <a id=\"craftid-account\" class=\"menubtn hidden\"><span class=\"photo\">{{ svg('@appicons/craftid.svg', namespace=true) }}</span><span class=\"label\">Account</span></a>

        <div class=\"menu\">
            <ul>
                <li><a href=\"{{ craft.cp.craftIdAccountUrl() }}\" rel=\"noopener\" target=\"_blank\">{{ \"Manage your Craft Console account\"|t('app') }}</a></li>
                {#
                <li>
                    <form method=\"post\" id=\"disconnect\">
                        {{ csrfInput() }}
                        {{ actionInput('plugin-store/disconnect') }}
                        <a onclick=\"document.getElementById('disconnect').submit();\">Sign out from Craft Console</a>
                    </form>
                </li>
                #}
            </ul>
        </div>

        {#
        <form id=\"craftid-connect-form\" method=\"post\">
            {{ csrfInput() }}
            {{ actionInput('plugin-store/connect') }}
            <div class=\"ssl-status light\" title=\"{{ craft.app.request.isSecureConnection ? \"Your connection is secure\"|t('app') : \"Your connection is insecure\"|t('app') }}\" aria-label=\"{{ craft.app.request.isSecureConnection ? \"Your connection is secure\"|t('app') : \"Your connection is insecure\" }}\">
                <i class=\"{{ craft.app.request.isSecureConnection ? \"secure\" : \"insecure\" }} icon\"></i>
            </div>
            <a onclick=\"document.getElementById('craftid-connect-form').submit();\">Sign into Craft Console</a>
        </form>
        #}
    </div>
{% endblock %}

{% set content %}
    <div id=\"app\"></div>
{% endset %}
", "plugin-store/_index.twig", "/var/www/html/vendor/craftcms/cms/src/templates/plugin-store/_index.twig");
    }
}
