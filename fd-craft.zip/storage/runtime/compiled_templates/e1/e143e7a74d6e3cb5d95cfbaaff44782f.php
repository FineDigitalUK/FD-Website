<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/fields/_type-settings */
class __TwigTemplate_031e8375c502cdfb7170b255f67f9fc2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/fields/_type-settings");
        // line 1
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 2
        yield "
";
        // line 3
        $_namespace = (($context["namespace"]) ?? (null));
        if ($_namespace !== null && $_namespace !== '') {
            $_originalNamespace = Craft::$app->getView()->getNamespace();
            Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
            ob_start();
            try {
                // line 4
                yield "  ";
                // line 5
                yield "    ";
                yield (((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 5, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 5, $this->source); })()), "getReadOnlySettingsHtml", [], "method", false, false, false, 5)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 5, $this->source); })()), "getSettingsHtml", [], "method", false, false, false, 5)));
                yield "
  ";
            } catch (Exception $e) {
                ob_end_clean();

                throw $e;
            }
            echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
            Craft::$app->getView()->setNamespace($_originalNamespace);
        } else {
            // line 4
            yield "  ";
            // line 5
            yield "    ";
            yield (((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 5, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 5, $this->source); })()), "getReadOnlySettingsHtml", [], "method", false, false, false, 5)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 5, $this->source); })()), "getSettingsHtml", [], "method", false, false, false, 5)));
            yield "
  ";
        }
        unset($_originalNamespace, $_namespace);
        craft\helpers\Template::endProfile("template", "settings/fields/_type-settings");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/fields/_type-settings";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  72 => 5,  70 => 4,  57 => 5,  55 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set readOnly = readOnly ?? false %}

{% namespace namespace ?? null %}
  {% autoescape false %}
    {{ readOnly ? field.getReadOnlySettingsHtml() : field.getSettingsHtml() }}
  {% endautoescape %}
{% endnamespace %}
", "settings/fields/_type-settings", "/var/www/html/vendor/craftcms/cms/src/templates/settings/fields/_type-settings.twig");
    }
}
