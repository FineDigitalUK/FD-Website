<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/buttonGroup.twig */
class __TwigTemplate_de7cb73065d3b8ed812a0c0e4c2f1046 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/buttonGroup.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "_includes/forms/buttonGroup.twig", 1)->unwrap();
        // line 3
        $context["options"] = (($context["options"]) ?? ([]));
        // line 4
        $context["value"] = (($context["value"]) ?? (null));
        // line 5
        $context["disabled"] = (($context["disabled"]) ?? (false));
        // line 7
        $context["id"] = (($context["id"]) ?? (("button-group-" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 8
        $context["class"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["btngroup", "btngroup--exclusive"]));
        // line 13
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>         // line 14
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 14, $this->source); })()), "class" =>         // line 15
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 15, $this->source); })()), "aria" => ["labelledby" => ((        // line 17
$context["labelledBy"]) ?? (false))]], ((        // line 19
$context["containerAttributes"]) ?? ([])), true);
        // line 20
        yield "
<div class=\"btngroup-container\">
  ";
        // line 22
        ob_start();
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 23, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["option"]) {
            // line 24
            if ( !is_iterable($context["option"])) {
                // line 25
                $context["option"] = ["label" => $context["option"], "value" => $context["key"]];
            }
            // line 27
            yield "      ";
            $context["selected"] = (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", true, true, false, 27) && (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", false, false, false, 27) == (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 27, $this->source); })())));
            // line 28
            yield "      ";
            yield $macros["forms"]->getTemplateForMacro("macro_button", $context, 28, $this->getSourceContext())->macro_button(...[$this->extensions['craft\web\twig\Extension']->mergeFilter($context["option"], ["type" => "button", "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(((            // line 30
(isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 30, $this->source); })())) ? (["active"]) : ([])), craft\helpers\Html::explodeClass((((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "class", [], "any", true, true, false, 30) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "class", [], "any", false, false, false, 30)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "class", [], "any", false, false, false, 30)) : ([])))), "attributes" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["aria" => ["pressed" => ((            // line 33
(isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 33, $this->source); })())) ? ("true") : ("false"))], "data" => ["value" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 36
$context["option"], "value", [], "any", true, true, false, 36) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", false, false, false, 36)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", false, false, false, 36)) : (null))], "tabindex" => ((            // line 38
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 38, $this->source); })())) ? ("-1") : ("0"))], (((craft\helpers\Template::attribute($this->env, $this->source,             // line 39
$context["option"], "attributes", [], "any", true, true, false, 39) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "attributes", [], "any", false, false, false, 39)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "attributes", [], "any", false, false, false, 39)) : ([])), true), "readOnly" =>             // line 40
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 40, $this->source); })())])]);
            // line 41
            yield "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['key'], $context['option'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        yield "  ";
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 22
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 22, $this->source); })()));
        // line 44
        yield "</div>

";
        // line 46
        if ((($context["name"]) ?? (false))) {
            // line 47
            yield "  ";
            $context["inputId"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 47, $this->source); })()) . "-input");
            // line 48
            yield "  ";
            yield craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 48, $this->source); })()), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 48, $this->source); })()), ["id" =>             // line 49
(isset($context["inputId"]) || array_key_exists("inputId", $context) ? $context["inputId"] : (function () { throw new RuntimeError('Variable "inputId" does not exist.', 49, $this->source); })())]);
            // line 50
            yield "

  ";
            // line 52
            ob_start();
            // line 53
            yield "  (() => {
    new Craft.Listbox(\$('#";
            // line 54
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 54, $this->source); })())), "html", null, true);
            yield "'), {
      onChange: (selectedOption) => {
        \$('#";
            // line 56
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["inputId"]) || array_key_exists("inputId", $context) ? $context["inputId"] : (function () { throw new RuntimeError('Variable "inputId" does not exist.', 56, $this->source); })())), "html", null, true);
            yield "').val(selectedOption.data('value'));
      },
      readOnly: ";
            // line 58
            yield (((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 58, $this->source); })())) ? (1) : (0));
            yield "
    });
  })();
  ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/buttonGroup.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/buttonGroup.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  131 => 58,  126 => 56,  121 => 54,  118 => 53,  116 => 52,  112 => 50,  110 => 49,  108 => 48,  105 => 47,  103 => 46,  99 => 44,  97 => 22,  95 => 43,  88 => 41,  86 => 40,  85 => 39,  84 => 38,  83 => 36,  82 => 33,  81 => 30,  79 => 28,  76 => 27,  73 => 25,  71 => 24,  67 => 23,  65 => 22,  61 => 20,  59 => 19,  58 => 17,  57 => 15,  56 => 14,  55 => 13,  53 => 8,  51 => 7,  49 => 5,  47 => 4,  45 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms.twig' as forms %}

{%- set options = options ?? [] %}
{%- set value = value ?? null %}
{%- set disabled = disabled ?? false %}

{%- set id = id ?? \"button-group-#{random()}\" %}
{%- set class = (class ?? [])|explodeClass|merge([
  'btngroup',
  'btngroup--exclusive',
]|filter) %}

{%- set containerAttributes = {
  id,
  class,
  aria: {
    labelledby: labelledBy ?? false,
  },
}|merge(containerAttributes ?? [], recursive=true) %}

<div class=\"btngroup-container\">
  {% tag 'div' with containerAttributes %}
    {%- for key, option in options %}
      {%- if option is not iterable %}
        {%- set option = {label: option, value: key} %}
      {%- endif %}
      {% set selected = option.value is defined and option.value == value %}
      {{ forms.button(option|merge({
        type: 'button',
        class: (selected ? ['active'] : [])|merge((option.class ?? [])|explodeClass),
        attributes: {
          aria: {
            pressed: selected ? 'true' : 'false',
          },
          data: {
            value: option.value ?? null,
          },
          tabindex: disabled ? '-1' : '0',
        }|merge(option.attributes ?? {}, recursive=true),
        readOnly: disabled,
      })) }}
    {% endfor %}
  {% endtag %}
</div>

{% if name ?? false %}
  {% set inputId = \"#{id}-input\" %}
  {{ hiddenInput(name, value, {
    id: inputId,
  }) }}

  {% js %}
  (() => {
    new Craft.Listbox(\$('#{{ id|namespaceInputId }}'), {
      onChange: (selectedOption) => {
        \$('#{{ inputId|namespaceInputId }}').val(selectedOption.data('value'));
      },
      readOnly: {{ disabled ? 1 : 0 }}
    });
  })();
  {% endjs %}
{% endif %}
", "_includes/forms/buttonGroup.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/buttonGroup.twig");
    }
}
