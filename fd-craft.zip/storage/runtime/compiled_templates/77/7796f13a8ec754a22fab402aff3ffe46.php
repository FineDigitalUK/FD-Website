<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/fieldtypes/PlainText/input.twig */
class __TwigTemplate_1068bfbaf1def446689a63eee12af1f8 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/PlainText/input.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/PlainText/input.twig", 1)->unwrap();
        // line 3
        $context["disabled"] = (($context["disabled"]) ?? (false));
        // line 5
        $context["class"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["nicetext", ((craft\helpers\Template::attribute($this->env, $this->source,         // line 7
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 7, $this->source); })()), "code", [], "any", false, false, false, 7)) ? ("code") : ("")), (((craft\helpers\Template::attribute($this->env, $this->source,         // line 8
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 8, $this->source); })()), "uiMode", [], "any", false, false, false, 8) == "enlarged")) ? ("readable") : (""))]);
        // line 10
        yield "
";
        // line 11
        $context["config"] = ["id" => ((        // line 12
$context["id"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 12, $this->source); })()), "getInputId", [], "method", false, false, false, 12))), "describedBy" => craft\helpers\Template::attribute($this->env, $this->source,         // line 13
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 13, $this->source); })()), "describedBy", [], "any", false, false, false, 13), "name" =>         // line 14
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 14, $this->source); })()), "value" =>         // line 15
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 15, $this->source); })()), "class" =>         // line 16
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 16, $this->source); })()), "maxlength" => (( !        // line 17
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 17, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 17, $this->source); })()), "charLimit", [], "any", false, false, false, 17)) : ("")), "showCharsLeft" => true, "placeholder" =>         // line 19
(isset($context["placeholder"]) || array_key_exists("placeholder", $context) ? $context["placeholder"] : (function () { throw new RuntimeError('Variable "placeholder" does not exist.', 19, $this->source); })()), "required" => craft\helpers\Template::attribute($this->env, $this->source,         // line 20
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 20, $this->source); })()), "required", [], "any", false, false, false, 20), "rows" => craft\helpers\Template::attribute($this->env, $this->source,         // line 21
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 21, $this->source); })()), "initialRows", [], "any", false, false, false, 21), "orientation" => ((        // line 22
$context["orientation"]) ?? (null)), "disabled" =>         // line 23
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 23, $this->source); })())];
        // line 25
        yield "
";
        // line 26
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 26, $this->source); })()), "multiline", [], "any", false, false, false, 26)) {
            // line 27
            yield "    ";
            yield $macros["forms"]->getTemplateForMacro("macro_textarea", $context, 27, $this->getSourceContext())->macro_textarea(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 27, $this->source); })())]);
            yield "
";
        } else {
            // line 29
            yield "    ";
            yield $macros["forms"]->getTemplateForMacro("macro_text", $context, 29, $this->getSourceContext())->macro_text(...[(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 29, $this->source); })())]);
            yield "
";
        }
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/PlainText/input.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/fieldtypes/PlainText/input.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  78 => 29,  72 => 27,  70 => 26,  67 => 25,  65 => 23,  64 => 22,  63 => 21,  62 => 20,  61 => 19,  60 => 17,  59 => 16,  58 => 15,  57 => 14,  56 => 13,  55 => 12,  54 => 11,  51 => 10,  49 => 8,  48 => 7,  47 => 5,  45 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{%- set disabled = disabled ?? false %}

{%- set class = [
    'nicetext',
    field.code ? 'code',
    field.uiMode == 'enlarged' ? 'readable',
]|filter %}

{% set config = {
    id: id ?? field.getInputId(),
    describedBy: field.describedBy,
    name: name,
    value: value,
    class: class,
    maxlength: not disabled ? field.charLimit,
    showCharsLeft: true,
    placeholder: placeholder,
    required: field.required,
    rows: field.initialRows,
    orientation: orientation ?? null,
    disabled,
} %}

{% if field.multiline %}
    {{ forms.textarea(config) }}
{% else %}
    {{ forms.text(config) }}
{% endif %}
", "_components/fieldtypes/PlainText/input.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fieldtypes/PlainText/input.twig");
    }
}
