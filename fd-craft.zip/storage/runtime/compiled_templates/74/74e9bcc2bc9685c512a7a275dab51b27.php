<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/email/_index.twig */
class __TwigTemplate_bef1da284df5dc78b7ecd7509ad8ef9f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 3
        return "_layouts/cp.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/email/_index.twig");
        // line 1
        Craft::$app->controller->requireAdmin(false);
        // line 5
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Email Settings", "app");
        // line 6
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 7
        $context["fullPageForm"] =  !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 7, $this->source); })());
        // line 9
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 13
        $context["formActions"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"), "redirect" => $this->env->getFilter('hash')->getCallable()("settings/email"), "shortcut" => true, "retainScroll" => true]];
        // line 22
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "settings/email/_index.twig", 22)->unwrap();
        // line 24
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 24, $this->source); })()), "registerTranslations", ["app", ["Email sent successfully! Check your inbox."]], "method", false, false, false, 24);
        // line 29
        if ( !array_key_exists("settings", $context)) {
            // line 30
            $context["settings"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 30, $this->source); })()), "app", [], "any", false, false, false, 30), "projectConfig", [], "any", false, false, false, 30), "get", ["email"], "method", false, false, false, 30);
            // line 31
            $context["freshSettings"] = true;
        } else {
            // line 33
            $context["freshSettings"] = false;
        }
        // line 37
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 37, $this->source); })())) {
            // line 38
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 3
        $this->parent = $this->loadTemplate("_layouts/cp.twig", "settings/email/_index.twig", 3);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/email/_index.twig");
    }

    // line 41
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 42
        yield "    ";
        if ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["customMailerFiles"]) || array_key_exists("customMailerFiles", $context) ? $context["customMailerFiles"] : (function () { throw new RuntimeError('Variable "customMailerFiles" does not exist.', 42, $this->source); })()))) {
            // line 43
            yield "        <div class=\"readable\">
            <blockquote class=\"note warning\">
                <p>
                    ";
            // line 46
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("It looks like these settings are being overridden by {paths}.", "app", ["paths" => Twig\Extension\CoreExtension::join(            // line 47
(isset($context["customMailerFiles"]) || array_key_exists("customMailerFiles", $context) ? $context["customMailerFiles"] : (function () { throw new RuntimeError('Variable "customMailerFiles" does not exist.', 47, $this->source); })()), ", ")]), "html", null, true);
            // line 48
            yield "
                </p>
            </blockquote>
        </div>
        <hr>
    ";
        }
        // line 54
        yield "
    ";
        // line 55
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 55, $this->source); })())) {
            // line 56
            yield "        ";
            yield craft\helpers\Html::actionInput("system-settings/save-email-settings");
            yield "
        ";
            // line 57
            yield craft\helpers\Html::redirectInput("settings");
            yield "
    ";
        }
        // line 59
        yield "
    ";
        // line 60
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 60, $this->getSourceContext())->macro_autosuggestField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("System Email Address", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The email address Craft CMS will use when sending email.", "app"), "id" => "fromEmail", "name" => "fromEmail", "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 67
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 67, $this->source); })()), "fromEmail", [], "any", false, false, false, 67), "autofocus" => true, "required" => true, "errors" => ((        // line 70
(isset($context["freshSettings"]) || array_key_exists("freshSettings", $context) ? $context["freshSettings"] : (function () { throw new RuntimeError('Variable "freshSettings" does not exist.', 70, $this->source); })())) ? (null) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 70, $this->source); })()), "getErrors", ["fromEmail"], "method", false, false, false, 70))), "disabled" =>         // line 71
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 71, $this->source); })())]]);
        // line 72
        yield "

    ";
        // line 74
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 74, $this->getSourceContext())->macro_autosuggestField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Reply-To Address", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The Reply-To email address Craft CMS should use when sending email.", "app"), "id" => "replyToEmail", "name" => "replyToEmail", "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 81
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 81, $this->source); })()), "replyToEmail", [], "any", false, false, false, 81), "errors" => ((        // line 82
(isset($context["freshSettings"]) || array_key_exists("freshSettings", $context) ? $context["freshSettings"] : (function () { throw new RuntimeError('Variable "freshSettings" does not exist.', 82, $this->source); })())) ? (null) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 82, $this->source); })()), "getErrors", ["replyToEmail"], "method", false, false, false, 82))), "disabled" =>         // line 83
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 83, $this->source); })())]]);
        // line 84
        yield "

    ";
        // line 86
        yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 86, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sender Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The “From” name Craft CMS will use when sending email.", "app"), "id" => "fromName", "name" => "fromName", "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 92
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 92, $this->source); })()), "fromName", [], "any", false, false, false, 92), "required" => true, "errors" => ((        // line 94
(isset($context["freshSettings"]) || array_key_exists("freshSettings", $context) ? $context["freshSettings"] : (function () { throw new RuntimeError('Variable "freshSettings" does not exist.', 94, $this->source); })())) ? (null) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 94, $this->source); })()), "getErrors", ["fromName"], "method", false, false, false, 94))), "disabled" =>         // line 95
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 95, $this->source); })())]]);
        // line 96
        yield "

    ";
        // line 98
        if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 98, $this->source); })()) >= (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 98, $this->source); })()))) {
            // line 99
            yield "        ";
            yield $macros["forms"]->getTemplateForMacro("macro_autosuggestField", $context, 99, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("HTML Email Template", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The template Craft CMS will use for HTML emails", "app"), "id" => "template", "name" => "template", "suggestTemplates" => true, "suggestEnvVars" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 106
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 106, $this->source); })()), "template", [], "any", false, false, false, 106), "errors" => ((            // line 107
(isset($context["freshSettings"]) || array_key_exists("freshSettings", $context) ? $context["freshSettings"] : (function () { throw new RuntimeError('Variable "freshSettings" does not exist.', 107, $this->source); })())) ? (null) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 107, $this->source); })()), "getErrors", ["template"], "method", false, false, false, 107))), "disabled" =>             // line 108
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 108, $this->source); })())]]);
            // line 109
            yield "
    ";
        }
        // line 111
        yield "
    ";
        // line 112
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 112, $this->source); })()), "app", [], "any", false, false, false, 112), "isMultiSite", [], "any", false, false, false, 112)) {
            // line 113
            yield "        ";
            yield $macros["forms"]->getTemplateForMacro("macro_editableTableField", $context, 113, $this->getSourceContext())->macro_editableTableField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site Overrides", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Blank values will default to the settings above.", "app"), "id" => "site-overrides", "name" => "siteOverrides", "cols" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["heading" => ["type" => "heading", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app"), "suggestEnvVars" => true, "thin" => true], "fromEmail" => ["type" => "autosuggest", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("System Email Address", "app"), "suggestEnvVars" => true], "replyToEmail" => ["type" => "autosuggest", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Reply-To Address", "app"), "suggestEnvVars" => true], "fromName" => ["type" => "autosuggest", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sender Name", "app"), "suggestEnvVars" => true], "template" => (((            // line 140
(isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 140, $this->source); })()) >= (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 140, $this->source); })()))) ? (["type" => "template", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("HTML Email Template", "app"), "suggestEnvVars" => true, "code" => true]) : (""))]), "rows" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $this->extensions['craft\web\twig\Extension']->collectFunction(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 147
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 147, $this->source); })()), "app", [], "any", false, false, false, 147), "sites", [], "any", false, false, false, 147), "getAllSites", [], "method", false, false, false, 147)), "keyBy", [            // line 148
function ($__site__) use ($context, $macros) { $context["site"] = $__site__; return craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 148, $this->source); })()), "uid", [], "any", false, false, false, 148); }], "method", false, false, false, 147), "map", [            // line 149
function ($__site__) use ($context, $macros) { $context["site"] = $__site__; return ["heading" => craft\helpers\Template::attribute($this->env, $this->source,             // line 150
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 150, $this->source); })()), "getUiLabel", [], "method", false, false, false, 150), ...(((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 151
($context["settings"] ?? null), "siteOverrides", [], "any", false, true, false, 151), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 151, $this->source); })()), "uid", [], "any", false, false, false, 151), [], "array", true, true, false, 151) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["settings"] ?? null), "siteOverrides", [], "any", false, true, false, 151), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 151, $this->source); })()), "uid", [], "any", false, false, false, 151), [], "array", false, false, false, 151)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["settings"] ?? null), "siteOverrides", [], "any", false, true, false, 151), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 151, $this->source); })()), "uid", [], "any", false, false, false, 151), [], "array", false, false, false, 151)) : ([]))]; }], "method", false, false, false, 148), "all", [], "method", false, false, false, 149), "fullWidth" => true, "allowAdd" => false, "allowDelete" => false, "allowReorder" => false, "errors" => ((            // line 158
(isset($context["freshSettings"]) || array_key_exists("freshSettings", $context) ? $context["freshSettings"] : (function () { throw new RuntimeError('Variable "freshSettings" does not exist.', 158, $this->source); })())) ? (null) : (array_unique(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 158, $this->source); })()), "getErrors", ["siteOverrides"], "method", false, false, false, 158)))), "static" =>             // line 159
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 159, $this->source); })())]]);
            // line 160
            yield "
    ";
        }
        // line 162
        yield "
    <hr>

    ";
        // line 165
        yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 165, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Transport Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How should Craft CMS send the emails?", "app"), "id" => "transportType", "name" => "transportType", "options" =>         // line 170
(isset($context["transportTypeOptions"]) || array_key_exists("transportTypeOptions", $context) ? $context["transportTypeOptions"] : (function () { throw new RuntimeError('Variable "transportTypeOptions" does not exist.', 170, $this->source); })()), "value" => get_class(        // line 171
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 171, $this->source); })())), "errors" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 172
($context["adapter"] ?? null), "getErrors", ["type"], "method", true, true, false, 172) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["adapter"] ?? null), "getErrors", ["type"], "method", false, false, false, 172)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["adapter"] ?? null), "getErrors", ["type"], "method", false, false, false, 172)) : (null)), "toggle" => true, "disabled" =>         // line 174
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 174, $this->source); })())]]);
        // line 175
        yield "


    ";
        // line 178
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["allTransportAdapters"]) || array_key_exists("allTransportAdapters", $context) ? $context["allTransportAdapters"] : (function () { throw new RuntimeError('Variable "allTransportAdapters" does not exist.', 178, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["_adapter"]) {
            // line 179
            yield "        ";
            $context["isCurrent"] = (get_class($context["_adapter"]) == get_class((isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 179, $this->source); })())));
            // line 180
            yield "        ";
            $context["a"] = (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 180, $this->source); })())) ? ((isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 180, $this->source); })())) : ($context["_adapter"]));
            // line 181
            yield "        ";
            $context["classes"] = [];
            // line 182
            yield "        ";
            if ( !(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 182, $this->source); })())) {
                // line 183
                yield "            ";
                $context["classes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["classes"]) || array_key_exists("classes", $context) ? $context["classes"] : (function () { throw new RuntimeError('Variable "classes" does not exist.', 183, $this->source); })()), ["hidden"]);
                // line 184
                yield "        ";
            }
            // line 185
            yield "
        <div id=\"";
            // line 186
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Html::id(get_class($context["_adapter"])), "html", null, true);
            yield "\" ";
            if ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["classes"]) || array_key_exists("classes", $context) ? $context["classes"] : (function () { throw new RuntimeError('Variable "classes" does not exist.', 186, $this->source); })()))) {
                yield "class=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join((isset($context["classes"]) || array_key_exists("classes", $context) ? $context["classes"] : (function () { throw new RuntimeError('Variable "classes" does not exist.', 186, $this->source); })()), " "), "html", null, true);
                yield "\"";
            }
            yield ">
            ";
            // line 187
            $_namespace = (("transportTypes[" . craft\helpers\Html::id(get_class($context["_adapter"]))) . "]");
            if ($_namespace !== null && $_namespace !== '') {
                $_originalNamespace = Craft::$app->getView()->getNamespace();
                Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                ob_start();
                try {
                    // line 188
                    yield "                ";
                    // line 189
                    yield "                    ";
                    yield (((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 189, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 189, $this->source); })()), "getReadOnlySettingsHtml", [], "method", false, false, false, 189)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 189, $this->source); })()), "getSettingsHtml", [], "method", false, false, false, 189)));
                    yield "
                ";
                    // line 191
                    yield "            ";
                } catch (Exception $e) {
                    ob_end_clean();

                    throw $e;
                }
                echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
                Craft::$app->getView()->setNamespace($_originalNamespace);
            } else {
                // line 188
                yield "                ";
                // line 189
                yield "                    ";
                yield (((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 189, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 189, $this->source); })()), "getReadOnlySettingsHtml", [], "method", false, false, false, 189)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 189, $this->source); })()), "getSettingsHtml", [], "method", false, false, false, 189)));
                yield "
                ";
                // line 191
                yield "            ";
            }
            unset($_originalNamespace, $_namespace);
            // line 192
            yield "        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['_adapter'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 194
        yield "
    <hr>

    <div class=\"buttons\">
        ";
        // line 198
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 198, $this->source); })())) {
            // line 199
            yield "            <button type=\"button\" id=\"test\" class=\"btn formsubmit\" data-action=\"system-settings/test-email-settings\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Test", "app"), "html", null, true);
            yield "</button>
        ";
        } else {
            // line 201
            yield "            <form method=\"post\" accept-charset=\"UTF-8\">
                ";
            // line 202
            yield craft\helpers\Html::actionInput("system-settings/test-email-settings");
            yield "
                ";
            // line 203
            yield craft\helpers\Html::csrfInput();
            yield "
                <button type=\"submit\" id=\"test\" class=\"btn\">";
            // line 204
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Test", "app"), "html", null, true);
            yield "</button>
            </form>
        ";
        }
        // line 207
        yield "    </div>

";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/email/_index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  313 => 207,  307 => 204,  303 => 203,  299 => 202,  296 => 201,  290 => 199,  288 => 198,  282 => 194,  275 => 192,  271 => 191,  266 => 189,  264 => 188,  254 => 191,  249 => 189,  247 => 188,  240 => 187,  230 => 186,  227 => 185,  224 => 184,  221 => 183,  218 => 182,  215 => 181,  212 => 180,  209 => 179,  205 => 178,  200 => 175,  198 => 174,  197 => 172,  196 => 171,  195 => 170,  194 => 165,  189 => 162,  185 => 160,  183 => 159,  182 => 158,  181 => 151,  180 => 150,  179 => 149,  178 => 148,  177 => 147,  176 => 140,  174 => 113,  172 => 112,  169 => 111,  165 => 109,  163 => 108,  162 => 107,  161 => 106,  159 => 99,  157 => 98,  153 => 96,  151 => 95,  150 => 94,  149 => 92,  148 => 86,  144 => 84,  142 => 83,  141 => 82,  140 => 81,  139 => 74,  135 => 72,  133 => 71,  132 => 70,  131 => 67,  130 => 60,  127 => 59,  122 => 57,  117 => 56,  115 => 55,  112 => 54,  104 => 48,  102 => 47,  101 => 46,  96 => 43,  93 => 42,  85 => 41,  79 => 3,  76 => 38,  74 => 37,  71 => 33,  68 => 31,  66 => 30,  64 => 29,  62 => 24,  60 => 22,  58 => 13,  56 => 9,  54 => 7,  52 => 6,  50 => 5,  48 => 1,  40 => 3,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% requireAdmin false %}

{% extends '_layouts/cp.twig' %}

{% set title = 'Email Settings'|t('app') %}
{% set readOnly = readOnly ?? false %}
{% set fullPageForm = not readOnly %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% set formActions = [
    {
        label: 'Save and continue editing'|t('app'),
        redirect: 'settings/email'|hash,
        shortcut: true,
        retainScroll: true,
    },
] %}

{% import '_includes/forms.twig' as forms %}

{% do view.registerTranslations('app', [
    \"Email sent successfully! Check your inbox.\",
]) %}


{% if settings is not defined %}
    {% set settings = craft.app.projectConfig.get('email') %}
    {% set freshSettings = true %}
{% else %}
    {% set freshSettings = false %}
{% endif %}


{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    {% if customMailerFiles|length %}
        <div class=\"readable\">
            <blockquote class=\"note warning\">
                <p>
                    {{ 'It looks like these settings are being overridden by {paths}.'|t('app', {
                        paths: customMailerFiles|join(', ')
                    }) }}
                </p>
            </blockquote>
        </div>
        <hr>
    {% endif %}

    {% if not readOnly %}
        {{ actionInput('system-settings/save-email-settings') }}
        {{ redirectInput('settings') }}
    {% endif %}

    {{ forms.autosuggestField({
        first: true,
        label: \"System Email Address\"|t('app'),
        instructions: \"The email address Craft CMS will use when sending email.\"|t('app'),
        id: 'fromEmail',
        name: 'fromEmail',
        suggestEnvVars: true,
        value: settings.fromEmail,
        autofocus: true,
        required: true,
        errors: (freshSettings ? null : settings.getErrors('fromEmail')),
        disabled: readOnly,
    }) }}

    {{ forms.autosuggestField({
        first: true,
        label: 'Reply-To Address'|t('app'),
        instructions: 'The Reply-To email address Craft CMS should use when sending email.'|t('app'),
        id: 'replyToEmail',
        name: 'replyToEmail',
        suggestEnvVars: true,
        value: settings.replyToEmail,
        errors: (freshSettings ? null : settings.getErrors('replyToEmail')),
        disabled: readOnly,
    }) }}

    {{ forms.autosuggestField({
        label: \"Sender Name\"|t('app'),
        instructions: \"The “From” name Craft CMS will use when sending email.\"|t('app'),
        id: 'fromName',
        name: 'fromName',
        suggestEnvVars: true,
        value: settings.fromName,
        required: true,
        errors: (freshSettings ? null : settings.getErrors('fromName')),
        disabled: readOnly,
    }) }}

    {% if CraftEdition >= CraftPro %}
        {{ forms.autosuggestField({
            label: \"HTML Email Template\"|t('app'),
            instructions: \"The template Craft CMS will use for HTML emails\"|t('app'),
            id: 'template',
            name: 'template',
            suggestTemplates: true,
            suggestEnvVars: true,
            value: settings.template,
            errors: (freshSettings ? null : settings.getErrors('template')),
            disabled: readOnly,
        }) }}
    {% endif %}

    {% if craft.app.isMultiSite %}
        {{ forms.editableTableField({
            label: 'Site Overrides'|t('app'),
            instructions: 'Blank values will default to the settings above.'|t('app'),
            id: 'site-overrides',
            name: 'siteOverrides',
            cols: {
                heading: {
                    type: 'heading',
                    heading: 'Site'|t('app'),
                    suggestEnvVars: true,
                    thin: true,
                },
                fromEmail: {
                    type: 'autosuggest',
                    heading: 'System Email Address'|t('app'),
                    suggestEnvVars: true,
                },
                replyToEmail: {
                    type: 'autosuggest',
                    heading: 'Reply-To Address'|t('app'),
                    suggestEnvVars: true,
                },
                fromName: {
                    type: 'autosuggest',
                    heading: 'Sender Name'|t('app'),
                    suggestEnvVars: true,
                },
                template: CraftEdition >= CraftPro ? {
                    type: 'template',
                    heading: 'HTML Email Template'|t('app'),
                    suggestEnvVars: true,
                    code: true,
                }
            }|filter,
            rows: collect(craft.app.sites.getAllSites())
                .keyBy(site => site.uid)
                .map(site => {
                    heading: site.getUiLabel(),
                    ...(settings.siteOverrides[site.uid] ?? {})
                })
                .all(),
            fullWidth: true,
            allowAdd: false,
            allowDelete: false,
            allowReorder: false,
            errors: (freshSettings ? null : settings.getErrors('siteOverrides')|unique),
            static: readOnly,
        }) }}
    {% endif %}

    <hr>

    {{ forms.selectField({
        label: \"Transport Type\"|t('app'),
        instructions: \"How should Craft CMS send the emails?\"|t('app'),
        id: 'transportType',
        name: 'transportType',
        options: transportTypeOptions,
        value: className(adapter),
        errors: adapter.getErrors('type') ?? null,
        toggle: true,
        disabled: readOnly,
    }) }}


    {% for _adapter in allTransportAdapters %}
        {% set isCurrent = (className(_adapter) == className(adapter)) %}
        {% set a = isCurrent ? adapter : _adapter %}
        {% set classes = [] %}
        {% if not isCurrent %}
            {% set classes = classes|merge(['hidden']) %}
        {% endif %}

        <div id=\"{{ className(_adapter)|id }}\" {% if classes|length %}class=\"{{ classes|join(' ') }}\"{% endif %}>
            {% namespace 'transportTypes['~className(_adapter)|id~']' %}
                {% autoescape false %}
                    {{ readOnly ? a.getReadOnlySettingsHtml() : a.getSettingsHtml() }}
                {% endautoescape %}
            {% endnamespace %}
        </div>
    {% endfor %}

    <hr>

    <div class=\"buttons\">
        {% if not readOnly %}
            <button type=\"button\" id=\"test\" class=\"btn formsubmit\" data-action=\"system-settings/test-email-settings\">{{ \"Test\"|t('app') }}</button>
        {% else %}
            <form method=\"post\" accept-charset=\"UTF-8\">
                {{ actionInput('system-settings/test-email-settings') }}
                {{ csrfInput() }}
                <button type=\"submit\" id=\"test\" class=\"btn\">{{ \"Test\"|t('app') }}</button>
            </form>
        {% endif %}
    </div>

{% endblock %}
", "settings/email/_index.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/email/_index.twig");
    }
}
