<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/utilities/Updates.twig */
class __TwigTemplate_798243789087e62373460320eabb45f7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/utilities/Updates.twig");
        // line 1
        yield "<div id=\"graphic\" class=\"spinner big\"></div>
<div id=\"status\">";
        // line 2
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Checking for updates…", "app"), "html", null, true);
        yield "</div>
";
        craft\helpers\Template::endProfile("template", "_components/utilities/Updates.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/utilities/Updates.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  46 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<div id=\"graphic\" class=\"spinner big\"></div>
<div id=\"status\">{{ \"Checking for updates…\"|t('app') }}</div>
", "_components/utilities/Updates.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/utilities/Updates.twig");
    }
}
