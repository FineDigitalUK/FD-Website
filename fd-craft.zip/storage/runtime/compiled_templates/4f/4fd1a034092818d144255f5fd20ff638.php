<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/entry-types/_edit.twig */
class __TwigTemplate_d86aa468fd364e69040d42cefd774b68 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/entry-types/_edit.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/entry-types/_edit.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 3, $this->source); })()), "id", [], "any", false, false, false, 3)) {
            yield craft\helpers\Html::hiddenInput("entryTypeId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 3, $this->source); })()), "id", [], "any", false, false, false, 3));
        }
        // line 4
        yield "
";
        // line 5
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 5, $this->getSourceContext())->macro_textField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this entry type will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 11
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 11, $this->source); })()), "name", [], "any", false, false, false, 11), "autofocus" => true, "required" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 14
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 14, $this->source); })()), "getErrors", ["name"], "method", false, false, false, 14), "data" => ["error-key" => "name"], "disabled" =>         // line 16
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 16, $this->source); })())]]);
        // line 17
        yield "

";
        // line 19
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 19, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this entry type in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 27
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 27, $this->source); })()), "handle", [], "any", false, false, false, 27), "required" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 29
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 29, $this->source); })()), "getErrors", ["handle"], "method", false, false, false, 29), "data" => ["error-key" => "handle"], "disabled" =>         // line 31
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 31, $this->source); })())]]);
        // line 32
        yield "

";
        // line 34
        yield $macros["forms"]->getTemplateForMacro("macro_textareaField", $context, 34, $this->getSourceContext())->macro_textareaField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Description", "app"), "id" => "description", "class" => "nicetext", "name" => "description", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 39
($context["entryType"] ?? null), "description", [], "any", true, true, false, 39) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entryType"] ?? null), "description", [], "any", false, false, false, 39)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entryType"] ?? null), "description", [], "any", false, false, false, 39)) : (null)), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 40
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 40, $this->source); })()), "getErrors", ["description"], "method", false, false, false, 40), "disabled" =>         // line 41
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 41, $this->source); })())]]);
        // line 42
        yield "

";
        // line 44
        yield $macros["forms"]->getTemplateForMacro("macro_iconPickerField", $context, 44, $this->getSourceContext())->macro_iconPickerField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Icon", "app"), "id" => "icon", "name" => "icon", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 48
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 48, $this->source); })()), "icon", [], "any", false, false, false, 48), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 49
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 49, $this->source); })()), "getErrors", ["icon"], "method", false, false, false, 49), "data" => ["error-key" => "icon"], "static" =>         // line 53
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 53, $this->source); })())]]);
        // line 54
        yield "

";
        // line 56
        yield $macros["forms"]->getTemplateForMacro("macro_colorSelectField", $context, 56, $this->getSourceContext())->macro_colorSelectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Color", "app"), "id" => "color", "name" => "color", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 60
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 60, $this->source); })()), "color", [], "any", false, false, false, 60), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 61
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 61, $this->source); })()), "getErrors", ["color"], "method", false, false, false, 61), "data" => ["error-key" => "color"], "disabled" =>         // line 65
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 65, $this->source); })())]]);
        // line 66
        yield "

<hr>

";
        // line 70
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 70, $this->source); })()), "app", [], "any", false, false, false, 70), "getIsMultiSite", [], "method", false, false, false, 70)) {
            // line 71
            yield "    <div id=\"title-container\">
        ";
            // line 72
            yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 72, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("{name} Translation Method", "app", ["name" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "app")]), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How should {name} values be translated?", "app", ["name" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "app")]), "id" => "translation-method", "name" => "titleTranslationMethod", "options" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")], ["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")], ["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")], ["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")], ["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]]), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 88
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 88, $this->source); })()), "titleTranslationMethod", [], "any", false, false, false, 88), "toggle" => true, "targetPrefix" => "translation-method-", "disabled" =>             // line 91
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 91, $this->source); })())]]);
            // line 92
            yield "

        <div id=\"translation-method-custom\" ";
            // line 94
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 94, $this->source); })()), "titleTranslationMethod", [], "any", false, false, false, 94) != "custom")) {
                yield "class=\"hidden\"";
            }
            yield ">
            ";
            // line 95
            yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 95, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("{name} Translation Key Format", "app", ["name" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "app")]), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Template that defines the {name} field’s custom “translation key” format. Values will be copied to all sites that produce the same key.", "app", ["name" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "app")]), "id" => "translation-key-format", "name" => "titleTranslationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 104
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 104, $this->source); })()), "titleTranslationKeyFormat", [], "any", false, false, false, 104), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 105
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 105, $this->source); })()), "getErrors", ["titleTranslationKeyFormat"], "method", false, false, false, 105), "data" => ["error-key" => "titleTranslationKeyFormat"], "disabled" =>             // line 109
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 109, $this->source); })())]]);
            // line 110
            yield "
        </div>
    </div>
";
        }
        // line 114
        yield "
";
        // line 115
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 115, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default Title Format", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What auto-generated entry titles should look like. You can include tags that output entry properties, such as {ex}.", "app", ["ex" => "<code>{myCustomField}</code>"]), "id" => "titleFormat", "name" => "titleFormat", "class" => "code", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 121
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 121, $this->source); })()), "titleFormat", [], "any", false, false, false, 121), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 122
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 122, $this->source); })()), "getErrors", ["titleFormat"], "method", false, false, false, 122), "data" => ["error-key" => "titleFormat"], "disabled" =>         // line 126
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 126, $this->source); })())]]);
        // line 127
        yield "

";
        // line 129
        yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 129, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show the Slug field", "app"), "name" => "showSlugField", "toggle" => "slug-container", "reverseToggle" => "#slugFormat-container, #field-layout .fld-slug-field-icon", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 134
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 134, $this->source); })()), "showSlugField", [], "any", false, false, false, 134), "disabled" =>         // line 135
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 135, $this->source); })())]]);
        // line 136
        yield "

";
        // line 138
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 138, $this->source); })()), "app", [], "any", false, false, false, 138), "getIsMultiSite", [], "method", false, false, false, 138)) {
            // line 139
            yield "    <div id=\"slug-container\"";
            if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 139, $this->source); })()), "showSlugField", [], "any", false, false, false, 139)) {
                yield " class=\"hidden\"";
            }
            yield ">
        ";
            // line 140
            yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 140, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("{name} Translation Method", "app", ["name" => $this->extensions['craft\web\twig\Extension']->translateFilter("Slug", "app")]), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How should {name} values be translated?", "app", ["name" => $this->extensions['craft\web\twig\Extension']->translateFilter("Slug", "app")]), "id" => "slug-translation-method", "name" => "slugTranslationMethod", "options" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")], ["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")], ["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")], ["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")], ["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]]), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 156
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 156, $this->source); })()), "slugTranslationMethod", [], "any", false, false, false, 156), "toggle" => true, "targetPrefix" => "slug-translation-method-", "disabled" =>             // line 159
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 159, $this->source); })())]]);
            // line 160
            yield "

        <div id=\"slug-translation-method-custom\" ";
            // line 162
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 162, $this->source); })()), "slugTranslationMethod", [], "any", false, false, false, 162) != "custom")) {
                yield "class=\"hidden\"";
            }
            yield ">
            ";
            // line 163
            yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 163, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("{name} Translation Key Format", "app", ["name" => $this->extensions['craft\web\twig\Extension']->translateFilter("Slug", "app")]), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Template that defines the {name} field’s custom “translation key” format. Values will be copied to all sites that produce the same key.", "app", ["name" => $this->extensions['craft\web\twig\Extension']->translateFilter("Slug", "app")]), "id" => "slug-translation-key-format", "name" => "slugTranslationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 172
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 172, $this->source); })()), "slugTranslationKeyFormat", [], "any", false, false, false, 172), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 173
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 173, $this->source); })()), "getErrors", ["slugTranslationKeyFormat"], "method", false, false, false, 173), "data" => ["error-key" => "slugTranslationKeyFormat"], "disabled" =>             // line 177
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 177, $this->source); })())]]);
            // line 178
            yield "
        </div>
    </div>
";
        }
        // line 182
        yield "
";
        // line 183
        yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 183, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show the Status field", "app"), "id" => "showStatusField", "name" => "showStatusField", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 187
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 187, $this->source); })()), "showStatusField", [], "any", false, false, false, 187), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 188
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 188, $this->source); })()), "getErrors", ["showStatusField"], "method", false, false, false, 188), "data" => ["error-key" => "showStatusField"], "disabled" =>         // line 192
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 192, $this->source); })())]]);
        // line 193
        yield "

<hr>

";
        // line 197
        yield $macros["forms"]->getTemplateForMacro("macro_fieldLayoutDesignerField", $context, 197, $this->getSourceContext())->macro_fieldLayoutDesignerField(...[["id" => "field-layout", "fieldLayout" => craft\helpers\Template::attribute($this->env, $this->source,         // line 199
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 199, $this->source); })()), "getFieldLayout", [], "method", false, false, false, 199), "withGeneratedFields" => true, "withCardViewDesigner" => true, "disabled" =>         // line 202
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 202, $this->source); })())]]);
        // line 203
        yield "

";
        // line 205
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 205, $this->source); })()), "handle", [], "any", false, false, false, 205)) {
            // line 206
            yield "    ";
            craft\helpers\Template::js((((("new Craft.HandleGenerator('#" . $this->env->getFilter('namespaceInputId')->getCallable()("name")) . "', '#") . $this->env->getFilter('namespaceInputId')->getCallable()("handle")) . "');"), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "settings/entry-types/_edit.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/entry-types/_edit.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  210 => 206,  208 => 205,  204 => 203,  202 => 202,  201 => 199,  200 => 197,  194 => 193,  192 => 192,  191 => 188,  190 => 187,  189 => 183,  186 => 182,  180 => 178,  178 => 177,  177 => 173,  176 => 172,  175 => 163,  169 => 162,  165 => 160,  163 => 159,  162 => 156,  161 => 140,  154 => 139,  152 => 138,  148 => 136,  146 => 135,  145 => 134,  144 => 129,  140 => 127,  138 => 126,  137 => 122,  136 => 121,  135 => 115,  132 => 114,  126 => 110,  124 => 109,  123 => 105,  122 => 104,  121 => 95,  115 => 94,  111 => 92,  109 => 91,  108 => 88,  107 => 72,  104 => 71,  102 => 70,  96 => 66,  94 => 65,  93 => 61,  92 => 60,  91 => 56,  87 => 54,  85 => 53,  84 => 49,  83 => 48,  82 => 44,  78 => 42,  76 => 41,  75 => 40,  74 => 39,  73 => 34,  69 => 32,  67 => 31,  66 => 29,  65 => 27,  64 => 19,  60 => 17,  58 => 16,  57 => 14,  56 => 11,  55 => 5,  52 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% if entryType.id %}{{ hiddenInput('entryTypeId', entryType.id) }}{% endif %}

{{ forms.textField({
    first: true,
    label: \"Name\"|t('app'),
    instructions: \"What this entry type will be called in the control panel.\"|t('app'),
    id: 'name',
    name: 'name',
    value: entryType.name,
    autofocus: true,
    required: true,
    errors: entryType.getErrors('name'),
    data: {'error-key': 'name'},
    disabled: readOnly,
}) }}

{{ forms.textField({
    label: \"Handle\"|t('app'),
    instructions: \"How you’ll refer to this entry type in the templates.\"|t('app'),
    id: 'handle',
    name: 'handle',
    class: 'code',
    autocorrect: false,
    autocapitalize: false,
    value: entryType.handle,
    required: true,
    errors: entryType.getErrors('handle'),
    data: {'error-key': 'handle'},
    disabled: readOnly,
}) }}

{{ forms.textareaField({
    label: 'Description'|t('app'),
    id: 'description',
    class: 'nicetext',
    name: 'description',
    value: entryType.description ?? null,
    errors: entryType.getErrors('description'),
    disabled: readOnly,
}) }}

{{ forms.iconPickerField({
    label: 'Icon'|t('app'),
    id: 'icon',
    name: 'icon',
    value: entryType.icon,
    errors: entryType.getErrors('icon'),
    data: {
        'error-key': 'icon',
    },
    static: readOnly,
}) }}

{{ forms.colorSelectField({
    label: 'Color'|t('app'),
    id: 'color',
    name: 'color',
    value: entryType.color,
    errors: entryType.getErrors('color'),
    data: {
        'error-key': 'color',
    },
    disabled: readOnly,
}) }}

<hr>

{% if craft.app.getIsMultiSite() %}
    <div id=\"title-container\">
        {{ forms.selectField({
            label: '{name} Translation Method'|t('app', {
                name: 'Title'|t('app'),
            }),
            instructions: 'How should {name} values be translated?'|t('app', {
                name: 'Title'|t('app'),
            }),
            id: 'translation-method',
            name: 'titleTranslationMethod',
            options: [
                { value: 'none', label: 'Not translatable'|t('app') },
                { value: 'site', label: 'Translate for each site'|t('app') },
                { value: 'siteGroup', label: 'Translate for each site group'|t('app') },
                { value: 'language', label: 'Translate for each language'|t('app') },
                { value: 'custom', label: 'Custom…'|t('app') },
            ]|filter,
            value: entryType.titleTranslationMethod,
            toggle: true,
            targetPrefix: 'translation-method-',
            disabled: readOnly,
        }) }}

        <div id=\"translation-method-custom\" {% if entryType.titleTranslationMethod != 'custom' %}class=\"hidden\"{% endif %}>
            {{ forms.textField({
                label: '{name} Translation Key Format'|t('app', {
                    name: 'Title'|t('app'),
                }),
                instructions: 'Template that defines the {name} field’s custom “translation key” format. Values will be copied to all sites that produce the same key.'|t('app', {
                    name: 'Title'|t('app'),
                }),
                id: 'translation-key-format',
                name: 'titleTranslationKeyFormat',
                value: entryType.titleTranslationKeyFormat,
                errors: entryType.getErrors('titleTranslationKeyFormat'),
                data: {
                    'error-key': 'titleTranslationKeyFormat',
                },
                disabled: readOnly,
            }) }}
        </div>
    </div>
{% endif %}

{{ forms.textField({
    label: 'Default Title Format'|t('app'),
    instructions: 'What auto-generated entry titles should look like. You can include tags that output entry properties, such as {ex}.'|t('app', { ex: '<code>{myCustomField}</code>' }),
    id: 'titleFormat',
    name: 'titleFormat',
    class: 'code',
    value: entryType.titleFormat,
    errors: entryType.getErrors('titleFormat'),
    data: {
        'error-key': 'titleFormat',
    },
    disabled: readOnly,
}) }}

{{ forms.lightswitchField({
    label: \"Show the Slug field\"|t('app'),
    name: 'showSlugField',
    toggle: 'slug-container',
    reverseToggle: '#slugFormat-container, #field-layout .fld-slug-field-icon',
    on: entryType.showSlugField,
    disabled: readOnly,
}) }}

{% if craft.app.getIsMultiSite() %}
    <div id=\"slug-container\"{% if not entryType.showSlugField %} class=\"hidden\"{% endif %}>
        {{ forms.selectField({
            label: '{name} Translation Method'|t('app', {
                name: 'Slug'|t('app'),
            }),
            instructions: 'How should {name} values be translated?'|t('app', {
                name: 'Slug'|t('app'),
            }),
            id: 'slug-translation-method',
            name: 'slugTranslationMethod',
            options: [
                { value: 'none', label: 'Not translatable'|t('app') },
                { value: 'site', label: 'Translate for each site'|t('app') },
                { value: 'siteGroup', label: 'Translate for each site group'|t('app') },
                { value: 'language', label: 'Translate for each language'|t('app') },
                { value: 'custom', label: 'Custom…'|t('app') },
            ]|filter,
            value: entryType.slugTranslationMethod,
            toggle: true,
            targetPrefix: 'slug-translation-method-',
            disabled: readOnly,
        }) }}

        <div id=\"slug-translation-method-custom\" {% if entryType.slugTranslationMethod != 'custom' %}class=\"hidden\"{% endif %}>
            {{ forms.textField({
                label: '{name} Translation Key Format'|t('app', {
                    name: 'Slug'|t('app'),
                }),
                instructions: 'Template that defines the {name} field’s custom “translation key” format. Values will be copied to all sites that produce the same key.'|t('app', {
                    name: 'Slug'|t('app'),
                }),
                id: 'slug-translation-key-format',
                name: 'slugTranslationKeyFormat',
                value: entryType.slugTranslationKeyFormat,
                errors: entryType.getErrors('slugTranslationKeyFormat'),
                data: {
                    'error-key': 'slugTranslationKeyFormat',
                },
                disabled: readOnly,
            }) }}
        </div>
    </div>
{% endif %}

{{ forms.lightswitchField({
    label: \"Show the Status field\"|t('app'),
    id: 'showStatusField',
    name: 'showStatusField',
    on: entryType.showStatusField,
    errors: entryType.getErrors('showStatusField'),
    data: {
        'error-key': 'showStatusField',
    },
    disabled: readOnly,
}) }}

<hr>

{{ forms.fieldLayoutDesignerField({
    id: 'field-layout',
    fieldLayout: entryType.getFieldLayout(),
    withGeneratedFields: true,
    withCardViewDesigner: true,
    disabled: readOnly,
}) }}

{% if not entryType.handle %}
    {% js \"new Craft.HandleGenerator('##{'name'|namespaceInputId}', '##{'handle'|namespaceInputId}');\" %}
{% endif %}
", "settings/entry-types/_edit.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/entry-types/_edit.twig");
    }
}
