<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/password */
class __TwigTemplate_e0ce8332b24c90466c7c98e00c33b25c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/password");
        // line 1
        yield "<div class=\"passwordwrapper\">";
        // line 2
        yield from $this->loadTemplate("_includes/forms/text", "_includes/forms/password", 2)->unwrap()->yield(CoreExtension::merge($context, ["class" => $this->extensions['craft\web\twig\Extension']->pushFilter(craft\helpers\Html::explodeClass(((        // line 3
$context["class"]) ?? ([]))), "password"), "type" => "password"]));
        // line 6
        yield "</div>
";
        craft\helpers\Template::endProfile("template", "_includes/forms/password");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/password";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  48 => 6,  46 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<div class=\"passwordwrapper\">
    {%- include '_includes/forms/text' with {
        class: (class ?? [])|explodeClass|push('password'),
        type: 'password',
    } -%}
</div>
", "_includes/forms/password", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/password.twig");
    }
}
