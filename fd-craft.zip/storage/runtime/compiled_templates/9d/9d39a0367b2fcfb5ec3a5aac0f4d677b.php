<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/iconPicker */
class __TwigTemplate_9a79cdd84a34c6c7931c84e51edbe614 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/iconPicker");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "_includes/forms/iconPicker", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context["id"] = (($context["id"]) ?? (("selectize" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 4
        $context["value"] = (($context["value"]) ?? (null));
        // line 5
        $context["small"] = (($context["small"]) ?? (false));
        // line 6
        $context["static"] = (($context["static"]) ?? (false));
        // line 7
        yield "
";
        // line 8
        $context["hasValue"] = ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 8, $this->source); })()) || ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 8, $this->source); })()) === "0"));
        // line 9
        yield "
";
        // line 10
        ob_start();
        // line 17
        yield "  ";
        ob_start();
        // line 29
        yield "    ";
        if ((isset($context["hasValue"]) || array_key_exists("hasValue", $context) ? $context["hasValue"] : (function () { throw new RuntimeError('Variable "hasValue" does not exist.', 29, $this->source); })())) {
            // line 30
            yield "      ";
            yield $this->extensions['craft\web\twig\Extension']->svgFunction((("@appicons/" . (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 30, $this->source); })())) . ".svg"));
            yield "
    ";
        }
        // line 32
        yield "  ";
        echo craft\helpers\Html::tag("div", ob_get_clean(), ["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["icon-picker--icon" => true, "small" =>         // line 20
(isset($context["small"]) || array_key_exists("small", $context) ? $context["small"] : (function () { throw new RuntimeError('Variable "small" does not exist.', 20, $this->source); })())])), "title" => ((        // line 22
(isset($context["hasValue"]) || array_key_exists("hasValue", $context) ? $context["hasValue"] : (function () { throw new RuntimeError('Variable "hasValue" does not exist.', 22, $this->source); })())) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 22, $this->source); })())) : (false)), "role" => ((        // line 23
(isset($context["hasValue"]) || array_key_exists("hasValue", $context) ? $context["hasValue"] : (function () { throw new RuntimeError('Variable "hasValue" does not exist.', 23, $this->source); })())) ? ("img") : (false)), "lang" => (((is_string($_v0 = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 24
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 24, $this->source); })()), "app", [], "any", false, false, false, 24), "getTargetLanguage", [], "method", false, false, false, 24)) && is_string($_v1 = "en") && str_starts_with($_v0, $_v1))) ? (false) : ("en")), "aria" => ["label" => ((        // line 26
(isset($context["hasValue"]) || array_key_exists("hasValue", $context) ? $context["hasValue"] : (function () { throw new RuntimeError('Variable "hasValue" does not exist.', 26, $this->source); })())) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 26, $this->source); })())) : (false))]]);
        // line 33
        yield "
  ";
        // line 34
        if ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 34, $this->source); })())) {
            // line 35
            yield "    ";
            yield $macros["forms"]->getTemplateForMacro("macro_button", $context, 35, $this->getSourceContext())->macro_button(...[["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["icon-picker--choose-btn" => true, "small" =>             // line 38
(isset($context["small"]) || array_key_exists("small", $context) ? $context["small"] : (function () { throw new RuntimeError('Variable "small" does not exist.', 38, $this->source); })()), "hidden" => (            // line 39
(isset($context["hasValue"]) || array_key_exists("hasValue", $context) ? $context["hasValue"] : (function () { throw new RuntimeError('Variable "hasValue" does not exist.', 39, $this->source); })()) && (isset($context["small"]) || array_key_exists("small", $context) ? $context["small"] : (function () { throw new RuntimeError('Variable "small" does not exist.', 39, $this->source); })()))])), "label" => ((            // line 41
(isset($context["hasValue"]) || array_key_exists("hasValue", $context) ? $context["hasValue"] : (function () { throw new RuntimeError('Variable "hasValue" does not exist.', 41, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Change", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app")))]]);
            // line 42
            yield "

    ";
            // line 44
            yield $macros["forms"]->getTemplateForMacro("macro_button", $context, 44, $this->getSourceContext())->macro_button(...[["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["icon-picker--remove-btn" => true, "small" =>             // line 47
(isset($context["small"]) || array_key_exists("small", $context) ? $context["small"] : (function () { throw new RuntimeError('Variable "small" does not exist.', 47, $this->source); })()), "hidden" =>  !            // line 48
(isset($context["hasValue"]) || array_key_exists("hasValue", $context) ? $context["hasValue"] : (function () { throw new RuntimeError('Variable "hasValue" does not exist.', 48, $this->source); })())])), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Remove", "app")]]);
            // line 51
            yield "

    ";
            // line 53
            if ((($context["name"]) ?? (false))) {
                // line 54
                yield "      ";
                yield craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 54, $this->source); })()), (($context["value"]) ?? ("")));
                yield "
    ";
            }
            // line 56
            yield "  ";
        }
        echo craft\helpers\Html::tag("div", ob_get_clean(), ["id" =>         // line 11
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 11, $this->source); })()), "class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["icon-picker" => true, "small" =>         // line 14
(isset($context["small"]) || array_key_exists("small", $context) ? $context["small"] : (function () { throw new RuntimeError('Variable "small" does not exist.', 14, $this->source); })())]))]);
        // line 58
        yield "
";
        // line 59
        ob_start();
        // line 60
        yield "  new Craft.IconPicker('#";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 60, $this->source); })())), "html", null, true);
        yield "', {
    freeOnly: ";
        // line 61
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((($context["freeOnly"]) ?? (false))), "html", null, true);
        yield ",
  });
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_includes/forms/iconPicker");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/iconPicker";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  133 => 61,  128 => 60,  126 => 59,  123 => 58,  121 => 14,  120 => 11,  117 => 56,  111 => 54,  109 => 53,  105 => 51,  103 => 48,  102 => 47,  101 => 44,  97 => 42,  95 => 41,  94 => 39,  93 => 38,  91 => 35,  89 => 34,  86 => 33,  84 => 26,  83 => 24,  82 => 23,  81 => 22,  80 => 20,  78 => 32,  72 => 30,  69 => 29,  66 => 17,  64 => 10,  61 => 9,  59 => 8,  56 => 7,  54 => 6,  52 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms.twig' as forms %}

{% set id = id ?? \"selectize#{random()}\" %}
{% set value = value ?? null %}
{% set small = small ?? false %}
{% set static = static ?? false %}

{% set hasValue = value or value is same as('0') %}

{% tag 'div' with {
  id,
  class: {
    'icon-picker': true,
    small,
  }|filter|keys,
} %}
  {% tag 'div' with {
    class: {
      'icon-picker--icon': true,
      small,
    }|filter|keys,
    title: hasValue ? value : false,
    role: hasValue ? 'img' : false,
    lang: craft.app.getTargetLanguage() starts with 'en' ? false : 'en',
    aria: {
      label: hasValue ? value : false,
    },
  } %}
    {% if hasValue %}
      {{ svg(\"@appicons/#{value}.svg\") }}
    {% endif %}
  {% endtag %}

  {% if not static %}
    {{ forms.button({
      class: {
        'icon-picker--choose-btn': true,
        small,
        hidden: hasValue and small,
      }|filter|keys,
      label: hasValue ? 'Change'|t('app') : 'Choose'|t('app'),
    }) }}

    {{ forms.button({
      class: {
        'icon-picker--remove-btn': true,
        small,
        hidden: not hasValue,
      }|filter|keys,
      label: 'Remove'|t('app'),
    }) }}

    {% if name ?? false %}
      {{ hiddenInput(name, value ?? '') }}
    {% endif %}
  {% endif %}
{% endtag %}

{% js %}
  new Craft.IconPicker('#{{ id|namespaceInputId }}', {
    freeOnly: {{ (freeOnly ?? false)|json_encode }},
  });
{% endjs %}
", "_includes/forms/iconPicker", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/iconPicker.twig");
    }
}
