<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/fs/Local/settings.twig */
class __TwigTemplate_a6fdfac5ef5f86a47df284be044b8efb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fs/Local/settings.twig");
        // line 1
        $macros["_v0"] = $this->macros["_v0"] = $this->loadTemplate("_includes/forms", "_components/fs/Local/settings.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        yield $macros["_v0"]->getTemplateForMacro("macro_autosuggestField", $context, 3, $this->getSourceContext())->macro_autosuggestField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Base Path", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The base folder path that should be used as the root of the filesystem.", "app"), "id" => "path", "class" => "ltr", "name" => "path", "suggestEnvVars" => true, "suggestAliases" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 11
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 11, $this->source); })()), "path", [], "any", false, false, false, 11), "required" => true, "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("/path/to/folder", "app"), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 14
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 14, $this->source); })()), "getErrors", ["path"], "method", false, false, false, 14), "data" => ["error-key" => "path"], "disabled" =>         // line 16
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 16, $this->source); })())]]);
        // line 17
        yield "
";
        craft\helpers\Template::endProfile("template", "_components/fs/Local/settings.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/fs/Local/settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  53 => 17,  51 => 16,  50 => 14,  49 => 11,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% from \"_includes/forms\" import autosuggestField %}

{{ autosuggestField({
    label: \"Base Path\"|t('app'),
    instructions: \"The base folder path that should be used as the root of the filesystem.\"|t('app'),
    id: 'path',
    class: 'ltr',
    name: 'path',
    suggestEnvVars: true,
    suggestAliases: true,
    value: volume.path,
    required: true,
    placeholder: \"/path/to/folder\"|t('app'),
    errors: volume.getErrors('path'),
    data: {'error-key': 'path'},
    disabled: readOnly,
}) }}
", "_components/fs/Local/settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fs/Local/settings.twig");
    }
}
