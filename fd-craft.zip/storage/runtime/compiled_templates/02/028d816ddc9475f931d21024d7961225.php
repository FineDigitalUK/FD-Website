<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/routes */
class __TwigTemplate_201fbc5fcc4050517692481f04e10752 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 3
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/routes");
        // line 1
        Craft::$app->controller->requireAdmin(false);
        // line 4
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Routes", "app");
        // line 5
        $context["readOnly"] =  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", [], "any", false, false, false, 5), "config", [], "any", false, false, false, 5), "general", [], "any", false, false, false, 5), "allowAdminChanges", [], "any", false, false, false, 5);
        // line 13
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 17
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 17, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\routes\\RoutesAsset"], "method", false, false, false, 17);
        // line 19
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 19, $this->source); })()), "registerTranslations", ["app", ["Add a token", "Are you sure you want to delete this route?", "Couldn’t save new route order.", "Couldn’t save route.", "Create a new route", "Edit Route", "Global", "If the URI looks like this", "Load this template", "New route order saved.", "Route deleted.", "Route Saved.", "The URI can’t begin with the {setting} config setting."]], "method", false, false, false, 19);
        // line 36
        $context["routes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 36, $this->source); })()), "routes", [], "any", false, false, false, 36), "getProjectConfigRoutes", [], "method", false, false, false, 36);
        // line 67
        ob_start();
        // line 68
        yield "    Craft.routes.tokens = {
        ";
        // line 69
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["tokens"]) || array_key_exists("tokens", $context) ? $context["tokens"] : (function () { throw new RuntimeError('Variable "tokens" does not exist.', 69, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["name"] => $context["pattern"]) {
            // line 70
            yield "            ";
            if ( !craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 70)) {
                yield ",";
            }
            // line 71
            yield "            \"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["name"], "js"), "html", null, true);
            yield "\": \"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["pattern"], "js"), "html", null, true);
            yield "\"
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['pattern'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        yield "    };
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 3
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/routes", 3);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/routes");
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 8
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 8, $this->source); })())) {
            // line 9
            yield "        <button type=\"button\" id=\"add-route-btn\" class=\"btn submit add icon\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("New route", "app"), "html", null, true);
            yield "</button>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 38
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 39
        yield "    <div id=\"routes\">
        ";
        // line 40
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 40, $this->source); })())) {
            // line 41
            yield "            <div id=\"content-notice\">
                ";
            // line 42
            yield craft\helpers\Cp::readOnlyNoticeHtml();
            yield "
            </div>
        ";
        }
        // line 45
        yield "
        <p id=\"noroutes\"";
        // line 46
        if ((isset($context["routes"]) || array_key_exists("routes", $context) ? $context["routes"] : (function () { throw new RuntimeError('Variable "routes" does not exist.', 46, $this->source); })())) {
            yield " class=\"hidden\"";
        }
        yield ">
            ";
        // line 47
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("No routes exist yet.", "app"), "html", null, true);
        yield "
        </p>

        ";
        // line 50
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["routes"]) || array_key_exists("routes", $context) ? $context["routes"] : (function () { throw new RuntimeError('Variable "routes" does not exist.', 50, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["route"]) {
            // line 51
            yield "            <div class=\"route";
            yield (((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 51, $this->source); })())) ? (" inactive") : (""));
            yield "\" data-uid=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["route"], "uid", [], "any", false, false, false, 51), "html", null, true);
            yield "\"";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["route"], "siteUid", [], "any", false, false, false, 51)) {
                yield " data-site-uid=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["route"], "siteUid", [], "any", false, false, false, 51), "html", null, true);
                yield "\"";
            }
            yield ">
                <div class=\"uri-container\">";
            // line 53
            $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 54
                yield "                        ";
                if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 54, $this->source); })()), "app", [], "any", false, false, false, 54), "getIsMultiSite", [], "method", false, false, false, 54)) {
                    // line 55
                    yield "                            <span class=\"site\">";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((craft\helpers\Template::attribute($this->env, $this->source, $context["route"], "siteUid", [], "any", false, false, false, 55)) ? ($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 55, $this->source); })()), "app", [], "any", false, false, false, 55), "sites", [], "any", false, false, false, 55), "getSiteByUid", [craft\helpers\Template::attribute($this->env, $this->source, $context["route"], "siteUid", [], "any", false, false, false, 55)], "method", false, false, false, 55), "name", [], "any", false, false, false, 55), "site")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Global", "app"))), "html", null, true);
                    yield "</span>
                        ";
                }
                // line 57
                yield "                        <span class=\"uri\">";
                yield craft\helpers\Template::attribute($this->env, $this->source, $context["route"], "uriDisplayHtml", [], "any", false, false, false, 57);
                yield "</span>
                    ";
                yield from [];
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 53
            yield Twig\Extension\CoreExtension::spaceless($_v0);
            // line 59
            yield "</div>
                <div class=\"template\">";
            // line 60
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["route"], "template", [], "any", false, false, false, 60), "html", null, true);
            yield "</div>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['route'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 63
        yield "    </div>
";
        craft\helpers\Template::endProfile("block", "main");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/routes";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  226 => 63,  217 => 60,  214 => 59,  212 => 53,  205 => 57,  199 => 55,  196 => 54,  194 => 53,  181 => 51,  177 => 50,  171 => 47,  165 => 46,  162 => 45,  156 => 42,  153 => 41,  151 => 40,  148 => 39,  140 => 38,  130 => 9,  127 => 8,  119 => 7,  113 => 3,  109 => 73,  90 => 71,  85 => 70,  68 => 69,  65 => 68,  63 => 67,  61 => 36,  59 => 19,  57 => 17,  55 => 13,  53 => 5,  51 => 4,  49 => 1,  41 => 3,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% requireAdmin false %}

{% extends \"_layouts/cp\" %}
{% set title = \"Routes\"|t('app') %}
{% set readOnly = not craft.app.config.general.allowAdminChanges %}

{% block actionButton %}
    {% if not readOnly %}
        <button type=\"button\" id=\"add-route-btn\" class=\"btn submit add icon\">{{ \"New route\"|t('app') }}</button>
    {% endif %}
{% endblock %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\routes\\\\RoutesAsset\") %}

{% do view.registerTranslations('app', [
    \"Add a token\",
    \"Are you sure you want to delete this route?\",
    \"Couldn’t save new route order.\",
    \"Couldn’t save route.\",
    \"Create a new route\",
    \"Edit Route\",
    \"Global\",
    \"If the URI looks like this\",
    \"Load this template\",
    \"New route order saved.\",
    \"Route deleted.\",
    \"Route Saved.\",
    \"The URI can’t begin with the {setting} config setting.\",
]) %}


{% set routes = craft.routes.getProjectConfigRoutes() %}

{% block main %}
    <div id=\"routes\">
        {% if readOnly %}
            <div id=\"content-notice\">
                {{ readOnlyNotice()|raw }}
            </div>
        {% endif %}

        <p id=\"noroutes\"{% if routes %} class=\"hidden\"{% endif %}>
            {{ \"No routes exist yet.\"|t('app') }}
        </p>

        {% for route in routes %}
            <div class=\"route{{ readOnly ? ' inactive' : '' }}\" data-uid=\"{{ route.uid }}\"{% if route.siteUid %} data-site-uid=\"{{ route.siteUid }}\"{% endif %}>
                <div class=\"uri-container\">
                    {%- apply spaceless %}
                        {% if craft.app.getIsMultiSite() %}
                            <span class=\"site\">{{ route.siteUid ? craft.app.sites.getSiteByUid(route.siteUid).name|t('site') : \"Global\"|t('app') }}</span>
                        {% endif %}
                        <span class=\"uri\">{{ route.uriDisplayHtml|raw }}</span>
                    {% endapply -%}
                </div>
                <div class=\"template\">{{ route.template }}</div>
            </div>
        {% endfor %}
    </div>
{% endblock %}


{% js %}
    Craft.routes.tokens = {
        {% for name, pattern in tokens %}
            {% if not loop.first %},{% endif %}
            \"{{ name|e('js') }}\": \"{{ pattern|e('js') }}\"
        {% endfor %}
    };
{% endjs %}
", "settings/routes", "/var/www/html/vendor/craftcms/cms/src/templates/settings/routes.twig");
    }
}
