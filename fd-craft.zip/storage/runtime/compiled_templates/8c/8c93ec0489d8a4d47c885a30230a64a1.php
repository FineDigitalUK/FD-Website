<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/customSelect */
class __TwigTemplate_31c791fe4ad730e53084f4b24024261c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/customSelect");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "_includes/forms/customSelect", 1)->unwrap();
        // line 2
        $macros["_v0"] = $this->macros["_v0"] = $this->loadTemplate("_includes/disclosuremenu.twig", "_includes/forms/customSelect", 2)->unwrap();
        // line 3
        yield "
";
        // line 4
        $context["id"] = (($context["id"]) ?? (("customselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 5
        $context["buttonId"] = (($context["buttonId"]) ?? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 5, $this->source); })()) . "-button")));
        // line 6
        $context["menuId"] = (($context["menuId"]) ?? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 6, $this->source); })()) . "-menu")));
        // line 7
        $context["inputId"] = (($context["inputId"]) ?? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 7, $this->source); })()) . "-input")));
        // line 8
        $context["value"] = (($context["value"]) ?? (""));
        // line 9
        $context["disabled"] = (($context["disabled"]) ?? (false));
        // line 10
        $context["selectedOption"] = (((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 10, $this->source); })())) ? (craft\helpers\ArrayHelper::firstWhere((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 10, $this->source); })()), function ($__o__) use ($context, $macros) { $context["o"] = $__o__; return (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 10, $this->source); })()), "value", [], "any", false, false, false, 10) == (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 10, $this->source); })())); })) : (null));
        // line 11
        $context["buttonAttributes"] = (($context["buttonAttribues"]) ?? ([]));
        // line 12
        if ((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 12, $this->source); })())) {
            // line 13
            yield "  ";
            $context["buttonAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["buttonAttributes"]) || array_key_exists("buttonAttributes", $context) ? $context["buttonAttributes"] : (function () { throw new RuntimeError('Variable "buttonAttributes" does not exist.', 13, $this->source); })()), ["disabled" => "disabled"]);
        }
        // line 15
        yield "
";
        // line 19
        yield "
";
        // line 20
        $context["buttonIconHtml"] = null;
        // line 21
        if (((((craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "icon", [], "any", true, true, false, 21) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "icon", [], "any", false, false, false, 21)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "icon", [], "any", false, false, false, 21)) : (null)) || ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "icon", [], "any", true, true, false, 21) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "icon", [], "any", false, false, false, 21)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "icon", [], "any", false, false, false, 21)) : (null)) === "0"))) {
            // line 22
            yield "    ";
            $context["buttonIconHtml"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 23
                yield "        ";
                yield $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["cp-icon", $this->getTemplateForMacro("macro_color", $context, 26, $this->getSourceContext())->macro_color(...[(((craft\helpers\Template::attribute($this->env, $this->source,                 // line 26
($context["selectedOption"] ?? null), "iconColor", [], "any", true, true, false, 26) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "iconColor", [], "any", false, false, false, 26)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "iconColor", [], "any", false, false, false, 26)) : (null))])]), "html" => craft\helpers\Cp::iconSvg(craft\helpers\Template::attribute($this->env, $this->source,                 // line 28
(isset($context["selectedOption"]) || array_key_exists("selectedOption", $context) ? $context["selectedOption"] : (function () { throw new RuntimeError('Variable "selectedOption" does not exist.', 28, $this->source); })()), "icon", [], "any", false, false, false, 28))]);
                // line 29
                yield "
    ";
                yield from [];
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
        }
        // line 32
        yield "
";
        // line 33
        $context["buttonLabel"] = (((isset($context["selectedOption"]) || array_key_exists("selectedOption", $context) ? $context["selectedOption"] : (function () { throw new RuntimeError('Variable "selectedOption" does not exist.', 33, $this->source); })())) ? ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "label", [], "any", true, true, false, 33) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "label", [], "any", false, false, false, 33)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["selectedOption"] ?? null), "label", [], "any", false, false, false, 33)) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["selectedOption"]) || array_key_exists("selectedOption", $context) ? $context["selectedOption"] : (function () { throw new RuntimeError('Variable "selectedOption" does not exist.', 33, $this->source); })()), "labelHtml", [], "any", false, false, false, 33)))) : ((($context["defaultButtonLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app")))));
        // line 34
        yield "
";
        // line 35
        ob_start();
        // line 43
        yield "  ";
        yield $macros["forms"]->getTemplateForMacro("macro_button", $context, 43, $this->getSourceContext())->macro_button(...[["id" =>         // line 44
(isset($context["buttonId"]) || array_key_exists("buttonId", $context) ? $context["buttonId"] : (function () { throw new RuntimeError('Variable "buttonId" does not exist.', 44, $this->source); })()), "iconHtml" =>         // line 45
(isset($context["buttonIconHtml"]) || array_key_exists("buttonIconHtml", $context) ? $context["buttonIconHtml"] : (function () { throw new RuntimeError('Variable "buttonIconHtml" does not exist.', 45, $this->source); })()), "label" =>         // line 46
(isset($context["buttonLabel"]) || array_key_exists("buttonLabel", $context) ? $context["buttonLabel"] : (function () { throw new RuntimeError('Variable "buttonLabel" does not exist.', 46, $this->source); })()), "class" => ["menubtn"], "attributes" => ((        // line 48
$context["buttonAttributes"]) ?? ([]))]]);
        // line 49
        yield "

  ";
        // line 51
        if ( !(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 51, $this->source); })())) {
            // line 52
            yield "    ";
            ob_start();
            // line 56
            yield "      <ul class=\"padded\">
        ";
            // line 57
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 57, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["option"]) {
                // line 58
                yield "          <li>
            ";
                // line 59
                ob_start();
                // line 68
                yield "              ";
                if (((((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "icon", [], "any", true, true, false, 68) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "icon", [], "any", false, false, false, 68)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "icon", [], "any", false, false, false, 68)) : (null)) || ((((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "icon", [], "any", true, true, false, 68) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "icon", [], "any", false, false, false, 68)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "icon", [], "any", false, false, false, 68)) : (null)) === "0"))) {
                    // line 69
                    yield "                ";
                    yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["icon", $this->getTemplateForMacro("macro_color", $context, 72, $this->getSourceContext())->macro_color(...[(((craft\helpers\Template::attribute($this->env, $this->source,                     // line 72
$context["option"], "iconColor", [], "any", true, true, false, 72) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "iconColor", [], "any", false, false, false, 72)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "iconColor", [], "any", false, false, false, 72)) : (null))])]), "html" => craft\helpers\Cp::iconSvg(craft\helpers\Template::attribute($this->env, $this->source,                     // line 74
$context["option"], "icon", [], "any", false, false, false, 74))]);
                    // line 75
                    yield "
              ";
                }
                // line 77
                yield "              <span class=\"label\">";
                (((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "label", [], "any", true, true, false, 77) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "label", [], "any", false, false, false, 77)))) ? (yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "label", [], "any", false, false, false, 77), "html", null, true)) : (yield craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "labelHtml", [], "any", false, false, false, 77)));
                yield "</span>
            ";
                echo craft\helpers\Html::tag("button", ob_get_clean(), $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["menu-item" => true, "sel" => (craft\helpers\Template::attribute($this->env, $this->source,                 // line 62
$context["option"], "value", [], "any", false, false, false, 62) == (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 62, $this->source); })()))])), "data" => ["value" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 65
$context["option"], "value", [], "any", false, false, false, 65)]], (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 67
$context["option"], "attributes", [], "any", true, true, false, 67) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "attributes", [], "any", false, false, false, 67)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "attributes", [], "any", false, false, false, 67)) : ([])), true));
                // line 79
                yield "          </li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['option'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 81
            yield "      </ul>
    ";
            echo craft\helpers\Html::tag("div", ob_get_clean(), $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>             // line 53
(isset($context["menuId"]) || array_key_exists("menuId", $context) ? $context["menuId"] : (function () { throw new RuntimeError('Variable "menuId" does not exist.', 53, $this->source); })()), "class" => ["menu"]], ((            // line 55
$context["menuAttributes"]) ?? ([])), true));
            // line 83
            yield "
    ";
            // line 84
            if ((($context["name"]) ?? (false))) {
                // line 85
                yield "      ";
                yield craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 85, $this->source); })()), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 85, $this->source); })()), ["id" =>                 // line 86
(isset($context["inputId"]) || array_key_exists("inputId", $context) ? $context["inputId"] : (function () { throw new RuntimeError('Variable "inputId" does not exist.', 86, $this->source); })())]);
                // line 87
                yield "
    ";
            }
            // line 89
            yield "  ";
        }
        echo craft\helpers\Html::tag("div", ob_get_clean(), $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["custom-select" => true, "disabled" =>         // line 38
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 38, $this->source); })())])), "id" =>         // line 40
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 40, $this->source); })()), "data" => ["value" =>         // line 41
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 41, $this->source); })())]], ((        // line 42
$context["attributes"]) ?? ([])), true));
        // line 91
        yield "
";
        // line 92
        if ( !(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 92, $this->source); })())) {
            // line 93
            yield "  ";
            ob_start();
            // line 94
            yield "    (() => {
      const \$container = \$('#";
            // line 95
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 95, $this->source); })())), "html", null, true);
            yield "');
      const \$button = \$('#";
            // line 96
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["buttonId"]) || array_key_exists("buttonId", $context) ? $context["buttonId"] : (function () { throw new RuntimeError('Variable "buttonId" does not exist.', 96, $this->source); })())), "html", null, true);
            yield "');
      const \$buttonFlex = \$button.find('.inline-flex:first');
      const \$input = \$('#";
            // line 98
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["inputId"]) || array_key_exists("inputId", $context) ? $context["inputId"] : (function () { throw new RuntimeError('Variable "inputId" does not exist.', 98, $this->source); })())), "html", null, true);
            yield "');
      const menubtn = \$button
        .menubtn()
        .data('menubtn');
        if (menubtn) {
          menubtn
            .on('optionSelect', (ev) => {
              const \$option = \$(ev.option);
              const \$icon = \$option.find('.icon');
              const \$label = \$option.find('.label');
              let labelHtml = '';
              if (\$icon.length) {
                labelHtml += \$icon.clone().removeClass('icon').addClass('cp-icon').prop('outerHTML');
              }
              labelHtml += `<div class=\"label\">\${\$label.html()}</div>`;
              \$buttonFlex.html(labelHtml);
              \$input.val(\$option.data('value'));
              menubtn.menu.\$options.removeClass('sel');
              \$option.addClass('sel');
              \$container.data('value', \$option.data('value'));
              \$container.trigger('change');
            });
        }
    })();
  ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/customSelect");
        yield from [];
    }

    // line 16
    public function macro_color($color = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "color" => $color,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "color");
            // line 17
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($this->env->getTest('instance of')->getCallable()((isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 17, $this->source); })()), "craft\\enums\\Color")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 17, $this->source); })()), "value", [], "any", false, false, false, 17)) : ((isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 17, $this->source); })()))), "html", null, true);
            craft\helpers\Template::endProfile("macro", "color");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/customSelect";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  255 => 17,  242 => 16,  209 => 98,  204 => 96,  200 => 95,  197 => 94,  194 => 93,  192 => 92,  189 => 91,  187 => 42,  186 => 41,  185 => 40,  184 => 38,  181 => 89,  177 => 87,  175 => 86,  173 => 85,  171 => 84,  168 => 83,  166 => 55,  165 => 53,  162 => 81,  155 => 79,  153 => 67,  152 => 65,  151 => 62,  146 => 77,  142 => 75,  140 => 74,  139 => 72,  137 => 69,  134 => 68,  132 => 59,  129 => 58,  125 => 57,  122 => 56,  119 => 52,  117 => 51,  113 => 49,  111 => 48,  110 => 46,  109 => 45,  108 => 44,  106 => 43,  104 => 35,  101 => 34,  99 => 33,  96 => 32,  90 => 29,  88 => 28,  87 => 26,  85 => 23,  82 => 22,  80 => 21,  78 => 20,  75 => 19,  72 => 15,  68 => 13,  66 => 12,  64 => 11,  62 => 10,  60 => 9,  58 => 8,  56 => 7,  54 => 6,  52 => 5,  50 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms.twig' as forms %}
{% from '_includes/disclosuremenu.twig' import item as itemMacro %}

{% set id = id ?? \"customselect#{random()}\" %}
{% set buttonId = buttonId ?? \"#{id}-button\" %}
{% set menuId = menuId ?? \"#{id}-menu\" %}
{% set inputId = inputId ?? \"#{id}-input\" %}
{% set value = value ?? '' %}
{% set disabled = disabled ?? false %}
{% set selectedOption = value ? options|firstWhere(o => o.value == value) : null %}
{% set buttonAttributes = buttonAttribues ?? {} %}
{% if disabled %}
  {% set buttonAttributes = buttonAttributes|merge({'disabled': 'disabled'}) %}
{% endif %}

{% macro color(color) %}
  {{- color is instance of ('craft\\\\enums\\\\Color') ? color.value : color -}}
{% endmacro %}

{% set buttonIconHtml = null %}
{% if (selectedOption.icon ?? null) or (selectedOption.icon ?? null) is same as('0') %}
    {% set buttonIconHtml %}
        {{ tag('div', {
            class: [
                'cp-icon',
                _self.color(selectedOption.iconColor ?? null),
            ]|filter,
            html: iconSvg(selectedOption.icon),
        }) }}
    {% endset %}
{% endif %}

{% set buttonLabel = selectedOption ? (selectedOption.label ?? selectedOption.labelHtml|raw) : defaultButtonLabel ?? 'Choose'|t('app')  %}

{% tag 'div' with {
  class: {
    'custom-select': true,
    disabled: disabled,
  }|filter|keys,
  id: id,
  data: {value},
}|merge(attributes ?? {}, recursive=true) %}
  {{ forms.button({
    id: buttonId,
    iconHtml: buttonIconHtml,
    label: buttonLabel,
    class: ['menubtn'],
    attributes: buttonAttributes ?? {},
  }) }}

  {% if not disabled %}
    {% tag 'div' with {
      id: menuId,
      class: ['menu']
    }|merge(menuAttributes ?? {}, recursive=true) %}
      <ul class=\"padded\">
        {% for option in options %}
          <li>
            {% tag 'button' with {
              class: {
                'menu-item': true,
                sel: option.value == value,
              }|filter|keys,
              data: {
                value: option.value,
              },
            }|merge(option.attributes ?? {}, recursive=true) %}
              {% if (option.icon ?? null) or (option.icon ?? null) is same as('0') %}
                {{ tag('span', {
                  class: [
                    'icon',
                    _self.color(option.iconColor ?? null),
                  ]|filter,
                  html: iconSvg(option.icon),
                }) }}
              {% endif %}
              <span class=\"label\">{{ option.label ?? option.labelHtml|raw }}</span>
            {% endtag %}
          </li>
        {% endfor %}
      </ul>
    {% endtag %}

    {% if name ?? false %}
      {{ hiddenInput(name, value, {
        id: inputId,
      }) }}
    {% endif %}
  {% endif %}
{% endtag %}

{% if not disabled %}
  {% js %}
    (() => {
      const \$container = \$('#{{ id|namespaceInputId }}');
      const \$button = \$('#{{ buttonId|namespaceInputId }}');
      const \$buttonFlex = \$button.find('.inline-flex:first');
      const \$input = \$('#{{ inputId|namespaceInputId }}');
      const menubtn = \$button
        .menubtn()
        .data('menubtn');
        if (menubtn) {
          menubtn
            .on('optionSelect', (ev) => {
              const \$option = \$(ev.option);
              const \$icon = \$option.find('.icon');
              const \$label = \$option.find('.label');
              let labelHtml = '';
              if (\$icon.length) {
                labelHtml += \$icon.clone().removeClass('icon').addClass('cp-icon').prop('outerHTML');
              }
              labelHtml += `<div class=\"label\">\${\$label.html()}</div>`;
              \$buttonFlex.html(labelHtml);
              \$input.val(\$option.data('value'));
              menubtn.menu.\$options.removeClass('sel');
              \$option.addClass('sel');
              \$container.data('value', \$option.data('value'));
              \$container.trigger('change');
            });
        }
    })();
  {% endjs %}
{% endif %}
", "_includes/forms/customSelect", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/customSelect.twig");
    }
}
