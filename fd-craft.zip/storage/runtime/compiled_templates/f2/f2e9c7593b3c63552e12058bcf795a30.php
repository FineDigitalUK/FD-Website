<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/generatedFieldsTable */
class __TwigTemplate_950dbb98e41a2d9c96834b9b8f4fabd1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/generatedFieldsTable");
        // line 1
        $context["fieldLayout"] = (($context["fieldLayout"]) ?? (Craft::createObject("craft\\models\\FieldLayout")));
        // line 2
        yield craft\helpers\Cp::generatedFieldsTableHtml((isset($context["fieldLayout"]) || array_key_exists("fieldLayout", $context) ? $context["fieldLayout"] : (function () { throw new RuntimeError('Variable "fieldLayout" does not exist.', 2, $this->source); })()), $context);
        yield "
";
        craft\helpers\Template::endProfile("template", "_includes/forms/generatedFieldsTable");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/generatedFieldsTable";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set fieldLayout = fieldLayout ?? create('craft\\\\models\\\\FieldLayout') %}
{{ generatedFieldsTable(fieldLayout, _context)|raw }}
", "_includes/forms/generatedFieldsTable", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/generatedFieldsTable.twig");
    }
}
