<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* about */
class __TwigTemplate_f0a44046dca64179b381278ee70e01e2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "about");
        craft\helpers\Template::preloadSingles(['entry', 'values', 'value', 'siteUrl', 'team', 'member', 'testimonials', 'testimonial', 'ctaButtonLink', 'ctaButtonText']);
        // line 3
        $context["title"] = (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : null)), "title", [], "any", true, true, false, 3) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 3, $this->source); })())), "title", [], "any", false, false, false, 3)))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 3, $this->source); })())), "title", [], "any", false, false, false, 3)) : ("About Fine Digital"));
        // line 1
        $this->parent = $this->loadTemplate("_layout", "about", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "about");
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 6
        yield "
";
        // line 8
        yield "<section class=\"relative min-h-[60vh] flex items-center justify-center overflow-hidden\">
  <!-- Photo background with overlay -->
  <div class=\"about-hero-photo-bg\">
    <img src=\"/assets/layout/plamen.webp\" alt=\"Plamen working at Fine Digital\" class=\"w-full h-full object-cover\"/>
    <div class=\"absolute inset-0 bg-slate-900/70\"></div>
  </div>
  ";
        // line 15
        yield "  ";
        // line 16
        yield "
  <!-- Animated colorful orbs (homepage style) -->
  <div class=\"about-hero-orb about-hero-yellow\" style=\"top:12%;left:8%;width:40px;height:40px;\"></div>
  <div class=\"about-hero-orb about-hero-pink about-hero-orb-delayed\" style=\"top:60%;right:10%;width:32px;height:32px;\"></div>
  <div class=\"about-hero-orb about-hero-blue\" style=\"bottom:18%;left:30%;width:48px;height:48px;\"></div>
  <div class=\"about-hero-orb about-hero-green about-hero-orb-delayed\" style=\"top:30%;right:18%;width:28px;height:28px;\"></div>
  <!-- Minimal floating dots for extra accent (optional) -->
  <div class=\"floating-dot\" style=\"top:22%;left:22%;animation-delay:1.2s;\"></div>
  <div class=\"floating-dot\" style=\"top:70%;right:22%;animation-delay:2.7s;\"></div>
  <!-- Shimmer overlay -->
  <div class=\"about-hero-shimmer\"></div>
  <!-- Content -->
  <div class=\"relative z-10 text-center px-6 max-w-4xl mx-auto\">
    <div class=\"space-y-6\">
      <h1 class=\"about-hero-headline text-4xl md:text-6xl font-extrabold leading-tight\">
        <span class=\"block font-extrabold\" style=\"color: #fff;\">Discover our story 2</span>
        <span class=\"block animate-gradient-x bg-clip-text text-transparent font-bold md:text-5xl mt-2\">commitment to excellence</span>
      </h1>
      <p class=\"about-hero-subheadline text-xl max-w-3xl mx-auto\">
        From Sofia to Worthing - A journey of perseverance, friendship, and digital innovation
      </p>
    </div>
  </div>
</section>

";
        // line 42
        yield "<section class=\"relative py-24 bg-white dark:bg-navy/80\">
  <div class=\"absolute left-0 top-0 w-32 h-32 bg-gradient-to-br from-brand/10 to-blue/10 rounded-full blur-2xl opacity-30 pointer-events-none\"></div>
  <div class=\"absolute right-0 bottom-0 w-40 h-40 bg-gradient-to-tr from-blue/10 to-brand/10 rounded-full blur-3xl opacity-20 pointer-events-none\"></div>
  <div class=\"max-w-3xl mx-auto px-6\">
    <div class=\"glass-effect premium-shadow rounded-3xl p-10 md:p-16 text-center\">
      <h2 class=\"text-3xl md:text-4xl font-bold text-navy dark:text-white mb-8\">Our Journey</h2>
      <div class=\"relative\">
        <div class=\"hidden md:block absolute left-1/2 top-0 h-full w-1 bg-gradient-to-b from-brand/40 to-blue/40 -translate-x-1/2\"></div>
        <div class=\"space-y-12 relative z-10\">
          <div class=\"flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-12\">
            <div class=\"flex-shrink-0 w-20 h-20 rounded-full bg-gradient-to-br from-brand to-blue flex items-center justify-center shadow-lg border-4 border-white dark:border-navy/40\">
              <span class=\"text-2xl font-bold text-white\">Sofia</span>
            </div>
            <div class=\"text-left md:text-base text-charcoal dark:text-gray-200\">
              <span class=\"block font-semibold text-brand mb-1\">Start</span>
              <span class=\"block\">Plamen's journey begins in Sofia, Bulgaria.</span>
            </div>
          </div>
          <div class=\"flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-12\">
            <div class=\"flex-shrink-0 w-20 h-20 rounded-full bg-gradient-to-br from-blue to-brand flex items-center justify-center shadow-lg border-4 border-white dark:border-navy/40\">
              <span class=\"text-2xl font-bold text-white\">Wales</span>
            </div>
            <div class=\"text-left md:text-base text-charcoal dark:text-gray-200\">
              <span class=\"block font-semibold text-blue mb-1\">2010</span>
              <span class=\"block\">Arrives in a quiet Welsh village, working as a car valet and learning English.</span>
            </div>
          </div>
          <div class=\"flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-12\">
            <div class=\"flex-shrink-0 w-20 h-20 rounded-full bg-gradient-to-br from-brand to-blue flex items-center justify-center shadow-lg border-4 border-white dark:border-navy/40\">
              <span class=\"text-2xl font-bold text-white\">Brighton</span>
            </div>
            <div class=\"text-left md:text-base text-charcoal dark:text-gray-200\">
              <span class=\"block font-semibold text-brand mb-1\">2013</span>
              <span class=\"block\">Studies Business & Management at Brighton University, graduates in 2016.</span>
            </div>
          </div>
          <div class=\"flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-12\">
            <div class=\"flex-shrink-0 w-20 h-20 rounded-full bg-gradient-to-br from-blue to-brand flex items-center justify-center shadow-lg border-4 border-white dark:border-navy/40\">
              <span class=\"text-2xl font-bold text-white\">Worthing</span>
            </div>
            <div class=\"text-left md:text-base text-charcoal dark:text-gray-200\">
              <span class=\"block font-semibold text-blue mb-1\">2016+</span>
              <span class=\"block\">Fine Digital is founded with Lubo. From humble beginnings to a thriving digital agency serving clinics across the UK and beyond.</span>
            </div>
          </div>
        </div>
      </div>
      <div class=\"mt-12 text-lg md:text-xl text-charcoal dark:text-gray-200 leading-relaxed text-left\">
        ";
        // line 90
        (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : null)), "storyContent", [], "any", true, true, false, 90) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 90, $this->source); })())), "storyContent", [], "any", false, false, false, 90)))) ? (yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 90, $this->source); })())), "storyContent", [], "any", false, false, false, 90), "html", null, true)) : (yield Twig\Extension\CoreExtension::nl2br("So, with a leap of faith, I set my sights on the UK, seeking new horizons and fresh opportunities. In 2010, I landed in a quiet Welsh village, armed with little more than determination and a knack for hard work. Starting as a car valet, I gradually found my way to Worthing, a coastal gem where fate reunited me with my childhood friend Lubo.

As my English flourished, so did my aspirations. In 2013, fueled by newfound confidence, I embarked on an academic journey at Brighton University, emerging three years later armed with a degree in Business & Management.

Post-graduation, the entrepreneurial bug bit me hard. Fueled by a passion for web design and development, I hatched a plan to establish a digital agency. With Lubo by my side, Fine Digital was born, a testament to our shared vision and determination.

The early days were far from easy. Juggling the demands of a fledgling business alongside my role as a support worker for West Sussex County Council tested my determination. Our focus on serving local businesses, coupled with word-of-mouth referrals, became the cornerstone of our growth.

Today, as I reflect on the journey from Sofia to Worthing, I'm filled with gratitude for the challenges that shaped me and the friendships that sustained me. Fine Digital stands as a testament to the power of perseverance, friendship, and unwavering belief in one's dreams. And with Lubo by my side, I know that together, we'll continue to scale new heights, one satisfied client at a time.

As the sun sets on our journey thus far, I'm proud to say that Fine Digital isn't just a dream; it's a thriving reality. Our team has steadily grown, each member bringing their unique talents and passion to the table. With every project we undertake, we're reminded that success is not just about individual achievement, but the collective effort of a dedicated team.")));
        yield "
      </div>
    </div>
  </div>
</section>

";
        // line 97
        yield "<section class=\"relative py-24 bg-slate-50 dark:bg-navy/90\">
  <div class=\"max-w-6xl mx-auto px-6\">
    <div class=\"text-center mb-16\">
      <h2 class=\"text-4xl font-bold mb-4 text-brand\">What Sets Us Apart</h2>
      <p class=\"text-lg text-charcoal/80 dark:text-gray-200 max-w-2xl mx-auto\">We are a small web design agency based in Brighton, Sussex, serving clients across the UK and abroad. Fine Digital is known for professionalism, respect, and successful web and marketing projects.</p>
    </div>
    <div class=\"grid md:grid-cols-4 gap-8\">
      ";
        // line 104
        $context["values"] = (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : null)), "valuesGrid", [], "any", true, true, false, 104) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 104, $this->source); })())), "valuesGrid", [], "any", false, false, false, 104)))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 104, $this->source); })())), "valuesGrid", [], "any", false, false, false, 104)) : ([["icon" => "star", "title" => "Bespoke Design", "description" => "We create custom, functional websites aimed at converting users into customers."], ["icon" => "heart", "title" => "Passionate Team", "description" => "Each of us loves what we do, and that spirit translates into the quality of our work."], ["icon" => "handshake", "title" => "True Partnership", "description" => "Working with clients who love their work creates a fun, wonderful partnership."], ["icon" => "rocket", "title" => "Results-Driven", "description" => "We focus on delivering measurable results and long-term growth for our clients."]]));
        // line 126
        yield "      ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (craft\helpers\Template::fallbackExists("values") ? craft\helpers\Template::fallback("values") : (function () { throw new RuntimeError('Variable "values" does not exist.', 126, $this->source); })())));
        foreach ($context['_seq'] as $context["_key"] => $context["value"]) {
            // line 127
            yield "      <div class=\"glass-effect premium-shadow rounded-2xl p-8 flex flex-col items-center text-center border border-gray-100 dark:border-navy/40\">
        <div class=\"w-16 h-16 mb-4 flex items-center justify-center rounded-full bg-gradient-to-br from-brand to-blue shadow-lg\">
          ";
            // line 129
            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["value"], "icon", [], "any", false, false, false, 129) == "star")) {
                // line 130
                yield "            <svg class=\"w-8 h-8 text-white\" fill=\"currentColor\" viewBox=\"0 0 20 20\"><polygon points=\"10 1.5 12.59 7.36 18.9 7.64 13.97 11.64 15.54 17.86 10 14.27 4.46 17.86 6.03 11.64 1.1 7.64 7.41 7.36 10 1.5\"/></svg>
          ";
            } elseif ((craft\helpers\Template::attribute($this->env, $this->source,             // line 131
$context["value"], "icon", [], "any", false, false, false, 131) == "heart")) {
                // line 132
                yield "            <svg class=\"w-8 h-8 text-white\" fill=\"currentColor\" viewBox=\"0 0 20 20\"><path d=\"M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z\"/></svg>
          ";
            } elseif ((craft\helpers\Template::attribute($this->env, $this->source,             // line 133
$context["value"], "icon", [], "any", false, false, false, 133) == "handshake")) {
                // line 134
                yield "            <svg class=\"w-8 h-8 text-white\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\"><path d=\"M12 19l-7-7 7-7 7 7-7 7z\"/></svg>
          ";
            } elseif ((craft\helpers\Template::attribute($this->env, $this->source,             // line 135
$context["value"], "icon", [], "any", false, false, false, 135) == "rocket")) {
                // line 136
                yield "            <svg class=\"w-8 h-8 text-white\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\"><path d=\"M5 13l4 4L19 7\"/></svg>
          ";
            }
            // line 138
            yield "        </div>
        <h3 class=\"text-xl font-semibold mb-2 text-navy dark:text-white\">";
            // line 139
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["value"], "title", [], "any", false, false, false, 139), "html", null, true);
            yield "</h3>
        <p class=\"text-charcoal/80 dark:text-gray-200\">";
            // line 140
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["value"], "description", [], "any", false, false, false, 140), "html", null, true);
            yield "</p>
      </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 143
        yield "    </div>
  </div>
</section>

";
        // line 148
        yield "<section class=\"relative py-24 bg-white dark:bg-navy/80\">
  <div class=\"max-w-5xl mx-auto px-6\">
    <div class=\"text-center mb-16\">
      <h2 class=\"text-4xl font-bold mb-4 text-brand\">Meet the Team</h2>
      <p class=\"text-lg text-charcoal/80 dark:text-gray-200 max-w-2xl mx-auto\">Our team brings together a wealth of experience, creativity, and passion for digital excellence.</p>
    </div>
    <div class=\"grid md:grid-cols-2 gap-10\">
      ";
        // line 155
        $context["team"] = (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : null)), "teamMembers", [], "any", true, true, false, 155) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 155, $this->source); })())), "teamMembers", [], "any", false, false, false, 155)))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 155, $this->source); })())), "teamMembers", [], "any", false, false, false, 155)) : ([["photo" => (        // line 157
(isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 157, $this->source); })())) . "assets/layout/plamen.webp"), "name" => "Plamen", "role" => "Co-Founder", "bio" => "Plamen leads Fine Digital with a passion for web design, business strategy, and client success."], ["photo" => (        // line 163
(isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 163, $this->source); })())) . "assets/layout/logo.webp"), "name" => "Lubo", "role" => "Co-Founder", "bio" => "Lubo brings technical expertise and a creative eye to every project."]]));
        // line 169
        yield "      ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["team"]) || array_key_exists("team", $context) ? $context["team"] : (craft\helpers\Template::fallbackExists("team") ? craft\helpers\Template::fallback("team") : (function () { throw new RuntimeError('Variable "team" does not exist.', 169, $this->source); })())));
        foreach ($context['_seq'] as $context["_key"] => $context["member"]) {
            // line 170
            yield "      <div class=\"glass-effect premium-shadow rounded-2xl p-8 flex flex-col items-center text-center border border-gray-100 dark:border-navy/40\">
        <img src=\"";
            // line 171
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["member"], "photo", [], "any", false, false, false, 171), "html", null, true);
            yield "\" alt=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["member"], "name", [], "any", false, false, false, 171), "html", null, true);
            yield "\" class=\"w-32 h-32 md:w-40 md:h-40 lg:w-48 lg:h-48 object-cover rounded-full border-4 border-brand shadow-lg mx-auto mb-6\" loading=\"lazy\">
        <h3 class=\"text-xl font-bold text-navy dark:text-white mb-1\">";
            // line 172
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["member"], "name", [], "any", false, false, false, 172), "html", null, true);
            yield "</h3>
        <div class=\"text-brand font-semibold mb-2\">";
            // line 173
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["member"], "role", [], "any", false, false, false, 173), "html", null, true);
            yield "</div>
        <p class=\"text-charcoal/80 dark:text-gray-200\">";
            // line 174
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["member"], "bio", [], "any", false, false, false, 174), "html", null, true);
            yield "</p>
      </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['member'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 177
        yield "    </div>
  </div>
</section>

";
        // line 182
        yield "<section class=\"relative py-24 bg-slate-50 dark:bg-navy/90\">
  <div class=\"max-w-5xl mx-auto px-6\">
    <div class=\"text-center mb-16\">
      <h2 class=\"text-3xl md:text-4xl font-extrabold text-navy dark:text-white mb-4\">What Our Clients Say</h2>
      <p class=\"text-lg text-charcoal/80 dark:text-gray-200 max-w-2xl mx-auto\">Real feedback from clinics and healthcare professionals we've helped grow.</p>
    </div>
    <div class=\"grid md:grid-cols-3 gap-10\">
      ";
        // line 189
        $context["testimonials"] = (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : null)), "testimonials", [], "any", true, true, false, 189) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 189, $this->source); })())), "testimonials", [], "any", false, false, false, 189)))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 189, $this->source); })())), "testimonials", [], "any", false, false, false, 189)) : ([["content" => "I couldn't be without Plamen and his team for the website support. Having been hugely disappointed when I got over promised (and hugely overcharged) for an initial website to be made with a different company who took 12 months to complete, and would take a further 2/3 months to make the smallest change I was at my wits end. I'd lost confidence in the company and got recommended Plamen. I told Plamen about my previous experience and just asked for him to be upfront with any timeline to complete work. He went above and beyond! I can't express my gratitude with his professionalism and speed at which he gets tasks done.", "author" => "Clinic Owner", "rating" => 5, "company" => "Private Clinic"], ["content" => "Amazing service from start to finish!!! Extremely professional, accurate and supportive. I will highly recommend Plamen in Fine Digital to anyone looking for this kind of service.", "author" => "Business Owner", "rating" => 5, "company" => "Aesthetics Business"], ["content" => "Nothing but good things to say about Fine Digital. Got the site up running very quickly from first consultation. Will use again. A+. Thanks Plamen", "author" => "Entrepreneur", "rating" => 5, "company" => "Startup"], ["content" => "Fine Digital set up my website for the purpose of informing and detailing what my business provides. I also had a very slick booking system added to my website that my clients have given very positive feedback about.", "author" => "Therapist", "rating" => 5, "company" => "Therapy Practice"]]));
        // line 215
        yield "      ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["testimonials"]) || array_key_exists("testimonials", $context) ? $context["testimonials"] : (craft\helpers\Template::fallbackExists("testimonials") ? craft\helpers\Template::fallback("testimonials") : (function () { throw new RuntimeError('Variable "testimonials" does not exist.', 215, $this->source); })())));
        foreach ($context['_seq'] as $context["_key"] => $context["testimonial"]) {
            // line 216
            yield "      <div class=\"bg-white dark:bg-navy/70 glass-effect premium-shadow rounded-2xl shadow-lg p-8 flex flex-col items-center text-center border border-gray-100 dark:border-navy/40\" itemscope itemtype=\"https://schema.org/Review\">
        <div class=\"flex items-center mb-4\">
          <img src=\"";
            // line 218
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 218, $this->source); })())), "html", null, true);
            yield "assets/layout/testimonial.jpg\" alt=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["testimonial"], "author", [], "any", false, false, false, 218), "html", null, true);
            yield "\" class=\"w-14 h-14 rounded-full object-cover border-2 border-brand shadow-md mr-3\">
          <div>
            <div class=\"flex items-center justify-center mb-1\">
              ";
            // line 221
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(range(1, craft\helpers\Template::attribute($this->env, $this->source, $context["testimonial"], "rating", [], "any", false, false, false, 221)));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 222
                yield "                <svg class=\"w-5 h-5 text-yellow-400\" fill=\"currentColor\" viewBox=\"0 0 20 20\"><polygon points=\"10 1.5 12.59 7.36 18.9 7.64 13.97 11.64 15.54 17.86 10 14.27 4.46 17.86 6.03 11.64 1.1 7.64 7.41 7.36 10 1.5\"/></svg>
              ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['i'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 224
            yield "            </div>
            <span class=\"font-semibold text-navy dark:text-white\" itemprop=\"author\">";
            // line 225
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["testimonial"], "author", [], "any", false, false, false, 225), "html", null, true);
            yield "</span>
            <div class=\"text-xs text-charcoal/60 dark:text-gray-400\" itemprop=\"publisher\">";
            // line 226
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["testimonial"], "company", [], "any", false, false, false, 226), "html", null, true);
            yield "</div>
          </div>
        </div>
        <p class=\"text-charcoal/80 dark:text-gray-200\" itemprop=\"reviewBody\">\"";
            // line 229
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["testimonial"], "content", [], "any", false, false, false, 229), "html", null, true);
            yield "\"</p>
        <meta itemprop=\"reviewRating\" content=\"";
            // line 230
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["testimonial"], "rating", [], "any", false, false, false, 230), "html", null, true);
            yield "\">
      </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['testimonial'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 233
        yield "    </div>
  </div>
</section>

";
        // line 238
        yield "<section id=\"contact\" class=\"relative py-24 bg-gradient-to-br from-navy via-slate-900 to-charcoal\">
  <div class=\"absolute inset-0 bg-gradient-to-r from-brand/10 to-blue/10 opacity-50\"></div>
  <div class=\"relative z-10 max-w-3xl mx-auto px-6 text-center\">
    <h2 class=\"text-4xl md:text-5xl font-extrabold text-white mb-6\">";
        // line 241
        (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : null)), "ctaHeadline", [], "any", true, true, false, 241) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 241, $this->source); })())), "ctaHeadline", [], "any", false, false, false, 241)))) ? (yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 241, $this->source); })())), "ctaHeadline", [], "any", false, false, false, 241), "html", null, true)) : (yield "Ready to Grow Your Clinic?"));
        yield "</h2>
    <p class=\"text-xl text-white/90 mb-8 max-w-2xl mx-auto\">";
        // line 242
        (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : null)), "ctaText", [], "any", true, true, false, 242) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 242, $this->source); })())), "ctaText", [], "any", false, false, false, 242)))) ? (yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 242, $this->source); })())), "ctaText", [], "any", false, false, false, 242), "html", null, true)) : (yield "Book a free strategy call and discover how minimalist design can drive real results for your clinic."));
        yield "</p>
    ";
        // line 243
        $context["ctaButtonText"] = (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : null)), "ctaButtonText", [], "any", true, true, false, 243) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 243, $this->source); })())), "ctaButtonText", [], "any", false, false, false, 243)))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 243, $this->source); })())), "ctaButtonText", [], "any", false, false, false, 243)) : ("Book Your Free Consultation"));
        // line 244
        yield "    ";
        $context["ctaButtonLink"] = (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : null)), "ctaButtonLink", [], "any", true, true, false, 244) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 244, $this->source); })())), "ctaButtonLink", [], "any", false, false, false, 244)))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 244, $this->source); })())), "ctaButtonLink", [], "any", false, false, false, 244)) : ("#"));
        // line 245
        yield "    <a href=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["ctaButtonLink"]) || array_key_exists("ctaButtonLink", $context) ? $context["ctaButtonLink"] : (craft\helpers\Template::fallbackExists("ctaButtonLink") ? craft\helpers\Template::fallback("ctaButtonLink") : (function () { throw new RuntimeError('Variable "ctaButtonLink" does not exist.', 245, $this->source); })())), "html", null, true);
        yield "\" class=\"inline-block px-12 py-4 bg-brand text-white font-bold text-lg rounded-xl shadow-lg hover:bg-brand/90 transition transform hover:-translate-y-1 hover:scale-105\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["ctaButtonText"]) || array_key_exists("ctaButtonText", $context) ? $context["ctaButtonText"] : (craft\helpers\Template::fallbackExists("ctaButtonText") ? craft\helpers\Template::fallback("ctaButtonText") : (function () { throw new RuntimeError('Variable "ctaButtonText" does not exist.', 245, $this->source); })())), "html", null, true);
        yield "</a>
  </div>
</section>

";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "about";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  376 => 245,  373 => 244,  371 => 243,  367 => 242,  363 => 241,  358 => 238,  352 => 233,  343 => 230,  339 => 229,  333 => 226,  329 => 225,  326 => 224,  319 => 222,  315 => 221,  307 => 218,  303 => 216,  298 => 215,  296 => 189,  287 => 182,  281 => 177,  272 => 174,  268 => 173,  264 => 172,  258 => 171,  255 => 170,  250 => 169,  248 => 163,  247 => 157,  246 => 155,  237 => 148,  231 => 143,  222 => 140,  218 => 139,  215 => 138,  211 => 136,  209 => 135,  206 => 134,  204 => 133,  201 => 132,  199 => 131,  196 => 130,  194 => 129,  190 => 127,  185 => 126,  183 => 104,  174 => 97,  155 => 90,  105 => 42,  78 => 16,  76 => 15,  68 => 8,  65 => 6,  57 => 5,  51 => 1,  49 => 3,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layout\" %}

{% set title = entry.title ?? 'About Fine Digital' %}

{% block content %}

{# --- HERO SECTION: Photo Background with Animated Orbs (Homepage Style) --- #}
<section class=\"relative min-h-[60vh] flex items-center justify-center overflow-hidden\">
  <!-- Photo background with overlay -->
  <div class=\"about-hero-photo-bg\">
    <img src=\"/assets/layout/plamen.webp\" alt=\"Plamen working at Fine Digital\" class=\"w-full h-full object-cover\"/>
    <div class=\"absolute inset-0 bg-slate-900/70\"></div>
  </div>
  {# Optional: Subtle grid overlay #}
  {# <div class=\"grid-overlay\"></div> #}

  <!-- Animated colorful orbs (homepage style) -->
  <div class=\"about-hero-orb about-hero-yellow\" style=\"top:12%;left:8%;width:40px;height:40px;\"></div>
  <div class=\"about-hero-orb about-hero-pink about-hero-orb-delayed\" style=\"top:60%;right:10%;width:32px;height:32px;\"></div>
  <div class=\"about-hero-orb about-hero-blue\" style=\"bottom:18%;left:30%;width:48px;height:48px;\"></div>
  <div class=\"about-hero-orb about-hero-green about-hero-orb-delayed\" style=\"top:30%;right:18%;width:28px;height:28px;\"></div>
  <!-- Minimal floating dots for extra accent (optional) -->
  <div class=\"floating-dot\" style=\"top:22%;left:22%;animation-delay:1.2s;\"></div>
  <div class=\"floating-dot\" style=\"top:70%;right:22%;animation-delay:2.7s;\"></div>
  <!-- Shimmer overlay -->
  <div class=\"about-hero-shimmer\"></div>
  <!-- Content -->
  <div class=\"relative z-10 text-center px-6 max-w-4xl mx-auto\">
    <div class=\"space-y-6\">
      <h1 class=\"about-hero-headline text-4xl md:text-6xl font-extrabold leading-tight\">
        <span class=\"block font-extrabold\" style=\"color: #fff;\">Discover our story 2</span>
        <span class=\"block animate-gradient-x bg-clip-text text-transparent font-bold md:text-5xl mt-2\">commitment to excellence</span>
      </h1>
      <p class=\"about-hero-subheadline text-xl max-w-3xl mx-auto\">
        From Sofia to Worthing - A journey of perseverance, friendship, and digital innovation
      </p>
    </div>
  </div>
</section>

{# --- STORY TIMELINE --- #}
<section class=\"relative py-24 bg-white dark:bg-navy/80\">
  <div class=\"absolute left-0 top-0 w-32 h-32 bg-gradient-to-br from-brand/10 to-blue/10 rounded-full blur-2xl opacity-30 pointer-events-none\"></div>
  <div class=\"absolute right-0 bottom-0 w-40 h-40 bg-gradient-to-tr from-blue/10 to-brand/10 rounded-full blur-3xl opacity-20 pointer-events-none\"></div>
  <div class=\"max-w-3xl mx-auto px-6\">
    <div class=\"glass-effect premium-shadow rounded-3xl p-10 md:p-16 text-center\">
      <h2 class=\"text-3xl md:text-4xl font-bold text-navy dark:text-white mb-8\">Our Journey</h2>
      <div class=\"relative\">
        <div class=\"hidden md:block absolute left-1/2 top-0 h-full w-1 bg-gradient-to-b from-brand/40 to-blue/40 -translate-x-1/2\"></div>
        <div class=\"space-y-12 relative z-10\">
          <div class=\"flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-12\">
            <div class=\"flex-shrink-0 w-20 h-20 rounded-full bg-gradient-to-br from-brand to-blue flex items-center justify-center shadow-lg border-4 border-white dark:border-navy/40\">
              <span class=\"text-2xl font-bold text-white\">Sofia</span>
            </div>
            <div class=\"text-left md:text-base text-charcoal dark:text-gray-200\">
              <span class=\"block font-semibold text-brand mb-1\">Start</span>
              <span class=\"block\">Plamen's journey begins in Sofia, Bulgaria.</span>
            </div>
          </div>
          <div class=\"flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-12\">
            <div class=\"flex-shrink-0 w-20 h-20 rounded-full bg-gradient-to-br from-blue to-brand flex items-center justify-center shadow-lg border-4 border-white dark:border-navy/40\">
              <span class=\"text-2xl font-bold text-white\">Wales</span>
            </div>
            <div class=\"text-left md:text-base text-charcoal dark:text-gray-200\">
              <span class=\"block font-semibold text-blue mb-1\">2010</span>
              <span class=\"block\">Arrives in a quiet Welsh village, working as a car valet and learning English.</span>
            </div>
          </div>
          <div class=\"flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-12\">
            <div class=\"flex-shrink-0 w-20 h-20 rounded-full bg-gradient-to-br from-brand to-blue flex items-center justify-center shadow-lg border-4 border-white dark:border-navy/40\">
              <span class=\"text-2xl font-bold text-white\">Brighton</span>
            </div>
            <div class=\"text-left md:text-base text-charcoal dark:text-gray-200\">
              <span class=\"block font-semibold text-brand mb-1\">2013</span>
              <span class=\"block\">Studies Business & Management at Brighton University, graduates in 2016.</span>
            </div>
          </div>
          <div class=\"flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-12\">
            <div class=\"flex-shrink-0 w-20 h-20 rounded-full bg-gradient-to-br from-blue to-brand flex items-center justify-center shadow-lg border-4 border-white dark:border-navy/40\">
              <span class=\"text-2xl font-bold text-white\">Worthing</span>
            </div>
            <div class=\"text-left md:text-base text-charcoal dark:text-gray-200\">
              <span class=\"block font-semibold text-blue mb-1\">2016+</span>
              <span class=\"block\">Fine Digital is founded with Lubo. From humble beginnings to a thriving digital agency serving clinics across the UK and beyond.</span>
            </div>
          </div>
        </div>
      </div>
      <div class=\"mt-12 text-lg md:text-xl text-charcoal dark:text-gray-200 leading-relaxed text-left\">
        {{ entry.storyContent ?? \"So, with a leap of faith, I set my sights on the UK, seeking new horizons and fresh opportunities. In 2010, I landed in a quiet Welsh village, armed with little more than determination and a knack for hard work. Starting as a car valet, I gradually found my way to Worthing, a coastal gem where fate reunited me with my childhood friend Lubo.\\n\\nAs my English flourished, so did my aspirations. In 2013, fueled by newfound confidence, I embarked on an academic journey at Brighton University, emerging three years later armed with a degree in Business & Management.\\n\\nPost-graduation, the entrepreneurial bug bit me hard. Fueled by a passion for web design and development, I hatched a plan to establish a digital agency. With Lubo by my side, Fine Digital was born, a testament to our shared vision and determination.\\n\\nThe early days were far from easy. Juggling the demands of a fledgling business alongside my role as a support worker for West Sussex County Council tested my determination. Our focus on serving local businesses, coupled with word-of-mouth referrals, became the cornerstone of our growth.\\n\\nToday, as I reflect on the journey from Sofia to Worthing, I'm filled with gratitude for the challenges that shaped me and the friendships that sustained me. Fine Digital stands as a testament to the power of perseverance, friendship, and unwavering belief in one's dreams. And with Lubo by my side, I know that together, we'll continue to scale new heights, one satisfied client at a time.\\n\\nAs the sun sets on our journey thus far, I'm proud to say that Fine Digital isn't just a dream; it's a thriving reality. Our team has steadily grown, each member bringing their unique talents and passion to the table. With every project we undertake, we're reminded that success is not just about individual achievement, but the collective effort of a dedicated team.\"|nl2br }}
      </div>
    </div>
  </div>
</section>

{# --- VALUES GRID --- #}
<section class=\"relative py-24 bg-slate-50 dark:bg-navy/90\">
  <div class=\"max-w-6xl mx-auto px-6\">
    <div class=\"text-center mb-16\">
      <h2 class=\"text-4xl font-bold mb-4 text-brand\">What Sets Us Apart</h2>
      <p class=\"text-lg text-charcoal/80 dark:text-gray-200 max-w-2xl mx-auto\">We are a small web design agency based in Brighton, Sussex, serving clients across the UK and abroad. Fine Digital is known for professionalism, respect, and successful web and marketing projects.</p>
    </div>
    <div class=\"grid md:grid-cols-4 gap-8\">
      {% set values = entry.valuesGrid ?? [
        {
          icon: 'star',
          title: 'Bespoke Design',
          description: 'We create custom, functional websites aimed at converting users into customers.'
        },
        {
          icon: 'heart',
          title: 'Passionate Team',
          description: 'Each of us loves what we do, and that spirit translates into the quality of our work.'
        },
        {
          icon: 'handshake',
          title: 'True Partnership',
          description: 'Working with clients who love their work creates a fun, wonderful partnership.'
        },
        {
          icon: 'rocket',
          title: 'Results-Driven',
          description: 'We focus on delivering measurable results and long-term growth for our clients.'
        }
      ] %}
      {% for value in values %}
      <div class=\"glass-effect premium-shadow rounded-2xl p-8 flex flex-col items-center text-center border border-gray-100 dark:border-navy/40\">
        <div class=\"w-16 h-16 mb-4 flex items-center justify-center rounded-full bg-gradient-to-br from-brand to-blue shadow-lg\">
          {% if value.icon == 'star' %}
            <svg class=\"w-8 h-8 text-white\" fill=\"currentColor\" viewBox=\"0 0 20 20\"><polygon points=\"10 1.5 12.59 7.36 18.9 7.64 13.97 11.64 15.54 17.86 10 14.27 4.46 17.86 6.03 11.64 1.1 7.64 7.41 7.36 10 1.5\"/></svg>
          {% elseif value.icon == 'heart' %}
            <svg class=\"w-8 h-8 text-white\" fill=\"currentColor\" viewBox=\"0 0 20 20\"><path d=\"M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z\"/></svg>
          {% elseif value.icon == 'handshake' %}
            <svg class=\"w-8 h-8 text-white\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\"><path d=\"M12 19l-7-7 7-7 7 7-7 7z\"/></svg>
          {% elseif value.icon == 'rocket' %}
            <svg class=\"w-8 h-8 text-white\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\"><path d=\"M5 13l4 4L19 7\"/></svg>
          {% endif %}
        </div>
        <h3 class=\"text-xl font-semibold mb-2 text-navy dark:text-white\">{{ value.title }}</h3>
        <p class=\"text-charcoal/80 dark:text-gray-200\">{{ value.description }}</p>
      </div>
      {% endfor %}
    </div>
  </div>
</section>

{# --- TEAM SECTION --- #}
<section class=\"relative py-24 bg-white dark:bg-navy/80\">
  <div class=\"max-w-5xl mx-auto px-6\">
    <div class=\"text-center mb-16\">
      <h2 class=\"text-4xl font-bold mb-4 text-brand\">Meet the Team</h2>
      <p class=\"text-lg text-charcoal/80 dark:text-gray-200 max-w-2xl mx-auto\">Our team brings together a wealth of experience, creativity, and passion for digital excellence.</p>
    </div>
    <div class=\"grid md:grid-cols-2 gap-10\">
      {% set team = entry.teamMembers ?? [
        {
          photo: siteUrl ~ 'assets/layout/plamen.webp',
          name: 'Plamen',
          role: 'Co-Founder',
          bio: 'Plamen leads Fine Digital with a passion for web design, business strategy, and client success.'
        },
        {
          photo: siteUrl ~ 'assets/layout/logo.webp',
          name: 'Lubo',
          role: 'Co-Founder',
          bio: 'Lubo brings technical expertise and a creative eye to every project.'
        }
      ] %}
      {% for member in team %}
      <div class=\"glass-effect premium-shadow rounded-2xl p-8 flex flex-col items-center text-center border border-gray-100 dark:border-navy/40\">
        <img src=\"{{ member.photo }}\" alt=\"{{ member.name }}\" class=\"w-32 h-32 md:w-40 md:h-40 lg:w-48 lg:h-48 object-cover rounded-full border-4 border-brand shadow-lg mx-auto mb-6\" loading=\"lazy\">
        <h3 class=\"text-xl font-bold text-navy dark:text-white mb-1\">{{ member.name }}</h3>
        <div class=\"text-brand font-semibold mb-2\">{{ member.role }}</div>
        <p class=\"text-charcoal/80 dark:text-gray-200\">{{ member.bio }}</p>
      </div>
      {% endfor %}
    </div>
  </div>
</section>

{# --- TESTIMONIALS CAROUSEL --- #}
<section class=\"relative py-24 bg-slate-50 dark:bg-navy/90\">
  <div class=\"max-w-5xl mx-auto px-6\">
    <div class=\"text-center mb-16\">
      <h2 class=\"text-3xl md:text-4xl font-extrabold text-navy dark:text-white mb-4\">What Our Clients Say</h2>
      <p class=\"text-lg text-charcoal/80 dark:text-gray-200 max-w-2xl mx-auto\">Real feedback from clinics and healthcare professionals we've helped grow.</p>
    </div>
    <div class=\"grid md:grid-cols-3 gap-10\">
      {% set testimonials = entry.testimonials ?? [
        {
          content: \"I couldn't be without Plamen and his team for the website support. Having been hugely disappointed when I got over promised (and hugely overcharged) for an initial website to be made with a different company who took 12 months to complete, and would take a further 2/3 months to make the smallest change I was at my wits end. I'd lost confidence in the company and got recommended Plamen. I told Plamen about my previous experience and just asked for him to be upfront with any timeline to complete work. He went above and beyond! I can't express my gratitude with his professionalism and speed at which he gets tasks done.\",
          author: 'Clinic Owner',
          rating: 5,
          company: 'Private Clinic'
        },
        {
          content: 'Amazing service from start to finish!!! Extremely professional, accurate and supportive. I will highly recommend Plamen in Fine Digital to anyone looking for this kind of service.',
          author: 'Business Owner',
          rating: 5,
          company: 'Aesthetics Business'
        },
        {
          content: 'Nothing but good things to say about Fine Digital. Got the site up running very quickly from first consultation. Will use again. A+. Thanks Plamen',
          author: 'Entrepreneur',
          rating: 5,
          company: 'Startup'
        },
        {
          content: 'Fine Digital set up my website for the purpose of informing and detailing what my business provides. I also had a very slick booking system added to my website that my clients have given very positive feedback about.',
          author: 'Therapist',
          rating: 5,
          company: 'Therapy Practice'
        }
      ] %}
      {% for testimonial in testimonials %}
      <div class=\"bg-white dark:bg-navy/70 glass-effect premium-shadow rounded-2xl shadow-lg p-8 flex flex-col items-center text-center border border-gray-100 dark:border-navy/40\" itemscope itemtype=\"https://schema.org/Review\">
        <div class=\"flex items-center mb-4\">
          <img src=\"{{ siteUrl }}assets/layout/testimonial.jpg\" alt=\"{{ testimonial.author }}\" class=\"w-14 h-14 rounded-full object-cover border-2 border-brand shadow-md mr-3\">
          <div>
            <div class=\"flex items-center justify-center mb-1\">
              {% for i in 1..testimonial.rating %}
                <svg class=\"w-5 h-5 text-yellow-400\" fill=\"currentColor\" viewBox=\"0 0 20 20\"><polygon points=\"10 1.5 12.59 7.36 18.9 7.64 13.97 11.64 15.54 17.86 10 14.27 4.46 17.86 6.03 11.64 1.1 7.64 7.41 7.36 10 1.5\"/></svg>
              {% endfor %}
            </div>
            <span class=\"font-semibold text-navy dark:text-white\" itemprop=\"author\">{{ testimonial.author }}</span>
            <div class=\"text-xs text-charcoal/60 dark:text-gray-400\" itemprop=\"publisher\">{{ testimonial.company }}</div>
          </div>
        </div>
        <p class=\"text-charcoal/80 dark:text-gray-200\" itemprop=\"reviewBody\">\"{{ testimonial.content }}\"</p>
        <meta itemprop=\"reviewRating\" content=\"{{ testimonial.rating }}\">
      </div>
      {% endfor %}
    </div>
  </div>
</section>

{# --- CTA SECTION --- #}
<section id=\"contact\" class=\"relative py-24 bg-gradient-to-br from-navy via-slate-900 to-charcoal\">
  <div class=\"absolute inset-0 bg-gradient-to-r from-brand/10 to-blue/10 opacity-50\"></div>
  <div class=\"relative z-10 max-w-3xl mx-auto px-6 text-center\">
    <h2 class=\"text-4xl md:text-5xl font-extrabold text-white mb-6\">{{ entry.ctaHeadline ?? 'Ready to Grow Your Clinic?' }}</h2>
    <p class=\"text-xl text-white/90 mb-8 max-w-2xl mx-auto\">{{ entry.ctaText ?? 'Book a free strategy call and discover how minimalist design can drive real results for your clinic.' }}</p>
    {% set ctaButtonText = entry.ctaButtonText ?? 'Book Your Free Consultation' %}
    {% set ctaButtonLink = entry.ctaButtonLink ?? '#' %}
    <a href=\"{{ ctaButtonLink }}\" class=\"inline-block px-12 py-4 bg-brand text-white font-bold text-lg rounded-xl shadow-lg hover:bg-brand/90 transition transform hover:-translate-y-1 hover:scale-105\">{{ ctaButtonText }}</a>
  </div>
</section>

{% endblock %}

", "about", "/var/www/html/templates/about.twig");
    }
}
