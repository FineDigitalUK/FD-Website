<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _elements/footer */
class __TwigTemplate_74433d8d58d44dc58131d340ec09dda2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/footer");
        // line 1
        yield "<div id=\"count-spinner\" class=\"spinner small hidden\"></div>
<div id=\"count-container\" class=\"light\">&nbsp;</div>
<div id=\"actions-container\" class=\"flex hidden\"></div>
<div class=\"flex flex-nowrap\">
  <button type=\"button\" id=\"export-btn\" class=\"btn hidden\" aria-expanded=\"false\">";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Export…", "app"), "html", null, true);
        yield "</button>
</div>
";
        craft\helpers\Template::endProfile("template", "_elements/footer");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_elements/footer";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  49 => 5,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<div id=\"count-spinner\" class=\"spinner small hidden\"></div>
<div id=\"count-container\" class=\"light\">&nbsp;</div>
<div id=\"actions-container\" class=\"flex hidden\"></div>
<div class=\"flex flex-nowrap\">
  <button type=\"button\" id=\"export-btn\" class=\"btn hidden\" aria-expanded=\"false\">{{ 'Export…'|t('app') }}</button>
</div>
", "_elements/footer", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/footer.twig");
    }
}
