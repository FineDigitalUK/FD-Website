<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/fieldLayoutDesigner */
class __TwigTemplate_0a3de4beca3e8e3872f104160c283cdf extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/fieldLayoutDesigner");
        // line 1
        $context["fieldLayout"] = (($context["fieldLayout"]) ?? (Craft::createObject("craft\\models\\FieldLayout")));
        // line 2
        yield craft\helpers\Cp::fieldLayoutDesignerHtml((isset($context["fieldLayout"]) || array_key_exists("fieldLayout", $context) ? $context["fieldLayout"] : (function () { throw new RuntimeError('Variable "fieldLayout" does not exist.', 2, $this->source); })()), $context);
        yield "
";
        craft\helpers\Template::endProfile("template", "_includes/forms/fieldLayoutDesigner");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/fieldLayoutDesigner";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set fieldLayout = fieldLayout ?? create('craft\\\\models\\\\FieldLayout') %}
{{ fieldLayoutDesigner(fieldLayout, _context)|raw }}
", "_includes/forms/fieldLayoutDesigner", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/fieldLayoutDesigner.twig");
    }
}
