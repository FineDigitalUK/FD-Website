<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/disclosuremenu.twig */
class __TwigTemplate_a250d71a3b562a79ec15815d5b356c14 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'menu' => [$this, 'block_menu'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/disclosuremenu.twig");
        // line 1
        $context["id"] = (($context["id"]) ?? (("menu-" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 2
        $context["withButton"] = (($context["withButton"]) ?? (false));
        // line 3
        $context["buttonSpinner"] = (($context["buttonSpinner"]) ?? (false));
        // line 4
        $context["withSearchInput"] = (($context["withSearchInput"]) ?? (false));
        // line 5
        $context["disabled"] = (($context["disabled"]) ?? (false));
        // line 6
        yield "
";
        // line 7
        $context["hasSelected"] = craft\helpers\ArrayHelper::contains(Illuminate\Support\Arr::flatten($this->extensions['craft\web\twig\Extension']->mapFilter($this->env, (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new RuntimeError('Variable "items" does not exist.', 7, $this->source); })()), function ($__i__) use ($context, $macros) { $context["i"] = $__i__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["i"] ?? null), "items", [], "any", true, true, false, 7) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["i"] ?? null), "items", [], "any", false, false, false, 7)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["i"] ?? null), "items", [], "any", false, false, false, 7)) : ([(isset($context["i"]) || array_key_exists("i", $context) ? $context["i"] : (function () { throw new RuntimeError('Variable "i" does not exist.', 7, $this->source); })())])); }), 1), "selected");
        // line 8
        yield "
";
        // line 22
        yield "
";
        // line 26
        yield "
";
        // line 103
        yield "
";
        // line 104
        if ((isset($context["withButton"]) || array_key_exists("withButton", $context) ? $context["withButton"] : (function () { throw new RuntimeError('Variable "withButton" does not exist.', 104, $this->source); })())) {
            // line 105
            yield "  ";
            if ((($context["html"]) ?? (false))) {
                // line 106
                yield "    ";
                yield (isset($context["html"]) || array_key_exists("html", $context) ? $context["html"] : (function () { throw new RuntimeError('Variable "html" does not exist.', 106, $this->source); })());
                yield "
  ";
            } elseif (((            // line 107
$context["label"]) ?? (false))) {
                // line 108
                yield "    <span>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 108, $this->source); })()), "html", null, true);
                yield "</span>
  ";
            }
            // line 110
            yield "
  ";
            // line 111
            ob_start();
            // line 123
            $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 124
                yield "      ";
                if ((isset($context["buttonSpinner"]) || array_key_exists("buttonSpinner", $context) ? $context["buttonSpinner"] : (function () { throw new RuntimeError('Variable "buttonSpinner" does not exist.', 124, $this->source); })())) {
                    // line 125
                    yield "        <div role=\"status\" class=\"visually-hidden\"></div>
      ";
                }
                // line 127
                yield "      ";
                yield ((((isset($context["buttonLabel"]) || array_key_exists("buttonLabel", $context) ? $context["buttonLabel"] : (function () { throw new RuntimeError('Variable "buttonLabel" does not exist.', 127, $this->source); })()) || (isset($context["buttonHtml"]) || array_key_exists("buttonHtml", $context) ? $context["buttonHtml"] : (function () { throw new RuntimeError('Variable "buttonHtml" does not exist.', 127, $this->source); })()))) ? ($this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => "label", "text" => ((                // line 129
$context["buttonLabel"]) ?? (null)), "html" => ((                // line 130
$context["buttonHtml"]) ?? (null))])) : (""));
                // line 131
                yield "
      ";
                // line 132
                if ((isset($context["buttonSpinner"]) || array_key_exists("buttonSpinner", $context) ? $context["buttonSpinner"] : (function () { throw new RuntimeError('Variable "buttonSpinner" does not exist.', 132, $this->source); })())) {
                    // line 133
                    yield "        <div class=\"spinner spinner-absolute\">
          <span class=\"visually-hidden\">";
                    // line 134
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Loading", "app"), "html", null, true);
                    yield "</span>
        </div>
      ";
                }
                // line 137
                yield "    ";
                yield from [];
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 123
            yield Twig\Extension\CoreExtension::spaceless($_v0);
            echo craft\helpers\Html::tag("button", ob_get_clean(), $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => ["btn", "menubtn"], "type" => "button", "aria" => ["controls" =>             // line 115
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 115, $this->source); })()), "label" => ((            // line 116
$context["hiddenLabel"]) ?? (null))], "data" => ["disclosure-trigger" => true], "disabled" => ((            // line 121
$context["disabled"]) ?? (false))], ((            // line 122
$context["buttonAttributes"]) ?? ([])), true));
        }
        // line 140
        yield "
";
        // line 141
        ob_start();
        // line 148
        yield "  ";
        yield from $this->unwrap()->yieldBlock('menu', $context, $blocks);
        echo craft\helpers\Html::tag("div", ob_get_clean(), ["id" =>         // line 142
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 142, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass(((        // line 143
$context["class"]) ?? ([]))), ["menu", "menu--disclosure"]), "data" => ["with-search-input" =>         // line 145
(isset($context["withSearchInput"]) || array_key_exists("withSearchInput", $context) ? $context["withSearchInput"] : (function () { throw new RuntimeError('Variable "withSearchInput" does not exist.', 145, $this->source); })())]]);
        craft\helpers\Template::endProfile("template", "_includes/disclosuremenu.twig");
        yield from [];
    }

    // line 148
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_menu(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "menu");
        // line 149
        yield "    ";
        $context["ulStarted"] = false;
        // line 150
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new RuntimeError('Variable "items" does not exist.', 150, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 151
            yield "      ";
            $context["headingTag"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "headingTag", [], "any", true, true, false, 151) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "headingTag", [], "any", false, false, false, 151)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "headingTag", [], "any", false, false, false, 151)) : ("h3"));
            // line 152
            yield "      ";
            $context["type"] = $this->getTemplateForMacro("macro_itemType", $context, 152, $this->getSourceContext())->macro_itemType(...[$context["item"]]);
            // line 153
            yield "      ";
            if (CoreExtension::inFilter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 153, $this->source); })()), ["hr", "group"])) {
                // line 154
                yield "        ";
                if ((isset($context["ulStarted"]) || array_key_exists("ulStarted", $context) ? $context["ulStarted"] : (function () { throw new RuntimeError('Variable "ulStarted" does not exist.', 154, $this->source); })())) {
                    // line 155
                    yield "          ";
                    yield "</ul>";
                    yield "
          ";
                    // line 156
                    $context["ulStarted"] = false;
                    // line 157
                    yield "        ";
                }
                // line 158
                yield "
        ";
                // line 159
                if (((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 159, $this->source); })()) == "hr")) {
                    // line 160
                    yield "          ";
                    yield $this->extensions['craft\web\twig\Extension']->tagFunction("hr", ["class" => (((((craft\helpers\Template::attribute($this->env, $this->source,                     // line 161
$context["item"], "padded", [], "any", true, true, false, 161) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "padded", [], "any", false, false, false, 161)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "padded", [], "any", false, false, false, 161)) : (true))) ? ("padded") : (null))]);
                    // line 162
                    yield "
        ";
                } else {
                    // line 164
                    yield "          ";
                    ob_start();
                    // line 170
                    yield "            ";
                    if (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "heading", [], "any", true, true, false, 170)) {
                        // line 171
                        yield "              ";
                        ob_start();
                        // line 177
                        yield "                ";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "heading", [], "any", false, false, false, 177), "html", null, true);
                        yield "
              ";
                        echo craft\helpers\Html::tag(                        // line 171
(isset($context["headingTag"]) || array_key_exists("headingTag", $context) ? $context["headingTag"] : (function () { throw new RuntimeError('Variable "headingTag" does not exist.', 171, $this->source); })()), ob_get_clean(), $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["h6" => true, "padded" => (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 174
$context["item"], "padded", [], "any", true, true, false, 174) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "padded", [], "any", false, false, false, 174)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "padded", [], "any", false, false, false, 174)) : (true))]))], (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 176
$context["item"], "headingAttributes", [], "any", true, true, false, 176) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "headingAttributes", [], "any", false, false, false, 176)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "headingAttributes", [], "any", false, false, false, 176)) : ([])), true));
                        // line 179
                        yield "            ";
                    }
                    // line 180
                    yield "            ";
                    ob_start();
                    // line 185
                    yield "              ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "items", [], "any", false, false, false, 185));
                    foreach ($context['_seq'] as $context["_key"] => $context["groupItem"]) {
                        // line 186
                        yield "                ";
                        yield $this->getTemplateForMacro("macro_item", $context, 186, $this->getSourceContext())->macro_item(...[$context["groupItem"], (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 186, $this->source); })())]);
                        yield "
              ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['groupItem'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 188
                    yield "            ";
                    echo craft\helpers\Html::tag("ul", ob_get_clean(), $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["padded" =>                     // line 182
(isset($context["hasSelected"]) || array_key_exists("hasSelected", $context) ? $context["hasSelected"] : (function () { throw new RuntimeError('Variable "hasSelected" does not exist.', 182, $this->source); })())]))], (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 184
$context["item"], "listAttributes", [], "any", true, true, false, 184) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "listAttributes", [], "any", false, false, false, 184)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "listAttributes", [], "any", false, false, false, 184)) : ([])), true));
                    // line 189
                    yield "          ";
                    echo craft\helpers\Html::tag("div", ob_get_clean(), ["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["menu-group" => true, "hidden" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 167
$context["item"], "hidden", [], "any", true, true, false, 167) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "hidden", [], "any", false, false, false, 167)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "hidden", [], "any", false, false, false, 167)) : (false))]))]);
                    // line 190
                    yield "        ";
                }
                // line 191
                yield "      ";
            } else {
                // line 192
                yield "        ";
                if ( !(isset($context["ulStarted"]) || array_key_exists("ulStarted", $context) ? $context["ulStarted"] : (function () { throw new RuntimeError('Variable "ulStarted" does not exist.', 192, $this->source); })())) {
                    // line 193
                    yield "          ";
                    if ((isset($context["hasSelected"]) || array_key_exists("hasSelected", $context) ? $context["hasSelected"] : (function () { throw new RuntimeError('Variable "hasSelected" does not exist.', 193, $this->source); })())) {
                        // line 194
                        yield "            ";
                        yield "<ul class=\"padded\">";
                        yield "
          ";
                    } else {
                        // line 196
                        yield "            ";
                        yield "<ul>";
                        yield "
          ";
                    }
                    // line 198
                    yield "          ";
                    $context["ulStarted"] = true;
                    // line 199
                    yield "        ";
                }
                // line 200
                yield "        ";
                yield $this->getTemplateForMacro("macro_item", $context, 200, $this->getSourceContext())->macro_item(...[$context["item"], (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 200, $this->source); })())]);
                yield "
      ";
            }
            // line 202
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 203
        yield "    ";
        if ((isset($context["ulStarted"]) || array_key_exists("ulStarted", $context) ? $context["ulStarted"] : (function () { throw new RuntimeError('Variable "ulStarted" does not exist.', 203, $this->source); })())) {
            yield "</ul>";
        }
        // line 204
        yield "  ";
        craft\helpers\Template::endProfile("block", "menu");
        yield from [];
    }

    // line 9
    public function macro_itemType($item = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "item" => $item,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "itemType");
            // line 10
            if ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "type", [], "any", true, true, false, 10) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "type", [], "any", false, false, false, 10)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "type", [], "any", false, false, false, 10)) : (false))) {
                // line 11
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 11, $this->source); })()), "type", [], "any", false, false, false, 11), "html", null, true);
            } elseif ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 12
($context["item"] ?? null), "url", [], "any", true, true, false, 12) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, false, 12)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, false, 12)) : (false))) {
                // line 13
                yield "link";
            } elseif ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 14
($context["item"] ?? null), "hr", [], "any", true, true, false, 14) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "hr", [], "any", false, false, false, 14)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "hr", [], "any", false, false, false, 14)) : (false))) {
                // line 15
                yield "hr";
            } elseif ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 16
($context["item"] ?? null), "heading", [], "any", true, true, false, 16) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "heading", [], "any", false, false, false, 16)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "heading", [], "any", false, false, false, 16)) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "items", [], "any", true, true, false, 16) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "items", [], "any", false, false, false, 16)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "items", [], "any", false, false, false, 16)) : (false))))) {
                // line 17
                yield "group";
            } else {
                // line 19
                yield "button";
            }
            craft\helpers\Template::endProfile("macro", "itemType");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 23
    public function macro_color($color = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "color" => $color,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "color");
            // line 24
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($this->env->getTest('instance of')->getCallable()((isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 24, $this->source); })()), "craft\\enums\\Color")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 24, $this->source); })()), "value", [], "any", false, false, false, 24)) : ((isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 24, $this->source); })()))), "html", null, true);
            craft\helpers\Template::endProfile("macro", "color");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 27
    public function macro_item($item = null, $menuId = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "item" => $item,
            "menuId" => $menuId,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "item");
            // line 28
            yield "  ";
            $context["type"] = $this->getTemplateForMacro("macro_itemType", $context, 28, $this->getSourceContext())->macro_itemType(...[(isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 28, $this->source); })())]);
            // line 29
            yield "  ";
            $context["id"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "id", [], "any", true, true, false, 29) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "id", [], "any", false, false, false, 29)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "id", [], "any", false, false, false, 29)) : (("menu-item-" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
            // line 30
            yield "  ";
            ob_start();
            // line 35
            yield "    ";
            $context["selected"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "selected", [], "any", true, true, false, 35) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "selected", [], "any", false, false, false, 35)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "selected", [], "any", false, false, false, 35)) : (false));
            // line 36
            yield "    ";
            ob_start();
            // line 56
            $_v1 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 57
                yield "        ";
                if ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", true, true, false, 57) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", false, false, false, 57)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", false, false, false, 57)) : (false))) {
                    // line 58
                    yield "          ";
                    yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["icon", $this->getTemplateForMacro("macro_color", $context, 61, $this->getSourceContext())->macro_color(...[(((craft\helpers\Template::attribute($this->env, $this->source,                     // line 61
($context["item"] ?? null), "color", [], "any", true, true, false, 61) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "color", [], "any", false, false, false, 61)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "color", [], "any", false, false, false, 61)) : (null))])]), "html" => craft\helpers\Cp::iconSvg(craft\helpers\Template::attribute($this->env, $this->source,                     // line 63
(isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 63, $this->source); })()), "icon", [], "any", false, false, false, 63))]);
                    // line 64
                    yield "
        ";
                }
                // line 66
                yield "        ";
                if ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "status", [], "any", true, true, false, 66) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "status", [], "any", false, false, false, 66)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "status", [], "any", false, false, false, 66)) : (false))) {
                    // line 67
                    yield craft\helpers\Cp::statusIndicatorHtml(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 67, $this->source); })()), "status", [], "any", false, false, false, 67));
                }
                // line 69
                yield "<span class=\"menu-item-label inline-flex flex-col items-start gap-2xs\">
          ";
                // line 70
                (((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "label", [], "any", true, true, false, 70) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "label", [], "any", false, false, false, 70)))) ? (yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "label", [], "any", false, false, false, 70), "html", null, true)) : (yield craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 70, $this->source); })()), "html", [], "any", false, false, false, 70)));
                yield "
          ";
                // line 71
                if (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "description", [], "any", true, true, false, 71)) {
                    // line 72
                    yield "            <span class=\"menu-item-description mt-2xs smalltext light\">";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 72, $this->source); })()), "description", [], "any", false, false, false, 72), "html", null, true);
                    yield "</span>
          ";
                } elseif (craft\helpers\Template::attribute($this->env, $this->source,                 // line 73
($context["item"] ?? null), "handle", [], "any", true, true, false, 73)) {
                    // line 74
                    yield "            <span class=\"menu-item-description mt-2xs smalltext light code\">";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 74, $this->source); })()), "handle", [], "any", false, false, false, 74), "html", null, true);
                    yield "</span>
          ";
                }
                // line 76
                yield "        </span>
        ";
                // line 77
                if ((isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 77, $this->source); })())) {
                    // line 78
                    yield "          <span class=\"visually-hidden\">, selected</span>
        ";
                }
                // line 80
                yield "        ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "info", [], "any", true, true, false, 80) &&  !Twig\Extension\CoreExtension::testEmpty(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 80, $this->source); })()), "info", [], "any", false, false, false, 80)))) {
                    // line 81
                    yield "          <span class=\"info\">";
                    yield craft\helpers\Cp::parseMarkdown($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 81, $this->source); })()), "info", [], "any", false, false, false, 81)));
                    yield "</span>
        ";
                }
                // line 83
                yield "      ";
                yield from [];
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 56
            yield Twig\Extension\CoreExtension::spaceless($_v1);
            echo craft\helpers\Html::tag((((            // line 36
(isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 36, $this->source); })()) == "button")) ? ("button") : ("a")), ob_get_clean(), $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>             // line 37
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 37, $this->source); })()), "class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["menu-item" => true, "sel" =>             // line 40
(isset($context["selected"]) || array_key_exists("selected", $context) ? $context["selected"] : (function () { throw new RuntimeError('Variable "selected" does not exist.', 40, $this->source); })()), "error" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 41
($context["item"] ?? null), "destructive", [], "any", true, true, false, 41) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "destructive", [], "any", false, false, false, 41)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "destructive", [], "any", false, false, false, 41)) : (false)), "formsubmit" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 42
($context["item"] ?? null), "action", [], "any", true, true, false, 42) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "action", [], "any", false, false, false, 42)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "action", [], "any", false, false, false, 42)) : (false)), "disabled" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 43
($context["item"] ?? null), "disabled", [], "any", true, true, false, 43) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "disabled", [], "any", false, false, false, 43)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "disabled", [], "any", false, false, false, 43)) : (false))])), "href" => (((            // line 45
(isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 45, $this->source); })()) == "button")) ? (null) : (craft\helpers\UrlHelper::url(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 45, $this->source); })()), "url", [], "any", false, false, false, 45)))), "data" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["destructive" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 47
($context["item"] ?? null), "destructive", [], "any", true, true, false, 47) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "destructive", [], "any", false, false, false, 47)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "destructive", [], "any", false, false, false, 47)) : (null)), "action" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 48
($context["item"] ?? null), "action", [], "any", true, true, false, 48) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "action", [], "any", false, false, false, 48)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "action", [], "any", false, false, false, 48)) : (null)), "params" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 49
($context["item"] ?? null), "params", [], "any", true, true, false, 49) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "params", [], "any", false, false, false, 49)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "params", [], "any", false, false, false, 49)) : (null)), "confirm" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 50
($context["item"] ?? null), "confirm", [], "any", true, true, false, 50) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "confirm", [], "any", false, false, false, 50)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "confirm", [], "any", false, false, false, 50)) : (null)), "redirect" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 51
($context["item"] ?? null), "redirect", [], "any", true, true, false, 51) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "redirect", [], "any", false, false, false, 51)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "redirect", [], "any", false, false, false, 51)) : (false))) ? ($this->env->getFilter('hash')->getCallable()(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 51, $this->source); })()), "redirect", [], "any", false, false, false, 51))) : (null)), "require-elevated-session" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 52
($context["item"] ?? null), "requireElevatedSession", [], "any", true, true, false, 52) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "requireElevatedSession", [], "any", false, false, false, 52)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "requireElevatedSession", [], "any", false, false, false, 52)) : (false)), "form" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 53
($context["item"] ?? null), "action", [], "any", true, true, false, 53) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "action", [], "any", false, false, false, 53)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "action", [], "any", false, false, false, 53)) : (false))) ? ("false") : (null))])], (((craft\helpers\Template::attribute($this->env, $this->source,             // line 55
($context["item"] ?? null), "attributes", [], "any", true, true, false, 55) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "attributes", [], "any", false, false, false, 55)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "attributes", [], "any", false, false, false, 55)) : ([])), true));
            // line 85
            yield "  ";
            echo craft\helpers\Html::tag("li", ob_get_clean(), $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["hidden" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 32
($context["item"] ?? null), "hidden", [], "any", true, true, false, 32) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "hidden", [], "any", false, false, false, 32)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "hidden", [], "any", false, false, false, 32)) : (false))]))], (((craft\helpers\Template::attribute($this->env, $this->source,             // line 34
($context["item"] ?? null), "liAttributes", [], "any", true, true, false, 34) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "liAttributes", [], "any", false, false, false, 34)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["item"] ?? null), "liAttributes", [], "any", false, false, false, 34)) : ([]))));
            // line 86
            yield "  ";
            if (((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 86, $this->source); })()) == "link")) {
                // line 87
                yield "    ";
                ob_start();
                // line 88
                yield "      \$('#";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 88, $this->source); })())), "html", null, true);
                yield "').on('keydown', (ev) => {
        if (ev.keyCode === Garnish.SPACE_KEY) {
          ev.currentTarget.click();
        }
      });
    ";
                craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
                // line 94
                yield "  ";
            }
            // line 95
            yield "  ";
            ob_start();
            // line 96
            yield "    \$('#";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 96, $this->source); })())), "html", null, true);
            yield "').on('activate', () => {
      setTimeout(() => {
        \$('#";
            // line 98
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["menuId"]) || array_key_exists("menuId", $context) ? $context["menuId"] : (function () { throw new RuntimeError('Variable "menuId" does not exist.', 98, $this->source); })())), "html", null, true);
            yield "').data('disclosureMenu').hide();
      }, 1);
    });
  ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
            craft\helpers\Template::endProfile("macro", "item");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/disclosuremenu.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  503 => 98,  497 => 96,  494 => 95,  491 => 94,  481 => 88,  478 => 87,  475 => 86,  473 => 34,  472 => 32,  470 => 85,  468 => 55,  467 => 53,  466 => 52,  465 => 51,  464 => 50,  463 => 49,  462 => 48,  461 => 47,  460 => 45,  459 => 43,  458 => 42,  457 => 41,  456 => 40,  455 => 37,  454 => 36,  452 => 56,  448 => 83,  442 => 81,  439 => 80,  435 => 78,  433 => 77,  430 => 76,  424 => 74,  422 => 73,  417 => 72,  415 => 71,  411 => 70,  408 => 69,  405 => 67,  402 => 66,  398 => 64,  396 => 63,  395 => 61,  393 => 58,  390 => 57,  388 => 56,  385 => 36,  382 => 35,  379 => 30,  376 => 29,  373 => 28,  359 => 27,  352 => 24,  339 => 23,  331 => 19,  328 => 17,  326 => 16,  324 => 15,  322 => 14,  320 => 13,  318 => 12,  316 => 11,  314 => 10,  301 => 9,  295 => 204,  290 => 203,  284 => 202,  278 => 200,  275 => 199,  272 => 198,  266 => 196,  260 => 194,  257 => 193,  254 => 192,  251 => 191,  248 => 190,  246 => 167,  244 => 189,  242 => 184,  241 => 182,  239 => 188,  230 => 186,  225 => 185,  222 => 180,  219 => 179,  217 => 176,  216 => 174,  215 => 171,  210 => 177,  207 => 171,  204 => 170,  201 => 164,  197 => 162,  195 => 161,  193 => 160,  191 => 159,  188 => 158,  185 => 157,  183 => 156,  178 => 155,  175 => 154,  172 => 153,  169 => 152,  166 => 151,  161 => 150,  158 => 149,  150 => 148,  144 => 145,  143 => 143,  142 => 142,  139 => 148,  137 => 141,  134 => 140,  131 => 122,  130 => 121,  129 => 116,  128 => 115,  126 => 123,  122 => 137,  116 => 134,  113 => 133,  111 => 132,  108 => 131,  106 => 130,  105 => 129,  103 => 127,  99 => 125,  96 => 124,  94 => 123,  92 => 111,  89 => 110,  83 => 108,  81 => 107,  76 => 106,  73 => 105,  71 => 104,  68 => 103,  65 => 26,  62 => 22,  59 => 8,  57 => 7,  54 => 6,  52 => 5,  50 => 4,  48 => 3,  46 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set id = id ?? \"menu-#{random()}\" %}
{% set withButton = withButton ?? false %}
{% set buttonSpinner = buttonSpinner ?? false %}
{% set withSearchInput = withSearchInput ?? false %}
{% set disabled = disabled ?? false %}

{% set hasSelected = items|map(i => i.items ?? [i])|flatten(1)|contains('selected') %}

{% macro itemType(item) %}
  {%- if item.type ?? false %}
    {{- item.type }}
  {%- elseif item.url ?? false %}
    {{- 'link' }}
  {%- elseif item.hr ?? false %}
    {{- 'hr' }}
  {%- elseif item.heading ?? item.items ?? false %}
    {{- 'group' }}
  {%- else %}
    {{- 'button' }}
  {%- endif %}
{%- endmacro %}

{% macro color(color) %}
  {{- color is instance of ('craft\\\\enums\\\\Color') ? color.value : color -}}
{% endmacro %}

{% macro item(item, menuId) %}
  {% set type = _self.itemType(item) %}
  {% set id = item.id ?? \"menu-item-#{random()}\" %}
  {% tag 'li' with {
    class: {
      hidden: item.hidden ?? false,
    }|filter|keys,
  }|merge(item.liAttributes ?? {}) %}
    {% set selected = item.selected ?? false %}
    {% tag (type == 'button' ? 'button' : 'a') with {
      id: id,
      class: {
        'menu-item': true,
        sel: selected,
        error: item.destructive ?? false,
        formsubmit: item.action ?? false,
        disabled: item.disabled ?? false,
      }|filter|keys,
      href: type == 'button' ? null : url(item.url),
      data: {
        destructive: item.destructive ?? null,
        action: item.action ?? null,
        params: item.params ?? null,
        confirm: item.confirm ?? null,
        redirect: (item.redirect ?? false) ? item.redirect|hash : null,
        'require-elevated-session': item.requireElevatedSession ?? false,
        form: (item.action ?? false) ? 'false' : null,
      }|filter,
    }|merge(item.attributes ?? {}, recursive=true) %}
      {%- apply spaceless %}
        {% if item.icon ?? false %}
          {{ tag('span', {
            class: [
              'icon',
              _self.color(item.color ?? null),
            ]|filter,
            html: iconSvg(item.icon),
          }) }}
        {% endif %}
        {% if item.status ?? false -%}
          {{ statusIndicator(item.status) }}
        {%- endif -%}
        <span class=\"menu-item-label inline-flex flex-col items-start gap-2xs\">
          {{ item.label ?? item.html|raw }}
          {% if item.description is defined %}
            <span class=\"menu-item-description mt-2xs smalltext light\">{{ item.description }}</span>
          {% elseif item.handle is defined %}
            <span class=\"menu-item-description mt-2xs smalltext light code\">{{ item.handle }}</span>
          {% endif %}
        </span>
        {% if selected %}
          <span class=\"visually-hidden\">, selected</span>
        {% endif %}
        {% if item.info is defined and item.info is not empty %}
          <span class=\"info\">{{ item.info|e|cpmd }}</span>
        {% endif %}
      {% endapply -%}
    {% endtag %}
  {% endtag %}
  {% if type == 'link' %}
    {% js %}
      \$('#{{ id|namespaceInputId }}').on('keydown', (ev) => {
        if (ev.keyCode === Garnish.SPACE_KEY) {
          ev.currentTarget.click();
        }
      });
    {% endjs %}
  {% endif %}
  {% js %}
    \$('#{{ id|namespaceInputId }}').on('activate', () => {
      setTimeout(() => {
        \$('#{{ menuId|namespaceInputId }}').data('disclosureMenu').hide();
      }, 1);
    });
  {% endjs %}
{% endmacro %}

{% if withButton %}
  {% if html ?? false %}
    {{ html|raw }}
  {% elseif label ?? false %}
    <span>{{ label }}</span>
  {% endif %}

  {% tag 'button' with {
    class: ['btn', 'menubtn'],
    type: 'button',
    aria: {
      controls: id,
      label: hiddenLabel ?? null
    },
    data: {
      'disclosure-trigger': true,
    },
    disabled: disabled ?? false,
  }|merge(buttonAttributes ?? {}, recursive=true) %}
    {%- apply spaceless %}
      {% if buttonSpinner %}
        <div role=\"status\" class=\"visually-hidden\"></div>
      {% endif %}
      {{ (buttonLabel or buttonHtml) ? tag('div', {
        class: 'label',
        text: buttonLabel ?? null,
        html: buttonHtml ?? null,
      }) }}
      {% if buttonSpinner %}
        <div class=\"spinner spinner-absolute\">
          <span class=\"visually-hidden\">{{ 'Loading'|t('app') }}</span>
        </div>
      {% endif %}
    {% endapply -%}
  {% endtag %}
{% endif %}

{% tag 'div' with {
  id: id,
  class: (class ?? [])|explodeClass|merge(['menu', 'menu--disclosure']),
  data: {
    'with-search-input': withSearchInput,
  },
} %}
  {% block menu %}
    {% set ulStarted = false %}
    {% for item in items %}
      {% set headingTag = item.headingTag ?? 'h3' %}
      {% set type = _self.itemType(item) %}
      {% if type in ['hr', 'group'] %}
        {% if ulStarted %}
          {{ '</ul>'|raw }}
          {% set ulStarted = false %}
        {% endif %}

        {% if type == 'hr' %}
          {{ tag('hr', {
            class: (item.padded ?? true) ? 'padded' : null,
          }) }}
        {% else %}
          {% tag 'div' with {
            class: {
              'menu-group': true,
              hidden: item.hidden ?? false,
            }|filter|keys
          } %}
            {% if item.heading is defined %}
              {% tag headingTag with {
                class: {
                  h6: true,
                  padded: item.padded ?? true,
                }|filter|keys,
              }|merge(item.headingAttributes ??{}, recursive=true) %}
                {{ item.heading }}
              {% endtag %}
            {% endif %}
            {% tag 'ul' with {
              class: {
                padded: hasSelected,
              }|filter|keys,
            }|merge(item.listAttributes ?? {}, recursive=true) %}
              {% for groupItem in item.items %}
                {{ _self.item(groupItem, id) }}
              {% endfor %}
            {% endtag %}
          {% endtag %}
        {% endif %}
      {% else %}
        {% if not ulStarted %}
          {% if hasSelected %}
            {{ '<ul class=\"padded\">'|raw }}
          {% else %}
            {{ '<ul>'|raw }}
          {% endif %}
          {% set ulStarted = true %}
        {% endif %}
        {{ _self.item(item, id) }}
      {% endif %}
    {% endfor %}
    {% if ulStarted %}{{ '</ul>'|raw }}{% endif %}
  {% endblock %}
{% endtag %}
", "_includes/disclosuremenu.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/disclosuremenu.twig");
    }
}
