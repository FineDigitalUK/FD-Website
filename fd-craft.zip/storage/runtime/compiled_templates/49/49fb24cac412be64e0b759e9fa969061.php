<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _elements/tableview/container */
class __TwigTemplate_e4b91ef1d2eea2f44dc9fb17d1a941f8 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/tableview/container");
        // line 1
        if ( !Twig\Extension\CoreExtension::testEmpty((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 1, $this->source); })()))) {
            // line 2
            yield "  ";
            $context["tableName"] = (($context["tableName"]) ?? (""));
            // line 3
            yield "  ";
            $context["instructionId"] = (($context["instructionId"]) ?? (("sort-instructions-" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
            // line 4
            yield "
  <div class=\"tableview";
            // line 5
            if (((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 5, $this->source); })()) == "index")) {
                yield " tablepane";
            }
            yield "\">
    <span class=\"visually-hidden\" data-status-message role=\"status\"></span>
    <table class=\"data fullwidth big\"";
            // line 7
            if ((array_key_exists("structureEditable", $context) && (isset($context["structureEditable"]) || array_key_exists("structureEditable", $context) ? $context["structureEditable"] : (function () { throw new RuntimeError('Variable "structureEditable" does not exist.', 7, $this->source); })()))) {
                yield " data-structure-id=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["structure"]) || array_key_exists("structure", $context) ? $context["structure"] : (function () { throw new RuntimeError('Variable "structure" does not exist.', 7, $this->source); })()), "id", [], "any", false, false, false, 7), "html", null, true);
                yield "\" data-max-levels=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["structure"]) || array_key_exists("structure", $context) ? $context["structure"] : (function () { throw new RuntimeError('Variable "structure" does not exist.', 7, $this->source); })()), "maxLevels", [], "any", false, false, false, 7), "html", null, true);
                yield "\"";
            }
            yield " data-name=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["tableName"]) || array_key_exists("tableName", $context) ? $context["tableName"] : (function () { throw new RuntimeError('Variable "tableName" does not exist.', 7, $this->source); })()), "html", null, true);
            yield "\">
      <caption class=\"visually-hidden\">";
            // line 8
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["tableName"]) || array_key_exists("tableName", $context) ? $context["tableName"] : (function () { throw new RuntimeError('Variable "tableName" does not exist.', 8, $this->source); })()), "html", null, true);
            yield "<span id=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["instructionId"]) || array_key_exists("instructionId", $context) ? $context["instructionId"] : (function () { throw new RuntimeError('Variable "instructionId" does not exist.', 8, $this->source); })()), "html", null, true);
            yield "\" data-sort-instructions>, ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Column headers with buttons are sortable", "app"), "html", null, true);
            yield "</span></caption>
      <thead>
      <tr>
        ";
            // line 11
            if ((isset($context["selectable"]) || array_key_exists("selectable", $context) ? $context["selectable"] : (function () { throw new RuntimeError('Variable "selectable" does not exist.', 11, $this->source); })())) {
                // line 12
                yield "          <th class=\"checkbox-cell selectallcontainer\"></th>
        ";
            }
            // line 14
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["attributes"]) || array_key_exists("attributes", $context) ? $context["attributes"] : (function () { throw new RuntimeError('Variable "attributes" does not exist.', 14, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["attribute"]) {
                // line 15
                yield "          ";
                $context["icon"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 1, [], "array", false, true, false, 15), "icon", [], "any", true, true, false, 15) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 1, [], "array", false, true, false, 15), "icon", [], "any", false, false, false, 15)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 1, [], "array", false, true, false, 15), "icon", [], "any", false, false, false, 15)) : (false));
                // line 16
                yield "          ";
                ob_start();
                // line 24
                yield "            ";
                if ((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 24, $this->source); })())) {
                    // line 25
                    yield "              <span data-icon=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 25, $this->source); })()), "html", null, true);
                    yield "\" aria-hidden=\"true\"></span>
              <span class=\"visually-hidden\">";
                    // line 26
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 1, [], "array", false, false, false, 26), "label", [], "any", false, false, false, 26), "html", null, true);
                    yield "</span>
            ";
                } elseif (( !craft\helpers\Template::attribute($this->env, $this->source,                 // line 27
$context["loop"], "first", [], "any", false, false, false, 27) || (($context["showHeaderColumn"]) ?? (true)))) {
                    // line 28
                    yield "              ";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 1, [], "array", false, false, false, 28), "label", [], "any", false, false, false, 28), "site"), "html", null, true);
                    yield "
            ";
                }
                // line 30
                yield "            <div class=\"spinner\"></div>
          ";
                echo craft\helpers\Html::tag("th", ob_get_clean(), ["scope" => "col", "title" => ((                // line 18
(isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 18, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["attribute"], 1, [], "array", false, false, false, 18), "label", [], "any", false, false, false, 18)) : (false)), "data" => ["attribute" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 20
$context["attribute"], 0, [], "array", false, false, false, 20)], "class" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 22
$context["loop"], "first", [], "any", false, false, false, 22) &&  !(($context["showHeaderColumn"]) ?? (true)))) ? ("thin") : (null))]);
                // line 32
                yield "        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['attribute'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            yield "      </tr>
      </thead>
      <tbody>
      ";
            // line 36
            yield from $this->loadTemplate("_elements/tableview/elements", "_elements/tableview/container", 36)->unwrap()->yield($context);
            // line 37
            yield "      </tbody>
    </table>
  </div>
";
        } else {
            // line 41
            yield "  <div class=\"zilch small\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Nothing yet.", "app"), "html", null, true);
            yield "</div>
";
        }
        craft\helpers\Template::endProfile("template", "_elements/tableview/container");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_elements/tableview/container";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  167 => 41,  161 => 37,  159 => 36,  154 => 33,  140 => 32,  138 => 22,  137 => 20,  136 => 18,  133 => 30,  127 => 28,  125 => 27,  121 => 26,  116 => 25,  113 => 24,  110 => 16,  107 => 15,  89 => 14,  85 => 12,  83 => 11,  73 => 8,  61 => 7,  54 => 5,  51 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% if elements is not empty %}
  {% set tableName = tableName ?? '' %}
  {% set instructionId = instructionId ?? \"sort-instructions-#{random()}\" %}

  <div class=\"tableview{% if context == 'index' %} tablepane{% endif %}\">
    <span class=\"visually-hidden\" data-status-message role=\"status\"></span>
    <table class=\"data fullwidth big\"{% if structureEditable is defined and structureEditable %} data-structure-id=\"{{ structure.id }}\" data-max-levels=\"{{ structure.maxLevels }}\"{% endif %} data-name=\"{{ tableName }}\">
      <caption class=\"visually-hidden\">{{ tableName }}<span id=\"{{ instructionId }}\" data-sort-instructions>, {{ 'Column headers with buttons are sortable'|t('app') }}</span></caption>
      <thead>
      <tr>
        {% if selectable %}
          <th class=\"checkbox-cell selectallcontainer\"></th>
        {% endif %}
        {% for attribute in attributes %}
          {% set icon = attribute[1].icon ?? false %}
          {% tag 'th' with {
            scope: 'col',
            title: icon ? attribute[1].label : false,
            data: {
              attribute: attribute[0],
            },
            class: loop.first and not (showHeaderColumn ?? true) ? 'thin' : null,
          } %}
            {% if icon %}
              <span data-icon=\"{{ icon }}\" aria-hidden=\"true\"></span>
              <span class=\"visually-hidden\">{{ attribute[1].label }}</span>
            {% elseif not loop.first or showHeaderColumn ?? true %}
              {{ attribute[1].label|t('site') }}
            {% endif %}
            <div class=\"spinner\"></div>
          {% endtag %}
        {% endfor %}
      </tr>
      </thead>
      <tbody>
      {% include \"_elements/tableview/elements\" %}
      </tbody>
    </table>
  </div>
{% else %}
  <div class=\"zilch small\">{{ 'Nothing yet.'|t('app') }}</div>
{% endif %}
", "_elements/tableview/container", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/tableview/container.twig");
    }
}
