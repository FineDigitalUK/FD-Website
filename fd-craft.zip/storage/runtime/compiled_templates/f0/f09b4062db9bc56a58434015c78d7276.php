<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/languageMenu */
class __TwigTemplate_1c6fecf3294ba2798cb0855a881aadab extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/languageMenu");
        // line 1
        $context["id"] = (($context["id"]) ?? (("languagemenu" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 2
        $context["value"] = (($context["value"]) ?? (null));
        // line 3
        $context["options"] = (($context["options"]) ?? ([]));
        // line 4
        $context["appOnly"] = (($context["appOnly"]) ?? (false));
        // line 5
        yield "

";
        // line 7
        if ((($context["includeEnvVars"]) ?? (false))) {
            // line 8
            yield "    ";
            $context["options"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 8, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 8, $this->source); })()), "cp", [], "any", false, false, false, 8), "getLanguageEnvOptions", [(isset($context["appOnly"]) || array_key_exists("appOnly", $context) ? $context["appOnly"] : (function () { throw new RuntimeError('Variable "appOnly" does not exist.', 8, $this->source); })())], "method", false, false, false, 8));
        }
        // line 10
        yield "
";
        // line 11
        yield from $this->loadTemplate("_includes/forms/selectize", "_includes/forms/languageMenu", 11)->unwrap()->yield(CoreExtension::merge($context, ["includeEnvVars" => false]));
        craft\helpers\Template::endProfile("template", "_includes/forms/languageMenu");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/languageMenu";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  64 => 11,  61 => 10,  57 => 8,  55 => 7,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set id = id ?? \"languagemenu#{random()}\" %}
{% set value = value ?? null -%}
{% set options = options ?? [] %}
{% set appOnly = appOnly ?? false %}


{% if includeEnvVars ?? false %}
    {% set options = options|merge(craft.cp.getLanguageEnvOptions(appOnly)) %}
{% endif %}

{% include '_includes/forms/selectize' with {
    includeEnvVars: false,
} %}
", "_includes/forms/languageMenu", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/languageMenu.twig");
    }
}
