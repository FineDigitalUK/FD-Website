<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* components/hero.twig */
class __TwigTemplate_391377ba9a9080956aa02d59b3c15b20 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/hero.twig");
        craft\helpers\Template::preloadSingles(['entry', 'siteUrl']);
        // line 1
        yield "<section class=\"relative overflow-hidden min-h-screen flex items-center bg-gradient-to-br from-navy via-slate-900 to-charcoal dark:from-navy dark:to-charcoal\">
  <!-- Background video -->
  <div class=\"absolute inset-0 w-full h-full z-0 pointer-events-none\">
    <video
      src=\"";
        // line 5
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 5, $this->source); })())), "heroVideo", [], "any", false, false, false, 5)) {
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 5, $this->source); })())), "heroVideo", [], "any", false, false, false, 5), "one", [], "method", false, false, false, 5), "url", [], "any", false, false, false, 5), "html", null, true);
        } else {
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 5, $this->source); })())), "html", null, true);
            yield "assets/layout/hero.mp4";
        }
        yield "\"
      autoplay
      loop
      muted
      playsinline
      class=\"w-full h-full object-cover object-center\"
    ></video>
    <!-- Dark overlay for readability -->
    <div class=\"absolute inset-0 bg-gradient-to-br from-navy/80 via-slate-900/70 to-charcoal/80 dark:from-navy/90 dark:to-charcoal/90\"></div>
  </div>
  
  <!-- Floating geometric shapes (remain above background) -->
  <div class=\"absolute -top-32 -left-32 w-96 h-96 bg-gradient-to-br from-brand/30 to-blue/20 rounded-full blur-3xl opacity-60 animate-pulse\"></div>
  <div class=\"absolute bottom-0 right-0 w-80 h-80 bg-gradient-to-tr from-blue/30 to-brand/20 rounded-full blur-2xl opacity-50 animate-spin-slow\"></div>
  
  <!-- Main hero content -->
  <div class=\"relative z-10 max-w-7xl mx-auto px-6 py-20 flex flex-col lg:flex-row items-center gap-12\">
    <div class=\"flex-1 text-center lg:text-left\">
      <h1 class=\"text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight drop-shadow-lg\">
        ";
        // line 24
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 24, $this->source); })())), "headlineLineOne", [], "any", false, false, false, 24)) {
            // line 25
            yield "          ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 25, $this->source); })())), "headlineLineOne", [], "any", false, false, false, 25), "html", null, true);
            yield "<br>
        ";
        } else {
            // line 27
            yield "          Grow Your Clinic<br>
        ";
        }
        // line 29
        yield "        
        ";
        // line 30
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 30, $this->source); })())), "headlineLineTwo", [], "any", false, false, false, 30)) {
            // line 31
            yield "          <span class=\"bg-clip-text text-transparent bg-gradient-to-r from-brand to-blue animate-gradient-x\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 31, $this->source); })())), "headlineLineTwo", [], "any", false, false, false, 31), "html", null, true);
            yield "</span>
        ";
        } else {
            // line 33
            yield "          <span class=\"bg-clip-text text-transparent bg-gradient-to-r from-brand to-blue animate-gradient-x\">With Proven Digital Strategies</span>
        ";
        }
        // line 35
        yield "      </h1>
      
      <p class=\"mt-6 text-xl text-white/90 font-medium max-w-2xl mx-auto lg:mx-0\">
        ";
        // line 38
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 38, $this->source); })())), "heroDescription", [], "any", false, false, false, 38)) {
            // line 39
            yield "          ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 39, $this->source); })())), "heroDescription", [], "any", false, false, false, 39), "html", null, true);
            yield "
        ";
        } else {
            // line 41
            yield "          We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.
        ";
        }
        // line 43
        yield "      </p>
      
      <div class=\"mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start\">
        ";
        // line 47
        yield "        ";
        yield from $this->loadTemplate("components/cta-button", "components/hero.twig", 47)->unwrap()->yield(CoreExtension::merge($context, ["ctas" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 47, $this->source); })())), "ctaButtons", [], "any", false, false, false, 47)]));
        // line 48
        yield "      </div>
    </div>
    
    <div class=\"flex-1 flex justify-center\">
      ";
        // line 53
        yield "    </div>
  </div>
</section>";
        craft\helpers\Template::endProfile("template", "components/hero.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "components/hero.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  135 => 53,  129 => 48,  126 => 47,  121 => 43,  117 => 41,  111 => 39,  109 => 38,  104 => 35,  100 => 33,  94 => 31,  92 => 30,  89 => 29,  85 => 27,  79 => 25,  77 => 24,  50 => 5,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<section class=\"relative overflow-hidden min-h-screen flex items-center bg-gradient-to-br from-navy via-slate-900 to-charcoal dark:from-navy dark:to-charcoal\">
  <!-- Background video -->
  <div class=\"absolute inset-0 w-full h-full z-0 pointer-events-none\">
    <video
      src=\"{% if entry.heroVideo %}{{ entry.heroVideo.one().url }}{% else %}{{ siteUrl }}assets/layout/hero.mp4{% endif %}\"
      autoplay
      loop
      muted
      playsinline
      class=\"w-full h-full object-cover object-center\"
    ></video>
    <!-- Dark overlay for readability -->
    <div class=\"absolute inset-0 bg-gradient-to-br from-navy/80 via-slate-900/70 to-charcoal/80 dark:from-navy/90 dark:to-charcoal/90\"></div>
  </div>
  
  <!-- Floating geometric shapes (remain above background) -->
  <div class=\"absolute -top-32 -left-32 w-96 h-96 bg-gradient-to-br from-brand/30 to-blue/20 rounded-full blur-3xl opacity-60 animate-pulse\"></div>
  <div class=\"absolute bottom-0 right-0 w-80 h-80 bg-gradient-to-tr from-blue/30 to-brand/20 rounded-full blur-2xl opacity-50 animate-spin-slow\"></div>
  
  <!-- Main hero content -->
  <div class=\"relative z-10 max-w-7xl mx-auto px-6 py-20 flex flex-col lg:flex-row items-center gap-12\">
    <div class=\"flex-1 text-center lg:text-left\">
      <h1 class=\"text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight drop-shadow-lg\">
        {% if entry.headlineLineOne %}
          {{ entry.headlineLineOne }}<br>
        {% else %}
          Grow Your Clinic<br>
        {% endif %}
        
        {% if entry.headlineLineTwo %}
          <span class=\"bg-clip-text text-transparent bg-gradient-to-r from-brand to-blue animate-gradient-x\">{{ entry.headlineLineTwo }}</span>
        {% else %}
          <span class=\"bg-clip-text text-transparent bg-gradient-to-r from-brand to-blue animate-gradient-x\">With Proven Digital Strategies</span>
        {% endif %}
      </h1>
      
      <p class=\"mt-6 text-xl text-white/90 font-medium max-w-2xl mx-auto lg:mx-0\">
        {% if entry.heroDescription %}
          {{ entry.heroDescription }}
        {% else %}
          We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.
        {% endif %}
      </p>
      
      <div class=\"mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start\">
        {# Renders all selected CTAs automatically #}
        {% include 'components/cta-button' with { 'ctas': entry.ctaButtons } %}
      </div>
    </div>
    
    <div class=\"flex-1 flex justify-center\">
      {# You can add hero image or other content here #}
    </div>
  </div>
</section>", "components/hero.twig", "/var/www/html/templates/components/hero.twig");
    }
}
