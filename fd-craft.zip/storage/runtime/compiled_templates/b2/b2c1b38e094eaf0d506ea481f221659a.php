<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _layouts/elementindex */
class __TwigTemplate_6b288338720492685f4473c2cee70063 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'sidebar' => [$this, 'block_sidebar'],
            'toolbar' => [$this, 'block_toolbar'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
            'initJs' => [$this, 'block_initJs'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/elementindex");
        // line 3
        echo \Craft::$app->getView()->invokeHook("cp.layouts.elementindex", $context);

        // line 5
        if ((isset($context["showSiteMenu"]) || array_key_exists("showSiteMenu", $context) ? $context["showSiteMenu"] : (function () { throw new RuntimeError('Variable "showSiteMenu" does not exist.', 5, $this->source); })())) {
            // line 6
            if ( !array_key_exists("selectableSites", $context)) {
                // line 7
                if (array_key_exists("siteIds", $context)) {
                    // line 8
                    $context["selectableSites"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 8, $this->source); })()), "app", [], "any", false, false, false, 8), "sites", [], "any", false, false, false, 8), "getEditableSites", [], "method", false, false, false, 8), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return CoreExtension::inFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 8, $this->source); })()), "id", [], "any", false, false, false, 8), (isset($context["siteIds"]) || array_key_exists("siteIds", $context) ? $context["siteIds"] : (function () { throw new RuntimeError('Variable "siteIds" does not exist.', 8, $this->source); })())); });
                } else {
                    // line 10
                    $context["selectableSites"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", [], "any", false, false, false, 10), "sites", [], "any", false, false, false, 10), "getEditableSites", [], "method", false, false, false, 10);
                }
            }
            // line 14
            if ( !array_key_exists("selectedSite", $context)) {
                // line 15
                if (array_key_exists("selectedSiteId", $context)) {
                    // line 16
                    $context["selectedSite"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 16, $this->source); })()), "app", [], "any", false, false, false, 16), "sites", [], "any", false, false, false, 16), "getSiteById", [(isset($context["selectedSiteId"]) || array_key_exists("selectedSiteId", $context) ? $context["selectedSiteId"] : (function () { throw new RuntimeError('Variable "selectedSiteId" does not exist.', 16, $this->source); })())], "method", false, false, false, 16);
                } elseif ((                // line 17
(isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 17, $this->source); })()) && CoreExtension::inFilter((isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 17, $this->source); })()), (isset($context["selectableSites"]) || array_key_exists("selectableSites", $context) ? $context["selectableSites"] : (function () { throw new RuntimeError('Variable "selectableSites" does not exist.', 17, $this->source); })())))) {
                    // line 18
                    $context["selectedSite"] = (isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 18, $this->source); })());
                } else {
                    // line 20
                    $context["selectedSite"] = (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["selectableSites"]) || array_key_exists("selectableSites", $context) ? $context["selectableSites"] : (function () { throw new RuntimeError('Variable "selectableSites" does not exist.', 20, $this->source); })()))) ? (Twig\Extension\CoreExtension::first($this->env->getCharset(), (isset($context["selectableSites"]) || array_key_exists("selectableSites", $context) ? $context["selectableSites"] : (function () { throw new RuntimeError('Variable "selectableSites" does not exist.', 20, $this->source); })()))) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 20, $this->source); })()), "app", [], "any", false, false, false, 20), "sites", [], "any", false, false, false, 20), "getPrimarySite", [], "method", false, false, false, 20)));
                }
            }
            // line 24
            $context["crumbs"] = $this->extensions['craft\web\twig\Extension']->unshiftFilter((($context["crumbs"]) ?? ([])), ["id" => "site-crumb", "icon" => "world", "iconAltText" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 28
(isset($context["selectedSite"]) || array_key_exists("selectedSite", $context) ? $context["selectedSite"] : (function () { throw new RuntimeError('Variable "selectedSite" does not exist.', 28, $this->source); })()), "name", [], "any", false, false, false, 28), "site"), "menu" => ["items" => craft\helpers\Cp::siteMenuItems(            // line 30
(isset($context["selectableSites"]) || array_key_exists("selectableSites", $context) ? $context["selectableSites"] : (function () { throw new RuntimeError('Variable "selectableSites" does not exist.', 30, $this->source); })()), (isset($context["selectedSite"]) || array_key_exists("selectedSite", $context) ? $context["selectedSite"] : (function () { throw new RuntimeError('Variable "selectedSite" does not exist.', 30, $this->source); })())), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Select site", "app")]]);
        }
        // line 93
        craft\helpers\Template::js(        $this->unwrap()->renderBlock("initJs", $context, $blocks), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp.twig", "_layouts/elementindex", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_layouts/elementindex");
    }

    // line 36
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_sidebar(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "sidebar");
        // line 37
        yield "    ";
        if ( !Twig\Extension\CoreExtension::testEmpty((isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 37, $this->source); })()))) {
            // line 38
            yield "        ";
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["class" => "btn skip-link", "href" => "#elements", "html" => Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), $this->extensions['craft\web\twig\Extension']->translateFilter("Skip to {name}", "app", ["name" => Twig\Extension\CoreExtension::lower($this->env->getCharset(),             // line 42
(isset($context["elementPluralDisplayName"]) || array_key_exists("elementPluralDisplayName", $context) ? $context["elementPluralDisplayName"] : (function () { throw new RuntimeError('Variable "elementPluralDisplayName" does not exist.', 42, $this->source); })()))]))]);
            // line 44
            yield "

        <nav aria-labelledby=\"source-heading\">
            <h2 id=\"source-heading\" class=\"visually-hidden\">";
            // line 47
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Sources", "app"), "html", null, true);
            yield "</h2>
            ";
            // line 48
            yield from $this->loadTemplate("_elements/sources", "_layouts/elementindex", 48)->unwrap()->yield($context);
            // line 49
            yield "        </nav>

        <div id=\"source-actions\" class=\"buttons\"></div>
    ";
        }
        craft\helpers\Template::endProfile("block", "sidebar");
        yield from [];
    }

    // line 56
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_toolbar(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "toolbar");
        // line 57
        yield "    ";
        yield from $this->loadTemplate("_elements/toolbar", "_layouts/elementindex", 57)->unwrap()->yield(CoreExtension::merge($context, ["showSiteMenu" => false]));
        craft\helpers\Template::endProfile("block", "toolbar");
        yield from [];
    }

    // line 63
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 64
        yield "    <div class=\"main element-index\">
        <span class=\"visually-hidden\" role=\"status\" data-status-message></span>
        <a class=\"skip-link btn\" href=\"#footer\">";
        // line 66
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Skip to footer", "app"), "html", null, true);
        yield "</a>
        <div id=\"elements\" class=\"elements busy\">
            <div class=\"update-spinner spinner spinner-absolute\"></div>
        </div>
    </div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    // line 74
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "footer");
        // line 75
        yield "    ";
        yield from $this->loadTemplate("_elements/footer", "_layouts/elementindex", 75)->unwrap()->yield($context);
        craft\helpers\Template::endProfile("block", "footer");
        yield from [];
    }

    // line 79
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_initJs(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "initJs");
        // line 80
        yield "    Craft.elementIndex = Craft.createElementIndex('";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 80, $this->source); })()), "js"), "html", null, true);
        yield "', \$('#page-container'), {
        elementTypeName: '";
        // line 81
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["elementDisplayName"]) || array_key_exists("elementDisplayName", $context) ? $context["elementDisplayName"] : (function () { throw new RuntimeError('Variable "elementDisplayName" does not exist.', 81, $this->source); })()), "js"), "html", null, true);
        yield "',
        elementTypePluralName: '";
        // line 82
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["elementPluralDisplayName"]) || array_key_exists("elementPluralDisplayName", $context) ? $context["elementPluralDisplayName"] : (function () { throw new RuntimeError('Variable "elementPluralDisplayName" does not exist.', 82, $this->source); })()), "js"), "html", null, true);
        yield "',
        context: '";
        // line 83
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 83, $this->source); })()), "html", null, true);
        yield "',
        storageKey: 'elementindex.";
        // line 84
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 84, $this->source); })()), "js"), "html", null, true);
        yield "',
        criteria: Craft.defaultIndexCriteria,
        toolbarSelector: '#toolbar',
        defaultSource: ";
        // line 87
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((($context["defaultSource"]) ?? (null)));
        yield ",
        defaultSourcePath: ";
        // line 88
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((($context["defaultSourcePath"]) ?? (null)));
        yield ",
        canHaveDrafts: ";
        // line 89
        yield (((isset($context["canHaveDrafts"]) || array_key_exists("canHaveDrafts", $context) ? $context["canHaveDrafts"] : (function () { throw new RuntimeError('Variable "canHaveDrafts" does not exist.', 89, $this->source); })())) ? ("true") : ("false"));
        yield ",
    });
";
        craft\helpers\Template::endProfile("block", "initJs");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_layouts/elementindex";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  225 => 89,  221 => 88,  217 => 87,  211 => 84,  207 => 83,  203 => 82,  199 => 81,  194 => 80,  186 => 79,  179 => 75,  171 => 74,  159 => 66,  155 => 64,  147 => 63,  140 => 57,  132 => 56,  122 => 49,  120 => 48,  116 => 47,  111 => 44,  109 => 42,  107 => 38,  104 => 37,  96 => 36,  90 => 1,  88 => 93,  85 => 30,  84 => 28,  83 => 24,  79 => 20,  76 => 18,  74 => 17,  72 => 16,  70 => 15,  68 => 14,  64 => 10,  61 => 8,  59 => 7,  57 => 6,  55 => 5,  52 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '_layouts/cp.twig' %}

{% hook 'cp.layouts.elementindex' %}

{% if showSiteMenu %}
    {% if selectableSites is not defined %}
        {% if siteIds is defined %}
            {% set selectableSites = craft.app.sites.getEditableSites()|filter(s => s.id in siteIds) %}
        {% else %}
            {% set selectableSites = craft.app.sites.getEditableSites() %}
        {% endif %}
    {% endif %}

    {% if selectedSite is not defined %}
        {% if selectedSiteId is defined %}
            {% set selectedSite = craft.app.sites.getSiteById(selectedSiteId) %}
        {% elseif requestedSite and requestedSite in selectableSites %}
            {% set selectedSite = requestedSite %}
        {% else %}
            {% set selectedSite = selectableSites|length ? selectableSites|first : craft.app.sites.getPrimarySite() %}
        {% endif %}
    {% endif %}

    {% set crumbs = (crumbs ?? [])|unshift({
        id: 'site-crumb',
        icon: 'world',
        iconAltText: 'Site'|t('app'),
        label: selectedSite.name|t('site'),
        menu: {
            items: siteMenuItems(selectableSites, selectedSite),
            label: 'Select site'|t('app')
        }
    }) %}
{% endif %}

{% block sidebar %}
    {% if sources is not empty %}
        {{ tag('a', {
            class: 'btn skip-link',
            href: '#elements',
            html: 'Skip to {name}'|t('app', {
                name: elementPluralDisplayName|lower,
            })|capitalize,
        }) }}

        <nav aria-labelledby=\"source-heading\">
            <h2 id=\"source-heading\" class=\"visually-hidden\">{{ 'Sources'|t('app') }}</h2>
            {% include \"_elements/sources\" %}
        </nav>

        <div id=\"source-actions\" class=\"buttons\"></div>
    {% endif %}
{% endblock %}


{% block toolbar %}
    {% include '_elements/toolbar' with {
        showSiteMenu: false,
    } %}
{% endblock %}


{% block content %}
    <div class=\"main element-index\">
        <span class=\"visually-hidden\" role=\"status\" data-status-message></span>
        <a class=\"skip-link btn\" href=\"#footer\">{{ 'Skip to footer'|t('app') }}</a>
        <div id=\"elements\" class=\"elements busy\">
            <div class=\"update-spinner spinner spinner-absolute\"></div>
        </div>
    </div>
{% endblock %}


{% block footer %}
    {% include '_elements/footer' %}
{% endblock %}


{% block initJs %}
    Craft.elementIndex = Craft.createElementIndex('{{ elementType|e(\"js\") }}', \$('#page-container'), {
        elementTypeName: '{{ elementDisplayName|e(\"js\") }}',
        elementTypePluralName: '{{ elementPluralDisplayName|e(\"js\") }}',
        context: '{{ context }}',
        storageKey: 'elementindex.{{ elementType|e(\"js\") }}',
        criteria: Craft.defaultIndexCriteria,
        toolbarSelector: '#toolbar',
        defaultSource: {{ (defaultSource ?? null)|json_encode|raw }},
        defaultSourcePath: {{ (defaultSourcePath ?? null)|json_encode|raw }},
        canHaveDrafts: {{ canHaveDrafts ? 'true' : 'false' }},
    });
{% endblock %}

{% js block('initJs') %}
", "_layouts/elementindex", "/var/www/html/vendor/craftcms/cms/src/templates/_layouts/elementindex.twig");
    }
}
