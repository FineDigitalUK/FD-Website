<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/globals/_index.twig */
class __TwigTemplate_4cb84b464f6a5e6017d791cd8ae69416 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 3
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/globals/_index.twig");
        // line 1
        Craft::$app->controller->requireAdmin(false);
        // line 5
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 15
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 15, $this->source); })())) {
            // line 16
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 23
        $context["tableData"] = [];
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["globalSets"]) || array_key_exists("globalSets", $context) ? $context["globalSets"] : (function () { throw new RuntimeError('Variable "globalSets" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["globalSet"]) {
            // line 25
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 25, $this->source); })()), [["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 26
$context["globalSet"], "id", [], "any", false, false, false, 26), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 27
$context["globalSet"], "name", [], "any", false, false, false, 27), "site"), "url" => craft\helpers\UrlHelper::url(("settings/globals/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 28
$context["globalSet"], "id", [], "any", false, false, false, 28))), "handle" => craft\helpers\Template::attribute($this->env, $this->source,             // line 29
$context["globalSet"], "handle", [], "any", false, false, false, 29)]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['globalSet'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        ob_start();
        // line 34
        yield "var columns = [
    {
        name: '__slot:title',
        title: Craft.t('app', 'Global Set Name'),
    },
    {
        name: '__slot:handle',
        title: Craft.t('app', 'Handle'),
    },
];

let config = {
    columns: columns,
    container: '#sets-vue-admin-table',
    emptyMessage: Craft.t('app', 'No global sets exist yet.'),
    tableData: ";
        // line 49
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 49, $this->source); })()));
        yield "
}

";
        // line 52
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 52, $this->source); })())) {
            // line 53
            yield "    config['deleteAction'] = 'globals/delete-set';
    config['reorderAction'] = '";
            // line 54
            yield ((($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["globalSets"]) || array_key_exists("globalSets", $context) ? $context["globalSets"] : (function () { throw new RuntimeError('Variable "globalSets" does not exist.', 54, $this->source); })())) > 1)) ? ("globals/reorder-sets") : (""));
            yield "';
";
        }
        // line 56
        yield "
new Craft.VueAdminTable(config);
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 3
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/globals/_index.twig", 3);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/globals/_index.twig");
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 8
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 8, $this->source); })())) {
            // line 9
            yield "        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("settings/globals/new"), "html", null, true);
            yield "\" class=\"btn submit add icon\">
            ";
            // line 10
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["buttonLabel"]) || array_key_exists("buttonLabel", $context) ? $context["buttonLabel"] : (function () { throw new RuntimeError('Variable "buttonLabel" does not exist.', 10, $this->source); })()), "html", null, true);
            yield "
        </a>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 20
        yield "    <div id=\"sets-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/globals/_index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  154 => 20,  146 => 19,  136 => 10,  131 => 9,  128 => 8,  120 => 7,  114 => 3,  109 => 56,  104 => 54,  101 => 53,  99 => 52,  93 => 49,  76 => 34,  74 => 33,  68 => 29,  67 => 28,  66 => 27,  65 => 26,  64 => 25,  60 => 24,  58 => 23,  55 => 16,  53 => 15,  51 => 5,  49 => 1,  41 => 3,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% requireAdmin false %}

{% extends \"_layouts/cp\" %}

{% set readOnly = readOnly ?? false %}

{% block actionButton %}
    {% if not readOnly %}
        <a href=\"{{ url('settings/globals/new') }}\" class=\"btn submit add icon\">
            {{ buttonLabel }}
        </a>
    {% endif %}
{% endblock %}

{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    <div id=\"sets-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% for globalSet in globalSets %}
    {% set tableData = tableData|merge([{
        id: globalSet.id,
        title: globalSet.name|t('site'),
        url: url('settings/globals/' ~ globalSet.id),
        handle: globalSet.handle,
    }]) %}
{% endfor %}

{% js %}
var columns = [
    {
        name: '__slot:title',
        title: Craft.t('app', 'Global Set Name'),
    },
    {
        name: '__slot:handle',
        title: Craft.t('app', 'Handle'),
    },
];

let config = {
    columns: columns,
    container: '#sets-vue-admin-table',
    emptyMessage: Craft.t('app', 'No global sets exist yet.'),
    tableData: {{ tableData|json_encode|raw }}
}

{% if not readOnly %}
    config['deleteAction'] = 'globals/delete-set';
    config['reorderAction'] = '{{ globalSets|length > 1 ? 'globals/reorder-sets' : ''}}';
{% endif %}

new Craft.VueAdminTable(config);
{% endjs %}
", "settings/globals/_index.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/globals/_index.twig");
    }
}
