<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/mailertransportadapters/Sendmail/settings.twig */
class __TwigTemplate_cce96c9ecbd0e23981b2e95707971ec7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/mailertransportadapters/Sendmail/settings.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/mailertransportadapters/Sendmail/settings.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 4
        yield "
";
        // line 5
        yield $macros["forms"]->getTemplateForMacro("macro_selectizeField", $context, 5, $this->getSourceContext())->macro_selectizeField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sendmail Command", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The command to run Sendmail with.", "app"), "id" => "command", "name" => "command", "options" =>         // line 10
(isset($context["commandOptions"]) || array_key_exists("commandOptions", $context) ? $context["commandOptions"] : (function () { throw new RuntimeError('Variable "commandOptions" does not exist.', 10, $this->source); })()), "includeEnvVars" => true, "allowedEnvValues" => null, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 13
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 13, $this->source); })()), "command", [], "any", false, false, false, 13), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 14
(isset($context["adapter"]) || array_key_exists("adapter", $context) ? $context["adapter"] : (function () { throw new RuntimeError('Variable "adapter" does not exist.', 14, $this->source); })()), "getErrors", ["command"], "method", false, false, false, 14), "disabled" =>         // line 15
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 15, $this->source); })())]]);
        // line 16
        yield "
";
        craft\helpers\Template::endProfile("template", "_components/mailertransportadapters/Sendmail/settings.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/mailertransportadapters/Sendmail/settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  59 => 16,  57 => 15,  56 => 14,  55 => 13,  54 => 10,  53 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% set readOnly = readOnly ?? false %}

{{ forms.selectizeField({
    label: 'Sendmail Command'|t('app'),
    instructions: 'The command to run Sendmail with.'|t('app'),
    id: 'command',
    name: 'command',
    options: commandOptions,
    includeEnvVars: true,
    allowedEnvValues: null,
    value: adapter.command,
    errors: adapter.getErrors('command'),
    disabled: readOnly,
}) }}
", "_components/mailertransportadapters/Sendmail/settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/mailertransportadapters/Sendmail/settings.twig");
    }
}
