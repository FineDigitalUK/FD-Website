<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* navigation/_layouts */
class __TwigTemplate_c3d960274c4510db82794f3993c0bba6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'blockContent' => [$this, 'block_blockContent'],
            'footerButton' => [$this, 'block_footerButton'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "navigation/_layouts");
        // line 3
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 3, $this->source); })()), "registerAssetBundle", ["verbb\\navigation\\assetbundles\\NavigationAsset"], "method", false, false, false, 3);
        // line 5
        if ( !array_key_exists("title", $context)) {
            // line 6
            $context["title"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "navigation", [], "any", false, false, false, 6), "getPluginName", [], "method", false, false, false, 6);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "navigation/_layouts", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "navigation/_layouts");
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 10
        yield "    ";
        yield from $this->unwrap()->yieldBlock('blockContent', $context, $blocks);
        // line 13
        yield "
    <hr>
    
    <div id=\"plugin-footer\">
        <div class=\"footer-left\">
            ";
        // line 18
        yield from $this->unwrap()->yieldBlock('footerButton', $context, $blocks);
        // line 21
        yield "        </div>

        <div class=\"footer-right\">
            <a class=\"plugin-credit\" href=\"https://verbb.io\" target=\"_blank\">
                <span class=\"credit-love\">Made with <span style=\"color: #e25555;\">&#9829;</span> by</span>

                <div class=\"credit-pill\">
                    <div class=\"credit-mask\">
                        <div class=\"credit-wrap\">
                            ";
        // line 30
        yield from $this->loadTemplate("verbb-base/_svg/verbb-logo.svg", "navigation/_layouts", 30)->unwrap()->yield($context);
        // line 31
        yield "                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_blockContent(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "blockContent");
        // line 11
        yield "
    ";
        craft\helpers\Template::endProfile("block", "blockContent");
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footerButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "footerButton");
        // line 19
        yield "
            ";
        craft\helpers\Template::endProfile("block", "footerButton");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "navigation/_layouts";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  131 => 19,  123 => 18,  116 => 11,  108 => 10,  96 => 31,  94 => 30,  83 => 21,  81 => 18,  74 => 13,  71 => 10,  63 => 9,  57 => 1,  54 => 6,  52 => 5,  50 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '_layouts/cp' %}

{% do view.registerAssetBundle(\"verbb\\\\navigation\\\\assetbundles\\\\NavigationAsset\") %}

{% if title is not defined %}
    {% set title = craft.navigation.getPluginName() %}
{% endif %}

{% block content %}
    {% block blockContent %}

    {% endblock %}

    <hr>
    
    <div id=\"plugin-footer\">
        <div class=\"footer-left\">
            {% block footerButton %}

            {% endblock %}
        </div>

        <div class=\"footer-right\">
            <a class=\"plugin-credit\" href=\"https://verbb.io\" target=\"_blank\">
                <span class=\"credit-love\">Made with <span style=\"color: #e25555;\">&#9829;</span> by</span>

                <div class=\"credit-pill\">
                    <div class=\"credit-mask\">
                        <div class=\"credit-wrap\">
                            {% include 'verbb-base/_svg/verbb-logo.svg' %}
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
{% endblock %}
", "navigation/_layouts", "/var/www/html/vendor/verbb/navigation/src/templates/_layouts/index.html");
    }
}
