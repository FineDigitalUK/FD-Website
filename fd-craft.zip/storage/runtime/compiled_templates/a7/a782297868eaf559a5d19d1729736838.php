<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _layout */
class __TwigTemplate_20b16ce5f9c0bb0f1954b5861d66b21f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layout");
        craft\helpers\Template::preloadSingles(['title', 'siteName', 'craft', 'siteUrl', 'entry', 'isHomepage', 'navNodes', 'node', 'hasChildren', 'child', 'footerNavNodes']);
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"en\" class=\"\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>";
        // line 6
        if ((array_key_exists("title", $context) || craft\helpers\Template::fallbackExists("title"))) {
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (craft\helpers\Template::fallbackExists("title") ? craft\helpers\Template::fallback("title") : (function () { throw new RuntimeError('Variable "title" does not exist.', 6, $this->source); })())), "html", null, true);
            yield " - ";
        }
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["siteName"]) || array_key_exists("siteName", $context) ? $context["siteName"] : (craft\helpers\Template::fallbackExists("siteName") ? craft\helpers\Template::fallback("siteName") : (function () { throw new RuntimeError('Variable "siteName" does not exist.', 6, $this->source); })())), "html", null, true);
        yield "</title>
    
    <!-- Critical CSS - Only essential styles inline -->
    <style>
        /* Critical above-the-fold styles only */
        body { 
            margin: 0; 
            font-family: system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
            transition: background-color 0.3s ease;
        }
        .dark body { 
            background-color: #181c2a; 
        }
        
        /* Critical navigation styles to prevent layout shift */
        nav {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 50;
            transition: all 0.3s ease;
        }
        
        .nav-overlay {
            background: transparent;
            backdrop-filter: none;
        }
        
        .nav-overlay.scrolled {
            background: rgba(24, 28, 42, 0.95);
            backdrop-filter: blur(10px);
        }
        
        .nav-solid {
            background: rgba(24, 28, 42, 0.98);
            backdrop-filter: blur(10px);
        }
        
        /* Prevent flash of unstyled content */
        .mobile-menu {
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }
        
        .mobile-menu.open {
            transform: translateX(0);
        }
        
        /* Hide content until fonts/CSS load */
        .content-wrapper {
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .content-loaded .content-wrapper {
            opacity: 1;
        }
    </style>
    
    <!-- Preload critical resources -->
    ";
        // line 68
        if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 68, $this->source); })())), "app", [], "any", false, false, false, 68), "config", [], "any", false, false, false, 68), "env", [], "any", false, false, false, 68) == "dev")) {
            // line 69
            yield "        <link rel=\"preload\" href=\"http://localhost:5173/src/css/app.css\" as=\"style\" onload=\"this.onload=null;this.rel='stylesheet'\">
        <noscript><link rel=\"stylesheet\" href=\"http://localhost:5173/src/css/app.css\"></noscript>
    ";
        } else {
            // line 72
            yield "        <link rel=\"preload\" href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 72, $this->source); })())), "html", null, true);
            yield "dist/assets/app.css\" as=\"style\" onload=\"this.onload=null;this.rel='stylesheet'\">
        <noscript><link rel=\"stylesheet\" href=\"";
            // line 73
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 73, $this->source); })())), "html", null, true);
            yield "dist/assets/app.css\"></noscript>
    ";
        }
        // line 75
        yield "    
    <!-- Load CSS asynchronously -->
    ";
        // line 77
        if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 77, $this->source); })())), "app", [], "any", false, false, false, 77), "config", [], "any", false, false, false, 77), "env", [], "any", false, false, false, 77) == "dev")) {
            // line 78
            yield "        <link rel=\"stylesheet\" href=\"http://localhost:5173/src/css/app.css\" media=\"print\" onload=\"this.media='all'\">
    ";
        } else {
            // line 80
            yield "        <link rel=\"stylesheet\" href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 80, $this->source); })())), "html", null, true);
            yield "dist/assets/app.css\" media=\"print\" onload=\"this.media='all'\">
    ";
        }
        // line 82
        yield "    
    <!-- Preload JavaScript -->
    ";
        // line 84
        if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 84, $this->source); })())), "app", [], "any", false, false, false, 84), "config", [], "any", false, false, false, 84), "env", [], "any", false, false, false, 84) == "dev")) {
            // line 85
            yield "        <script type=\"module\" src=\"http://localhost:5173/@vite/client\"></script>
        <link rel=\"modulepreload\" href=\"http://localhost:5173/src/js/app.js\">
    ";
        }
        // line 88
        yield "";
        $this->env->getFunction('head')->getCallable()();
        yield "</head>
<body>";
        // line 89
        $this->env->getFunction('beginBody')->getCallable()();
        yield "
    
    ";
        // line 92
        yield "  
    ";
        // line 93
        $context["isHomepage"] = (((array_key_exists("entry", $context) || craft\helpers\Template::fallbackExists("entry")) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 93, $this->source); })())), "slug", [], "any", false, false, false, 93) == "__home__")) || (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 93, $this->source); })())), "app", [], "any", false, false, false, 93), "request", [], "any", false, false, false, 93), "pathInfo", [], "any", false, false, false, 93) == ""));
        // line 94
        yield "
    <!-- Content wrapper for loading states -->
    <div class=\"content-wrapper\">
        
        ";
        // line 99
        yield "        ";
        if ((isset($context["isHomepage"]) || array_key_exists("isHomepage", $context) ? $context["isHomepage"] : (craft\helpers\Template::fallbackExists("isHomepage") ? craft\helpers\Template::fallback("isHomepage") : (function () { throw new RuntimeError('Variable "isHomepage" does not exist.', 99, $this->source); })()))) {
            // line 100
            yield "            <!-- HOMEPAGE NAVIGATION - Overlay style with sticky scroll -->
            <nav id=\"homepage-nav\" class=\"nav-overlay py-4\">
                <div class=\"max-w-7xl mx-auto px-6 flex items-center justify-between\">
                    
                    <!-- Logo -->
                    <div class=\"flex items-center\">
                        <a href=\"";
            // line 106
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 106, $this->source); })())), "html", null, true);
            yield "\" class=\"flex items-center gap-3\">
                            <div class=\"w-10 h-10 bg-brand rounded-lg flex items-center justify-center\">
                                <span class=\"text-white font-bold text-lg\">F</span>
                            </div>
                            ";
            // line 113
            yield "   
                            <span class=\"text-white font-bold text-xl\">Fine Digital</span>
                        </a>
                    </div>
                    
                    <!-- Desktop Menu -->
                    <div class=\"hidden lg:flex items-center space-x-8\">
                        ";
            // line 120
            $context["navNodes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 120, $this->source); })())), "navigation", [], "any", false, false, false, 120), "nodes", [], "method", false, false, false, 120), "handle", ["mainNav"], "method", false, false, false, 120), "level", [1], "method", false, false, false, 120), "all", [], "method", false, false, false, 120);
            // line 121
            yield "                        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["navNodes"]) || array_key_exists("navNodes", $context) ? $context["navNodes"] : (craft\helpers\Template::fallbackExists("navNodes") ? craft\helpers\Template::fallback("navNodes") : (function () { throw new RuntimeError('Variable "navNodes" does not exist.', 121, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["node"]) {
                // line 122
                yield "                            ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "buttonType", [], "any", false, false, false, 122) != "cta")) {
                    // line 123
                    yield "                                ";
                    $context["hasChildren"] = $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "children", [], "any", false, false, false, 123));
                    // line 124
                    yield "                                
                                ";
                    // line 125
                    if ((isset($context["hasChildren"]) || array_key_exists("hasChildren", $context) ? $context["hasChildren"] : (craft\helpers\Template::fallbackExists("hasChildren") ? craft\helpers\Template::fallback("hasChildren") : (function () { throw new RuntimeError('Variable "hasChildren" does not exist.', 125, $this->source); })()))) {
                        // line 126
                        yield "                                    <!-- Parent with dropdown -->
                                    <div class=\"relative group\">
                                        <button class=\"text-white/90 hover:text-brand transition-colors font-medium flex items-center gap-1\">
                                            ";
                        // line 129
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 129), "html", null, true);
                        yield "
                                            <svg class=\"w-4 h-4 transition-transform group-hover:rotate-180\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">
                                                <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 9l-7 7-7-7\"></path>
                                            </svg>
                                        </button>
                                        
                                        <!-- Dropdown menu -->
                                        <div class=\"absolute top-full  left-0 bg-white shadow-lg rounded-lg py-3 w-48 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50 mt-2\">
                                            ";
                        // line 137
                        $context['_parent'] = $context;
                        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "children", [], "any", false, false, false, 137));
                        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                            // line 138
                            yield "                                                <a href=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["child"], "url", [], "any", false, false, false, 138), "html", null, true);
                            yield "\" class=\"block px-5 py-2 text-gray-700 hover:bg-gray-50 hover:text-brand transition-colors\">
                                                    ";
                            // line 139
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["child"], "title", [], "any", false, false, false, 139), "html", null, true);
                            yield "
                                                </a>
                                            ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_key'], $context['child'], $context['_parent']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 142
                        yield "                                        </div>
                                    </div>
                                ";
                    } else {
                        // line 145
                        yield "                                    <!-- Regular link (no children) -->
                                    <a href=\"";
                        // line 146
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "url", [], "any", false, false, false, 146), "html", null, true);
                        yield "\" class=\"text-white/90 hover:text-brand transition-colors font-medium\">
                                        ";
                        // line 147
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 147), "html", null, true);
                        yield "
                                    </a>
                                ";
                    }
                    // line 150
                    yield "                            ";
                }
                // line 151
                yield "                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['node'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 152
            yield "                    </div>

                    <!-- CTA Button -->
                    <div class=\"hidden lg:flex items-center gap-4\">
                        ";
            // line 156
            $context["navNodes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 156, $this->source); })())), "navigation", [], "any", false, false, false, 156), "nodes", [], "method", false, false, false, 156), "handle", ["mainNav"], "method", false, false, false, 156), "all", [], "method", false, false, false, 156);
            // line 157
            yield "                        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["navNodes"]) || array_key_exists("navNodes", $context) ? $context["navNodes"] : (craft\helpers\Template::fallbackExists("navNodes") ? craft\helpers\Template::fallback("navNodes") : (function () { throw new RuntimeError('Variable "navNodes" does not exist.', 157, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["node"]) {
                // line 158
                yield "                            ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "buttonType", [], "any", false, false, false, 158) == "cta")) {
                    yield " ";
                    // line 159
                    yield "                                <a href=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "url", [], "any", false, false, false, 159), "html", null, true);
                    yield "\" class=\"px-6 py-3 bg-brand text-white font-semibold rounded-lg hover:bg-brand/90 transition-all transform hover:scale-105\">
                                    ";
                    // line 160
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 160), "html", null, true);
                    yield "
                                </a>
                            ";
                }
                // line 163
                yield "                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['node'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 164
            yield "                    </div>
                    
                    <!-- Mobile Menu Button -->
                    <button id=\"mobile-menu-button\" class=\"lg:hidden p-2 text-white hover:text-brand transition-colors\">
                        <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                            <path d=\"M4 6h16M4 12h16M4 18h16\"/>
                        </svg>
                    </button>
                </div>
            </nav>
            
            <!-- Mobile Menu Overlay for Homepage -->
            <div id=\"mobile-menu-overlay\" class=\"mobile-menu fixed inset-0 z-40 lg:hidden\">
                <div class=\"absolute inset-0 bg-navy/95 backdrop-blur-lg\"></div>
                <div class=\"relative h-full flex flex-col justify-center items-center space-y-8\">
                    ";
            // line 179
            $context["navNodes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 179, $this->source); })())), "navigation", [], "any", false, false, false, 179), "nodes", [], "method", false, false, false, 179), "handle", ["mainNav"], "method", false, false, false, 179), "level", [1], "method", false, false, false, 179), "all", [], "method", false, false, false, 179);
            // line 180
            yield "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["navNodes"]) || array_key_exists("navNodes", $context) ? $context["navNodes"] : (craft\helpers\Template::fallbackExists("navNodes") ? craft\helpers\Template::fallback("navNodes") : (function () { throw new RuntimeError('Variable "navNodes" does not exist.', 180, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["node"]) {
                // line 181
                yield "                        ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "buttonType", [], "any", false, false, false, 181) != "cta")) {
                    // line 182
                    yield "                            ";
                    $context["hasChildren"] = $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "children", [], "any", false, false, false, 182));
                    // line 183
                    yield "                            
                            ";
                    // line 184
                    if ((isset($context["hasChildren"]) || array_key_exists("hasChildren", $context) ? $context["hasChildren"] : (craft\helpers\Template::fallbackExists("hasChildren") ? craft\helpers\Template::fallback("hasChildren") : (function () { throw new RuntimeError('Variable "hasChildren" does not exist.', 184, $this->source); })()))) {
                        // line 185
                        yield "                                <!-- Parent with expandable children -->
                                <div class=\"text-center mb-4\">
                                    <button class=\"text-white text-2xl ml-[20px] font-semibold hover:text-brand transition-colors\" 
                                            onclick=\"toggleSubmenu(this)\">
                                        ";
                        // line 189
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 189), "html", null, true);
                        yield "
                                        <svg class=\"w-5 h-5 transition-transform inline-block\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">
                                            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 9l-7 7-7-7\"></path>
                                        </svg>
                                    </button>
                                    
                                    <!-- Submenu -->
                                    <div class=\"submenu max-h-0 overflow-hidden transition-all duration-300 mt-4\">
                                        ";
                        // line 197
                        $context['_parent'] = $context;
                        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "children", [], "any", false, false, false, 197));
                        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                            // line 198
                            yield "                                            <a href=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["child"], "url", [], "any", false, false, false, 198), "html", null, true);
                            yield "\" class=\"block py-2 text-white/80 hover:text-brand transition-colors text-lg\">
                                                ";
                            // line 199
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["child"], "title", [], "any", false, false, false, 199), "html", null, true);
                            yield "
                                            </a>
                                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_key'], $context['child'], $context['_parent']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 202
                        yield "                                    </div>
                                </div>
                            ";
                    } else {
                        // line 205
                        yield "                                <!-- Regular link -->
                                <a href=\"";
                        // line 206
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "url", [], "any", false, false, false, 206), "html", null, true);
                        yield "\" class=\"text-white text-2xl font-semibold hover:text-brand transition-colors\">";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 206), "html", null, true);
                        yield "</a>
                            ";
                    }
                    // line 208
                    yield "                        ";
                }
                // line 209
                yield "                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['node'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 210
            yield "                    
                    <!-- Mobile CTA -->
                    ";
            // line 212
            $context["navNodes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 212, $this->source); })())), "navigation", [], "any", false, false, false, 212), "nodes", [], "method", false, false, false, 212), "handle", ["mainNav"], "method", false, false, false, 212), "all", [], "method", false, false, false, 212);
            // line 213
            yield "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["navNodes"]) || array_key_exists("navNodes", $context) ? $context["navNodes"] : (craft\helpers\Template::fallbackExists("navNodes") ? craft\helpers\Template::fallback("navNodes") : (function () { throw new RuntimeError('Variable "navNodes" does not exist.', 213, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["node"]) {
                // line 214
                yield "                        ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "buttonType", [], "any", false, false, false, 214) == "cta")) {
                    // line 215
                    yield "                            <a href=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "url", [], "any", false, false, false, 215), "html", null, true);
                    yield "\" class=\"mt-8 px-8 py-4 bg-brand text-white font-bold rounded-lg hover:bg-brand/90 transition-all transform hover:scale-105\">
                                ";
                    // line 216
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 216), "html", null, true);
                    yield "
                            </a>
                        ";
                }
                // line 219
                yield "                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['node'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 220
            yield "                    
                    <!-- Close Button -->
                    <button id=\"mobile-menu-close\" class=\"absolute top-6 right-6 p-2 text-white hover:text-brand transition-colors\">
                        <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                            <path d=\"M6 18L18 6M6 6l12 12\"/>
                        </svg>
                    </button>
                </div>
            </div>
            
        ";
        } else {
            // line 231
            yield "            <!-- OTHER PAGES NAVIGATION - Solid style -->
            <nav class=\"nav-solid py-4\">
                <div class=\"max-w-7xl mx-auto px-6 flex items-center justify-between\">
                    
                    <!-- Logo -->
                    <div class=\"flex items-center\">
                        <a href=\"";
            // line 237
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 237, $this->source); })())), "html", null, true);
            yield "\" class=\"flex items-center gap-3\">
                            <div class=\"w-10 h-10 bg-brand rounded-lg flex items-center justify-center\">
                                <span class=\"text-white font-bold text-lg\">F</span> 
                            </div>
                            <span class=\"text-white font-bold text-xl\">Fine Digital</span>
                        </a>
                    </div>
                    
                    <!-- Desktop Menu -->
                    <div class=\"hidden lg:flex items-center space-x-8\">
                        ";
            // line 247
            $context["navNodes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 247, $this->source); })())), "navigation", [], "any", false, false, false, 247), "nodes", [], "method", false, false, false, 247), "handle", ["mainNav"], "method", false, false, false, 247), "level", [1], "method", false, false, false, 247), "all", [], "method", false, false, false, 247);
            // line 248
            yield "                        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["navNodes"]) || array_key_exists("navNodes", $context) ? $context["navNodes"] : (craft\helpers\Template::fallbackExists("navNodes") ? craft\helpers\Template::fallback("navNodes") : (function () { throw new RuntimeError('Variable "navNodes" does not exist.', 248, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["node"]) {
                // line 249
                yield "                            ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "buttonType", [], "any", false, false, false, 249) != "cta")) {
                    // line 250
                    yield "                                ";
                    $context["hasChildren"] = $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "children", [], "any", false, false, false, 250));
                    // line 251
                    yield "                                
                                ";
                    // line 252
                    if ((isset($context["hasChildren"]) || array_key_exists("hasChildren", $context) ? $context["hasChildren"] : (craft\helpers\Template::fallbackExists("hasChildren") ? craft\helpers\Template::fallback("hasChildren") : (function () { throw new RuntimeError('Variable "hasChildren" does not exist.', 252, $this->source); })()))) {
                        // line 253
                        yield "                                    <!-- Parent with dropdown -->
                                    <div class=\"relative group\">
                                        <button class=\"text-white/90 hover:text-brand transition-colors font-medium flex items-center gap-1\">
                                            ";
                        // line 256
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 256), "html", null, true);
                        yield "
                                            <svg class=\"w-4 h-4 transition-transform group-hover:rotate-180\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">
                                                <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 9l-7 7-7-7\"></path>
                                            </svg>
                                        </button>
                                        
                                        <!-- Dropdown menu -->
                                        <div class=\"absolute top-full left-0 bg-white shadow-lg rounded-lg py-3 w-48 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50 mt-2\">
                                            ";
                        // line 264
                        $context['_parent'] = $context;
                        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "children", [], "any", false, false, false, 264));
                        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                            // line 265
                            yield "                                                <a href=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["child"], "url", [], "any", false, false, false, 265), "html", null, true);
                            yield "\" class=\"block px-5 py-2 text-gray-700 hover:bg-gray-50 hover:text-brand transition-colors\">
                                                    ";
                            // line 266
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["child"], "title", [], "any", false, false, false, 266), "html", null, true);
                            yield "
                                                </a>
                                            ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_key'], $context['child'], $context['_parent']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 269
                        yield "                                        </div>
                                    </div>
                                ";
                    } else {
                        // line 272
                        yield "                                    <!-- Regular link (no children) -->
                                    <a href=\"";
                        // line 273
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "url", [], "any", false, false, false, 273), "html", null, true);
                        yield "\" class=\"text-white/90 hover:text-brand transition-colors font-medium\">
                                        ";
                        // line 274
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 274), "html", null, true);
                        yield "
                                    </a>
                                ";
                    }
                    // line 277
                    yield "                            ";
                }
                // line 278
                yield "                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['node'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 279
            yield "                    </div>
                    
                    <!-- CTA Button -->
                    <div class=\"hidden lg:flex items-center gap-4\">
                        ";
            // line 283
            $context["navNodes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 283, $this->source); })())), "navigation", [], "any", false, false, false, 283), "nodes", [], "method", false, false, false, 283), "handle", ["mainNav"], "method", false, false, false, 283), "all", [], "method", false, false, false, 283);
            // line 284
            yield "                        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["navNodes"]) || array_key_exists("navNodes", $context) ? $context["navNodes"] : (craft\helpers\Template::fallbackExists("navNodes") ? craft\helpers\Template::fallback("navNodes") : (function () { throw new RuntimeError('Variable "navNodes" does not exist.', 284, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["node"]) {
                // line 285
                yield "                            ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "buttonType", [], "any", false, false, false, 285) == "cta")) {
                    // line 286
                    yield "                                <a href=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "url", [], "any", false, false, false, 286), "html", null, true);
                    yield "\" class=\"px-6 py-3 bg-brand text-white font-semibold rounded-lg hover:bg-brand/90 transition-all transform hover:scale-105\">
                                    ";
                    // line 287
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 287), "html", null, true);
                    yield "
                                </a>
                            ";
                }
                // line 290
                yield "                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['node'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 291
            yield "                    </div>
                    
                    <!-- Mobile Menu Button -->
                    <button id=\"mobile-menu-button-inner\" class=\"lg:hidden p-2 text-white hover:text-brand transition-colors\">
                        <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                            <path d=\"M4 6h16M4 12h16M4 18h16\"/>
                        </svg>
                    </button>
                </div>
            </nav>
            
            <!-- Mobile Menu Overlay for Other Pages -->
            <div id=\"mobile-menu-overlay-inner\" class=\"mobile-menu fixed inset-0 z-40 lg:hidden\">
                <div class=\"absolute inset-0 bg-navy/95 backdrop-blur-lg\"></div>
                <div class=\"relative h-full flex flex-col justify-center items-center space-y-8\">
                    ";
            // line 306
            $context["navNodes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 306, $this->source); })())), "navigation", [], "any", false, false, false, 306), "nodes", [], "method", false, false, false, 306), "handle", ["mainNav"], "method", false, false, false, 306), "level", [1], "method", false, false, false, 306), "all", [], "method", false, false, false, 306);
            // line 307
            yield "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["navNodes"]) || array_key_exists("navNodes", $context) ? $context["navNodes"] : (craft\helpers\Template::fallbackExists("navNodes") ? craft\helpers\Template::fallback("navNodes") : (function () { throw new RuntimeError('Variable "navNodes" does not exist.', 307, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["node"]) {
                // line 308
                yield "                        ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "buttonType", [], "any", false, false, false, 308) != "cta")) {
                    // line 309
                    yield "                            ";
                    $context["hasChildren"] = $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "children", [], "any", false, false, false, 309));
                    // line 310
                    yield "                            
                            ";
                    // line 311
                    if ((isset($context["hasChildren"]) || array_key_exists("hasChildren", $context) ? $context["hasChildren"] : (craft\helpers\Template::fallbackExists("hasChildren") ? craft\helpers\Template::fallback("hasChildren") : (function () { throw new RuntimeError('Variable "hasChildren" does not exist.', 311, $this->source); })()))) {
                        // line 312
                        yield "                                <!-- Parent with expandable children -->
                                <div class=\"text-center mb-4\">
                                    <button class=\"text-white text-2xl font-semibold hover:text-brand transition-colors\" 
                                            onclick=\"toggleSubmenu(this)\">
                                        ";
                        // line 316
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 316), "html", null, true);
                        yield "
                                        <svg class=\"w-5 h-5 transition-transform inline-block\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">
                                            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 9l-7 7-7-7\"></path>
                                        </svg>
                                    </button>
                                    
                                    <!-- Submenu -->
                                    <div class=\"submenu max-h-0 overflow-hidden transition-all duration-300 mt-4\">
                                        ";
                        // line 324
                        $context['_parent'] = $context;
                        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "children", [], "any", false, false, false, 324));
                        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                            // line 325
                            yield "                                            <a href=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["child"], "url", [], "any", false, false, false, 325), "html", null, true);
                            yield "\" class=\"block py-2 text-white/80 hover:text-brand transition-colors text-lg\">
                                                ";
                            // line 326
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["child"], "title", [], "any", false, false, false, 326), "html", null, true);
                            yield "
                                            </a>
                                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_key'], $context['child'], $context['_parent']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 329
                        yield "                                    </div>
                                </div>
                            ";
                    } else {
                        // line 332
                        yield "                                <!-- Regular link -->
                                <a href=\"";
                        // line 333
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "url", [], "any", false, false, false, 333), "html", null, true);
                        yield "\" class=\"text-white text-2xl font-semibold hover:text-brand transition-colors\">";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 333), "html", null, true);
                        yield "</a>
                            ";
                    }
                    // line 335
                    yield "                        ";
                }
                // line 336
                yield "                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['node'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 337
            yield "                    
                    <!-- Mobile CTA -->
                    ";
            // line 339
            $context["navNodes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 339, $this->source); })())), "navigation", [], "any", false, false, false, 339), "nodes", [], "method", false, false, false, 339), "handle", ["mainNav"], "method", false, false, false, 339), "all", [], "method", false, false, false, 339);
            // line 340
            yield "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["navNodes"]) || array_key_exists("navNodes", $context) ? $context["navNodes"] : (craft\helpers\Template::fallbackExists("navNodes") ? craft\helpers\Template::fallback("navNodes") : (function () { throw new RuntimeError('Variable "navNodes" does not exist.', 340, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["node"]) {
                // line 341
                yield "                        ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "buttonType", [], "any", false, false, false, 341) == "cta")) {
                    // line 342
                    yield "                            <a href=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "url", [], "any", false, false, false, 342), "html", null, true);
                    yield "\" class=\"mt-8 px-8 py-4 bg-brand text-white font-bold rounded-lg hover:bg-brand/90 transition-all transform hover:scale-105\">
                                ";
                    // line 343
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 343), "html", null, true);
                    yield "
                            </a>
                        ";
                }
                // line 346
                yield "                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['node'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 347
            yield "                    
                    <!-- Close Button -->
                    <button id=\"mobile-menu-close-inner\" class=\"absolute top-6 right-6 p-2 text-white hover:text-brand transition-colors\">
                        <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                            <path d=\"M6 18L18 6M6 6l12 12\"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <!-- Page Content Spacer for Fixed Nav -->
            <div class=\"pt-20\"></div>
        ";
        }
        // line 360
        yield "        
        <!-- Main Content -->
        ";
        // line 362
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 363
        yield "        
    </div>
    
    <!-- Footer -->
    <footer class=\"bg-navy text-white pt-16 pb-8 border-t-4 border-brand\">
      <div class=\"max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-12\">
        <!-- Logo & Social -->
        <div class=\"flex flex-col items-center md:items-start\">
          <div class=\"flex flex-col items-center md:items-start\">
            <div class=\"w-14 h-14 rounded-lg flex items-center justify-center mb-2\">
              <img src=\"/assets/layout/logo.webp\" alt=\"Fine Digital Logo\" class=\"w-full h-full object-contain\" loading=\"lazy\">
            </div>
            <span class=\"text-white font-bold text-lg mb-4\">Fine Digital</span>
            <div class=\"flex gap-4 mt-2\">
              <a href=\"#\" aria-label=\"Instagram\" class=\"hover:text-brand transition-colors\">
                <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                  <rect x=\"2\" y=\"2\" width=\"20\" height=\"20\" rx=\"5\" ry=\"5\"/>
                  <path d=\"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z\"/>
                  <line x1=\"17.5\" y1=\"6.5\" x2=\"17.5\" y2=\"6.5\"/>
                </svg>
              </a>
              <a href=\"#\" aria-label=\"LinkedIn\" class=\"hover:text-brand transition-colors\">
                <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                  <rect x=\"2\" y=\"2\" width=\"20\" height=\"20\" rx=\"5\" ry=\"5\"/>
                  <path d=\"M16 8a6 6 0 0 1 6 6v5h-4v-5a2 2 0 0 0-4 0v5h-4v-9h4v1.5\"/>
                  <line x1=\"8\" y1=\"11\" x2=\"8\" y2=\"16\"/>
                  <line x1=\"8\" y1=\"8\" x2=\"8\" y2=\"8\"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
        <!-- Quick Links -->
            <!-- Quick Links -->
            <div class=\"flex flex-col items-center md:items-start\">
            <h3 class=\"text-lg font-bold mb-4 text-brand\">Quick Links</h3>
            <ul class=\"space-y-2 text-white/90\">
                ";
        // line 400
        $context["footerNavNodes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 400, $this->source); })())), "navigation", [], "any", false, false, false, 400), "nodes", [], "method", false, false, false, 400), "handle", ["footerNav"], "method", false, false, false, 400), "all", [], "method", false, false, false, 400);
        // line 401
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["footerNavNodes"]) || array_key_exists("footerNavNodes", $context) ? $context["footerNavNodes"] : (craft\helpers\Template::fallbackExists("footerNavNodes") ? craft\helpers\Template::fallback("footerNavNodes") : (function () { throw new RuntimeError('Variable "footerNavNodes" does not exist.', 401, $this->source); })())));
        foreach ($context['_seq'] as $context["_key"] => $context["node"]) {
            // line 402
            yield "                <li><a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "url", [], "any", false, false, false, 402), "html", null, true);
            yield "\" class=\"hover:text-brand transition-colors\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["node"], "title", [], "any", false, false, false, 402), "html", null, true);
            yield "</a></li>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['node'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 404
        yield "            </ul>
            </div>

        
        <!-- Contact Form -->
        <div class=\"flex flex-col items-center md:items-start\">
          <h3 class=\"text-lg font-bold mb-4 text-brand\">Contact</h3>
          <form class=\"w-full max-w-xs space-y-3\">
            <input type=\"text\" name=\"name\" placeholder=\"Name\" class=\"w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-brand focus:ring-2 focus:ring-brand/30 outline-none transition\" required>
            <input type=\"email\" name=\"email\" placeholder=\"Email\" class=\"w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-brand focus:ring-2 focus:ring-brand/30 outline-none transition\" required>
            <textarea name=\"message\" placeholder=\"Message\" rows=\"3\" class=\"w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-brand focus:ring-2 focus:ring-brand/30 outline-none transition\" required></textarea>
            <button type=\"submit\" class=\"w-full px-4 py-2 rounded-lg bg-brand text-white font-bold hover:bg-brand/90 transition\">Send Message</button>
          </form>
        </div>
      </div>
      <div class=\"mt-12 text-center text-white/60 text-sm\">
        &copy; ";
        // line 420
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->dateFilter($this->env, "now", "Y"), "html", null, true);
        yield " Fine Digital. All rights reserved.
      </div>
    </footer>
    
    <!-- Load JavaScript at the end for better performance -->
    ";
        // line 425
        if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 425, $this->source); })())), "app", [], "any", false, false, false, 425), "config", [], "any", false, false, false, 425), "env", [], "any", false, false, false, 425) == "dev")) {
            // line 426
            yield "        <script type=\"module\" src=\"http://localhost:5173/src/js/app.js\"></script>
    ";
        } else {
            // line 428
            yield "        <script type=\"module\" src=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 428, $this->source); })())), "html", null, true);
            yield "dist/assets/app.js\"></script>
    ";
        }
        // line 430
        yield "    
    
    <!-- Inline only essential JavaScript -->
    <script>
        // Mark content as loaded to prevent FOUC
        document.documentElement.classList.add('content-loaded');
        
        // Mobile submenu toggle function
        function toggleSubmenu(button) {
            const submenu = button.nextElementSibling;
            const icon = button.querySelector('svg');
            
            if (submenu.style.maxHeight && submenu.style.maxHeight !== '0px') {
                submenu.style.maxHeight = '0px';
                icon.style.transform = 'rotate(0deg)';
            } else {
                submenu.style.maxHeight = submenu.scrollHeight + 'px';
                icon.style.transform = 'rotate(180deg)';
            }
        }
    </script>

";
        // line 452
        $this->env->getFunction('endBody')->getCallable()();
        yield "</body>
</html>";
        craft\helpers\Template::endProfile("template", "_layout");
        yield from [];
    }

    // line 362
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_layout";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  870 => 362,  862 => 452,  838 => 430,  832 => 428,  828 => 426,  826 => 425,  818 => 420,  800 => 404,  789 => 402,  784 => 401,  782 => 400,  743 => 363,  741 => 362,  737 => 360,  722 => 347,  716 => 346,  710 => 343,  705 => 342,  702 => 341,  697 => 340,  695 => 339,  691 => 337,  685 => 336,  682 => 335,  675 => 333,  672 => 332,  667 => 329,  658 => 326,  653 => 325,  649 => 324,  638 => 316,  632 => 312,  630 => 311,  627 => 310,  624 => 309,  621 => 308,  616 => 307,  614 => 306,  597 => 291,  591 => 290,  585 => 287,  580 => 286,  577 => 285,  572 => 284,  570 => 283,  564 => 279,  558 => 278,  555 => 277,  549 => 274,  545 => 273,  542 => 272,  537 => 269,  528 => 266,  523 => 265,  519 => 264,  508 => 256,  503 => 253,  501 => 252,  498 => 251,  495 => 250,  492 => 249,  487 => 248,  485 => 247,  472 => 237,  464 => 231,  451 => 220,  445 => 219,  439 => 216,  434 => 215,  431 => 214,  426 => 213,  424 => 212,  420 => 210,  414 => 209,  411 => 208,  404 => 206,  401 => 205,  396 => 202,  387 => 199,  382 => 198,  378 => 197,  367 => 189,  361 => 185,  359 => 184,  356 => 183,  353 => 182,  350 => 181,  345 => 180,  343 => 179,  326 => 164,  320 => 163,  314 => 160,  309 => 159,  305 => 158,  300 => 157,  298 => 156,  292 => 152,  286 => 151,  283 => 150,  277 => 147,  273 => 146,  270 => 145,  265 => 142,  256 => 139,  251 => 138,  247 => 137,  236 => 129,  231 => 126,  229 => 125,  226 => 124,  223 => 123,  220 => 122,  215 => 121,  213 => 120,  204 => 113,  197 => 106,  189 => 100,  186 => 99,  180 => 94,  178 => 93,  175 => 92,  170 => 89,  165 => 88,  160 => 85,  158 => 84,  154 => 82,  148 => 80,  144 => 78,  142 => 77,  138 => 75,  133 => 73,  128 => 72,  123 => 69,  121 => 68,  52 => 6,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\" class=\"\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>{% if title is defined %}{{ title }} - {% endif %}{{ siteName }}</title>
    
    <!-- Critical CSS - Only essential styles inline -->
    <style>
        /* Critical above-the-fold styles only */
        body { 
            margin: 0; 
            font-family: system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
            transition: background-color 0.3s ease;
        }
        .dark body { 
            background-color: #181c2a; 
        }
        
        /* Critical navigation styles to prevent layout shift */
        nav {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 50;
            transition: all 0.3s ease;
        }
        
        .nav-overlay {
            background: transparent;
            backdrop-filter: none;
        }
        
        .nav-overlay.scrolled {
            background: rgba(24, 28, 42, 0.95);
            backdrop-filter: blur(10px);
        }
        
        .nav-solid {
            background: rgba(24, 28, 42, 0.98);
            backdrop-filter: blur(10px);
        }
        
        /* Prevent flash of unstyled content */
        .mobile-menu {
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }
        
        .mobile-menu.open {
            transform: translateX(0);
        }
        
        /* Hide content until fonts/CSS load */
        .content-wrapper {
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .content-loaded .content-wrapper {
            opacity: 1;
        }
    </style>
    
    <!-- Preload critical resources -->
    {% if craft.app.config.env == 'dev' %}
        <link rel=\"preload\" href=\"http://localhost:5173/src/css/app.css\" as=\"style\" onload=\"this.onload=null;this.rel='stylesheet'\">
        <noscript><link rel=\"stylesheet\" href=\"http://localhost:5173/src/css/app.css\"></noscript>
    {% else %}
        <link rel=\"preload\" href=\"{{ siteUrl }}dist/assets/app.css\" as=\"style\" onload=\"this.onload=null;this.rel='stylesheet'\">
        <noscript><link rel=\"stylesheet\" href=\"{{ siteUrl }}dist/assets/app.css\"></noscript>
    {% endif %}
    
    <!-- Load CSS asynchronously -->
    {% if craft.app.config.env == 'dev' %}
        <link rel=\"stylesheet\" href=\"http://localhost:5173/src/css/app.css\" media=\"print\" onload=\"this.media='all'\">
    {% else %}
        <link rel=\"stylesheet\" href=\"{{ siteUrl }}dist/assets/app.css\" media=\"print\" onload=\"this.media='all'\">
    {% endif %}
    
    <!-- Preload JavaScript -->
    {% if craft.app.config.env == 'dev' %}
        <script type=\"module\" src=\"http://localhost:5173/@vite/client\"></script>
        <link rel=\"modulepreload\" href=\"http://localhost:5173/src/js/app.js\">
    {% endif %}
</head>
<body>
    
    {# Determine if this is the homepage #}
  
    {% set isHomepage = (entry is defined and entry.slug == '__home__') or craft.app.request.pathInfo == '' %}

    <!-- Content wrapper for loading states -->
    <div class=\"content-wrapper\">
        
        {# Navigation - Different styles for homepage vs other pages #}
        {% if isHomepage %}
            <!-- HOMEPAGE NAVIGATION - Overlay style with sticky scroll -->
            <nav id=\"homepage-nav\" class=\"nav-overlay py-4\">
                <div class=\"max-w-7xl mx-auto px-6 flex items-center justify-between\">
                    
                    <!-- Logo -->
                    <div class=\"flex items-center\">
                        <a href=\"{{ siteUrl }}\" class=\"flex items-center gap-3\">
                            <div class=\"w-10 h-10 bg-brand rounded-lg flex items-center justify-center\">
                                <span class=\"text-white font-bold text-lg\">F</span>
                            </div>
                            {# <div class=\"w-10 h-10  rounded-lg flex items-center justify-center\">
                            <img src=\"{{ siteUrl }}assets\\layout\\logo.webp\" alt=\"Fine Digital Logo\" class=\"w-8 h-8 object-contain\" loading=\"lazy\">
                            </div> #}
   
                            <span class=\"text-white font-bold text-xl\">Fine Digital</span>
                        </a>
                    </div>
                    
                    <!-- Desktop Menu -->
                    <div class=\"hidden lg:flex items-center space-x-8\">
                        {% set navNodes = craft.navigation.nodes().handle('mainNav').level(1).all() %}
                        {% for node in navNodes %}
                            {% if node.buttonType != 'cta' %}
                                {% set hasChildren = node.children|length %}
                                
                                {% if hasChildren %}
                                    <!-- Parent with dropdown -->
                                    <div class=\"relative group\">
                                        <button class=\"text-white/90 hover:text-brand transition-colors font-medium flex items-center gap-1\">
                                            {{ node.title }}
                                            <svg class=\"w-4 h-4 transition-transform group-hover:rotate-180\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">
                                                <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 9l-7 7-7-7\"></path>
                                            </svg>
                                        </button>
                                        
                                        <!-- Dropdown menu -->
                                        <div class=\"absolute top-full  left-0 bg-white shadow-lg rounded-lg py-3 w-48 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50 mt-2\">
                                            {% for child in node.children %}
                                                <a href=\"{{ child.url }}\" class=\"block px-5 py-2 text-gray-700 hover:bg-gray-50 hover:text-brand transition-colors\">
                                                    {{ child.title }}
                                                </a>
                                            {% endfor %}
                                        </div>
                                    </div>
                                {% else %}
                                    <!-- Regular link (no children) -->
                                    <a href=\"{{ node.url }}\" class=\"text-white/90 hover:text-brand transition-colors font-medium\">
                                        {{ node.title }}
                                    </a>
                                {% endif %}
                            {% endif %}
                        {% endfor %}
                    </div>

                    <!-- CTA Button -->
                    <div class=\"hidden lg:flex items-center gap-4\">
                        {% set navNodes = craft.navigation.nodes().handle('mainNav').all() %}
                        {% for node in navNodes %}
                            {% if node.buttonType == 'cta' %} {# Show CTA button here #}
                                <a href=\"{{ node.url }}\" class=\"px-6 py-3 bg-brand text-white font-semibold rounded-lg hover:bg-brand/90 transition-all transform hover:scale-105\">
                                    {{ node.title }}
                                </a>
                            {% endif %}
                        {% endfor %}
                    </div>
                    
                    <!-- Mobile Menu Button -->
                    <button id=\"mobile-menu-button\" class=\"lg:hidden p-2 text-white hover:text-brand transition-colors\">
                        <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                            <path d=\"M4 6h16M4 12h16M4 18h16\"/>
                        </svg>
                    </button>
                </div>
            </nav>
            
            <!-- Mobile Menu Overlay for Homepage -->
            <div id=\"mobile-menu-overlay\" class=\"mobile-menu fixed inset-0 z-40 lg:hidden\">
                <div class=\"absolute inset-0 bg-navy/95 backdrop-blur-lg\"></div>
                <div class=\"relative h-full flex flex-col justify-center items-center space-y-8\">
                    {% set navNodes = craft.navigation.nodes().handle('mainNav').level(1).all() %}
                    {% for node in navNodes %}
                        {% if node.buttonType != 'cta' %}
                            {% set hasChildren = node.children|length %}
                            
                            {% if hasChildren %}
                                <!-- Parent with expandable children -->
                                <div class=\"text-center mb-4\">
                                    <button class=\"text-white text-2xl ml-[20px] font-semibold hover:text-brand transition-colors\" 
                                            onclick=\"toggleSubmenu(this)\">
                                        {{ node.title }}
                                        <svg class=\"w-5 h-5 transition-transform inline-block\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">
                                            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 9l-7 7-7-7\"></path>
                                        </svg>
                                    </button>
                                    
                                    <!-- Submenu -->
                                    <div class=\"submenu max-h-0 overflow-hidden transition-all duration-300 mt-4\">
                                        {% for child in node.children %}
                                            <a href=\"{{ child.url }}\" class=\"block py-2 text-white/80 hover:text-brand transition-colors text-lg\">
                                                {{ child.title }}
                                            </a>
                                        {% endfor %}
                                    </div>
                                </div>
                            {% else %}
                                <!-- Regular link -->
                                <a href=\"{{ node.url }}\" class=\"text-white text-2xl font-semibold hover:text-brand transition-colors\">{{ node.title }}</a>
                            {% endif %}
                        {% endif %}
                    {% endfor %}
                    
                    <!-- Mobile CTA -->
                    {% set navNodes = craft.navigation.nodes().handle('mainNav').all() %}
                    {% for node in navNodes %}
                        {% if node.buttonType == 'cta' %}
                            <a href=\"{{ node.url }}\" class=\"mt-8 px-8 py-4 bg-brand text-white font-bold rounded-lg hover:bg-brand/90 transition-all transform hover:scale-105\">
                                {{ node.title }}
                            </a>
                        {% endif %}
                    {% endfor %}
                    
                    <!-- Close Button -->
                    <button id=\"mobile-menu-close\" class=\"absolute top-6 right-6 p-2 text-white hover:text-brand transition-colors\">
                        <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                            <path d=\"M6 18L18 6M6 6l12 12\"/>
                        </svg>
                    </button>
                </div>
            </div>
            
        {% else %}
            <!-- OTHER PAGES NAVIGATION - Solid style -->
            <nav class=\"nav-solid py-4\">
                <div class=\"max-w-7xl mx-auto px-6 flex items-center justify-between\">
                    
                    <!-- Logo -->
                    <div class=\"flex items-center\">
                        <a href=\"{{ siteUrl }}\" class=\"flex items-center gap-3\">
                            <div class=\"w-10 h-10 bg-brand rounded-lg flex items-center justify-center\">
                                <span class=\"text-white font-bold text-lg\">F</span> 
                            </div>
                            <span class=\"text-white font-bold text-xl\">Fine Digital</span>
                        </a>
                    </div>
                    
                    <!-- Desktop Menu -->
                    <div class=\"hidden lg:flex items-center space-x-8\">
                        {% set navNodes = craft.navigation.nodes().handle('mainNav').level(1).all() %}
                        {% for node in navNodes %}
                            {% if node.buttonType != 'cta' %}
                                {% set hasChildren = node.children|length %}
                                
                                {% if hasChildren %}
                                    <!-- Parent with dropdown -->
                                    <div class=\"relative group\">
                                        <button class=\"text-white/90 hover:text-brand transition-colors font-medium flex items-center gap-1\">
                                            {{ node.title }}
                                            <svg class=\"w-4 h-4 transition-transform group-hover:rotate-180\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">
                                                <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 9l-7 7-7-7\"></path>
                                            </svg>
                                        </button>
                                        
                                        <!-- Dropdown menu -->
                                        <div class=\"absolute top-full left-0 bg-white shadow-lg rounded-lg py-3 w-48 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50 mt-2\">
                                            {% for child in node.children %}
                                                <a href=\"{{ child.url }}\" class=\"block px-5 py-2 text-gray-700 hover:bg-gray-50 hover:text-brand transition-colors\">
                                                    {{ child.title }}
                                                </a>
                                            {% endfor %}
                                        </div>
                                    </div>
                                {% else %}
                                    <!-- Regular link (no children) -->
                                    <a href=\"{{ node.url }}\" class=\"text-white/90 hover:text-brand transition-colors font-medium\">
                                        {{ node.title }}
                                    </a>
                                {% endif %}
                            {% endif %}
                        {% endfor %}
                    </div>
                    
                    <!-- CTA Button -->
                    <div class=\"hidden lg:flex items-center gap-4\">
                        {% set navNodes = craft.navigation.nodes().handle('mainNav').all() %}
                        {% for node in navNodes %}
                            {% if node.buttonType == 'cta' %}
                                <a href=\"{{ node.url }}\" class=\"px-6 py-3 bg-brand text-white font-semibold rounded-lg hover:bg-brand/90 transition-all transform hover:scale-105\">
                                    {{ node.title }}
                                </a>
                            {% endif %}
                        {% endfor %}
                    </div>
                    
                    <!-- Mobile Menu Button -->
                    <button id=\"mobile-menu-button-inner\" class=\"lg:hidden p-2 text-white hover:text-brand transition-colors\">
                        <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                            <path d=\"M4 6h16M4 12h16M4 18h16\"/>
                        </svg>
                    </button>
                </div>
            </nav>
            
            <!-- Mobile Menu Overlay for Other Pages -->
            <div id=\"mobile-menu-overlay-inner\" class=\"mobile-menu fixed inset-0 z-40 lg:hidden\">
                <div class=\"absolute inset-0 bg-navy/95 backdrop-blur-lg\"></div>
                <div class=\"relative h-full flex flex-col justify-center items-center space-y-8\">
                    {% set navNodes = craft.navigation.nodes().handle('mainNav').level(1).all() %}
                    {% for node in navNodes %}
                        {% if node.buttonType != 'cta' %}
                            {% set hasChildren = node.children|length %}
                            
                            {% if hasChildren %}
                                <!-- Parent with expandable children -->
                                <div class=\"text-center mb-4\">
                                    <button class=\"text-white text-2xl font-semibold hover:text-brand transition-colors\" 
                                            onclick=\"toggleSubmenu(this)\">
                                        {{ node.title }}
                                        <svg class=\"w-5 h-5 transition-transform inline-block\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">
                                            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 9l-7 7-7-7\"></path>
                                        </svg>
                                    </button>
                                    
                                    <!-- Submenu -->
                                    <div class=\"submenu max-h-0 overflow-hidden transition-all duration-300 mt-4\">
                                        {% for child in node.children %}
                                            <a href=\"{{ child.url }}\" class=\"block py-2 text-white/80 hover:text-brand transition-colors text-lg\">
                                                {{ child.title }}
                                            </a>
                                        {% endfor %}
                                    </div>
                                </div>
                            {% else %}
                                <!-- Regular link -->
                                <a href=\"{{ node.url }}\" class=\"text-white text-2xl font-semibold hover:text-brand transition-colors\">{{ node.title }}</a>
                            {% endif %}
                        {% endif %}
                    {% endfor %}
                    
                    <!-- Mobile CTA -->
                    {% set navNodes = craft.navigation.nodes().handle('mainNav').all() %}
                    {% for node in navNodes %}
                        {% if node.buttonType == 'cta' %}
                            <a href=\"{{ node.url }}\" class=\"mt-8 px-8 py-4 bg-brand text-white font-bold rounded-lg hover:bg-brand/90 transition-all transform hover:scale-105\">
                                {{ node.title }}
                            </a>
                        {% endif %}
                    {% endfor %}
                    
                    <!-- Close Button -->
                    <button id=\"mobile-menu-close-inner\" class=\"absolute top-6 right-6 p-2 text-white hover:text-brand transition-colors\">
                        <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                            <path d=\"M6 18L18 6M6 6l12 12\"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <!-- Page Content Spacer for Fixed Nav -->
            <div class=\"pt-20\"></div>
        {% endif %}
        
        <!-- Main Content -->
        {% block content %}{% endblock %}
        
    </div>
    
    <!-- Footer -->
    <footer class=\"bg-navy text-white pt-16 pb-8 border-t-4 border-brand\">
      <div class=\"max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-12\">
        <!-- Logo & Social -->
        <div class=\"flex flex-col items-center md:items-start\">
          <div class=\"flex flex-col items-center md:items-start\">
            <div class=\"w-14 h-14 rounded-lg flex items-center justify-center mb-2\">
              <img src=\"/assets/layout/logo.webp\" alt=\"Fine Digital Logo\" class=\"w-full h-full object-contain\" loading=\"lazy\">
            </div>
            <span class=\"text-white font-bold text-lg mb-4\">Fine Digital</span>
            <div class=\"flex gap-4 mt-2\">
              <a href=\"#\" aria-label=\"Instagram\" class=\"hover:text-brand transition-colors\">
                <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                  <rect x=\"2\" y=\"2\" width=\"20\" height=\"20\" rx=\"5\" ry=\"5\"/>
                  <path d=\"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z\"/>
                  <line x1=\"17.5\" y1=\"6.5\" x2=\"17.5\" y2=\"6.5\"/>
                </svg>
              </a>
              <a href=\"#\" aria-label=\"LinkedIn\" class=\"hover:text-brand transition-colors\">
                <svg class=\"w-6 h-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" viewBox=\"0 0 24 24\">
                  <rect x=\"2\" y=\"2\" width=\"20\" height=\"20\" rx=\"5\" ry=\"5\"/>
                  <path d=\"M16 8a6 6 0 0 1 6 6v5h-4v-5a2 2 0 0 0-4 0v5h-4v-9h4v1.5\"/>
                  <line x1=\"8\" y1=\"11\" x2=\"8\" y2=\"16\"/>
                  <line x1=\"8\" y1=\"8\" x2=\"8\" y2=\"8\"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
        <!-- Quick Links -->
            <!-- Quick Links -->
            <div class=\"flex flex-col items-center md:items-start\">
            <h3 class=\"text-lg font-bold mb-4 text-brand\">Quick Links</h3>
            <ul class=\"space-y-2 text-white/90\">
                {% set footerNavNodes = craft.navigation.nodes().handle('footerNav').all() %}
                {% for node in footerNavNodes %}
                <li><a href=\"{{ node.url }}\" class=\"hover:text-brand transition-colors\">{{ node.title }}</a></li>
                {% endfor %}
            </ul>
            </div>

        
        <!-- Contact Form -->
        <div class=\"flex flex-col items-center md:items-start\">
          <h3 class=\"text-lg font-bold mb-4 text-brand\">Contact</h3>
          <form class=\"w-full max-w-xs space-y-3\">
            <input type=\"text\" name=\"name\" placeholder=\"Name\" class=\"w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-brand focus:ring-2 focus:ring-brand/30 outline-none transition\" required>
            <input type=\"email\" name=\"email\" placeholder=\"Email\" class=\"w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-brand focus:ring-2 focus:ring-brand/30 outline-none transition\" required>
            <textarea name=\"message\" placeholder=\"Message\" rows=\"3\" class=\"w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-brand focus:ring-2 focus:ring-brand/30 outline-none transition\" required></textarea>
            <button type=\"submit\" class=\"w-full px-4 py-2 rounded-lg bg-brand text-white font-bold hover:bg-brand/90 transition\">Send Message</button>
          </form>
        </div>
      </div>
      <div class=\"mt-12 text-center text-white/60 text-sm\">
        &copy; {{ \"now\"|date(\"Y\") }} Fine Digital. All rights reserved.
      </div>
    </footer>
    
    <!-- Load JavaScript at the end for better performance -->
    {% if craft.app.config.env == 'dev' %}
        <script type=\"module\" src=\"http://localhost:5173/src/js/app.js\"></script>
    {% else %}
        <script type=\"module\" src=\"{{ siteUrl }}dist/assets/app.js\"></script>
    {% endif %}
    
    
    <!-- Inline only essential JavaScript -->
    <script>
        // Mark content as loaded to prevent FOUC
        document.documentElement.classList.add('content-loaded');
        
        // Mobile submenu toggle function
        function toggleSubmenu(button) {
            const submenu = button.nextElementSibling;
            const icon = button.querySelector('svg');
            
            if (submenu.style.maxHeight && submenu.style.maxHeight !== '0px') {
                submenu.style.maxHeight = '0px';
                icon.style.transform = 'rotate(0deg)';
            } else {
                submenu.style.maxHeight = submenu.scrollHeight + 'px';
                icon.style.transform = 'rotate(180deg)';
            }
        }
    </script>

</body>
</html>", "_layout", "/var/www/html/templates/_layout.twig");
    }
}
