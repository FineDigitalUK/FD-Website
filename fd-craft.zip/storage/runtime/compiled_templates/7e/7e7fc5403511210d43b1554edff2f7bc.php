<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/fields/_edit.twig */
class __TwigTemplate_58e7bfb67f3d2b8ad33d01a7dbe55b80 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/fields/_edit.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "settings/fields/_edit.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 4
        yield "
";
        // line 5
        if ((( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 5, $this->source); })()) && array_key_exists("fieldId", $context)) && (isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 5, $this->source); })()))) {
            // line 6
            yield "  ";
            yield craft\helpers\Html::hiddenInput("fieldId", (isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 6, $this->source); })()));
            yield "
";
        }
        // line 8
        yield "
";
        // line 9
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 9, $this->getSourceContext())->macro_textField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this field will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 15
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 15, $this->source); })()), "name", [], "any", false, false, false, 15), "required" => true, "autofocus" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 18
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 18, $this->source); })()), "getErrors", ["name"], "method", false, false, false, 18), "data" => ["error-key" => "name"], "disabled" =>         // line 20
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 20, $this->source); })())]]);
        // line 21
        yield "

";
        // line 23
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 23, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this field in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 32
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 32, $this->source); })()), "handle", [], "any", false, false, false, 32), "required" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 34
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 34, $this->source); })()), "getErrors", ["handle"], "method", false, false, false, 34), "data" => ["error-key" => "handle"], "disabled" =>         // line 36
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 36, $this->source); })())]]);
        // line 37
        yield "

";
        // line 39
        yield $macros["forms"]->getTemplateForMacro("macro_textareaField", $context, 39, $this->getSourceContext())->macro_textareaField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default Instructions", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Helper text to guide the author.", "app"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 45
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 45, $this->source); })()), "instructions", [], "any", false, false, false, 45), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 46
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 46, $this->source); })()), "getErrors", ["instructions"], "method", false, false, false, 46), "data" => ["error-key" => "instructions"], "disabled" =>         // line 50
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 50, $this->source); })())]]);
        // line 51
        yield "

";
        // line 53
        yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 53, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use this field’s values as search keywords", "app"), "id" => "searchable", "name" => "searchable", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 57
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 57, $this->source); })()), "searchable", [], "any", false, false, false, 57), "disabled" =>         // line 58
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 58, $this->source); })())]]);
        // line 59
        yield "

";
        // line 61
        yield $macros["forms"]->getTemplateForMacro("macro_customSelectField", $context, 61, $this->getSourceContext())->macro_customSelectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of field is this?", "app"), "warning" => ((( !Twig\Extension\CoreExtension::testEmpty(        // line 64
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 64, $this->source); })())) &&  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 64, $this->source); })()), "hasErrors", ["type"], "method", false, false, false, 64))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" =>         // line 67
(isset($context["fieldTypeOptions"]) || array_key_exists("fieldTypeOptions", $context) ? $context["fieldTypeOptions"] : (function () { throw new RuntimeError('Variable "fieldTypeOptions" does not exist.', 67, $this->source); })()), "value" => (($this->env->getTest('missing')->getCallable()(        // line 68
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })()), "expectedType", [], "any", false, false, false, 68)) : (get_class((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })())))), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 69
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 69, $this->source); })()), "getErrors", ["type"], "method", false, false, false, 69), "data" => ["error-key" => "type"], "disabled" =>         // line 73
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 73, $this->source); })())]]);
        // line 74
        yield "

";
        // line 76
        yield (isset($context["missingFieldPlaceholder"]) || array_key_exists("missingFieldPlaceholder", $context) ? $context["missingFieldPlaceholder"] : (function () { throw new RuntimeError('Variable "missingFieldPlaceholder" does not exist.', 76, $this->source); })());
        yield "

";
        // line 78
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 78, $this->source); })()), "app", [], "any", false, false, false, 78), "getIsMultiSite", [], "method", false, false, false, 78)) {
            // line 79
            yield "  ";
            $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 79, $this->source); })()), "supportedTranslationMethods", [], "any", false, false, false, 79);
            // line 80
            yield "  ";
            if (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 80, $this->source); })())) > 1)) {
                // line 81
                yield "    <div id=\"translation-settings\">
      ";
                // line 82
                yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 82, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How should this field’s values be translated?", "app"), "id" => "translation-method", "name" => "translationMethod", "options" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [((CoreExtension::inFilter("none",                 // line 88
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 88, $this->source); })()))) ? (["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")]) : ("")), ((CoreExtension::inFilter("site",                 // line 89
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 89, $this->source); })()))) ? (["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")]) : ("")), ((CoreExtension::inFilter("siteGroup",                 // line 90
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 90, $this->source); })()))) ? (["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")]) : ("")), ((CoreExtension::inFilter("language",                 // line 91
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 91, $this->source); })()))) ? (["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")]) : ("")), ((CoreExtension::inFilter("custom",                 // line 92
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 92, $this->source); })()))) ? (["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]) : (""))]), "value" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 94
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 94, $this->source); })()), "translationMethod", [], "any", false, false, false, 94), "toggle" => true, "targetPrefix" => "translation-method-", "disabled" =>                 // line 97
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 97, $this->source); })())]]);
                // line 98
                yield "

      ";
                // line 100
                if (CoreExtension::inFilter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 100, $this->source); })()))) {
                    // line 101
                    yield "        ";
                    ob_start();
                    // line 105
                    yield "          ";
                    yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 105, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "app"), "instructions" => "Template that defines the field’s custom “translation key” format. Field values will be copied to all sites that produce the same key. For example, to make the field translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.", "id" => "translation-key-format", "class" => "code", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 111
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 111, $this->source); })()), "translationKeyFormat", [], "any", false, false, false, 111), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 112
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 112, $this->source); })()), "getErrors", ["translationKeyFormat"], "method", false, false, false, 112), "data" => ["error-key" => "translationKeyFormat"], "disabled" =>                     // line 114
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 114, $this->source); })())]]);
                    // line 115
                    yield "
        ";
                    echo craft\helpers\Html::tag("div", ob_get_clean(), ["id" => "translation-method-custom", "class" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 103
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 103, $this->source); })()), "translationMethod", [], "any", false, false, false, 103) != "custom")) ? ("hidden") : (null))]);
                    // line 117
                    yield "      ";
                }
                // line 118
                yield "    </div>
  ";
            }
        }
        // line 121
        yield "
<hr>

<div id=\"settings\">
  <div id=\"";
        // line 125
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Html::id(get_class((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 125, $this->source); })()))), "html", null, true);
        yield "\">
    ";
        // line 126
        yield from $this->loadTemplate("settings/fields/_type-settings", "settings/fields/_edit.twig", 126)->unwrap()->yield(CoreExtension::merge($context, ["namespace" => (("types[" . craft\helpers\Html::id(get_class(        // line 127
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 127, $this->source); })())))) . "]")]));
        // line 129
        yield "  </div>
</div>


";
        // line 133
        if ( !(((craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "handle", [], "any", true, true, false, 133) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "handle", [], "any", false, false, false, 133)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "handle", [], "any", false, false, false, 133)) : (false))) {
            // line 134
            yield "  ";
            ob_start();
            // line 135
            yield "    new Craft.HandleGenerator('#";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()("name"), "js"), "html", null, true);
            yield "', '#";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()("handle"), "js"), "html", null, true);
            yield "');
  ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 138
        yield "
";
        // line 139
        ob_start();
        // line 140
        yield "  (() => {
    Craft.supportedTranslationMethods = ";
        // line 141
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["supportedTranslationMethods"]) || array_key_exists("supportedTranslationMethods", $context) ? $context["supportedTranslationMethods"] : (function () { throw new RuntimeError('Variable "supportedTranslationMethods" does not exist.', 141, $this->source); })()));
        yield ";

    Craft.updateTranslationMethodSettings = (type, container) => {
      const \$container = \$(container);
      if (!Craft.supportedTranslationMethods[type] || Craft.supportedTranslationMethods[type].length == 1) {
        \$container.addClass('hidden');
      } else {
        \$container.removeClass('hidden');
        // Rebuild the options based on the field type's supported translation methods
        \$container.find('select').html(
          (\$.inArray('none', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"none\">";
        // line 151
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app"), "js"), "html", null, true);
        yield "</option>' : '') +
          (\$.inArray('site', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">";
        // line 152
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app"), "js"), "html", null, true);
        yield "</option>' : '') +
          (\$.inArray('siteGroup', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"siteGroup\">";
        // line 153
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app"), "js"), "html", null, true);
        yield "</option>' : '') +
          (\$.inArray('language', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"language\">";
        // line 154
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app"), "js"), "html", null, true);
        yield "</option>' : '') +
          (\$.inArray('custom', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"custom\">";
        // line 155
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app"), "js"), "html", null, true);
        yield "</option>' : '')
        );
      }
    };

    const \$fieldTypeInput = \$(\"#";
        // line 160
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()("type"), "js"), "html", null, true);
        yield "\");
    const \$translationSettings = \$(\"#";
        // line 161
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()("translation-settings"), "js"), "html", null, true);
        yield "\");

    \$fieldTypeInput.on('change', (ev) => {
      Craft.updateTranslationMethodSettings(\$fieldTypeInput.data('value'), \$translationSettings);
    });
  })();
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "settings/fields/_edit.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/fields/_edit.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  245 => 161,  241 => 160,  233 => 155,  229 => 154,  225 => 153,  221 => 152,  217 => 151,  204 => 141,  201 => 140,  199 => 139,  196 => 138,  187 => 135,  184 => 134,  182 => 133,  176 => 129,  174 => 127,  173 => 126,  169 => 125,  163 => 121,  158 => 118,  155 => 117,  153 => 103,  150 => 115,  148 => 114,  147 => 112,  146 => 111,  144 => 105,  141 => 101,  139 => 100,  135 => 98,  133 => 97,  132 => 94,  131 => 92,  130 => 91,  129 => 90,  128 => 89,  127 => 88,  126 => 82,  123 => 81,  120 => 80,  117 => 79,  115 => 78,  110 => 76,  106 => 74,  104 => 73,  103 => 69,  102 => 68,  101 => 67,  100 => 64,  99 => 61,  95 => 59,  93 => 58,  92 => 57,  91 => 53,  87 => 51,  85 => 50,  84 => 46,  83 => 45,  82 => 39,  78 => 37,  76 => 36,  75 => 34,  74 => 32,  73 => 23,  69 => 21,  67 => 20,  66 => 18,  65 => 15,  64 => 9,  61 => 8,  55 => 6,  53 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms.twig' as forms %}

{% set readOnly = readOnly ?? false %}

{% if not readOnly and fieldId is defined and fieldId %}
  {{ hiddenInput('fieldId', fieldId) }}
{% endif %}

{{ forms.textField({
  first: true,
  label: \"Name\"|t('app'),
  instructions: \"What this field will be called in the control panel.\"|t('app'),
  id: 'name',
  name: 'name',
  value: field.name,
  required: true,
  autofocus: true,
  errors: field.getErrors('name'),
  data: {'error-key': 'name'},
  disabled: readOnly,
}) }}

{{ forms.textField({
  label: \"Handle\"|t('app'),
  instructions: \"How you’ll refer to this field in the templates.\"|t('app'),
  id: 'handle',
  name: 'handle',
  class: 'code',
  autocorrect: false,
  autocapitalize: false,
  maxlength: 64,
  value: field.handle,
  required: true,
  errors: field.getErrors('handle'),
  data: {'error-key': 'handle'},
  disabled: readOnly,
}) }}

{{ forms.textareaField({
  label: \"Default Instructions\"|t('app'),
  instructions: \"Helper text to guide the author.\"|t('app'),
  id: 'instructions',
  class: 'nicetext',
  name: 'instructions',
  value: field.instructions,
  errors: field.getErrors('instructions'),
  data: {
    'error-key': 'instructions',
  },
  disabled: readOnly,
}) }}

{{ forms.lightswitchField({
  label: 'Use this field’s values as search keywords'|t('app'),
  id: 'searchable',
  name: 'searchable',
  on: field.searchable,
  disabled: readOnly,
}) }}

{{ forms.customSelectField({
  label: \"Field Type\"|t('app'),
  instructions: \"What type of field is this?\"|t('app'),
  warning: (fieldId is not empty and not field.hasErrors('type') ? \"Changing this may result in data loss.\"|t('app')),
  id: 'type',
  name: 'type',
  options: fieldTypeOptions,
  value: field is missing ? field.expectedType : className(field),
  errors: field.getErrors('type'),
  data: {
    'error-key': 'type',
  },
  disabled: readOnly,
}) }}

{{ missingFieldPlaceholder|raw }}

{% if craft.app.getIsMultiSite() %}
  {% set translationMethods = field.supportedTranslationMethods %}
  {% if translationMethods|length > 1 %}
    <div id=\"translation-settings\">
      {{ forms.selectField({
        label: \"Translation Method\"|t('app'),
        instructions: \"How should this field’s values be translated?\"|t('app'),
        id: 'translation-method',
        name: 'translationMethod',
        options: [
          'none' in translationMethods ? { value: 'none', label: \"Not translatable\"|t('app') },
          'site' in translationMethods ? { value: 'site', label: \"Translate for each site\"|t('app') },
          'siteGroup' in translationMethods ? { value: 'siteGroup', label: \"Translate for each site group\"|t('app') },
          'language' in translationMethods ? { value: 'language', label: \"Translate for each language\"|t('app') },
          'custom' in translationMethods ? { value: 'custom', label: \"Custom…\"|t('app') }
        ]|filter,
        value: field.translationMethod,
        toggle: true,
        targetPrefix: 'translation-method-',
        disabled: readOnly,
      }) }}

      {% if 'custom' in translationMethods %}
        {% tag 'div' with {
          id: 'translation-method-custom',
          class: field.translationMethod != 'custom' ? 'hidden' : null,
        } %}
          {{ forms.textField({
            label: \"Translation Key Format\"|t('app'),
            instructions: \"Template that defines the field’s custom “translation key” format. Field values will be copied to all sites that produce the same key. For example, to make the field translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.\",
            id: 'translation-key-format',
            class: 'code',
            name: 'translationKeyFormat',
            value: field.translationKeyFormat,
            errors: field.getErrors('translationKeyFormat'),
            data: {'error-key': 'translationKeyFormat'},
            disabled: readOnly,
          }) }}
        {% endtag %}
      {% endif %}
    </div>
  {% endif %}
{% endif %}

<hr>

<div id=\"settings\">
  <div id=\"{{ className(field)|id }}\">
    {% include 'settings/fields/_type-settings' with {
      namespace: 'types['~className(field)|id~']'
    } %}
  </div>
</div>


{% if not (field.handle ?? false) %}
  {% js %}
    new Craft.HandleGenerator('#{{ 'name'|namespaceInputId|e('js') }}', '#{{ 'handle'|namespaceInputId|e('js') }}');
  {% endjs %}
{% endif %}

{% js %}
  (() => {
    Craft.supportedTranslationMethods = {{ supportedTranslationMethods|json_encode|raw }};

    Craft.updateTranslationMethodSettings = (type, container) => {
      const \$container = \$(container);
      if (!Craft.supportedTranslationMethods[type] || Craft.supportedTranslationMethods[type].length == 1) {
        \$container.addClass('hidden');
      } else {
        \$container.removeClass('hidden');
        // Rebuild the options based on the field type's supported translation methods
        \$container.find('select').html(
          (\$.inArray('none', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"none\">{{ \"Not translatable\"|t('app')|e('js') }}</option>' : '') +
          (\$.inArray('site', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">{{ \"Translate for each site\"|t('app')|e('js') }}</option>' : '') +
          (\$.inArray('siteGroup', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"siteGroup\">{{ \"Translate for each site group\"|t('app')|e('js') }}</option>' : '') +
          (\$.inArray('language', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"language\">{{ \"Translate for each language\"|t('app')|e('js') }}</option>' : '') +
          (\$.inArray('custom', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"custom\">{{ \"Custom…\"|t('app')|e('js') }}</option>' : '')
        );
      }
    };

    const \$fieldTypeInput = \$(\"#{{ 'type'|namespaceInputId|e('js') }}\");
    const \$translationSettings = \$(\"#{{ 'translation-settings'|namespaceInputId|e('js') }}\");

    \$fieldTypeInput.on('change', (ev) => {
      Craft.updateTranslationMethodSettings(\$fieldTypeInput.data('value'), \$translationSettings);
    });
  })();
{% endjs %}
", "settings/fields/_edit.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/fields/_edit.twig");
    }
}
