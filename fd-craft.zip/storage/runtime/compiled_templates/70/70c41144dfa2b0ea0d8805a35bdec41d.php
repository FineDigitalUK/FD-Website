<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/color */
class __TwigTemplate_50400231a659fc1f7131ea0823a114ac extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/color");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_includes/forms/color", 1)->unwrap();
        // line 3
        $context["id"] = (($context["id"]) ?? (("color" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 4
        $context["containerId"] = ((($context["containerId"]) ?? ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 4, $this->source); })()))) . "-container");
        // line 5
        $context["hexLabelId"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 5, $this->source); })()) . "-label");
        // line 6
        $context["hexDescriptionId"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 6, $this->source); })()) . "-desc");
        // line 7
        $context["name"] = (($context["name"]) ?? (null));
        // line 8
        $context["value"] = (($context["value"]) ?? (null));
        // line 9
        $context["small"] = (($context["small"]) ?? (false));
        // line 10
        $context["autofocus"] = ((($context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", [], "any", false, false, false, 10), "request", [], "any", false, false, false, 10), "isMobileBrowser", [true], "method", false, false, false, 10));
        // line 11
        $context["disabled"] = (($context["disabled"]) ?? (false));
        // line 12
        $context["labelledBy"] = (($context["labelledBy"]) ?? (null));
        // line 13
        yield "
";
        // line 14
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>         // line 15
(isset($context["containerId"]) || array_key_exists("containerId", $context) ? $context["containerId"] : (function () { throw new RuntimeError('Variable "containerId" does not exist.', 15, $this->source); })()), "class" => ["flex", "flex-nowrap", "color-container"]], ((        // line 17
$context["containerAttributes"]) ?? ([])), true);
        // line 19
        if (        $this->unwrap()->hasBlock("attr", $context, $blocks)) {
            // line 20
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 20, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 22
        yield "
";
        // line 23
        $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 24
            yield "    ";
            ob_start();
            // line 25
            yield "        ";
            ob_start();
            // line 28
            yield "            ";
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => ["color-preview"], "style" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["background-color" =>             // line 30
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 30, $this->source); })())])]);
            // line 31
            yield "
        ";
            echo craft\helpers\Html::tag("div", ob_get_clean(), ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["color", "static", ((            // line 26
(isset($context["small"]) || array_key_exists("small", $context) ? $context["small"] : (function () { throw new RuntimeError('Variable "small" does not exist.', 26, $this->source); })())) ? ("small") : (""))])]);
            // line 33
            yield "        <div class=\"color-input-container\">
            <div class=\"color-hex-indicator light code\" aria-hidden=\"true\">#</div>
            <span id=\"";
            // line 35
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["hexLabelId"]) || array_key_exists("hexLabelId", $context) ? $context["hexLabelId"] : (function () { throw new RuntimeError('Variable "hexLabelId" does not exist.', 35, $this->source); })()), "html", null, true);
            yield "\" class=\"visually-hidden\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Color hex value", "app"), "html", null, true);
            yield "</span>
            <span id=\"";
            // line 36
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["hexDescriptionId"]) || array_key_exists("hexDescriptionId", $context) ? $context["hexDescriptionId"] : (function () { throw new RuntimeError('Variable "hexDescriptionId" does not exist.', 36, $this->source); })()), "html", null, true);
            yield "\" class=\"visually-hidden\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Value prefixed by “{prefix}”.", "app", ["prefix" => "#"]), "html", null, true);
            yield "</span>
            ";
            // line 37
            yield $macros["forms"]->getTemplateForMacro("macro_text", $context, 37, $this->getSourceContext())->macro_text(...[["id" =>             // line 38
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 38, $this->source); })()), "describedBy" => ((            // line 39
$context["describedBy"]) ?? (false)), "name" =>             // line 40
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 40, $this->source); })()), "value" => Twig\Extension\CoreExtension::trim(            // line 41
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 41, $this->source); })()), "#"), "size" => 10, "class" => "color-input", "autofocus" =>             // line 44
(isset($context["autofocus"]) || array_key_exists("autofocus", $context) ? $context["autofocus"] : (function () { throw new RuntimeError('Variable "autofocus" does not exist.', 44, $this->source); })()), "disabled" =>             // line 45
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 45, $this->source); })()), "labelledBy" => Twig\Extension\CoreExtension::join($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [            // line 46
(isset($context["labelledBy"]) || array_key_exists("labelledBy", $context) ? $context["labelledBy"] : (function () { throw new RuntimeError('Variable "labelledBy" does not exist.', 46, $this->source); })()), (isset($context["hexLabelId"]) || array_key_exists("hexLabelId", $context) ? $context["hexLabelId"] : (function () { throw new RuntimeError('Variable "hexLabelId" does not exist.', 46, $this->source); })())]), " "), "inputAttributes" => ["aria" => ["describedby" =>             // line 49
(isset($context["hexDescriptionId"]) || array_key_exists("hexDescriptionId", $context) ? $context["hexDescriptionId"] : (function () { throw new RuntimeError('Variable "hexDescriptionId" does not exist.', 49, $this->source); })())]]]]);
            // line 52
            yield "
        </div>
    ";
            echo craft\helpers\Html::tag("div", ob_get_clean(),             // line 24
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 24, $this->source); })()));
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 23
        yield Twig\Extension\CoreExtension::spaceless($_v0);
        // line 57
        ob_start();
        // line 58
        yield "    new Craft.ColorInput('#";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["containerId"]) || array_key_exists("containerId", $context) ? $context["containerId"] : (function () { throw new RuntimeError('Variable "containerId" does not exist.', 58, $this->source); })())), "html", null, true);
        yield "', {
        presets: ";
        // line 59
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((($context["presets"]) ?? ([])));
        yield ",
    });
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_includes/forms/color");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/color";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  140 => 59,  135 => 58,  133 => 57,  131 => 23,  127 => 24,  123 => 52,  121 => 49,  120 => 46,  119 => 45,  118 => 44,  117 => 41,  116 => 40,  115 => 39,  114 => 38,  113 => 37,  107 => 36,  101 => 35,  97 => 33,  95 => 26,  92 => 31,  90 => 30,  88 => 28,  85 => 25,  82 => 24,  80 => 23,  77 => 22,  74 => 20,  72 => 19,  70 => 17,  69 => 15,  68 => 14,  65 => 13,  63 => 12,  61 => 11,  59 => 10,  57 => 9,  55 => 8,  53 => 7,  51 => 6,  49 => 5,  47 => 4,  45 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/forms\" as forms -%}

{% set id = id ?? \"color#{random()}\" -%}
{% set containerId = containerId ?? id~'-container' -%}
{% set hexLabelId = \"#{id}-label\" %}
{% set hexDescriptionId = \"#{id}-desc\" %}
{% set name = name ?? null -%}
{% set value = value ?? null -%}
{% set small = small ?? false -%}
{% set autofocus = (autofocus ?? false) and not craft.app.request.isMobileBrowser(true) -%}
{% set disabled = disabled ?? false -%}
{% set labelledBy = labelledBy ?? null %}

{% set containerAttributes = {
    id: containerId,
    class: ['flex', 'flex-nowrap', 'color-container'],
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% apply spaceless %}
    {% tag 'div' with containerAttributes %}
        {% tag 'div' with {
            class: ['color', 'static', small ? 'small']|filter,
        } %}
            {{ tag('div', {
                class: ['color-preview'],
                style: {'background-color': value}|filter,
            }) }}
        {% endtag %}
        <div class=\"color-input-container\">
            <div class=\"color-hex-indicator light code\" aria-hidden=\"true\">#</div>
            <span id=\"{{ hexLabelId }}\" class=\"visually-hidden\">{{ 'Color hex value'|t('app') }}</span>
            <span id=\"{{ hexDescriptionId }}\" class=\"visually-hidden\">{{ 'Value prefixed by “{prefix}”.'|t('app', {prefix: '#'}) }}</span>
            {{ forms.text({
                id: id,
                describedBy: describedBy ?? false,
                name: name,
                value: value|trim('#'),
                size: 10,
                class: 'color-input',
                autofocus: autofocus,
                disabled: disabled,
                labelledBy: [labelledBy, hexLabelId]|filter|join(' '),
                inputAttributes: {
                    aria: {
                        describedby: hexDescriptionId,
                    }
                }
            }) }}
        </div>
    {% endtag %}
{% endapply -%}

{% js %}
    new Craft.ColorInput('#{{ containerId|namespaceInputId }}', {
        presets: {{ (presets ?? [])|json_encode|raw }},
    });
{% endjs -%}
", "_includes/forms/color", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/color.twig");
    }
}
