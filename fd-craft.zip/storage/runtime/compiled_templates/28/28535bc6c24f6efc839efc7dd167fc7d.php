<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/sections/_index.twig */
class __TwigTemplate_52af0fe2bd6231dc6ee91f3c1885ae19 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/sections/_index.twig");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Sections", "app");
        // line 4
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 6
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 6, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\admintable\\AdminTableAsset"], "method", false, false, false, 6);
        // line 8
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 8, $this->source); })()), "registerTranslations", ["app", ["Are you sure you want to delete “{name}” and all its entries?", "Edit entry type", "Edit entry types ({count})", "Edit entry types", "Entry Types", "Handle", "Name", "No sections exist yet.", "Type"]], "method", false, false, false, 8);
        // line 20
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 30
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 30, $this->source); })())) {
            // line 31
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 38
        ob_start();
        // line 39
        yield "    (() => {
        const columns = [
            { name: '__slot:title', title: Craft.t('app', 'Name'), sortField: true },
            { name: '__slot:handle', title: Craft.t('app', 'Handle'), sortField: true },
            { name: 'type', title: Craft.t('app', 'Type'), sortField: true },
        ];

        let config = {
            columns,
            container: '#sections-vue-admin-table',
            emptyMessage: Craft.t('app', 'No sections exist yet.'),
            tableDataEndpoint: 'sections/table-data',
        };

        ";
        // line 53
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 53, $this->source); })())) {
            // line 54
            yield "            config['deleteAction'] = 'sections/delete-section';
            config['deleteConfirmationMessage'] = Craft.t('app', \"Are you sure you want to delete “{name}” and all its entries?\");
        ";
        }
        // line 57
        yield "
        new Craft.VueAdminTable(config);
    })();
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sections/_index.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/sections/_index.twig");
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 25
        yield "    ";
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 25, $this->source); })())) {
            // line 26
            yield "        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("settings/sections/new"), "html", null, true);
            yield "\" class=\"btn submit add icon\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("New section", "app"), "html", null, true);
            yield "</a>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 35
        yield "    <div id=\"sections-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/sections/_index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  132 => 35,  124 => 34,  112 => 26,  109 => 25,  101 => 24,  95 => 1,  89 => 57,  84 => 54,  82 => 53,  66 => 39,  64 => 38,  61 => 31,  59 => 30,  57 => 20,  55 => 8,  53 => 6,  51 => 4,  49 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"Sections\"|t('app') %}

{% set readOnly = readOnly ?? false %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% do view.registerTranslations('app', [
    \"Are you sure you want to delete “{name}” and all its entries?\",
    \"Edit entry type\",
    \"Edit entry types ({count})\",
    \"Edit entry types\",
    \"Entry Types\",
    \"Handle\",
    \"Name\",
    \"No sections exist yet.\",
    \"Type\",
]) %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% block actionButton %}
    {% if not readOnly %}
        <a href=\"{{ url('settings/sections/new') }}\" class=\"btn submit add icon\">{{ \"New section\"|t('app') }}</a>
    {% endif %}
{% endblock %}

{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    <div id=\"sections-vue-admin-table\"></div>
{% endblock %}

{% js %}
    (() => {
        const columns = [
            { name: '__slot:title', title: Craft.t('app', 'Name'), sortField: true },
            { name: '__slot:handle', title: Craft.t('app', 'Handle'), sortField: true },
            { name: 'type', title: Craft.t('app', 'Type'), sortField: true },
        ];

        let config = {
            columns,
            container: '#sections-vue-admin-table',
            emptyMessage: Craft.t('app', 'No sections exist yet.'),
            tableDataEndpoint: 'sections/table-data',
        };

        {% if not readOnly %}
            config['deleteAction'] = 'sections/delete-section';
            config['deleteConfirmationMessage'] = Craft.t('app', \"Are you sure you want to delete “{name}” and all its entries?\");
        {% endif %}

        new Craft.VueAdminTable(config);
    })();
{% endjs %}
", "settings/sections/_index.twig", "/var/www/html/vendor/craftcms/cms/src/templates/settings/sections/_index.twig");
    }
}
