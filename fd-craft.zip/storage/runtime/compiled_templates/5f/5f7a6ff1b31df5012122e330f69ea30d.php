<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/text */
class __TwigTemplate_9e1e4c4b2c10db142d4fe3a28b254be8 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/text");
        // line 1
        $context["type"] = (($context["type"]) ?? ("text"));
        // line 2
        $context["autocomplete"] = (($context["autocomplete"]) ?? (false));
        // line 4
        $context["class"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["text", (( !((        // line 6
$context["size"]) ?? (false))) ? ("fullwidth") : (null))]));
        // line 8
        $context["id"] = (($context["id"]) ?? (("text" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 9
        $context["descriptionId"] = (($context["descriptionId"]) ?? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 9, $this->source); })()) . "-desc")));
        // line 11
        $context["orientation"] = (($context["orientation"]) ?? ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["inputAttributes"] ?? null), "dir", [], "any", true, true, false, 11) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["inputAttributes"] ?? null), "dir", [], "any", false, false, false, 11)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["inputAttributes"] ?? null), "dir", [], "any", false, false, false, 11)) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 11, $this->source); })()), "app", [], "any", false, false, false, 11), "locale", [], "any", false, false, false, 11), "getOrientation", [], "method", false, false, false, 11)))));
        // line 12
        $context["expanded"] = ((((($context["expanded"]) ?? ((($context["role"]) ?? (false)))) == "combobox")) ? ("false") : ((((true &&  !(null === false))) ? (false) : (false))));
        // line 14
        $context["suffix"] = (($context["suffix"]) ?? ((($context["unit"]) ?? (false))));
        // line 15
        $context["hasSuffix"] =  !((isset($context["suffix"]) || array_key_exists("suffix", $context) ? $context["suffix"] : (function () { throw new RuntimeError('Variable "suffix" does not exist.', 15, $this->source); })()) === false);
        // line 17
        $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 18
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 18, $this->source); })()), "type" =>         // line 19
(isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 19, $this->source); })()), "id" =>         // line 20
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 20, $this->source); })()), "inputmode" => ((        // line 21
$context["inputmode"]) ?? (false)), "size" => ((        // line 22
$context["size"]) ?? (false)), "name" => ((        // line 23
$context["name"]) ?? (false)), "value" => ((        // line 24
$context["value"]) ?? (false)), "maxlength" => ((        // line 25
$context["maxlength"]) ?? (false)), "autofocus" => (((((        // line 26
$context["autofocus"]) ?? (false)) && (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 26, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 26, $this->source); })()), "getAutofocusPreferred", [], "method", false, false, false, 26)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 26, $this->source); })()), "app", [], "any", false, false, false, 26), "request", [], "any", false, false, false, 26), "isMobileBrowser", [true], "method", false, false, false, 26)), "autocomplete" => (($this->env->getTest('boolean')->getCallable()(        // line 27
(isset($context["autocomplete"]) || array_key_exists("autocomplete", $context) ? $context["autocomplete"] : (function () { throw new RuntimeError('Variable "autocomplete" does not exist.', 27, $this->source); })()))) ? ((((isset($context["autocomplete"]) || array_key_exists("autocomplete", $context) ? $context["autocomplete"] : (function () { throw new RuntimeError('Variable "autocomplete" does not exist.', 27, $this->source); })())) ? ("on") : ("off"))) : ((isset($context["autocomplete"]) || array_key_exists("autocomplete", $context) ? $context["autocomplete"] : (function () { throw new RuntimeError('Variable "autocomplete" does not exist.', 27, $this->source); })()))), "autocorrect" => ((((        // line 28
$context["autocorrect"]) ?? (true))) ? (false) : ("off")), "autocapitalize" => ((((        // line 29
$context["autocapitalize"]) ?? (true))) ? (false) : ("none")), "disabled" => ((        // line 30
$context["disabled"]) ?? (false)), "readonly" => ((        // line 31
$context["readonly"]) ?? (false)), "title" => ((        // line 32
$context["title"]) ?? (false)), "placeholder" => ((        // line 33
$context["placeholder"]) ?? (false)), "step" => ((        // line 34
$context["step"]) ?? (false)), "min" => ((        // line 35
$context["min"]) ?? (false)), "max" => ((        // line 36
$context["max"]) ?? (false)), "dir" =>         // line 37
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 37, $this->source); })()), "role" => ((        // line 38
$context["role"]) ?? (false)), "aria" => ["labelledby" => (((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 40
($context["inputAttributes"] ?? null), "aria", [], "any", false, true, false, 40), "label", [], "any", true, true, false, 40) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["inputAttributes"] ?? null), "aria", [], "any", false, true, false, 40), "label", [], "any", false, false, false, 40)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["inputAttributes"] ?? null), "aria", [], "any", false, true, false, 40), "label", [], "any", false, false, false, 40)) : (false))) ? (false) : ((($context["labelledBy"]) ?? (false)))), "describedby" => ((Twig\Extension\CoreExtension::join($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [((        // line 42
$context["describedBy"]) ?? (null)), ((        // line 43
(isset($context["hasSuffix"]) || array_key_exists("hasSuffix", $context) ? $context["hasSuffix"] : (function () { throw new RuntimeError('Variable "hasSuffix" does not exist.', 43, $this->source); })())) ? ((isset($context["descriptionId"]) || array_key_exists("descriptionId", $context) ? $context["descriptionId"] : (function () { throw new RuntimeError('Variable "descriptionId" does not exist.', 43, $this->source); })())) : (null))]), " ")) ?: (false)), "expanded" =>         // line 45
(isset($context["expanded"]) || array_key_exists("expanded", $context) ? $context["expanded"] : (function () { throw new RuntimeError('Variable "expanded" does not exist.', 45, $this->source); })())]], ((        // line 47
$context["inputAttributes"]) ?? ([])), true);
        // line 49
        if (        $this->unwrap()->hasBlock("attr", $context, $blocks)) {
            // line 50
            $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 50, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 53
        if ((($context["showCharsLeft"]) ?? (false))) {
            // line 54
            $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 54, $this->source); })()), ["data" => ["show-chars-left" =>             // line 56
(isset($context["showCharsLeft"]) || array_key_exists("showCharsLeft", $context) ? $context["showCharsLeft"] : (function () { throw new RuntimeError('Variable "showCharsLeft" does not exist.', 56, $this->source); })())], "style" => [("padding-" . (((            // line 59
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 59, $this->source); })()) == "ltr")) ? ("right") : ("left"))) => (((($context["maxlength"]) ?? (false))) ? ((((7.2 * $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["maxlength"]) || array_key_exists("maxlength", $context) ? $context["maxlength"] : (function () { throw new RuntimeError('Variable "maxlength" does not exist.', 59, $this->source); })()))) + 14) . "px")) : (""))]], true);
        }
        // line 64
        $context["input"] = $this->extensions['craft\web\twig\Extension']->tagFunction("input", (isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 64, $this->source); })()));
        // line 66
        if ((isset($context["hasSuffix"]) || array_key_exists("hasSuffix", $context) ? $context["hasSuffix"] : (function () { throw new RuntimeError('Variable "hasSuffix" does not exist.', 66, $this->source); })())) {
            // line 67
            yield "    ";
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["id" =>             // line 68
(isset($context["descriptionId"]) || array_key_exists("descriptionId", $context) ? $context["descriptionId"] : (function () { throw new RuntimeError('Variable "descriptionId" does not exist.', 68, $this->source); })()), "hidden" => true, "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("Value suffixed by “{suffix}”.", "app", ["suffix" =>             // line 70
(isset($context["suffix"]) || array_key_exists("suffix", $context) ? $context["suffix"] : (function () { throw new RuntimeError('Variable "suffix" does not exist.', 70, $this->source); })())])]);
            // line 71
            yield "
    <div class=\"flex\">
        <div class=\"textwrapper\">";
            // line 73
            yield (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 73, $this->source); })());
            yield "</div>
        <div class=\"label light\" aria-hidden=\"true\">";
            // line 74
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["suffix"]) || array_key_exists("suffix", $context) ? $context["suffix"] : (function () { throw new RuntimeError('Variable "suffix" does not exist.', 74, $this->source); })()), "html", null, true);
            yield "</div>
    </div>";
        } else {
            // line 77
            yield (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 77, $this->source); })());
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/text");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/text";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  124 => 77,  119 => 74,  115 => 73,  111 => 71,  109 => 70,  108 => 68,  106 => 67,  104 => 66,  102 => 64,  99 => 59,  98 => 56,  97 => 54,  95 => 53,  92 => 50,  90 => 49,  88 => 47,  87 => 45,  86 => 43,  85 => 42,  84 => 40,  83 => 38,  82 => 37,  81 => 36,  80 => 35,  79 => 34,  78 => 33,  77 => 32,  76 => 31,  75 => 30,  74 => 29,  73 => 28,  72 => 27,  71 => 26,  70 => 25,  69 => 24,  68 => 23,  67 => 22,  66 => 21,  65 => 20,  64 => 19,  63 => 18,  62 => 17,  60 => 15,  58 => 14,  56 => 12,  54 => 11,  52 => 9,  50 => 8,  48 => 6,  47 => 4,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{%- set type = type ?? 'text' %}
{%- set autocomplete = autocomplete ?? false %}

{%- set class = (class ?? [])|explodeClass|merge([
    'text',
    not (size ?? false) ? 'fullwidth' : null,
]|filter) %}
{%- set id = id ?? \"text#{random()}\" %}
{%- set descriptionId = descriptionId ?? \"#{id}-desc\" %}

{%- set orientation = orientation ?? inputAttributes.dir ?? craft.app.locale.getOrientation() %}
{%- set expanded = expanded ?? (role ?? false) == 'combobox' ? 'false' : false ?? false %}

{%- set suffix = suffix ?? unit ?? false %}
{%- set hasSuffix = suffix is not same as(false) %}

{%- set inputAttributes = {
    class: class,
    type: type,
    id: id,
    inputmode: inputmode ?? false,
    size: size ?? false,
    name: name ?? false,
    value: value ?? false,
    maxlength: maxlength ?? false,
    autofocus: (autofocus ?? false) and currentUser and currentUser.getAutofocusPreferred() and not craft.app.request.isMobileBrowser(true),
    autocomplete: autocomplete is boolean ? (autocomplete ? 'on' : 'off') : autocomplete,
    autocorrect: (autocorrect ?? true) ? false : 'off',
    autocapitalize: (autocapitalize ?? true) ? false : 'none',
    disabled: disabled ?? false,
    readonly: readonly ?? false,
    title: title ?? false,
    placeholder: placeholder ?? false,
    step: step ?? false,
    min: min ?? false,
    max: max ?? false,
    dir: orientation,
    role: role ?? false,
    aria: {
        labelledby: (inputAttributes.aria.label ?? false) ? false : (labelledBy ?? false),
        describedby: [
            describedBy ?? null,
            hasSuffix ? descriptionId : null,
        ]|filter|join(' ') ?: false,
        expanded: expanded,
    },
}|merge(inputAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set inputAttributes = inputAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{%- endif %}

{%- if showCharsLeft ?? false %}
    {%- set inputAttributes = inputAttributes|merge({
        data: {
            'show-chars-left': showCharsLeft,
        },
        style: {
            (\"padding-#{orientation == 'ltr' ? 'right' : 'left'}\"): (maxlength ?? false) ? \"#{7.2*maxlength|length+14}px\",
        },
    }, recursive=true) %}
{%- endif %}

{%- set input = tag('input', inputAttributes) %}

{%- if hasSuffix %}
    {{ tag('span', {
        id: descriptionId,
        hidden: true,
        text: 'Value suffixed by “{suffix}”.'|t('app', {suffix: suffix}),
    }) }}
    <div class=\"flex\">
        <div class=\"textwrapper\">{{ input|raw }}</div>
        <div class=\"label light\" aria-hidden=\"true\">{{ suffix }}</div>
    </div>
{%- else %}
    {{- input|raw }}
{%- endif %}
", "_includes/forms/text", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/text.twig");
    }
}
