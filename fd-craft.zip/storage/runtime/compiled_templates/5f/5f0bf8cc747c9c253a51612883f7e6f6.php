<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _components/widgets/QuickPost/settings.twig */
class __TwigTemplate_c8af9508cec357a3a258602679a2ea46 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/widgets/QuickPost/settings.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/widgets/QuickPost/settings.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        if ((isset($context["sections"]) || array_key_exists("sections", $context) ? $context["sections"] : (function () { throw new RuntimeError('Variable "sections" does not exist.', 3, $this->source); })())) {
            // line 4
            yield "    ";
            if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", [], "any", false, false, false, 4), "getIsMultiSite", [], "method", false, false, false, 4)) {
                // line 5
                yield "        ";
                $context["editableSites"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", [], "any", false, false, false, 5), "sites", [], "any", false, false, false, 5), "getEditableSites", [], "method", false, false, false, 5);
                // line 6
                yield "
        ";
                // line 7
                if (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["editableSites"]) || array_key_exists("editableSites", $context) ? $context["editableSites"] : (function () { throw new RuntimeError('Variable "editableSites" does not exist.', 7, $this->source); })())) > 1)) {
                    // line 8
                    yield "            ";
                    $context["siteInput"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                        // line 9
                        yield "                <div class=\"select\">
                    <select id=\"site-id\" name=\"siteId\">
                        ";
                        // line 11
                        $context['_parent'] = $context;
                        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["editableSites"]) || array_key_exists("editableSites", $context) ? $context["editableSites"] : (function () { throw new RuntimeError('Variable "editableSites" does not exist.', 11, $this->source); })()));
                        foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                            // line 12
                            yield "                            <option value=\"";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [], "any", false, false, false, 12), "html", null, true);
                            yield "\"";
                            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [], "any", false, false, false, 12) == (isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 12, $this->source); })()))) {
                                yield " selected";
                            }
                            yield ">";
                            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", [], "any", false, false, false, 12), "site"), "html", null, true);
                            yield "</option>
                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_key'], $context['site'], $context['_parent']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 14
                        yield "                    </select>
                </div>
            ";
                        yield from [];
                    })())) ? '' : new Markup($tmp, $this->env->getCharset());
                    // line 17
                    yield "
            ";
                    // line 18
                    yield $macros["forms"]->getTemplateForMacro("macro_field", $context, 18, $this->getSourceContext())->macro_field(...[["id" => "site-id", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app")],                     // line 21
(isset($context["siteInput"]) || array_key_exists("siteInput", $context) ? $context["siteInput"] : (function () { throw new RuntimeError('Variable "siteInput" does not exist.', 21, $this->source); })())]);
                    yield "
        ";
                }
                // line 23
                yield "    ";
            }
            // line 24
            yield "
    ";
            // line 25
            $context["sectionOptions"] = [];
            // line 26
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["sections"]) || array_key_exists("sections", $context) ? $context["sections"] : (function () { throw new RuntimeError('Variable "sections" does not exist.', 26, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
                // line 27
                yield "        ";
                $context["sectionOptions"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["sectionOptions"]) || array_key_exists("sectionOptions", $context) ? $context["sectionOptions"] : (function () { throw new RuntimeError('Variable "sectionOptions" does not exist.', 27, $this->source); })()), [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["s"], "name", [], "any", false, false, false, 27), "site"), "value" => craft\helpers\Template::attribute($this->env, $this->source, $context["s"], "id", [], "any", false, false, false, 27)]]);
                // line 28
                yield "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['s'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 29
            yield "    ";
            yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 29, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Section", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which section do you want to save entries to?", "app"), "id" => "section", "name" => "section", "options" =>             // line 34
(isset($context["sectionOptions"]) || array_key_exists("sectionOptions", $context) ? $context["sectionOptions"] : (function () { throw new RuntimeError('Variable "sectionOptions" does not exist.', 34, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 35
($context["section"] ?? null), "id", [], "any", true, true, false, 35) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "id", [], "any", false, false, false, 35)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "id", [], "any", false, false, false, 35)) : (null)), "toggle" => true, "targetPrefix" => "section"]]);
            // line 38
            yield "

    ";
            // line 40
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["sections"]) || array_key_exists("sections", $context) ? $context["sections"] : (function () { throw new RuntimeError('Variable "sections" does not exist.', 40, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
                // line 41
                yield "        ";
                $context["showSection"] = (( !(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 41, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 41)) || ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "id", [], "any", true, true, false, 41) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "id", [], "any", false, false, false, 41)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "id", [], "any", false, false, false, 41)) : (null)) == craft\helpers\Template::attribute($this->env, $this->source, $context["s"], "id", [], "any", false, false, false, 41)));
                // line 42
                yield "        <div id=\"section";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["s"], "id", [], "any", false, false, false, 42), "html", null, true);
                yield "\"";
                if ( !(isset($context["showSection"]) || array_key_exists("showSection", $context) ? $context["showSection"] : (function () { throw new RuntimeError('Variable "showSection" does not exist.', 42, $this->source); })())) {
                    yield " class=\"hidden\"";
                }
                yield ">

            ";
                // line 44
                $context["entryTypeOptions"] = [];
                // line 45
                yield "            ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, $context["s"], "getEntryTypes", [], "method", false, false, false, 45));
                foreach ($context['_seq'] as $context["_key"] => $context["et"]) {
                    // line 46
                    yield "                ";
                    $context["entryTypeOptions"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["entryTypeOptions"]) || array_key_exists("entryTypeOptions", $context) ? $context["entryTypeOptions"] : (function () { throw new RuntimeError('Variable "entryTypeOptions" does not exist.', 46, $this->source); })()), [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["et"], "name", [], "any", false, false, false, 46), "site"), "value" => craft\helpers\Template::attribute($this->env, $this->source, $context["et"], "id", [], "any", false, false, false, 46)]]);
                    // line 47
                    yield "            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['et'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 48
                yield "
            ";
                // line 49
                if (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["entryTypeOptions"]) || array_key_exists("entryTypeOptions", $context) ? $context["entryTypeOptions"] : (function () { throw new RuntimeError('Variable "entryTypeOptions" does not exist.', 49, $this->source); })())) == 1)) {
                    // line 50
                    yield "                ";
                    yield craft\helpers\Html::hiddenInput((("sections[" . craft\helpers\Template::attribute($this->env, $this->source, $context["s"], "id", [], "any", false, false, false, 50)) . "][entryType]"), (((craft\helpers\Template::attribute($this->env, $this->source, ($context["entryType"] ?? null), "id", [], "any", true, true, false, 50) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entryType"] ?? null), "id", [], "any", false, false, false, 50)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entryType"] ?? null), "id", [], "any", false, false, false, 50)) : (null)));
                    yield "
            ";
                } else {
                    // line 52
                    yield "                ";
                    yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 52, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Entry Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which type of entries do you want to create?", "app"), "id" => "entryType", "name" => (("sections[" . craft\helpers\Template::attribute($this->env, $this->source,                     // line 56
$context["s"], "id", [], "any", false, false, false, 56)) . "][entryType]"), "options" =>                     // line 57
(isset($context["entryTypeOptions"]) || array_key_exists("entryTypeOptions", $context) ? $context["entryTypeOptions"] : (function () { throw new RuntimeError('Variable "entryTypeOptions" does not exist.', 57, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 58
($context["entryType"] ?? null), "id", [], "any", true, true, false, 58) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entryType"] ?? null), "id", [], "any", false, false, false, 58)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entryType"] ?? null), "id", [], "any", false, false, false, 58)) : (null)), "toggle" => true, "targetPrefix" => (("section" . craft\helpers\Template::attribute($this->env, $this->source,                     // line 60
$context["s"], "id", [], "any", false, false, false, 60)) . "-type")]]);
                    // line 61
                    yield "
            ";
                }
                // line 63
                yield "        </div>
    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 65
            yield "    ";
            yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 65, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Widget Title", "app"), "id" => "custom-title", "name" => "customTitle", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 69
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 69, $this->source); })()), "customTitle", [], "any", false, false, false, 69), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Create a new {section} entry", "app", ["section" => craft\helpers\Template::attribute($this->env, $this->source, ((            // line 71
$context["section"]) ?? (Twig\Extension\CoreExtension::first($this->env->getCharset(), (isset($context["sections"]) || array_key_exists("sections", $context) ? $context["sections"] : (function () { throw new RuntimeError('Variable "sections" does not exist.', 71, $this->source); })())))), "getUiLabel", [], "method", false, false, false, 71)])]]);
            // line 73
            yield "
";
        } else {
            // line 75
            yield "    <p>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("No sections are available.", "app"), "html", null, true);
            yield "</p>
";
        }
        // line 77
        yield "
";
        // line 78
        ob_start();
        // line 79
        yield "  (() => {
    const \$sectionSelect = \$('#";
        // line 80
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()("section"), "html", null, true);
        yield "');
    const \$titleInput = \$('#";
        // line 81
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()("custom-title"), "html", null, true);
        yield "');
    \$sectionSelect.on('change', () => {
      \$titleInput.attr('placeholder', Craft.t('app', 'Create a new {section} entry', {
        section: \$sectionSelect.find(`option[value=\"\${\$sectionSelect.val()}\"]`).text(),
      }));
    });
  })();
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_components/widgets/QuickPost/settings.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_components/widgets/QuickPost/settings.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  243 => 81,  239 => 80,  236 => 79,  234 => 78,  231 => 77,  225 => 75,  221 => 73,  219 => 71,  218 => 69,  216 => 65,  201 => 63,  197 => 61,  195 => 60,  194 => 58,  193 => 57,  192 => 56,  190 => 52,  184 => 50,  182 => 49,  179 => 48,  173 => 47,  170 => 46,  165 => 45,  163 => 44,  153 => 42,  150 => 41,  133 => 40,  129 => 38,  127 => 35,  126 => 34,  124 => 29,  118 => 28,  115 => 27,  110 => 26,  108 => 25,  105 => 24,  102 => 23,  97 => 21,  96 => 18,  93 => 17,  87 => 14,  72 => 12,  68 => 11,  64 => 9,  61 => 8,  59 => 7,  56 => 6,  53 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% if sections %}
    {% if craft.app.getIsMultiSite() %}
        {% set editableSites = craft.app.sites.getEditableSites() %}

        {% if editableSites|length > 1 %}
            {% set siteInput %}
                <div class=\"select\">
                    <select id=\"site-id\" name=\"siteId\">
                        {% for site in editableSites %}
                            <option value=\"{{ site.id }}\"{% if site.id == siteId %} selected{% endif %}>{{ site.name|t('site') }}</option>
                        {% endfor %}
                    </select>
                </div>
            {% endset %}

            {{ forms.field({
                id: 'site-id',
                label: \"Site\"|t('app'),
            }, siteInput) }}
        {% endif %}
    {% endif %}

    {% set sectionOptions = [] %}
    {% for s in sections %}
        {% set sectionOptions = sectionOptions|merge([{ label: s.name|t('site'), value: s.id }]) %}
    {% endfor %}
    {{ forms.selectField({
        label: \"Section\"|t('app'),
        instructions: 'Which section do you want to save entries to?'|t('app'),
        id: 'section',
        name: 'section',
        options: sectionOptions,
        value: section.id ?? null,
        toggle: true,
        targetPrefix: 'section'
    }) }}

    {% for s in sections %}
        {% set showSection = ((not section and loop.first) or (section.id ?? null) == s.id) %}
        <div id=\"section{{ s.id }}\"{% if not showSection %} class=\"hidden\"{% endif %}>

            {% set entryTypeOptions = [] %}
            {% for et in s.getEntryTypes() %}
                {% set entryTypeOptions = entryTypeOptions|merge([{ label: et.name|t('site'), value: et.id }]) %}
            {% endfor %}

            {% if entryTypeOptions|length == 1 %}
                {{ hiddenInput(\"sections[#{s.id}][entryType]\", entryType.id ?? null) }}
            {% else %}
                {{ forms.selectField({
                    label: \"Entry Type\"|t('app'),
                    instructions: \"Which type of entries do you want to create?\"|t('app'),
                    id: 'entryType',
                    name: 'sections['~s.id~'][entryType]',
                    options: entryTypeOptions,
                    value: entryType.id ?? null,
                    toggle: true,
                    targetPrefix: 'section'~s.id~'-type'
                }) }}
            {% endif %}
        </div>
    {% endfor %}
    {{ forms.textField({
        label: 'Widget Title'|t('app'),
        id: 'custom-title',
        name: 'customTitle',
        value: widget.customTitle,
        placeholder: 'Create a new {section} entry'|t('app', {
            section: (section ?? sections|first).getUiLabel(),
        }),
    }) }}
{% else %}
    <p>{{ \"No sections are available.\"|t('app') }}</p>
{% endif %}

{% js %}
  (() => {
    const \$sectionSelect = \$('#{{ 'section'|namespaceInputId }}');
    const \$titleInput = \$('#{{ 'custom-title'|namespaceInputId }}');
    \$sectionSelect.on('change', () => {
      \$titleInput.attr('placeholder', Craft.t('app', 'Create a new {section} entry', {
        section: \$sectionSelect.find(`option[value=\"\${\$sectionSelect.val()}\"]`).text(),
      }));
    });
  })();
{% endjs %}
", "_components/widgets/QuickPost/settings.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_components/widgets/QuickPost/settings.twig");
    }
}
