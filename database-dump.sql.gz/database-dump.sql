-- MySQL dump 10.13  Distrib 8.0.40, for Linux (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epgcoigraaewvvyyavmrmnykqpzlteglttbs` (`primaryOwnerId`),
  CONSTRAINT `fk_bfgzsvbcywllxwmikdrgmsewlxdfmduqfsgs` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_epgcoigraaewvvyyavmrmnykqpzlteglttbs` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_niiaekrlkamqjtcsvwvhbgxzabqkopbrioww` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_cjramdojlffmrurweuasazfgsokooiphzxcr` (`dateRead`),
  KEY `fk_ceorjjfnbrqiqgrenwmlabebrhpyyakxowpp` (`pluginId`),
  CONSTRAINT `fk_ceorjjfnbrqiqgrenwmlabebrhpyyakxowpp` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nofmocpghlplrkaaxehubqtmzbevypfhkpjz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bcpvaxfjsmxrwfxnqegzadasvlbebjqlkevw` (`sessionId`,`volumeId`),
  KEY `idx_brpaogjtfbxaxmprcqehqbsccwpeamjnrcwo` (`volumeId`),
  CONSTRAINT `fk_qlsvmercwspwcuiefdcxpsmolgbrhohlwbgn` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qvnxowhcsxoxexxshxhppabrxqoszfqkhcwm` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `mimeType` varchar(255) DEFAULT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dqwloivtwhojxyiynovachqztkpyxnujjahh` (`filename`,`folderId`),
  KEY `idx_tnjajprxibfgiylpgtkamurfsterxgrjvgkh` (`folderId`),
  KEY `idx_netewrvxptyyiwjxupipmmnpwxklxdszbdqr` (`volumeId`),
  KEY `fk_kokwzcrhigtotvnkglvlcutvdttkspjcowuh` (`uploaderId`),
  CONSTRAINT `fk_fhwqwyzkyrubnpehitugzthjusxobpepvyal` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kokwzcrhigtotvnkglvlcutvdttkspjcowuh` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ozksqznoqkwdzkbumvwmpgtrzagpaccgmqfm` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tbyqsfhfepfaqbuslhyfpndovgoneyujaien` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (33,1,3,1,'hero.mp4','video/mp4','video',NULL,NULL,NULL,2322735,NULL,NULL,NULL,'2025-07-12 23:04:18','2025-07-12 23:04:18','2025-07-12 23:04:18'),(69,1,3,1,'testimonial.jpg','image/jpeg','image',NULL,240,240,10964,NULL,NULL,NULL,'2025-07-13 10:01:34','2025-07-13 10:01:34','2025-07-13 10:01:34'),(76,1,3,1,'plamen.webp','image/webp','image',NULL,768,1024,58254,NULL,NULL,NULL,'2025-07-13 10:04:44','2025-07-13 10:04:44','2025-07-13 10:04:44'),(77,1,3,1,'laservision.png','image/png','image',NULL,1869,947,1331906,NULL,NULL,NULL,'2025-07-13 10:04:47','2025-07-13 10:04:47','2025-07-13 10:04:47');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_vsoxdrjehxxflmurwzxzflpdbahwfosucvyo` (`siteId`),
  CONSTRAINT `fk_emndydgtwjygpcaorkcqoqoylplvmyrrhvhh` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vsoxdrjehxxflmurwzxzflpdbahwfosucvyo` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
INSERT INTO `assets_sites` VALUES (33,1,NULL),(69,1,NULL),(76,1,NULL),(77,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_mcypgeetsrfvjnjxivuaddtrgnbqmcwccoge` (`userId`),
  CONSTRAINT `fk_mcypgeetsrfvjnjxivuaddtrgnbqmcwccoge` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bulkopevents`
--

DROP TABLE IF EXISTS `bulkopevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulkopevents` (
  `key` char(10) NOT NULL,
  `senderClass` varchar(255) NOT NULL,
  `eventName` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`key`,`senderClass`,`eventName`),
  KEY `idx_txpqxdfmqovmgikhkfebdtmwcewrjmucdtbf` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulkopevents`
--

LOCK TABLES `bulkopevents` WRITE;
/*!40000 ALTER TABLE `bulkopevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `bulkopevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qhkbcazlktzwaayowlsubqbrjhqkuluiyuvc` (`groupId`),
  KEY `fk_uxpyusdoytxzjkbbqwrbebfxepznjhbynnlk` (`parentId`),
  CONSTRAINT `fk_dporidduikpmnxpferbhftcpbxhdslrsevdj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qnxyycivmsvnputegmyvcudwjttldqxpyuqk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uxpyusdoytxzjkbbqwrbebfxepznjhbynnlk` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ebutgrwakpqqsxrcrlplftsmbqwbbhrjwzmb` (`name`),
  KEY `idx_hnzjcigswgtbmzvfdiodklskznyuhfdlruev` (`handle`),
  KEY `idx_kxnpmcoaofychjvtrjibrodysywgghjtzyhq` (`structureId`),
  KEY `idx_clegdilldjwhvqwkbmsdinfmrsnwatrfrcjh` (`fieldLayoutId`),
  KEY `idx_dtbxgdvaiqnnwynyipmkeshsmkglhmshfyvv` (`dateDeleted`),
  CONSTRAINT `fk_vkkagdazmpaiqoehsbgkziiqnyngdaasdvgw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xlaivisbnzmaqzeiijvlmazdadkhgbpmbriy` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zkxjjuwmjwmbmcdrphtxnxpkauetktnbxjhu` (`groupId`,`siteId`),
  KEY `idx_wsfaxpjmzbqxstnsfyxpzrhftswlxzeutcre` (`siteId`),
  CONSTRAINT `fk_teflvgroztmgdqapbwrckfoegiosraungcsz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xmcahxhiglyacbftgyswydplmeciqehgchou` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_cvhokqnfwqcxgjthynmyoxhayfjdxvndonwe` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_tzgmfafntxjwajsvgjxsjlllzuxewvmtgsox` (`siteId`),
  KEY `fk_upgemmfxrxcmppvckravqbbswnjdoymppdtk` (`userId`),
  CONSTRAINT `fk_nkcvnthfqyznefryvocfxmeyfqvuzngokgjd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tzgmfafntxjwajsvgjxsjlllzuxewvmtgsox` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_upgemmfxrxcmppvckravqbbswnjdoymppdtk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (1,1,'invalidLoginCount','2025-09-09 16:26:07',0,NULL),(1,1,'invalidLoginWindowStart','2025-09-09 16:26:07',0,NULL),(1,1,'lastPasswordChangeDate','2025-09-09 16:26:07',0,NULL),(1,1,'password','2025-09-09 16:26:07',0,NULL),(2,1,'uri','2025-07-10 17:23:46',0,1),(4,1,'title','2025-07-10 17:16:10',0,1),(6,1,'url','2025-07-21 11:51:02',0,1),(9,1,'title','2025-07-10 17:18:26',0,1),(14,1,'title','2025-07-10 17:19:17',0,1),(20,1,'classes','2025-07-10 17:38:18',0,1),(20,1,'customAttributes','2025-07-10 17:28:40',0,1),(20,1,'enabled','2025-07-10 19:04:13',0,1),(20,1,'newWindow','2025-07-10 19:04:13',0,1),(20,1,'title','2025-07-10 17:39:24',0,1),(45,1,'primaryOwnerId','2025-07-13 09:07:08',0,1),(45,1,'title','2025-07-13 09:07:08',0,1),(46,1,'primaryOwnerId','2025-07-13 09:07:08',0,1),(46,1,'title','2025-07-13 09:07:08',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_ztawrbhzxklfoujfkrqsqrocsptfjlamvrqt` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_qmyqbxvcyvhtnrrjxyyotyjvfsjlluhpafrj` (`siteId`),
  KEY `fk_ieuajmpzimhapvblsxauvtrldtahnupeedac` (`fieldId`),
  KEY `fk_zdikigebvqpxszchuncauvesoicjvsjdjbtm` (`userId`),
  CONSTRAINT `fk_cwixjkdnxupqqxjkosfeezkiznikzgfqchkr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ieuajmpzimhapvblsxauvtrldtahnupeedac` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qmyqbxvcyvhtnrrjxyyotyjvfsjlluhpafrj` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zdikigebvqpxszchuncauvesoicjvsjdjbtm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (2,1,2,'a6adc52c-67b8-4596-9603-06a83b9fab8f','2025-07-15 12:56:38',0,1),(2,1,2,'d1896df3-3b7d-4551-87c3-e18ab68833c9','2025-07-13 07:57:48',0,1),(2,1,2,'f8e43b78-6014-43e5-8899-804e2e660fbf','2025-07-13 09:57:16',0,1),(2,1,3,'4326a0e4-0443-499b-a957-73bf4ee9affe','2025-07-13 10:02:05',0,1),(2,1,4,'1337744c-dd1f-4322-b151-d80f7bb95060','2025-07-13 09:57:16',0,1),(2,1,6,'4ef01fcf-9e33-4ea1-a290-db41df6fefa8','2025-07-13 09:07:08',0,1),(6,1,1,'0460f28c-5013-4ec1-8957-e06e42d43cb7','2025-07-21 11:51:02',0,1),(20,1,1,'0460f28c-5013-4ec1-8957-e06e42d43cb7','2025-09-09 16:45:39',0,1),(45,1,2,'76a53286-b93a-4b66-9d77-ddb2969e8c68','2025-07-13 09:07:08',0,1),(46,1,2,'76a53286-b93a-4b66-9d77-ddb2969e8c68','2025-07-13 09:07:08',0,1),(85,1,6,'4ef01fcf-9e33-4ea1-a290-db41df6fefa8','2025-07-15 15:33:07',0,1),(91,1,5,'a86d2f56-503c-484d-b4f7-1696b74f75f5','2025-09-09 16:56:17',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contentblocks`
--

DROP TABLE IF EXISTS `contentblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contentblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mubfviszomsbphvymafgpznwpjdcjqiapmhz` (`primaryOwnerId`),
  KEY `idx_vdidskqctgnitlwgfhlupkskaupjvoeaupvy` (`fieldId`),
  CONSTRAINT `fk_qwexuiwkmmyzuyaaoizyvdeoajpxpypsbxqg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uhqogvmlawbgpqlisxbgvvcadxsqupeuouif` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wwavjlrvldzowfriybctjyvkdpmwrwxpycug` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contentblocks`
--

LOCK TABLES `contentblocks` WRITE;
/*!40000 ALTER TABLE `contentblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `contentblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_xlibrhuruoepydgqehhhnicwygpggniotxuw` (`userId`),
  CONSTRAINT `fk_xlibrhuruoepydgqehhhnicwygpggniotxuw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jizxxahraymjtnuyjaffdcoumhehdeotokft` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_nvymyarlqwarlnnihjhwdgzmaeheuestkscb` (`creatorId`,`provisional`),
  KEY `idx_tdcxqildhwjgvoabjzqsfregyfxvovuyitat` (`saved`),
  KEY `fk_jwuvxfhlqrkpvkswklcsufqjiuidrzvjxjyz` (`canonicalId`),
  CONSTRAINT `fk_jwuvxfhlqrkpvkswklcsufqjiuidrzvjxjyz` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ywqgmoarrcwbovznkpozweskxfiunslreehr` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES (2,10,1,1,'Draft 1',NULL,1,NULL,1),(32,2,1,1,'Draft 1','',1,NULL,1),(33,NULL,1,0,'First draft',NULL,0,NULL,0),(38,45,1,1,'Draft 1',NULL,1,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_djrlfhebsgafswegfsodyjrnxqdpmvpjeznh` (`elementId`,`timestamp`,`userId`),
  KEY `fk_lcgmajzuyeodglxliuueokzeoytlqgwfkrmk` (`userId`),
  KEY `fk_yrdlinkgspcawyujxhxsmilbbehnligppabd` (`siteId`),
  KEY `fk_sggqwcseyoafgxofmllqmnhqvhqcnbcywybx` (`draftId`),
  CONSTRAINT `fk_lcgmajzuyeodglxliuueokzeoytlqgwfkrmk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sggqwcseyoafgxofmllqmnhqvhqcnbcywybx` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_voscjibeeyxhmmxzqhaqgqinguydygfuvkpx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yrdlinkgspcawyujxhxsmilbbehnligppabd` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (2,1,1,NULL,'edit','2025-07-15 15:33:14'),(2,1,1,NULL,'save','2025-07-15 15:05:40'),(4,1,1,NULL,'edit','2025-07-10 17:16:07'),(4,1,1,NULL,'save','2025-07-10 17:16:10'),(6,1,1,NULL,'edit','2025-07-21 11:51:01'),(6,1,1,NULL,'save','2025-07-21 11:51:02'),(9,1,1,NULL,'save','2025-07-10 17:18:26'),(10,1,1,NULL,'edit','2025-07-10 17:19:18'),(20,1,1,NULL,'edit','2025-09-09 16:45:36'),(20,1,1,NULL,'save','2025-09-09 16:45:39'),(45,1,1,NULL,'edit','2025-09-09 16:56:17'),(46,1,1,NULL,'edit','2025-07-13 09:07:05');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_muuhtaxyhxsdkpgccmrrgdcmuyqbtiftdsdm` (`dateDeleted`),
  KEY `idx_jfnvzoetykbiassqqmjkommqfjlwwnatcsle` (`fieldLayoutId`),
  KEY `idx_kyqtrbqxbfmwjcuhdtjldutogcnjvvnbjihr` (`type`),
  KEY `idx_fijnabvonuzusresavghhrzqxqysxtxcranr` (`enabled`),
  KEY `idx_dcfugwxzjgoyasnwluiownfqsgdzpntticfp` (`canonicalId`),
  KEY `idx_trvslbdidkuhltmelconbctdordvarexnprb` (`archived`,`dateCreated`),
  KEY `idx_zetsujttysjhhogvejkbcadbugtnypthulzr` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_nianrivksfettwdrymwmfugwgaceczoiuplx` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_kyffucccthgwghfexzsbxapeosrmcrqugyje` (`draftId`),
  KEY `fk_hgwxtnqirjboywlnzpauuizcxyrigttfdjjq` (`revisionId`),
  CONSTRAINT `fk_hfpddcnhnkjbxumgkecnplfjxutfyoocesni` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hgwxtnqirjboywlnzpauuizcxyrigttfdjjq` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kyffucccthgwghfexzsbxapeosrmcrqugyje` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_liaufmrdpntuqzzdycevreimynlupkxjpgbw` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2025-07-10 10:15:15','2025-09-09 16:26:06',NULL,NULL,NULL,'9c385b27-9978-449f-a3e6-07324e946a33'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2025-07-10 13:36:44','2025-07-15 15:05:40',NULL,NULL,NULL,'02407ae9-7151-4232-9a42-19c55d1e0cdd'),(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2025-07-10 13:36:44','2025-07-10 13:36:44',NULL,NULL,NULL,'2b1e560b-d2a4-4e06-9774-0a67c824056a'),(4,NULL,NULL,NULL,2,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:16:03','2025-07-15 15:05:40',NULL,NULL,NULL,'8e09b2dc-c897-459a-86d4-26c4a7d5e688'),(6,NULL,NULL,NULL,2,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:17:24','2025-07-21 11:51:02',NULL,NULL,NULL,'550cdc4f-88cb-4284-bd19-0d0aad73c79e'),(7,NULL,NULL,NULL,2,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:17:34','2025-07-10 17:17:34',NULL,NULL,NULL,'7b9fc715-c10c-4814-b910-eef31860bf1f'),(8,NULL,NULL,NULL,2,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:17:43','2025-07-10 17:17:43',NULL,NULL,NULL,'f67e0f54-95ce-49fc-aacd-8d42065a1446'),(9,NULL,NULL,NULL,3,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:18:21','2025-07-15 15:05:40',NULL,NULL,NULL,'50bd60d9-bc2d-4481-8977-7a35ec0dbcd2'),(10,NULL,NULL,NULL,3,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:18:32','2025-07-10 17:18:32',NULL,NULL,NULL,'d9b1c743-4a2d-40ad-9b55-71222976aff7'),(11,NULL,NULL,NULL,3,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:18:54','2025-07-10 17:18:54',NULL,NULL,NULL,'7270ab32-9bed-4fdb-a308-7882fc3911d1'),(12,NULL,NULL,NULL,3,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:18:57','2025-07-10 17:18:57',NULL,NULL,NULL,'b6d13074-b87c-41b7-9375-369f5b1393cb'),(13,NULL,NULL,NULL,3,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:19:05','2025-07-10 17:19:05',NULL,NULL,NULL,'3512d042-6bc0-41d3-ae26-9c30a8be94b4'),(14,10,2,NULL,3,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:19:17','2025-07-10 17:19:17',NULL,NULL,NULL,'4044834a-c1db-4996-be43-782f8572d3eb'),(15,NULL,NULL,NULL,3,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:19:24','2025-07-10 17:19:24',NULL,NULL,NULL,'d565c104-55c6-4267-81fd-c6533251b80f'),(16,NULL,NULL,NULL,3,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:19:31','2025-07-10 17:19:31',NULL,NULL,NULL,'bb5016f5-6e1e-46bf-b9a1-5eaac0c4c1a7'),(17,NULL,NULL,NULL,3,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:19:36','2025-07-10 17:19:36',NULL,NULL,NULL,'ab403851-13ee-4f76-9bdf-a418d157e03b'),(18,2,NULL,2,1,'craft\\elements\\Entry',1,0,'2025-07-10 17:23:46','2025-07-10 17:23:46',NULL,NULL,NULL,'4887e5ac-c5c7-48d5-b5d1-3b81a9d07804'),(19,2,NULL,3,1,'craft\\elements\\Entry',1,0,'2025-07-10 17:24:41','2025-07-10 17:24:41',NULL,NULL,NULL,'79aee299-eaaa-473d-b770-d5fd52b4b6b3'),(20,NULL,NULL,NULL,2,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:28:08','2025-09-09 16:45:39',NULL,NULL,NULL,'e9c097f5-9038-4bd0-9b6b-d8a13feb06e9'),(24,NULL,NULL,NULL,2,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:54:29','2025-07-10 17:54:29',NULL,NULL,NULL,'76f246a0-92bf-40f0-abe6-f21c6e3576ca'),(25,NULL,NULL,NULL,2,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:54:37','2025-07-10 17:54:37',NULL,NULL,NULL,'5e7c4c0b-588a-4502-82ca-88ef58f193d0'),(26,NULL,NULL,NULL,2,'verbb\\navigation\\elements\\Node',1,0,'2025-07-10 17:54:45','2025-07-10 17:54:45',NULL,NULL,NULL,'d724c16d-9c6d-43b3-b6df-026718d140a6'),(28,2,NULL,4,1,'craft\\elements\\Entry',1,0,'2025-07-12 14:31:20','2025-07-12 14:31:20',NULL,NULL,NULL,'7fdba64e-4c2c-4d39-8bee-b4041886ab88'),(32,2,NULL,5,1,'craft\\elements\\Entry',1,0,'2025-07-12 23:00:33','2025-07-12 23:00:33',NULL,NULL,NULL,'d2498265-0275-4d23-973d-20dc4137d0e3'),(33,NULL,NULL,NULL,4,'craft\\elements\\Asset',1,0,'2025-07-12 23:04:18','2025-07-12 23:04:18',NULL,NULL,NULL,'0ba4ce85-2243-478b-9b1f-7205cb762182'),(35,2,NULL,6,1,'craft\\elements\\Entry',1,0,'2025-07-12 23:04:21','2025-07-12 23:04:22',NULL,NULL,NULL,'864eb2ff-a773-42ca-9cd6-5cb037a4b44b'),(37,2,NULL,7,1,'craft\\elements\\Entry',1,0,'2025-07-13 07:57:48','2025-07-13 07:57:48',NULL,NULL,NULL,'126b0c32-9675-42ad-8977-d038554cfa1c'),(44,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2025-07-13 08:58:19','2025-07-13 09:04:50',NULL,'2025-07-13 09:04:50',NULL,'217f1ec9-9caa-43e1-8273-85d9b8542388'),(45,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2025-07-13 08:58:19','2025-07-13 09:07:08',NULL,NULL,NULL,'283a724c-75c8-4236-ba9d-1df4733cc307'),(46,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2025-07-13 08:58:19','2025-07-13 09:07:08',NULL,NULL,NULL,'1a913745-1c04-441e-bf93-a03ab9596810'),(47,2,NULL,8,1,'craft\\elements\\Entry',1,0,'2025-07-13 08:58:19','2025-07-13 08:58:19',NULL,NULL,NULL,'436a06d6-2025-488d-af79-71a802d69d90'),(48,44,NULL,9,5,'craft\\elements\\Entry',1,0,'2025-07-13 08:58:19','2025-07-13 08:58:19',NULL,'2025-07-13 09:04:50',NULL,'b577a81f-8b7c-45a7-a398-15d6e475b992'),(49,45,NULL,10,5,'craft\\elements\\Entry',1,0,'2025-07-13 08:58:19','2025-07-13 08:58:19',NULL,NULL,NULL,'b1b28b83-0ef0-45ac-abf0-6c8fc8272c19'),(50,46,NULL,11,5,'craft\\elements\\Entry',1,0,'2025-07-13 08:58:19','2025-07-13 08:58:19',NULL,NULL,NULL,'464036fc-037a-411c-8aa8-771934c6d87f'),(52,2,NULL,12,1,'craft\\elements\\Entry',1,0,'2025-07-13 09:04:50','2025-07-13 09:04:50',NULL,NULL,NULL,'cdc8ba9b-9b41-47b7-a615-dbacd105205c'),(55,2,NULL,13,1,'craft\\elements\\Entry',1,0,'2025-07-13 09:06:37','2025-07-13 09:06:37',NULL,NULL,NULL,'12f92509-1c6d-4a73-9ca5-37911be3d75f'),(56,46,NULL,14,5,'craft\\elements\\Entry',1,0,'2025-07-13 09:06:37','2025-07-13 09:06:37',NULL,NULL,NULL,'91364104-2e31-48d4-8fac-9bc81064c14b'),(60,2,NULL,15,1,'craft\\elements\\Entry',1,0,'2025-07-13 09:07:08','2025-07-13 09:07:08',NULL,NULL,NULL,'8e59fdeb-67d5-4370-8fed-1eff1523655e'),(61,45,NULL,16,5,'craft\\elements\\Entry',1,0,'2025-07-13 09:07:08','2025-07-13 09:07:08',NULL,NULL,NULL,'a3a04217-4fdd-40dd-94ba-96dfe993f807'),(62,46,NULL,17,5,'craft\\elements\\Entry',1,0,'2025-07-13 09:07:08','2025-07-13 09:07:08',NULL,NULL,NULL,'60b04674-2655-42bc-8bbd-3a54e7cb5afe'),(64,2,NULL,18,1,'craft\\elements\\Entry',1,0,'2025-07-13 09:15:21','2025-07-13 09:15:21',NULL,NULL,NULL,'8273230f-aff9-4b8c-b0d6-6352a0cb2e31'),(66,2,NULL,19,1,'craft\\elements\\Entry',1,0,'2025-07-13 09:57:16','2025-07-13 09:57:16',NULL,NULL,NULL,'80dc4178-3e2f-40fe-9572-99b0ede4ea67'),(68,2,NULL,20,1,'craft\\elements\\Entry',1,0,'2025-07-13 09:57:55','2025-07-13 09:57:55',NULL,NULL,NULL,'3fdbf656-64b9-46b8-876e-ab8b739c7766'),(69,NULL,NULL,NULL,4,'craft\\elements\\Asset',1,0,'2025-07-13 10:01:34','2025-07-13 10:01:34',NULL,NULL,NULL,'745dcb2f-6262-4b3e-99d1-3ae488ba34d4'),(71,2,NULL,21,1,'craft\\elements\\Entry',1,0,'2025-07-13 10:01:37','2025-07-13 10:01:37',NULL,NULL,NULL,'ebaa9b06-faf7-4f25-95a9-bdbac4add0b9'),(73,2,NULL,22,1,'craft\\elements\\Entry',1,0,'2025-07-13 10:01:51','2025-07-13 10:01:51',NULL,NULL,NULL,'ff5fd20e-e639-4450-bead-18b096663091'),(75,2,NULL,23,1,'craft\\elements\\Entry',1,0,'2025-07-13 10:02:05','2025-07-13 10:02:05',NULL,NULL,NULL,'f9d53309-839a-4659-8746-5bdd94729bd3'),(76,NULL,NULL,NULL,4,'craft\\elements\\Asset',1,0,'2025-07-13 10:04:44','2025-07-13 10:04:44',NULL,NULL,NULL,'f7d0f694-7602-4e91-be33-090dbc51ce12'),(77,NULL,NULL,NULL,4,'craft\\elements\\Asset',1,0,'2025-07-13 10:04:47','2025-07-13 10:04:47',NULL,NULL,NULL,'2f75b798-e7a3-4147-88d9-777186d22cb8'),(79,2,NULL,24,1,'craft\\elements\\Entry',1,0,'2025-07-15 12:56:29','2025-07-15 12:56:29',NULL,NULL,NULL,'01dcbdfd-50ee-48b2-9030-b615753ac519'),(81,2,NULL,25,1,'craft\\elements\\Entry',1,0,'2025-07-15 12:56:38','2025-07-15 12:56:38',NULL,NULL,NULL,'db0f56aa-038e-4f09-a669-36647c4e86b8'),(82,2,NULL,26,1,'craft\\elements\\Entry',1,0,'2025-07-15 15:05:40','2025-07-15 15:05:40',NULL,NULL,NULL,'073ee85f-a7c1-429f-8a3e-a4e60fd3daed'),(85,2,32,NULL,1,'craft\\elements\\Entry',1,0,'2025-07-15 15:33:07','2025-07-15 15:33:14',NULL,NULL,NULL,'b9a93f83-459a-4c03-86c2-90746da05273'),(86,NULL,33,NULL,5,'craft\\elements\\Entry',1,0,'2025-07-15 15:33:07','2025-07-15 15:33:07',NULL,NULL,NULL,'3fb50fce-718a-4e0d-a708-831dad98c4ed'),(91,45,38,NULL,5,'craft\\elements\\Entry',1,0,'2025-09-09 16:56:17','2025-09-09 16:56:17',NULL,NULL,NULL,'b29570e8-b8a2-4f86-9903-d2579010c963');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_nnfofqbpvtyabrsoloakiqinpnkakjrctjvn` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_qxibgdqkqdakcfcpzabbhpdfwxqmkrflyckt` (`ownerId`),
  CONSTRAINT `fk_ddhilroaibfcddcxogzavhwlfnegvmfzyxrd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qxibgdqkqdakcfcpzabbhpdfwxqmkrflyckt` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
INSERT INTO `elements_owners` VALUES (44,2,1),(44,85,1),(45,2,1),(45,85,1),(46,2,2),(46,85,2),(48,47,1),(49,47,2),(49,52,2),(49,55,1),(50,47,3),(50,52,3),(56,55,3),(61,60,1),(61,64,1),(61,66,1),(61,68,1),(61,71,1),(61,73,1),(61,75,1),(61,79,1),(61,81,1),(61,82,1),(62,60,2),(62,64,2),(62,66,2),(62,68,2),(62,71,2),(62,73,2),(62,75,2),(62,79,2),(62,81,2),(62,82,2),(86,85,3),(91,2,1),(91,85,1);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sguqeifstixjvolkdhumrpeckdoukfnzcker` (`elementId`,`siteId`),
  KEY `idx_itvueviixsurtpokdlrykgxptfxwrgyoxsuz` (`siteId`),
  KEY `idx_rjltilamhpvoeuhypxxucokrsgendihpjlkr` (`title`,`siteId`),
  KEY `idx_anqpslweihqkehhslgilrrtufkjkrqlgppfn` (`slug`,`siteId`),
  KEY `idx_gtpgzxccplappxceeuooxtaqadmlonruvzpz` (`enabled`),
  KEY `idx_avlkuxqnjyzoaogtdwbgmmbpdltsnffojlkp` (`uri`,`siteId`),
  CONSTRAINT `fk_nmfnrruwsmyodvjgdauxhmszbbecsjylxbml` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nvyhhdspmlgaymqhxannqrubkvimordyarya` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2025-07-10 10:15:15','2025-07-10 10:15:15','694fe169-8100-4a1d-900b-c8b9aeceb9b8'),(2,2,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-10 13:36:44','2025-07-15 12:56:38','6bdba9d1-c6b9-455c-ab7b-fb8a8ae1391b'),(3,3,1,'Homepage','homepage','homepage',NULL,1,'2025-07-10 13:36:44','2025-07-10 13:36:44','16661a3d-fa20-40c2-9e58-fd29f2520eba'),(4,4,1,'Home','1',NULL,NULL,1,'2025-07-10 17:16:03','2025-07-10 17:16:56','7a05ca72-df44-4c01-8305-93d8cd50f079'),(6,6,1,'About',NULL,NULL,'{\"0460f28c-5013-4ec1-8957-e06e42d43cb7\": \"normal\"}',1,'2025-07-10 17:17:24','2025-07-21 11:51:02','26c2e783-bcc2-4e08-b197-b8f3c243a465'),(7,7,1,'Services',NULL,NULL,NULL,1,'2025-07-10 17:17:34','2025-07-10 17:17:37','8441a177-b901-4396-8eb9-eba3a1fe2e13'),(8,8,1,'Contact',NULL,NULL,NULL,1,'2025-07-10 17:17:43','2025-07-10 17:54:19','94332ee0-555a-4114-b850-8d806331c579'),(9,9,1,'Home','1',NULL,NULL,1,'2025-07-10 17:18:21','2025-07-10 17:19:12','4be5ff81-b5cc-44e3-af83-6950d85d369a'),(10,10,1,'Services',NULL,NULL,NULL,1,'2025-07-10 17:18:32','2025-07-10 17:19:12','fe4f18a6-ed03-475e-97bf-5e8c25f947d0'),(11,11,1,'Web Design',NULL,NULL,NULL,1,'2025-07-10 17:18:54','2025-07-10 17:19:12','6a5af0e0-27c9-4d1a-8df5-8d67c776fcd9'),(12,12,1,'SEO',NULL,NULL,NULL,1,'2025-07-10 17:18:57','2025-07-10 17:19:12','3ae08708-b1d2-4a12-9cbc-a6e1f4ecd5a6'),(13,13,1,'Google Ads',NULL,NULL,NULL,1,'2025-07-10 17:19:05','2025-07-10 17:19:12','b81e0386-a353-4469-8b4a-4fbb122fb09b'),(14,14,1,'About',NULL,NULL,NULL,1,'2025-07-10 17:19:17','2025-07-10 17:19:17','07f4d0cd-9cdc-420b-b4e6-6a52cec78e3d'),(15,15,1,'Contact',NULL,NULL,NULL,1,'2025-07-10 17:19:24','2025-07-10 17:19:43','38d38a28-3f0f-413e-adb4-def425b476e7'),(16,16,1,'Privacy Policy',NULL,NULL,NULL,1,'2025-07-10 17:19:31','2025-07-10 17:19:43','387f7bf8-8ae3-4d7f-9432-979681cc2077'),(17,17,1,'Terms & Conditions',NULL,NULL,NULL,1,'2025-07-10 17:19:36','2025-07-10 17:19:43','792ea6c1-de5b-4ed1-b74b-0c48807bcbab'),(18,18,1,'Homepage','homepage','__home__',NULL,1,'2025-07-10 17:23:46','2025-07-10 17:23:46','2a1e130f-c183-4ae7-9d2b-9b3c5b6a25ea'),(19,19,1,'Homepage','homepage','__home__',NULL,1,'2025-07-10 17:24:41','2025-07-10 17:24:41','cd61e389-d909-45f9-b5ff-ab0808a04cbf'),(20,20,1,'Book Free Call',NULL,NULL,'{\"0460f28c-5013-4ec1-8957-e06e42d43cb7\": \"cta\"}',1,'2025-07-10 17:28:08','2025-09-09 16:45:39','24318cf8-7db9-48b9-95d0-ba533b4ba198'),(24,24,1,'Web Design',NULL,NULL,'{\"0460f28c-5013-4ec1-8957-e06e42d43cb7\": \"normal\"}',1,'2025-07-10 17:54:29','2025-07-10 17:54:33','1c77f17d-a8b6-4d5c-80ac-a2daba100f39'),(25,25,1,'SEO',NULL,NULL,'{\"0460f28c-5013-4ec1-8957-e06e42d43cb7\": \"normal\"}',1,'2025-07-10 17:54:37','2025-07-10 17:54:40','8ff83a79-fcd2-414c-b3dd-5881e878b294'),(26,26,1,'Google Ads',NULL,NULL,'{\"0460f28c-5013-4ec1-8957-e06e42d43cb7\": \"normal\"}',1,'2025-07-10 17:54:45','2025-07-10 17:54:48','f767bef2-bd71-4005-84ed-5240c1f1846f'),(28,28,1,'Homepage','homepage','__home__',NULL,1,'2025-07-12 14:31:20','2025-07-12 14:31:20','6f85c58e-3a19-4547-952a-45c1f41c50f4'),(32,32,1,'Homepage','homepage','__home__','{\"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"d1896df3-3b7d-4551-87c3-e18ab68833c9\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-12 23:00:33','2025-07-12 23:00:33','6e491576-6ba9-4285-a26a-cc2e8a4aefb0'),(33,33,1,'Hero',NULL,NULL,NULL,1,'2025-07-12 23:04:18','2025-07-12 23:04:18','d97ffc0b-a76e-4c41-b28e-7436add155dd'),(35,35,1,'Homepage','homepage','__home__','{\"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"d1896df3-3b7d-4551-87c3-e18ab68833c9\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-12 23:04:22','2025-07-12 23:04:22','46dca026-b1f2-4726-844c-83ad57799cc7'),(37,37,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 07:57:48','2025-07-13 07:57:48','b287ab98-84ec-4aea-b2d7-b33ac7a0129b'),(44,44,1,'Call to Action 1','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"normal\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Call to Action 1\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-07-13 08:58:19','2025-07-13 08:58:19','b1866402-c1e1-4959-9072-d8b219371cf1'),(45,45,1,'Book A Free Strategy Call','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"cta\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Book A Free Strategy Call\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-07-13 08:58:19','2025-07-13 09:07:08','323aec35-c18d-4e4e-80f4-114bfd3e3394'),(46,46,1,'Our Services','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"ctaAlt\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Our Services\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-07-13 08:58:19','2025-07-13 09:07:08','d817fb7c-7fdc-4739-a8e4-7e93f2a4cec7'),(47,47,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 08:58:19','2025-07-13 08:58:19','973aeb71-e944-425f-a618-aff3affc4107'),(48,48,1,'Call to Action 1','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"normal\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Call to Action 1\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-07-13 08:58:19','2025-07-13 08:58:19','42327e2c-1be5-4ac9-a9d8-7952aea7a44a'),(49,49,1,'Call to Action 2','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"cta\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Call to Action 2\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-07-13 08:58:19','2025-07-13 08:58:19','f6c21335-1bf7-4ff1-9ab5-9724e6989244'),(50,50,1,'Call to Action 2','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"ctaAlt\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Call to Action 2\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-07-13 08:58:19','2025-07-13 08:58:19','aafb29f1-fc7f-4781-8b12-6fd2da9382fd'),(52,52,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 09:04:50','2025-07-13 09:04:50','fc1d8ee6-f489-48bf-b578-51743b50af3d'),(55,55,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 09:06:37','2025-07-13 09:06:37','a8a6f562-5c31-4129-b1f7-30f29a39084d'),(56,56,1,'Call to Action 3','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"ctaAlt\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Call to Action 3\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-07-13 09:06:37','2025-07-13 09:06:37','3d0d722b-7c15-43a1-bfda-6818bae3f982'),(60,60,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 09:07:08','2025-07-13 09:07:08','932cc856-cb6b-466a-a1bf-fc6731aa91b1'),(61,61,1,'Book A Free Strategy Call','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"cta\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Book A Free Strategy Call\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-07-13 09:07:08','2025-07-13 09:07:08','25546e18-9bee-46da-9746-99b46e98f7d7'),(62,62,1,'Our Services','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"ctaAlt\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Our Services\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-07-13 09:07:08','2025-07-13 09:07:08','e127e845-8f25-4930-9458-ca2e52264858'),(64,64,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry. 3\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic 1\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies 2\"}',1,'2025-07-13 09:15:21','2025-07-13 09:15:21','4e659ff1-fcb5-4427-85c3-2affbc30f675'),(66,66,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 09:57:16','2025-07-13 09:57:16','a1d42795-b6b3-4798-8093-4f1b491bb6f1'),(68,68,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 09:57:55','2025-07-13 09:57:55','aa4bcd9d-6f80-40d7-89ed-9894a131f08b'),(69,69,1,'Testimonial',NULL,NULL,NULL,1,'2025-07-13 10:01:34','2025-07-13 10:01:34','a9201727-8b1e-4a58-acf5-234349c5785f'),(71,71,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33, 69], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 10:01:37','2025-07-13 10:01:37','5784d0cd-8053-4498-8d93-0a98b0190e3b'),(73,73,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [69, 33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 10:01:51','2025-07-13 10:01:51','0660ea95-8ae5-40d6-8005-b6976ca36507'),(75,75,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-13 10:02:05','2025-07-13 10:02:05','b8276135-8946-4432-ad0c-9fdb86de64ef'),(76,76,1,'Plamen',NULL,NULL,NULL,1,'2025-07-13 10:04:44','2025-07-13 10:04:44','a00844a6-6a4a-4faf-91db-6afc53785d0a'),(77,77,1,'Laservision',NULL,NULL,NULL,1,'2025-07-13 10:04:47','2025-07-13 10:04:47','8a8324ee-3c89-44e4-9398-88464f6d7249'),(79,79,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic2\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-15 12:56:29','2025-07-15 12:56:29','93d93ce1-87d0-4dca-95ef-edc820ce413c'),(81,81,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-15 12:56:38','2025-07-15 12:56:38','123ff79c-f94b-47f0-a00c-f4a34b0f9d36'),(82,82,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-15 15:05:40','2025-07-15 15:05:40','cb33246c-7bd5-4dfe-b6a7-2fe6ebd18dc2'),(85,85,1,'Homepage','homepage','__home__','{\"1337744c-dd1f-4322-b151-d80f7bb95060\": \"We help ambitious clinics attract more clients, generate qualified leads, and build stunning websites that convert—all with smart SEO, Google Ads, and beautiful design tailored for your industry.\", \"4326a0e4-0443-499b-a957-73bf4ee9affe\": [33], \"a6adc52c-67b8-4596-9603-06a83b9fab8f\": \"Grow Your Clinic\", \"f8e43b78-6014-43e5-8899-804e2e660fbf\": \"With Proven Digital Strategies\"}',1,'2025-07-15 15:33:07','2025-07-15 15:33:07','9d804f48-b079-44d7-9b7d-95c56eee9d5b'),(86,86,1,NULL,'__temp_slgqbrayycpjkvlyzadxjofovrtseqyfbvos',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"normal\"}',1,'2025-07-15 15:33:07','2025-07-15 15:33:07','c198819d-a5d7-404d-a8fe-49c0bb7e6244'),(91,91,1,'Book A Free Strategy Call','call-to-action-1',NULL,'{\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\": \"cta\", \"76a53286-b93a-4b66-9d77-ddb2969e8c68\": \"Book A Free Strategy Call\", \"a86d2f56-503c-484d-b4f7-1696b74f75f5\": {\"type\": \"url\", \"value\": \"#\"}}',1,'2025-09-09 16:56:17','2025-09-09 16:56:17','af0eb0a8-0bb1-45c2-828c-c0ab0d6da2d2');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `status` enum('live','pending','expired') NOT NULL DEFAULT 'live',
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pqwpxhrqmxambtgytueyivqbvngfbcyuxhig` (`postDate`),
  KEY `idx_sdwzjuvizsvtqsfovovosktqmraajtgpewxi` (`expiryDate`),
  KEY `idx_ncjksefhczsywzrrocyhuvwpejptajkuewpg` (`status`),
  KEY `idx_dezgnlfpziajbrfssrcvshobkycteozioryy` (`sectionId`),
  KEY `idx_qxdbbctwwdelyielcrncgczknrkujzovntdl` (`typeId`),
  KEY `idx_ajfkykkfjiuxtbxbmebrccwlbsqpwcorsmjg` (`primaryOwnerId`),
  KEY `idx_zeguvagcmkwvdrdlwckohysaazbskcmcfqkr` (`fieldId`),
  KEY `fk_bkrdlhkqamjjmwjqxkgklqxqbdluuznnodrv` (`parentId`),
  CONSTRAINT `fk_bkrdlhkqamjjmwjqxkgklqxqbdluuznnodrv` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pblhalaqpqeafjapdlxklvvuwifaxrgykkpb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pxlugpktnjzfwmdkxhkfpyyhmuhuqlleykfi` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xnciswjtyaizbfyenmwbeaxlfjrkkksglfvo` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zlrkuxagzfsihkfcshlvmtmhhtspqvvayycm` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zqnnamarewyanezqdyhshtxbndfkfnzhpxxt` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-10 13:36:44','2025-07-10 13:36:44'),(3,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-10 13:36:44','2025-07-10 13:36:44'),(18,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-10 17:23:46','2025-07-10 17:23:46'),(19,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-10 17:24:41','2025-07-10 17:24:41'),(28,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-12 14:31:20','2025-07-12 14:31:20'),(32,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-12 23:00:33','2025-07-12 23:00:33'),(35,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-12 23:04:22','2025-07-12 23:04:22'),(37,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 07:57:48','2025-07-13 07:57:48'),(44,NULL,NULL,2,6,2,'2025-07-13 08:57:00',NULL,'live',0,0,'2025-07-13 08:58:19','2025-07-13 08:58:19'),(45,NULL,NULL,2,6,2,'2025-07-13 08:57:00',NULL,'live',NULL,NULL,'2025-07-13 08:58:19','2025-07-13 08:58:19'),(46,NULL,NULL,2,6,2,'2025-07-13 08:57:00',NULL,'live',NULL,NULL,'2025-07-13 08:58:19','2025-07-13 08:58:19'),(47,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 08:58:19','2025-07-13 08:58:19'),(48,NULL,NULL,47,6,2,'2025-07-13 08:57:00',NULL,'live',NULL,NULL,'2025-07-13 08:58:19','2025-07-13 08:58:19'),(49,NULL,NULL,47,6,2,'2025-07-13 08:57:00',NULL,'live',NULL,NULL,'2025-07-13 08:58:19','2025-07-13 08:58:19'),(50,NULL,NULL,47,6,2,'2025-07-13 08:57:00',NULL,'live',NULL,NULL,'2025-07-13 08:58:19','2025-07-13 08:58:19'),(52,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 09:04:50','2025-07-13 09:04:50'),(55,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 09:06:37','2025-07-13 09:06:37'),(56,NULL,NULL,55,6,2,'2025-07-13 08:57:00',NULL,'live',NULL,NULL,'2025-07-13 09:06:37','2025-07-13 09:06:37'),(60,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 09:07:08','2025-07-13 09:07:08'),(61,NULL,NULL,60,6,2,'2025-07-13 08:57:00',NULL,'live',NULL,NULL,'2025-07-13 09:07:08','2025-07-13 09:07:08'),(62,NULL,NULL,60,6,2,'2025-07-13 08:57:00',NULL,'live',NULL,NULL,'2025-07-13 09:07:08','2025-07-13 09:07:08'),(64,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 09:15:21','2025-07-13 09:15:21'),(66,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 09:57:16','2025-07-13 09:57:16'),(68,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 09:57:55','2025-07-13 09:57:55'),(71,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 10:01:37','2025-07-13 10:01:37'),(73,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 10:01:51','2025-07-13 10:01:51'),(75,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-13 10:02:05','2025-07-13 10:02:05'),(79,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-15 12:56:29','2025-07-15 12:56:29'),(81,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-15 12:56:38','2025-07-15 12:56:38'),(82,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-15 15:05:40','2025-07-15 15:05:40'),(85,1,NULL,NULL,NULL,1,'2025-07-10 13:36:00',NULL,'live',NULL,NULL,'2025-07-15 15:33:07','2025-07-15 15:33:07'),(86,NULL,NULL,85,6,2,NULL,NULL,'pending',NULL,NULL,'2025-07-15 15:33:07','2025-07-15 15:33:07'),(91,NULL,NULL,2,6,2,'2025-07-13 08:57:00',NULL,'live',NULL,NULL,'2025-09-09 16:56:17','2025-09-09 16:56:17');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_ajtldllvfgcktacuaycfrmzthrgifrorquwx` (`authorId`),
  KEY `idx_ejeidghavhzwafxxvjvqbswimactqmkoznqi` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_frhkcduhmcvxzzgmbkefmfppldrjztlpfwpl` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nkulqncdrqkhoatrddttcvicyptsclczyxxi` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yvgxfchqsthjaauzjwtvthwrsyebxfhngiel` (`fieldLayoutId`),
  KEY `idx_daxonhkeswnmzehvfqfyuxhgxpdncnkladjv` (`dateDeleted`),
  CONSTRAINT `fk_eetzemekirpexeoijpbitqudcycgalrecpmd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,'Homepage','homepage',NULL,'house',NULL,1,'site',NULL,'{headline}',0,'site',NULL,0,'2025-07-10 13:36:40','2025-07-10 13:36:40',NULL,'f1c7e864-914a-44b3-8480-1a3fc4f46b09'),(2,5,'Call to Action','callToAction','Call to Action Buttons','link','lime',1,'site',NULL,NULL,0,'site',NULL,0,'2025-07-13 08:43:19','2025-07-13 08:43:19',NULL,'13030367-75b1-4224-9106-d1244c54cc43');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_emqbtxqnejezoqelxhfymawooeceyqgqqgvb` (`dateDeleted`),
  KEY `idx_lsowzrvrowmljjhwpizkuieovbwjkwumhrqf` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"8a1ca38c-100e-4b55-b294-6d95ddbd5182\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"16fb0f7f-a335-47b0-a9ca-a3d233a767f4\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-07-10T13:33:21+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"a6adc52c-67b8-4596-9603-06a83b9fab8f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Headline\", \"width\": 100, \"handle\": \"headlineLineOne\", \"warning\": null, \"fieldUid\": \"a580fa9f-fec5-4030-9ec4-056fa41939f4\", \"required\": true, \"dateAdded\": \"2025-07-12T14:31:17+00:00\", \"instructions\": \"The first line from the headline of the homepage\", \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"f8e43b78-6014-43e5-8899-804e2e660fbf\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Headline Line Two\", \"width\": 100, \"handle\": \"headlineLineTwo\", \"warning\": null, \"fieldUid\": \"a580fa9f-fec5-4030-9ec4-056fa41939f4\", \"required\": false, \"dateAdded\": \"2025-07-12T14:31:17+00:00\", \"instructions\": \"Line two of the headline of the homepage (the gradient animation part)\", \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"1337744c-dd1f-4322-b151-d80f7bb95060\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Hero description\", \"width\": 100, \"handle\": \"heroDescription\", \"warning\": null, \"fieldUid\": \"33dabbd5-4d93-4868-bee3-62998def8ddc\", \"required\": false, \"dateAdded\": \"2025-07-13T07:56:45+00:00\", \"instructions\": \"Appears under the hero image headline.\", \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"4326a0e4-0443-499b-a957-73bf4ee9affe\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Video\", \"width\": 100, \"handle\": \"heroVideo\", \"warning\": null, \"fieldUid\": \"3d54c233-d443-46e3-8ec7-850ab1c9d69a\", \"required\": false, \"dateAdded\": \"2025-07-12T14:31:17+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"4ef01fcf-9e33-4ea1-a290-db41df6fefa8\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"ad06897a-3f68-4e59-8dd8-6a551c070e88\", \"required\": false, \"dateAdded\": \"2025-07-13T08:57:13+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-10 13:36:40','2025-07-13 09:14:24',NULL,'2b244306-a1c5-4527-8693-1185df6923d2'),(2,'verbb\\navigation\\elements\\Node','{\"tabs\": [{\"uid\": \"43dbf10f-53e4-45be-9fc4-9b46843d2e85\", \"name\": \"Node\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"c91ae732-4c04-40f1-a70e-5be0680739f2\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\TitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2025-07-10T17:13:17+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"60e6d0f8-f834-4798-8604-a16dc1196b2c\", \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\NodeTypeElements\", \"label\": null, \"warning\": null, \"required\": false, \"dateAdded\": \"2025-07-10T17:13:17+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"id\": null, \"tip\": null, \"uid\": \"19c1e650-e191-4d35-9b66-59533f919814\", \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\NewWindowField\", \"label\": null, \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"newWindow\", \"dateAdded\": \"2025-07-10T17:13:17+00:00\", \"mandatory\": false, \"requirable\": true, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"0460f28c-5013-4ec1-8957-e06e42d43cb7\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"bb28314d-a061-45be-bebf-8b0a6076b3d0\", \"required\": false, \"dateAdded\": \"2025-07-10T17:37:40+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"384552db-74e3-43e5-b7d0-9a640bd9cd13\", \"name\": \"Advanced\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"0d181fc2-89b5-4a93-aeb9-c9df421b75c0\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\UrlSuffixField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"urlSuffix\", \"autofocus\": false, \"dateAdded\": \"2025-07-10T17:13:17+00:00\", \"inputType\": null, \"mandatory\": false, \"maxlength\": null, \"requirable\": true, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"8dba8be7-a202-4b38-8df3-a00a2b4e5c14\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\ClassesField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"classes\", \"autofocus\": false, \"dateAdded\": \"2025-07-10T17:13:17+00:00\", \"inputType\": null, \"mandatory\": false, \"maxlength\": null, \"requirable\": true, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"0118fb20-af3d-437e-aa4f-372e7e406b71\", \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\CustomAttributesField\", \"label\": null, \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"customAttributes\", \"dateAdded\": \"2025-07-10T17:13:17+00:00\", \"mandatory\": false, \"requirable\": true, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-10 17:15:03','2025-07-10 17:37:40',NULL,'b379fee8-82f5-455e-89ec-c085a37e63cd'),(3,'verbb\\navigation\\elements\\Node','{\"tabs\": [{\"uid\": \"1bef4cca-01de-4f2b-9409-64aa3ab93cc7\", \"name\": \"Node\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"46d2bcf4-65b7-4fc5-b517-902421162166\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\TitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2025-07-10T17:14:08+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"a01d152b-5ed3-4806-825c-7559f59a6d5a\", \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\NodeTypeElements\", \"label\": null, \"warning\": null, \"required\": false, \"dateAdded\": \"2025-07-10T17:14:08+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"id\": null, \"tip\": null, \"uid\": \"12d751f8-1c86-45f0-812a-80c707b6e4f2\", \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\NewWindowField\", \"label\": null, \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"newWindow\", \"dateAdded\": \"2025-07-10T17:14:08+00:00\", \"mandatory\": false, \"requirable\": true, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"f8930ef4-6989-44df-ae7b-222528606421\", \"name\": \"Advanced\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"ac6cb88b-2342-4501-9ad1-9a209690032d\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\UrlSuffixField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"urlSuffix\", \"autofocus\": false, \"dateAdded\": \"2025-07-10T17:14:08+00:00\", \"inputType\": null, \"mandatory\": false, \"maxlength\": null, \"requirable\": true, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"847f4af5-3ee7-4516-8165-e43060083798\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\ClassesField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"classes\", \"autofocus\": false, \"dateAdded\": \"2025-07-10T17:14:08+00:00\", \"inputType\": null, \"mandatory\": false, \"maxlength\": null, \"requirable\": true, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"d8f8cde9-cbf9-44b0-a7d8-eac50247ae3e\", \"type\": \"verbb\\\\navigation\\\\fieldlayoutelements\\\\CustomAttributesField\", \"label\": null, \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"customAttributes\", \"dateAdded\": \"2025-07-10T17:14:08+00:00\", \"mandatory\": false, \"requirable\": true, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-10 17:15:23','2025-07-10 17:15:23',NULL,'b71d9df7-fd0b-425b-88ec-c4c8ca9084ba'),(4,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"b4c79577-7de6-493c-965a-c3510de4139b\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"d63d3ea9-531a-492f-84c6-7bebdd453256\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2025-07-12T14:31:15+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"4fc08b7d-e76b-466c-8f82-7df2720a5cc5\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Alt\", \"width\": 100, \"handle\": \"imageAlt\", \"warning\": null, \"fieldUid\": \"a580fa9f-fec5-4030-9ec4-056fa41939f4\", \"required\": false, \"dateAdded\": \"2025-07-12T14:40:53+00:00\", \"instructions\": \"Alternative text for the images\", \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-12 14:40:53','2025-07-12 14:40:53',NULL,'e1b6b4f4-92a0-41b5-965a-3883046533f3'),(5,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"4ef4da52-7b07-41d3-954d-69824cbcd2f3\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"03b7685d-73fa-4b4f-a609-d5992cfc7439\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-07-13T08:41:00+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"76a53286-b93a-4b66-9d77-ddb2969e8c68\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Link text\", \"width\": 100, \"handle\": \"linkText\", \"warning\": null, \"fieldUid\": \"a580fa9f-fec5-4030-9ec4-056fa41939f4\", \"required\": false, \"dateAdded\": \"2025-07-13T08:43:19+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"a86d2f56-503c-484d-b4f7-1696b74f75f5\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"URL Address\", \"width\": 100, \"handle\": \"urlAddress\", \"warning\": null, \"fieldUid\": \"2c90d339-319f-41d1-96cf-1c889863fef2\", \"required\": false, \"dateAdded\": \"2025-07-13T08:43:19+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"49bc446c-2f5a-4b23-aa14-dd181cc323fa\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"bb28314d-a061-45be-bebf-8b0a6076b3d0\", \"required\": false, \"dateAdded\": \"2025-07-13T08:43:19+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-13 08:43:19','2025-07-13 08:43:19',NULL,'284fee46-1054-4234-8001-ff87c807d25e');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_axovvnpduzrtkrdgkfhxqauwcjiycpepeqtk` (`handle`,`context`),
  KEY `idx_xvrvvalmhigknqmkjorqbgmclnfvimejvofn` (`context`),
  KEY `idx_fbvpxxnpgpskwhgrsarcgeszruvuamgfttix` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Button Type','buttonType','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"customOptions\":false,\"options\":[{\"label\":\"Normal Link\",\"value\":\"normal\",\"icon\":\"\",\"color\":\"\",\"default\":\"1\"},{\"label\":\"Call To Action\",\"value\":\"cta\",\"icon\":\"\",\"color\":\"\",\"default\":\"\"},{\"label\":\"Call To Action Alt\",\"value\":\"ctaAlt\",\"icon\":\"\",\"color\":\"\",\"default\":\"\"}]}','2025-07-10 17:35:17','2025-07-12 12:34:21',NULL,'bb28314d-a061-45be-bebf-8b0a6076b3d0'),(2,'Plain Text ','plainText','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-07-12 14:23:34','2025-07-13 07:54:36',NULL,'a580fa9f-fec5-4030-9ec4-056fa41939f4'),(3,'Image','image','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"audio\",\"image\",\"pdf\",\"video\"],\"branchLimit\":null,\"defaultPlacement\":\"end\",\"defaultUploadLocationSource\":\"volume:de4e6ba3-84ff-4825-9f58-5cb381127cac\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:de4e6ba3-84ff-4825-9f58-5cb381127cac\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSearchInput\":true,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:de4e6ba3-84ff-4825-9f58-5cb381127cac\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-07-12 14:31:14','2025-07-12 23:04:10',NULL,'3d54c233-d443-46e3-8ec7-850ab1c9d69a'),(4,'Text Area','textArea','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-07-13 07:56:41','2025-07-13 07:56:41',NULL,'33dabbd5-4d93-4868-bee3-62998def8ddc'),(5,'URL','buttonUrl','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Link','{\"advancedFields\":[\"target\",\"title\"],\"fullGraphqlData\":true,\"maxLength\":255,\"showLabelField\":false,\"typeSettings\":{\"entry\":{\"sources\":\"*\",\"showUnpermittedSections\":\"\",\"showUnpermittedEntries\":\"\"},\"url\":{\"allowRootRelativeUrls\":\"1\",\"allowAnchors\":\"1\",\"allowCustomSchemes\":\"\"}},\"types\":[\"entry\",\"url\"]}','2025-07-13 08:27:12','2025-07-13 08:27:12',NULL,'2c90d339-319f-41d1-96cf-1c889863fef2'),(6,'Call to Action','ctaButtons','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"Add New Button\",\"defaultIndexViewMode\":\"cards\",\"enableVersioning\":false,\"entryTypes\":[{\"uid\":\"13030367-75b1-4224-9106-d1244c54cc43\",\"group\":\"General\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":true,\"viewMode\":\"cards\"}','2025-07-13 08:54:58','2025-07-13 09:09:30',NULL,'ad06897a-3f68-4e59-8dd8-6a551c070e88');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_keeoaivzpohfnhasxxnfbmlkbastsjyfvyfu` (`name`),
  KEY `idx_ndpajeytpmwkhraubninnahkagitkhmxucld` (`handle`),
  KEY `idx_caeyepwffxyjnzozxskmuyefrmmwqyvwluys` (`fieldLayoutId`),
  KEY `idx_ksnpfincrsymmgzcjzupfcomhqsvgyqpnbpy` (`sortOrder`),
  CONSTRAINT `fk_mkjrckvkoruzbkbrtlkoyjizkwwyroiqwieh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wbaypebnyclzfxlvmfjrslerpcpepmcllbxo` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2025-07-12 16:49:17','2025-07-12 16:49:17','d2ea8d0a-88c0-4325-9a19-ed218689f061');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ddcjmllwnljkjdqtkvvpodrogumohkghikww` (`accessToken`),
  UNIQUE KEY `idx_wstdlqpxtsahhzkyoymvmzllkhziaunbkynz` (`name`),
  KEY `fk_vflwgombncjuhddmatxfxkqkngsksyipqxxb` (`schemaId`),
  CONSTRAINT `fk_vflwgombncjuhddmatxfxkqkngsksyipqxxb` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_puwitdnblatnjvofnvdkxtiysasrnhshsxnr` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
INSERT INTO `imagetransformindex` VALUES (1,69,'craft\\imagetransforms\\ImageTransformer','testimonial.jpg',NULL,'_30x30_crop_center-center_none',1,0,0,'2025-07-13 10:01:34','2025-07-13 10:01:34','2025-07-13 10:01:37','32067efe-d745-454f-8d61-f8a99f4a2715'),(2,69,'craft\\imagetransforms\\ImageTransformer','testimonial.jpg',NULL,'_60x60_crop_center-center_none',1,0,0,'2025-07-13 10:01:34','2025-07-13 10:01:34','2025-07-13 10:01:34','11a1b487-afec-4523-8983-39ea5603a6ed'),(3,76,'craft\\imagetransforms\\ImageTransformer','plamen.webp',NULL,'_22x30_crop_center-center_none',1,0,0,'2025-07-13 10:04:44','2025-07-13 10:04:44','2025-07-13 10:04:47','80412c04-9257-4bab-acda-eaef740e4767'),(4,76,'craft\\imagetransforms\\ImageTransformer','plamen.webp',NULL,'_45x60_crop_center-center_none',1,0,0,'2025-07-13 10:04:44','2025-07-13 10:04:44','2025-07-13 10:04:44','e72a197f-bc37-4342-be7f-c7db62d2d08c'),(5,77,'craft\\imagetransforms\\ImageTransformer','laservision.png',NULL,'_30x15_crop_center-center_none',1,0,0,'2025-07-13 10:04:47','2025-07-13 10:04:47','2025-07-13 10:04:47','f998aeaf-b86e-4fa0-b6e7-42bde836b88d'),(6,77,'craft\\imagetransforms\\ImageTransformer','laservision.png',NULL,'_60x30_crop_center-center_none',1,0,0,'2025-07-13 10:04:47','2025-07-13 10:04:47','2025-07-13 10:04:47','1feeed6a-7b74-4341-a0b3-4370a8980e45'),(7,77,'craft\\imagetransforms\\ImageTransformer','laservision.png',NULL,'_350x177_crop_center-center_none',1,0,0,'2025-09-09 16:57:39','2025-09-09 16:57:39','2025-09-09 16:57:40','f8f0f1dc-2b40-4ab6-8335-3ec404274d12'),(8,77,'craft\\imagetransforms\\ImageTransformer','laservision.png',NULL,'_700x354_crop_center-center_none',1,0,0,'2025-09-09 16:57:39','2025-09-09 16:57:39','2025-09-09 16:57:40','1b5dc604-2037-4a9f-93ae-3ba40429a73c');
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zrqmhdzyagtlteefksbnyufegxiqdircilkw` (`name`),
  KEY `idx_xbcwakztvpvddlvxxdhijwtfctvdriisqpoh` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.8.8','5.8.0.3',0,'aiprgpqsebop','3@kdatymaxal','2025-07-10 10:15:15','2025-07-20 21:09:08','f49d3793-6c07-45ac-bddf-a0a72d4af0d7');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bdsbtkdpzvlabhaevslogisasmsmqkksymux` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','8751a252-2dbd-42c4-9755-1773c417a0d0'),(2,'craft','m221101_115859_create_entries_authors_table','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','c6f8f766-5eac-4d22-98a0-593353b1af92'),(3,'craft','m221107_112121_add_max_authors_to_sections','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','3cc60e92-9445-4e8d-a58d-8acabdd0e554'),(4,'craft','m221205_082005_translatable_asset_alt_text','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','4a25816a-baa5-4afd-9d10-c1dc70d75537'),(5,'craft','m230314_110309_add_authenticator_table','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','68eeb799-c0c8-4330-90a0-d4bfbb06a17b'),(6,'craft','m230314_111234_add_webauthn_table','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','4d582857-a3d8-4c8c-8afe-17f5b9ad2474'),(7,'craft','m230503_120303_add_recoverycodes_table','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','b4e107d0-4126-468d-937e-46942a9c9ade'),(8,'craft','m230511_000000_field_layout_configs','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','775231a7-aec8-4fa8-a4eb-73e351104d48'),(9,'craft','m230511_215903_content_refactor','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','06e2d2fa-8277-42bd-a92f-4c5846ca4f13'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','9a277248-8454-48b8-9190-815ac53f4c55'),(11,'craft','m230524_000001_entry_type_icons','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','0e69d2a9-8065-4752-968d-b4cd605723da'),(12,'craft','m230524_000002_entry_type_colors','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','fa405682-e338-4e05-9491-ef692fff7941'),(13,'craft','m230524_220029_global_entry_types','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','28b0ca97-6f0c-47c1-bce7-6f1f36b0914f'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','0145d1d9-c6da-4a20-b658-42ec2e56d1db'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','89bd9fb1-89ba-4af5-acce-a3be5b6a68d1'),(16,'craft','m230616_173810_kill_field_groups','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','93e09aa0-64e3-4a98-9e15-4903bebc7efc'),(17,'craft','m230616_183820_remove_field_name_limit','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','efdbb824-edc6-4bc9-aaf5-352b4daccfa5'),(18,'craft','m230617_070415_entrify_matrix_blocks','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','498c6a5c-8bb6-42fa-a9ba-e38bdd937d73'),(19,'craft','m230710_162700_element_activity','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','20c389cc-2b4d-4648-b755-67b277c9b816'),(20,'craft','m230820_162023_fix_cache_id_type','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','364a1b77-5bb8-4b89-9070-58d6e6762565'),(21,'craft','m230826_094050_fix_session_id_type','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','0425d22c-a583-4bfd-b377-0576f1ac5851'),(22,'craft','m230904_190356_address_fields','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','e582bb28-d1a7-481d-88c5-9164bf8c3b66'),(23,'craft','m230928_144045_add_subpath_to_volumes','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','914d07c4-109c-4b90-b189-dd4b9e0412af'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','4db1749c-f8ee-4f7a-a69a-cbd1b72d65ca'),(25,'craft','m231213_030600_element_bulk_ops','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','89a82bb1-a06e-43c0-b327-59691127cfbf'),(26,'craft','m240129_150719_sites_language_amend_length','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','580886ae-0954-4ffc-afba-a603d9653c33'),(27,'craft','m240206_035135_convert_json_columns','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','e426e106-5ada-49e8-bd12-32ea411b7aa2'),(28,'craft','m240207_182452_address_line_3','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','1a44a86a-fc3f-4ed7-b703-67969c1dfac3'),(29,'craft','m240302_212719_solo_preview_targets','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','050f2411-7e5e-480c-9cce-a94fd53be0d0'),(30,'craft','m240619_091352_add_auth_2fa_timestamp','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','fa691ef4-e098-40fd-9460-39513d7694a4'),(31,'craft','m240723_214330_drop_bulkop_fk','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','570a8bcf-1687-4603-94d6-7abe35d22cbf'),(32,'craft','m240731_053543_soft_delete_fields','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','6fb46c43-c325-4db3-be91-a9e23ae51242'),(33,'craft','m240805_154041_sso_identities','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','bf3a7201-b3c8-4e6f-a3a8-e679ae42928d'),(34,'craft','m240926_202248_track_entries_deleted_with_section','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','eb300e10-fbfe-4430-8317-817476413d9f'),(35,'craft','m241120_190905_user_affiliated_sites','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','ae9ccc80-7927-4a3c-ac47-16bb7857094f'),(36,'craft','m241125_122914_add_viewUsers_permission','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','974ae04e-62c0-4f6d-8293-63a70365b5b7'),(37,'craft','m250119_135304_entry_type_overrides','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','31df711d-11de-4557-8830-8a1e50ecfeb6'),(38,'craft','m250206_135036_search_index_queue','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','29d7ad0e-28dd-46f7-bb86-a65d4e19a6ba'),(39,'craft','m250207_172349_bulkop_events','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','76a68879-913b-4a1c-85d2-4ea4d484024d'),(40,'craft','m250315_131608_unlimited_authors','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','9778b5d6-29a3-4c2f-be2b-259ed20c87fd'),(41,'craft','m250403_171253_static_statuses','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','0c75dc27-0692-41e4-863a-59b2bd1e7ae7'),(42,'craft','m250512_164202_asset_mime_types','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','1c698090-d026-4e9a-822c-78c1278dbbd1'),(43,'craft','m250522_090843_add_deleteEntriesForSite_and_deletePeerEntriesForSite_permissions','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','a5d2b3a6-e810-4fca-ab0e-91a8478b8e58'),(44,'craft','m250531_183058_content_blocks','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','87db42ed-0af1-4ad8-984a-be9754ea868b'),(45,'craft','m250623_105031_entry_type_descriptions','2025-07-10 10:15:15','2025-07-10 10:15:15','2025-07-10 10:15:15','d141bb31-f3ea-45b9-8390-9e9b786bd378'),(46,'plugin:ckeditor','Install','2025-07-10 10:24:56','2025-07-10 10:24:56','2025-07-10 10:24:56','e7934fe8-c68c-4802-b374-2637b7874536'),(47,'plugin:ckeditor','m230408_163704_v3_upgrade','2025-07-10 10:24:56','2025-07-10 10:24:56','2025-07-10 10:24:56','4e1b5d1d-c7b7-420d-b869-7fd624f94eaa'),(48,'plugin:navigation','Install','2025-07-10 13:37:15','2025-07-10 13:37:15','2025-07-10 13:37:15','e5e06293-abbd-45cc-8cb1-91208fdc38fa'),(49,'plugin:navigation','m231229_000000_content_refactor','2025-07-10 13:37:15','2025-07-10 13:37:15','2025-07-10 13:37:15','a0c079c8-e56c-4260-8cb0-8f461ac3eb0c');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_navs`
--

DROP TABLE IF EXISTS `navigation_navs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_navs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `instructions` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `maxNodes` int DEFAULT NULL,
  `maxNodesSettings` text,
  `permissions` text,
  `fieldLayoutId` int DEFAULT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_chansenesnwfbxthxznyaakwgbagqxnpuswh` (`handle`),
  KEY `idx_gftnngmqrhvyduououaskcdroaxwgwzspfvx` (`structureId`),
  KEY `idx_rlqcruoohzlgeloqwggmgnbecahnuoevhotq` (`fieldLayoutId`),
  KEY `idx_miwabyhkwntrckqbwevxhcsntqognrjnxqxi` (`dateDeleted`),
  CONSTRAINT `fk_bnlvqgxqewiqfvdpjvczbpouvgcklciuukbl` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rxewtwkmyknkbruzbuaysjsemurlkrjemlrt` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_navs`
--

LOCK TABLES `navigation_navs` WRITE;
/*!40000 ALTER TABLE `navigation_navs` DISABLE KEYS */;
INSERT INTO `navigation_navs` VALUES (1,1,'Main Nav','mainNav','',1,'all',NULL,'[]','{\"craft\\\\elements\\\\Asset\":{\"enabled\":\"\",\"permissions\":\"*\"},\"craft\\\\elements\\\\Category\":{\"enabled\":\"\",\"permissions\":\"*\"},\"craft\\\\elements\\\\Entry\":{\"enabled\":\"1\",\"permissions\":\"*\"},\"craft\\\\elements\\\\Tag\":{\"enabled\":\"\",\"permissions\":\"*\"},\"verbb\\\\navigation\\\\nodetypes\\\\CustomType\":{\"enabled\":\"1\"},\"verbb\\\\navigation\\\\nodetypes\\\\PassiveType\":{\"enabled\":\"1\"}}',2,'end','2025-07-10 17:15:03','2025-07-10 17:53:30',NULL,'e7bfc324-8b18-4281-b77b-666ba9db6ce2'),(2,2,'Footer Nav','footerNav','',2,'all',NULL,'[]','{\"craft\\\\elements\\\\Asset\":{\"enabled\":\"\",\"permissions\":\"*\"},\"craft\\\\elements\\\\Category\":{\"enabled\":\"\",\"permissions\":\"*\"},\"craft\\\\elements\\\\Entry\":{\"enabled\":\"1\",\"permissions\":\"*\"},\"craft\\\\elements\\\\Tag\":{\"enabled\":\"\",\"permissions\":\"*\"},\"verbb\\\\navigation\\\\nodetypes\\\\CustomType\":{\"enabled\":\"1\"},\"verbb\\\\navigation\\\\nodetypes\\\\PassiveType\":{\"enabled\":\"1\"}}',3,'end','2025-07-10 17:15:23','2025-07-10 17:50:00',NULL,'852d5794-44c6-4ccc-becc-23c13c551f67');
/*!40000 ALTER TABLE `navigation_navs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_navs_sites`
--

DROP TABLE IF EXISTS `navigation_navs_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_navs_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `navId` int NOT NULL,
  `siteId` int NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yqlmhectwnilcghzjtlzlyyulauwjregvyeq` (`navId`,`siteId`),
  KEY `idx_rdtboaiyuzaahvevlxrwbmtjslsyliyrwyfp` (`siteId`),
  CONSTRAINT `fk_hihfsnhvymievkzutubbplkxsfhjjiprnvxm` FOREIGN KEY (`navId`) REFERENCES `navigation_navs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vwelmmddlgbxhzpogddmlnhrpnyrairetafk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_navs_sites`
--

LOCK TABLES `navigation_navs_sites` WRITE;
/*!40000 ALTER TABLE `navigation_navs_sites` DISABLE KEYS */;
INSERT INTO `navigation_navs_sites` VALUES (1,1,1,1,'2025-07-10 17:15:03','2025-07-10 17:15:03','c07e2424-bed6-4220-a2fd-2fe7282f8fa4'),(2,2,1,1,'2025-07-10 17:15:23','2025-07-10 17:15:23','07ba9949-4258-4bd9-bfa3-822cd612a203');
/*!40000 ALTER TABLE `navigation_navs_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_nodes`
--

DROP TABLE IF EXISTS `navigation_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_nodes` (
  `id` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `navId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `classes` varchar(255) DEFAULT NULL,
  `urlSuffix` varchar(255) DEFAULT NULL,
  `customAttributes` text,
  `data` text,
  `newWindow` tinyint(1) DEFAULT '0',
  `deletedWithNav` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qyndzmpbupazddezarusaqdolfjuuegfistx` (`navId`),
  KEY `fk_jpzycqdyvnmigkkwhcmmqoghdyqkxcqzizkz` (`elementId`),
  CONSTRAINT `fk_jpzycqdyvnmigkkwhcmmqoghdyqkxcqzizkz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_txnqurowjfhcfzunshnvmxkhwxxgriymzdqy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zbqgymtfibciytlabfzdfoolrhlixisxeapn` FOREIGN KEY (`navId`) REFERENCES `navigation_navs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_nodes`
--

LOCK TABLES `navigation_nodes` WRITE;
/*!40000 ALTER TABLE `navigation_nodes` DISABLE KEYS */;
INSERT INTO `navigation_nodes` VALUES (4,2,1,NULL,NULL,'craft\\elements\\Entry',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:16:03','2025-07-10 17:16:03','7fcfa060-e8aa-43d6-a04a-07521245d6f8'),(6,NULL,1,NULL,'/about','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:17:24','2025-07-21 11:51:02','51b7b764-0bee-46c7-a9c0-2bb41e48a0ea'),(7,NULL,1,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:17:34','2025-07-10 17:17:34','626f625b-7800-4d16-8bee-8d0ad2a05f96'),(8,NULL,1,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:17:43','2025-07-10 17:17:43','db87b52b-8ea1-4faf-a165-3d4fee3cd61e'),(9,2,2,NULL,NULL,'craft\\elements\\Entry',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:18:21','2025-07-10 17:18:21','86641f59-c4d2-4a63-87b1-2d65092c9570'),(10,NULL,2,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:18:32','2025-07-10 17:18:32','2682661f-c5c9-4620-9c39-8f7e9e2cdd83'),(11,NULL,2,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:18:54','2025-07-10 17:18:54','1d697c30-c18b-4ddf-9935-080e9236f990'),(12,NULL,2,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:18:57','2025-07-10 17:18:57','57c50cc7-9eda-40d5-8ccc-ff8123ae61bb'),(13,NULL,2,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:19:05','2025-07-10 17:19:05','79903e33-eb2b-49ec-8ef4-b6b41fef96b3'),(14,NULL,2,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:19:17','2025-07-10 17:19:17','6f62415e-27b5-4305-97d7-4b5a6635f754'),(15,NULL,2,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:19:24','2025-07-10 17:19:24','1b2144da-65ce-49f4-a1e9-02b2e930a02f'),(16,NULL,2,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:19:31','2025-07-10 17:19:31','a7acdd44-f470-4841-ae42-1b3a12f52521'),(17,NULL,2,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:19:36','2025-07-10 17:19:36','f13c8806-dc9e-40ff-a0f2-7a8d102e3718'),(20,NULL,1,NULL,'#bookfreecall','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:28:08','2025-07-10 17:38:18','138f6634-6368-406a-a292-ca914c1523a6'),(24,NULL,1,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:54:29','2025-07-10 17:54:29','ce9c1bac-f4e7-4b7a-8b29-a58a05acb813'),(25,NULL,1,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:54:37','2025-07-10 17:54:37','7ff2310c-0a89-47f1-a732-bf273982cb62'),(26,NULL,1,NULL,'#','verbb\\navigation\\nodetypes\\CustomType',NULL,NULL,'[]','[]',0,NULL,'2025-07-10 17:54:45','2025-07-10 17:54:45','62da0c33-38d3-4bed-bd33-1da5d4ef3221');
/*!40000 ALTER TABLE `navigation_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mbphrsgvtcesgttdwrmyxqqhwkfletruwyav` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'minify','5.0.0','1.0.0','2025-07-10 10:24:33','2025-07-10 10:24:33','2025-07-10 10:24:33','e204d013-9104-4ffd-ae24-3c88855f381f'),(2,'ckeditor','4.9.0','3.0.0.0','2025-07-10 10:24:56','2025-07-10 10:24:56','2025-07-10 10:24:56','c34b7d1e-0b9b-4f34-b61d-da56a34d7d4b'),(3,'blocksmith','1.6.9','1.1.4','2025-07-10 10:25:50','2025-07-10 10:25:50','2025-07-20 21:09:09','f776787a-ddf5-4e0b-acc2-ca85c5bac7dd'),(4,'vite','5.0.1','1.0.0','2025-07-10 11:46:43','2025-07-10 11:46:43','2025-07-10 11:46:43','e16b25e9-7021-4d89-9db3-2e4760e4b2af'),(5,'navigation','3.0.10','2.1.0','2025-07-10 13:37:14','2025-07-10 13:37:14','2025-07-20 21:09:09','aad9aca2-b52a-438c-af1c-f487baa78022');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('blocksmith.blocksmithMatrixFields.ad06897a-3f68-4e59-8dd8-6a551c070e88.enablePreview','true'),('blocksmith.blocksmithMatrixFields.ad06897a-3f68-4e59-8dd8-6a551c070e88.fieldHandle','\"ctaButtons\"'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.headingLevels.0','1'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.headingLevels.1','2'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.headingLevels.2','3'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.headingLevels.3','4'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.headingLevels.4','5'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.headingLevels.5','6'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.name','\"Simple\"'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.toolbar.0','\"heading\"'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.toolbar.1','\"|\"'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.toolbar.2','\"bold\"'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.toolbar.3','\"italic\"'),('ckeditor.configs.46639d9c-2fb8-477e-85aa-2910d7e89d87.toolbar.4','\"link\"'),('dateModified','1752398064'),('email.fromEmail','\"lubo.jordanov@gmail.com\"'),('email.fromName','\"Fine Digital\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.color','\"lime\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.description','\"Call to Action Buttons\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.cardThumbAlignment','\"end\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elementCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.autocapitalize','true'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.autocomplete','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.autocorrect','true'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.class','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.dateAdded','\"2025-07-13T08:41:00+00:00\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.disabled','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.elementCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.id','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.includeInCards','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.inputType','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.instructions','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.label','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.max','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.min','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.name','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.orientation','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.placeholder','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.providesThumbs','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.readonly','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.required','true'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.size','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.step','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.tip','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.title','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.uid','\"03b7685d-73fa-4b4f-a609-d5992cfc7439\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.userCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.warning','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.0.width','100'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.dateAdded','\"2025-07-13T08:43:19+00:00\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.editCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.elementCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.fieldUid','\"a580fa9f-fec5-4030-9ec4-056fa41939f4\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.handle','\"linkText\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.includeInCards','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.instructions','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.label','\"Link text\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.providesThumbs','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.required','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.tip','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.uid','\"76a53286-b93a-4b66-9d77-ddb2969e8c68\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.userCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.warning','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.1.width','100'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.dateAdded','\"2025-07-13T08:43:19+00:00\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.editCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.elementCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.fieldUid','\"2c90d339-319f-41d1-96cf-1c889863fef2\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.handle','\"urlAddress\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.includeInCards','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.instructions','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.label','\"URL Address\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.providesThumbs','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.required','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.tip','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.uid','\"a86d2f56-503c-484d-b4f7-1696b74f75f5\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.userCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.warning','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.2.width','100'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.dateAdded','\"2025-07-13T08:43:19+00:00\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.editCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.elementCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.fieldUid','\"bb28314d-a061-45be-bebf-8b0a6076b3d0\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.handle','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.includeInCards','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.instructions','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.label','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.providesThumbs','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.required','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.tip','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.uid','\"49bc446c-2f5a-4b23-aa14-dd181cc323fa\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.userCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.warning','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.elements.3.width','100'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.name','\"Content\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.uid','\"4ef4da52-7b07-41d3-954d-69824cbcd2f3\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.fieldLayouts.284fee46-1054-4234-8001-ff87c807d25e.tabs.0.userCondition','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.handle','\"callToAction\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.hasTitleField','true'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.icon','\"link\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.name','\"Call to Action\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.showSlugField','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.showStatusField','false'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.slugTranslationKeyFormat','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.slugTranslationMethod','\"site\"'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.titleFormat','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.titleTranslationKeyFormat','null'),('entryTypes.13030367-75b1-4224-9106-d1244c54cc43.titleTranslationMethod','\"site\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.color','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.description','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.cardThumbAlignment','\"end\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elementCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.autocapitalize','true'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.autocomplete','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.autocorrect','true'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.class','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.dateAdded','\"2025-07-10T13:33:21+00:00\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.disabled','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.elementCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.id','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.includeInCards','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.inputType','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.instructions','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.label','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.max','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.min','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.name','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.orientation','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.placeholder','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.providesThumbs','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.readonly','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.required','true'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.size','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.step','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.tip','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.title','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.uid','\"16fb0f7f-a335-47b0-a9ca-a3d233a767f4\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.userCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.warning','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.0.width','100'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.dateAdded','\"2025-07-12T14:31:17+00:00\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.editCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.elementCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.fieldUid','\"a580fa9f-fec5-4030-9ec4-056fa41939f4\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.handle','\"headlineLineOne\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.includeInCards','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.instructions','\"The first line from the headline of the homepage\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.label','\"Headline\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.providesThumbs','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.required','true'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.tip','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.uid','\"a6adc52c-67b8-4596-9603-06a83b9fab8f\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.userCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.warning','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.1.width','100'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.dateAdded','\"2025-07-12T14:31:17+00:00\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.editCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.elementCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.fieldUid','\"a580fa9f-fec5-4030-9ec4-056fa41939f4\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.handle','\"headlineLineTwo\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.includeInCards','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.instructions','\"Line two of the headline of the homepage (the gradient animation part)\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.label','\"Headline Line Two\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.providesThumbs','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.required','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.tip','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.uid','\"f8e43b78-6014-43e5-8899-804e2e660fbf\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.userCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.warning','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.2.width','100'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.dateAdded','\"2025-07-13T07:56:45+00:00\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.editCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.elementCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.fieldUid','\"33dabbd5-4d93-4868-bee3-62998def8ddc\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.handle','\"heroDescription\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.includeInCards','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.instructions','\"Appears under the hero image headline.\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.label','\"Hero description\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.providesThumbs','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.required','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.tip','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.uid','\"1337744c-dd1f-4322-b151-d80f7bb95060\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.userCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.warning','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.3.width','100'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.dateAdded','\"2025-07-12T14:31:17+00:00\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.editCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.elementCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.fieldUid','\"3d54c233-d443-46e3-8ec7-850ab1c9d69a\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.handle','\"heroVideo\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.includeInCards','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.instructions','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.label','\"Video\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.providesThumbs','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.required','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.tip','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.uid','\"4326a0e4-0443-499b-a957-73bf4ee9affe\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.userCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.warning','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.4.width','100'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.dateAdded','\"2025-07-13T08:57:13+00:00\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.editCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.elementCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.fieldUid','\"ad06897a-3f68-4e59-8dd8-6a551c070e88\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.handle','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.includeInCards','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.instructions','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.label','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.providesThumbs','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.required','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.tip','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.uid','\"4ef01fcf-9e33-4ea1-a290-db41df6fefa8\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.userCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.warning','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.elements.5.width','100'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.name','\"Content\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.uid','\"8a1ca38c-100e-4b55-b294-6d95ddbd5182\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.fieldLayouts.2b244306-a1c5-4527-8693-1185df6923d2.tabs.0.userCondition','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.handle','\"homepage\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.hasTitleField','true'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.icon','\"house\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.name','\"Homepage\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.showSlugField','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.showStatusField','false'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.slugTranslationKeyFormat','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.slugTranslationMethod','\"site\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.titleFormat','\"{headline}\"'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.titleTranslationKeyFormat','null'),('entryTypes.f1c7e864-914a-44b3-8480-1a3fc4f46b09.titleTranslationMethod','\"site\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.columnSuffix','null'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.handle','\"buttonUrl\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.instructions','null'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.name','\"URL\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.searchable','false'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.advancedFields.0','\"target\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.advancedFields.1','\"title\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.fullGraphqlData','true'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.maxLength','255'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.showLabelField','false'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.types.0','\"entry\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.types.1','\"url\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.0.0','\"entry\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.0.1.__assoc__.0.0','\"sources\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.0.1.__assoc__.0.1','\"*\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.0.1.__assoc__.1.0','\"showUnpermittedSections\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.0.1.__assoc__.1.1','\"\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.0.1.__assoc__.2.0','\"showUnpermittedEntries\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.0.1.__assoc__.2.1','\"\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.1.0','\"url\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.1.1.__assoc__.0.0','\"allowRootRelativeUrls\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.1.1.__assoc__.0.1','\"1\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.1.1.__assoc__.1.0','\"allowAnchors\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.1.1.__assoc__.1.1','\"1\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.1.1.__assoc__.2.0','\"allowCustomSchemes\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.settings.typeSettings.__assoc__.1.1.__assoc__.2.1','\"\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.translationKeyFormat','null'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.translationMethod','\"none\"'),('fields.2c90d339-319f-41d1-96cf-1c889863fef2.type','\"craft\\\\fields\\\\Link\"'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.columnSuffix','null'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.handle','\"textArea\"'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.instructions','null'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.name','\"Text Area\"'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.searchable','false'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.settings.byteLimit','null'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.settings.charLimit','null'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.settings.code','false'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.settings.initialRows','4'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.settings.multiline','true'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.settings.placeholder','null'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.settings.uiMode','\"normal\"'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.translationKeyFormat','null'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.translationMethod','\"none\"'),('fields.33dabbd5-4d93-4868-bee3-62998def8ddc.type','\"craft\\\\fields\\\\PlainText\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.columnSuffix','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.handle','\"image\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.instructions','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.name','\"Image\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.searchable','false'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.allowedKinds.0','\"audio\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.allowedKinds.1','\"image\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.allowedKinds.2','\"pdf\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.allowedKinds.3','\"video\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.allowSelfRelations','false'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.allowSubfolders','false'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.allowUploads','true'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.branchLimit','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.defaultPlacement','\"end\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.defaultUploadLocationSource','\"volume:de4e6ba3-84ff-4825-9f58-5cb381127cac\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.defaultUploadLocationSubpath','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.maintainHierarchy','false'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.maxRelations','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.minRelations','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.previewMode','\"full\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.restrictedDefaultUploadSubpath','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.restrictedLocationSource','\"volume:de4e6ba3-84ff-4825-9f58-5cb381127cac\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.restrictedLocationSubpath','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.restrictFiles','true'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.restrictLocation','false'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.selectionLabel','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.showCardsInGrid','false'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.showSearchInput','true'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.showSiteMenu','true'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.showUnpermittedFiles','false'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.showUnpermittedVolumes','false'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.sources.0','\"volume:de4e6ba3-84ff-4825-9f58-5cb381127cac\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.targetSiteId','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.validateRelatedElements','false'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.settings.viewMode','\"list\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.translationKeyFormat','null'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.translationMethod','\"none\"'),('fields.3d54c233-d443-46e3-8ec7-850ab1c9d69a.type','\"craft\\\\fields\\\\Assets\"'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.columnSuffix','null'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.handle','\"plainText\"'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.instructions','null'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.name','\"Plain Text \"'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.searchable','false'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.settings.byteLimit','null'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.settings.charLimit','null'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.settings.code','false'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.settings.initialRows','4'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.settings.multiline','false'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.settings.placeholder','null'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.settings.uiMode','\"normal\"'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.translationKeyFormat','null'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.translationMethod','\"none\"'),('fields.a580fa9f-fec5-4030-9ec4-056fa41939f4.type','\"craft\\\\fields\\\\PlainText\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.columnSuffix','null'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.handle','\"ctaButtons\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.instructions','null'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.name','\"Call to Action\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.searchable','false'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.createButtonLabel','\"Add New Button\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.defaultIndexViewMode','\"cards\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.enableVersioning','false'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.entryTypes.0.__assoc__.0.0','\"uid\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.entryTypes.0.__assoc__.0.1','\"13030367-75b1-4224-9106-d1244c54cc43\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.entryTypes.0.__assoc__.1.0','\"group\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.entryTypes.0.__assoc__.1.1','\"General\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.includeTableView','false'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.maxEntries','null'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.minEntries','null'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.pageSize','50'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.propagationKeyFormat','null'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.propagationMethod','\"all\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.showCardsInGrid','true'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.settings.viewMode','\"cards\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.translationKeyFormat','null'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.translationMethod','\"site\"'),('fields.ad06897a-3f68-4e59-8dd8-6a551c070e88.type','\"craft\\\\fields\\\\Matrix\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.columnSuffix','null'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.handle','\"buttonType\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.instructions','null'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.name','\"Button Type\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.searchable','false'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.customOptions','false'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.0.0','\"label\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.0.1','\"Normal Link\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.1.0','\"value\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.1.1','\"normal\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.2.0','\"icon\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.2.1','\"\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.3.0','\"color\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.3.1','\"\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.4.0','\"default\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.0.__assoc__.4.1','\"1\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.0.0','\"label\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.0.1','\"Call To Action\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.1.0','\"value\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.1.1','\"cta\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.2.0','\"icon\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.2.1','\"\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.3.0','\"color\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.3.1','\"\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.4.0','\"default\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.1.__assoc__.4.1','\"\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.0.0','\"label\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.0.1','\"Call To Action Alt\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.1.0','\"value\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.1.1','\"ctaAlt\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.2.0','\"icon\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.2.1','\"\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.3.0','\"color\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.3.1','\"\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.4.0','\"default\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.settings.options.2.__assoc__.4.1','\"\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.translationKeyFormat','null'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.translationMethod','\"none\"'),('fields.bb28314d-a061-45be-bebf-8b0a6076b3d0.type','\"craft\\\\fields\\\\Dropdown\"'),('fs.images.hasUrls','true'),('fs.images.name','\"Images\"'),('fs.images.settings.path','\"@webroot/assets/images\"'),('fs.images.type','\"craft\\\\fs\\\\Local\"'),('fs.images.url','\"$PRIMARY_SITE_URL/assets/images\"'),('graphql.schemas.d2ea8d0a-88c0-4325-9a19-ed218689f061.isPublic','true'),('graphql.schemas.d2ea8d0a-88c0-4325-9a19-ed218689f061.name','\"Public Schema\"'),('meta.__names__.13030367-75b1-4224-9106-d1244c54cc43','\"Call to Action\"'),('meta.__names__.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3','\"Homepage\"'),('meta.__names__.2c90d339-319f-41d1-96cf-1c889863fef2','\"URL\"'),('meta.__names__.33dabbd5-4d93-4868-bee3-62998def8ddc','\"Text Area\"'),('meta.__names__.3d54c233-d443-46e3-8ec7-850ab1c9d69a','\"Image\"'),('meta.__names__.46639d9c-2fb8-477e-85aa-2910d7e89d87','\"Simple\"'),('meta.__names__.6a3879bd-c2fc-4069-a70f-3720e125a496','\"Fine Digital\"'),('meta.__names__.852d5794-44c6-4ccc-becc-23c13c551f67','\"Footer Nav\"'),('meta.__names__.a580fa9f-fec5-4030-9ec4-056fa41939f4','\"Plain Text \"'),('meta.__names__.ad06897a-3f68-4e59-8dd8-6a551c070e88','\"Call to Action\"'),('meta.__names__.bb28314d-a061-45be-bebf-8b0a6076b3d0','\"Button Type\"'),('meta.__names__.d2ea8d0a-88c0-4325-9a19-ed218689f061','\"Public Schema\"'),('meta.__names__.de4e6ba3-84ff-4825-9f58-5cb381127cac','\"Images\"'),('meta.__names__.e7bfc324-8b18-4281-b77b-666ba9db6ce2','\"Main Nav\"'),('meta.__names__.ea9e13a0-c734-466e-b4da-e96997d32dbf','\"Fine Digital\"'),('meta.__names__.f1c7e864-914a-44b3-8480-1a3fc4f46b09','\"Homepage\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.defaultPlacement','\"end\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.cardThumbAlignment','\"end\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elementCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.autocapitalize','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.autocomplete','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.autocorrect','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.class','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.dateAdded','\"2025-07-10T17:14:08+00:00\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.disabled','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.elementCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.id','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.includeInCards','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.inputType','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.instructions','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.label','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.max','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.min','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.name','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.orientation','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.placeholder','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.providesThumbs','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.readonly','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.requirable','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.size','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.step','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.tip','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.title','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.uid','\"46d2bcf4-65b7-4fc5-b517-902421162166\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.userCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.warning','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.0.width','100'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.dateAdded','\"2025-07-10T17:14:08+00:00\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.elementCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.includeInCards','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.instructions','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.label','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.providesThumbs','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.required','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.tip','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\NodeTypeElements\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.uid','\"a01d152b-5ed3-4806-825c-7559f59a6d5a\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.userCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.1.warning','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.attribute','\"newWindow\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.dateAdded','\"2025-07-10T17:14:08+00:00\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.elementCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.id','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.includeInCards','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.instructions','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.label','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.mandatory','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.orientation','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.providesThumbs','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.requirable','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.required','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.tip','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.translatable','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\NewWindowField\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.uid','\"12d751f8-1c86-45f0-812a-80c707b6e4f2\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.userCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.warning','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.elements.2.width','100'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.name','\"Node\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.uid','\"1bef4cca-01de-4f2b-9409-64aa3ab93cc7\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.0.userCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elementCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.attribute','\"urlSuffix\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.autocapitalize','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.autocomplete','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.autocorrect','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.autofocus','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.class','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.dateAdded','\"2025-07-10T17:14:08+00:00\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.disabled','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.elementCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.id','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.includeInCards','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.inputType','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.instructions','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.label','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.mandatory','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.max','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.maxlength','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.min','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.name','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.orientation','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.placeholder','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.providesThumbs','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.readonly','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.requirable','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.required','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.size','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.step','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.tip','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.title','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.translatable','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\UrlSuffixField\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.uid','\"ac6cb88b-2342-4501-9ad1-9a209690032d\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.userCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.warning','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.0.width','100'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.attribute','\"classes\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.autocapitalize','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.autocomplete','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.autocorrect','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.autofocus','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.class','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.dateAdded','\"2025-07-10T17:14:08+00:00\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.disabled','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.elementCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.id','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.includeInCards','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.inputType','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.instructions','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.label','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.mandatory','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.max','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.maxlength','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.min','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.name','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.orientation','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.placeholder','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.providesThumbs','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.readonly','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.requirable','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.required','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.size','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.step','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.tip','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.title','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.translatable','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\ClassesField\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.uid','\"847f4af5-3ee7-4516-8165-e43060083798\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.userCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.warning','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.1.width','100'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.attribute','\"customAttributes\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.dateAdded','\"2025-07-10T17:14:08+00:00\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.elementCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.id','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.includeInCards','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.instructions','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.label','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.mandatory','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.orientation','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.providesThumbs','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.requirable','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.required','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.tip','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.translatable','false'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\CustomAttributesField\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.uid','\"d8f8cde9-cbf9-44b0-a7d8-eac50247ae3e\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.userCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.warning','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.elements.2.width','100'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.name','\"Advanced\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.uid','\"f8930ef4-6989-44df-ae7b-222528606421\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.fieldLayouts.b71d9df7-fd0b-425b-88ec-c4c8ca9084ba.tabs.1.userCondition','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.handle','\"footerNav\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.instructions','\"\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.maxNodes','null'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.name','\"Footer Nav\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.craft\\elements\\Asset.enabled','\"\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.craft\\elements\\Asset.permissions','\"*\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.craft\\elements\\Category.enabled','\"\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.craft\\elements\\Category.permissions','\"*\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.craft\\elements\\Entry.enabled','\"1\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.craft\\elements\\Entry.permissions','\"*\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.craft\\elements\\Tag.enabled','\"\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.craft\\elements\\Tag.permissions','\"*\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.verbb\\navigation\\nodetypes\\CustomType.enabled','\"1\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.permissions.verbb\\navigation\\nodetypes\\PassiveType.enabled','\"1\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.propagationMethod','\"all\"'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.siteSettings.6a3879bd-c2fc-4069-a70f-3720e125a496.enabled','true'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.sortOrder','2'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.structure.maxLevels','1'),('navigation.navs.852d5794-44c6-4ccc-becc-23c13c551f67.structure.uid','\"3b54b595-cdc3-4a78-b15e-46b02e60933e\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.defaultPlacement','\"end\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.cardThumbAlignment','\"end\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elementCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.autocapitalize','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.autocomplete','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.autocorrect','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.class','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.dateAdded','\"2025-07-10T17:13:17+00:00\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.disabled','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.elementCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.id','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.includeInCards','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.inputType','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.instructions','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.label','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.max','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.min','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.name','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.orientation','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.placeholder','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.providesThumbs','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.readonly','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.requirable','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.size','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.step','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.tip','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.title','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.uid','\"c91ae732-4c04-40f1-a70e-5be0680739f2\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.userCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.warning','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.0.width','100'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.dateAdded','\"2025-07-10T17:13:17+00:00\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.elementCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.includeInCards','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.instructions','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.label','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.providesThumbs','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.required','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.tip','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\NodeTypeElements\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.uid','\"60e6d0f8-f834-4798-8604-a16dc1196b2c\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.userCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.1.warning','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.attribute','\"newWindow\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.dateAdded','\"2025-07-10T17:13:17+00:00\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.elementCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.id','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.includeInCards','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.instructions','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.label','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.mandatory','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.orientation','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.providesThumbs','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.requirable','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.required','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.tip','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.translatable','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\NewWindowField\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.uid','\"19c1e650-e191-4d35-9b66-59533f919814\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.userCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.warning','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.2.width','100'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.dateAdded','\"2025-07-10T17:37:40+00:00\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.editCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.elementCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.fieldUid','\"bb28314d-a061-45be-bebf-8b0a6076b3d0\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.handle','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.includeInCards','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.instructions','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.label','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.providesThumbs','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.required','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.tip','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.uid','\"0460f28c-5013-4ec1-8957-e06e42d43cb7\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.userCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.warning','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.elements.3.width','100'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.name','\"Node\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.uid','\"43dbf10f-53e4-45be-9fc4-9b46843d2e85\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.0.userCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elementCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.attribute','\"urlSuffix\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.autocapitalize','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.autocomplete','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.autocorrect','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.autofocus','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.class','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.dateAdded','\"2025-07-10T17:13:17+00:00\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.disabled','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.elementCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.id','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.includeInCards','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.inputType','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.instructions','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.label','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.mandatory','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.max','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.maxlength','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.min','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.name','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.orientation','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.placeholder','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.providesThumbs','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.readonly','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.requirable','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.required','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.size','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.step','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.tip','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.title','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.translatable','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\UrlSuffixField\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.uid','\"0d181fc2-89b5-4a93-aeb9-c9df421b75c0\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.userCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.warning','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.0.width','100'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.attribute','\"classes\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.autocapitalize','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.autocomplete','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.autocorrect','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.autofocus','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.class','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.dateAdded','\"2025-07-10T17:13:17+00:00\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.disabled','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.elementCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.id','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.includeInCards','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.inputType','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.instructions','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.label','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.mandatory','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.max','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.maxlength','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.min','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.name','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.orientation','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.placeholder','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.providesThumbs','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.readonly','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.requirable','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.required','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.size','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.step','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.tip','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.title','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.translatable','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\ClassesField\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.uid','\"8dba8be7-a202-4b38-8df3-a00a2b4e5c14\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.userCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.warning','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.1.width','100'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.attribute','\"customAttributes\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.dateAdded','\"2025-07-10T17:13:17+00:00\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.elementCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.id','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.includeInCards','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.instructions','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.label','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.mandatory','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.orientation','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.providesThumbs','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.requirable','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.required','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.tip','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.translatable','false'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.type','\"verbb\\\\navigation\\\\fieldlayoutelements\\\\CustomAttributesField\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.uid','\"0118fb20-af3d-437e-aa4f-372e7e406b71\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.userCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.warning','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.elements.2.width','100'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.name','\"Advanced\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.uid','\"384552db-74e3-43e5-b7d0-9a640bd9cd13\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.fieldLayouts.b379fee8-82f5-455e-89ec-c085a37e63cd.tabs.1.userCondition','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.handle','\"mainNav\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.instructions','\"\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.maxNodes','null'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.name','\"Main Nav\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.craft\\elements\\Asset.enabled','\"\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.craft\\elements\\Asset.permissions','\"*\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.craft\\elements\\Category.enabled','\"\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.craft\\elements\\Category.permissions','\"*\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.craft\\elements\\Entry.enabled','\"1\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.craft\\elements\\Entry.permissions','\"*\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.craft\\elements\\Tag.enabled','\"\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.craft\\elements\\Tag.permissions','\"*\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.verbb\\navigation\\nodetypes\\CustomType.enabled','\"1\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.permissions.verbb\\navigation\\nodetypes\\PassiveType.enabled','\"1\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.propagationMethod','\"all\"'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.siteSettings.6a3879bd-c2fc-4069-a70f-3720e125a496.enabled','true'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.sortOrder','1'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.structure.maxLevels','2'),('navigation.navs.e7bfc324-8b18-4281-b77b-666ba9db6ce2.structure.uid','\"a5ab0b85-d6ee-4cdd-ad87-b2f47a1a0bae\"'),('plugins.blocksmith.edition','\"lite\"'),('plugins.blocksmith.enabled','true'),('plugins.blocksmith.schemaVersion','\"1.1.4\"'),('plugins.blocksmith.settings.enableCardsSupport','true'),('plugins.blocksmith.settings.previewImageSubfolder','null'),('plugins.blocksmith.settings.previewImageVolume','null'),('plugins.blocksmith.settings.previewStorageMode','null'),('plugins.blocksmith.settings.useEntryTypeGroups','false'),('plugins.blocksmith.settings.useHandleBasedPreviews','false'),('plugins.blocksmith.settings.wideViewFourBlocks','false'),('plugins.ckeditor.edition','\"standard\"'),('plugins.ckeditor.enabled','true'),('plugins.ckeditor.schemaVersion','\"3.0.0.0\"'),('plugins.minify.edition','\"standard\"'),('plugins.minify.enabled','true'),('plugins.minify.schemaVersion','\"1.0.0\"'),('plugins.navigation.edition','\"standard\"'),('plugins.navigation.enabled','true'),('plugins.navigation.licenseKey','\"MHFT6YWF45QAVKP3ST3LN0CL\"'),('plugins.navigation.schemaVersion','\"2.1.0\"'),('plugins.vite.edition','\"standard\"'),('plugins.vite.enabled','true'),('plugins.vite.schemaVersion','\"1.0.0\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.defaultPlacement','\"end\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.enableVersioning','true'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.entryTypes.0.uid','\"f1c7e864-914a-44b3-8480-1a3fc4f46b09\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.handle','\"homepage\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.maxAuthors','1'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.name','\"Homepage\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.propagationMethod','\"all\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.siteSettings.6a3879bd-c2fc-4069-a70f-3720e125a496.enabledByDefault','true'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.siteSettings.6a3879bd-c2fc-4069-a70f-3720e125a496.hasUrls','true'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.siteSettings.6a3879bd-c2fc-4069-a70f-3720e125a496.template','\"index.twig\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.siteSettings.6a3879bd-c2fc-4069-a70f-3720e125a496.uriFormat','\"__home__\"'),('sections.24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3.type','\"single\"'),('siteGroups.ea9e13a0-c734-466e-b4da-e96997d32dbf.name','\"Fine Digital\"'),('sites.6a3879bd-c2fc-4069-a70f-3720e125a496.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.6a3879bd-c2fc-4069-a70f-3720e125a496.handle','\"default\"'),('sites.6a3879bd-c2fc-4069-a70f-3720e125a496.hasUrls','true'),('sites.6a3879bd-c2fc-4069-a70f-3720e125a496.language','\"en\"'),('sites.6a3879bd-c2fc-4069-a70f-3720e125a496.name','\"Fine Digital\"'),('sites.6a3879bd-c2fc-4069-a70f-3720e125a496.primary','true'),('sites.6a3879bd-c2fc-4069-a70f-3720e125a496.siteGroup','\"ea9e13a0-c734-466e-b4da-e96997d32dbf\"'),('sites.6a3879bd-c2fc-4069-a70f-3720e125a496.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Fine Digital\"'),('system.schemaVersion','\"5.8.0.3\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.altTranslationKeyFormat','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.altTranslationMethod','\"none\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.cardThumbAlignment','\"end\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elementCondition','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.autocapitalize','true'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.autocomplete','false'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.autocorrect','true'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.class','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.dateAdded','\"2025-07-12T14:31:15+00:00\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.disabled','false'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.elementCondition','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.id','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.includeInCards','false'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.inputType','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.instructions','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.label','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.max','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.min','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.name','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.orientation','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.placeholder','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.providesThumbs','false'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.readonly','false'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.requirable','false'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.size','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.step','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.tip','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.title','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.uid','\"d63d3ea9-531a-492f-84c6-7bebdd453256\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.userCondition','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.warning','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.0.width','100'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.dateAdded','\"2025-07-12T14:40:53+00:00\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.editCondition','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.elementCondition','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.fieldUid','\"a580fa9f-fec5-4030-9ec4-056fa41939f4\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.handle','\"imageAlt\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.includeInCards','false'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.instructions','\"Alternative text for the images\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.label','\"Alt\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.providesThumbs','false'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.required','false'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.tip','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.uid','\"4fc08b7d-e76b-466c-8f82-7df2720a5cc5\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.userCondition','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.warning','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.elements.1.width','100'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.name','\"Content\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.uid','\"b4c79577-7de6-493c-965a-c3510de4139b\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fieldLayouts.e1b6b4f4-92a0-41b5-965a-3883046533f3.tabs.0.userCondition','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.fs','\"images\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.handle','\"images\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.name','\"Images\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.sortOrder','1'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.subpath','\"\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.titleTranslationKeyFormat','null'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.titleTranslationMethod','\"site\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.transformFs','\"\"'),('volumes.de4e6ba3-84ff-4825-9f58-5cb381127cac.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_dibrklpehoanozahqojtslulfpvvroefthhe` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_gycwafuvlxdvkqqbzfvjcvkpjletxasmrpyv` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_myuyxlbaknlvpxratxebsqgrghyglwrkubkl` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_jglatzlqrcqcotkoiuwfxjiwejfdqvfyrrvc` (`sourceId`),
  KEY `idx_ypqnttvhfjhnzmuevjqyxuawfcjbtzzgybva` (`targetId`),
  KEY `idx_lxabtaimrtmdrfxgulbostyosatootcnhwvj` (`sourceSiteId`),
  CONSTRAINT `fk_kbvlirdnztdnbxmbvqfffidggmfopmcrtefs` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wgccyrgdjxbypeytsgviguahipdmodhyyxll` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xxiabgygfwwvsofqtzpygmjwvweqljgnbfkp` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (2,3,2,NULL,33,1,'2025-07-12 23:04:21','2025-07-13 10:02:05','24d7ba0f-103f-49ea-ba8d-6624eb60b6ea'),(3,3,35,NULL,33,1,'2025-07-12 23:04:22','2025-07-12 23:04:22','f5baf6fd-9a4a-401c-a3fb-ddcfb897223d'),(5,3,37,NULL,33,1,'2025-07-13 07:57:48','2025-07-13 07:57:48','d51c9b63-b0a5-4edb-a3ec-383c2bd469bd'),(7,3,47,NULL,33,1,'2025-07-13 08:58:19','2025-07-13 08:58:19','dc448ebc-9780-4d95-aac3-66f8e426894c'),(9,3,52,NULL,33,1,'2025-07-13 09:04:50','2025-07-13 09:04:50','64becd59-6255-4d85-956c-737ec581a04e'),(11,3,55,NULL,33,1,'2025-07-13 09:06:37','2025-07-13 09:06:37','376025d5-cb81-4a83-bd1e-b257e4866c4a'),(13,3,60,NULL,33,1,'2025-07-13 09:07:08','2025-07-13 09:07:08','b2ffb7a3-107c-4bc4-8665-d55b7435a111'),(15,3,64,NULL,33,1,'2025-07-13 09:15:21','2025-07-13 09:15:21','dfa3b8ab-cf31-4ff6-b089-0a168dd6f1b1'),(17,3,66,NULL,33,1,'2025-07-13 09:57:16','2025-07-13 09:57:16','05fbb92c-84e0-4ac2-b088-c482e792a720'),(19,3,68,NULL,33,1,'2025-07-13 09:57:55','2025-07-13 09:57:55','3cef96b1-ded0-4190-a23b-63f5468ecf38'),(23,3,71,NULL,33,1,'2025-07-13 10:01:37','2025-07-13 10:01:37','dd61c239-a1b5-44fe-b6e4-227c6f2b82cd'),(24,3,71,NULL,69,2,'2025-07-13 10:01:37','2025-07-13 10:01:37','f49d2b08-9894-42fd-8a40-b0c5a6a07e25'),(27,3,73,NULL,69,1,'2025-07-13 10:01:51','2025-07-13 10:01:51','2711b28b-4989-441c-a521-6cd0c34b38e2'),(28,3,73,NULL,33,2,'2025-07-13 10:01:51','2025-07-13 10:01:51','789de0d2-7689-45b9-b41f-7d4fc9c83996'),(31,3,75,NULL,33,1,'2025-07-13 10:02:05','2025-07-13 10:02:05','65573bbc-77cc-41ca-b403-f1e8703aed4a'),(33,3,79,NULL,33,1,'2025-07-15 12:56:29','2025-07-15 12:56:29','23ab54a1-4025-48e4-b482-3f55dfff1681'),(35,3,81,NULL,33,1,'2025-07-15 12:56:38','2025-07-15 12:56:38','189d0544-b360-4deb-bf18-34acab4f27be'),(36,3,82,NULL,33,1,'2025-07-15 15:05:40','2025-07-15 15:05:40','fcf9b3f0-9d2e-479b-b416-4a2051ef5f46'),(37,3,85,NULL,33,1,'2025-07-15 15:33:07','2025-07-15 15:33:07','4c2a438a-28e6-457f-87b7-8479d306d411');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('125c5ef2','@craft/web/assets/jqueryui/dist'),('1260a88','@craft/web/assets/fileupload/dist'),('12ced414','@craft/web/assets/picturefill/dist'),('14062401','@craft/web/assets/prismjs/dist'),('15ba4c35','@bower/jquery/dist'),('174b0d2','@mediakreativ/blocksmith/assets'),('17bc1ede','@craft/web/assets/updates/dist'),('18bbcee4','@bower/jquery/dist'),('19766914','@craft/web/assets/xregexp/dist'),('1b12bed0','@craft/web/assets/craftsupport/dist'),('1bf4d6b6','@craft/web/assets/garnish/dist'),('1f5d1c3','@craft/web/assets/jqueryui/dist'),('1f5ddc23','@craft/web/assets/jqueryui/dist'),('1f8e0768','@craft/web/assets/fileupload/dist'),('236c779f','@craft/web/assets/utilities/dist'),('24078394','@craft/web/assets/feed/dist'),('2413cee7','@craft/web/assets/htmx/dist'),('278205e4','@craft/web/assets/animationblocker/dist'),('29982070','@mediakreativ/blocksmith/assets'),('2a838735','@craft/web/assets/animationblocker/dist'),('2b020c7d','@craft/web/assets/velocity/dist'),('2bb7a3e6','@craft/web/assets/matrix/dist'),('2e6d4188','@craft/web/assets/dashboard/dist'),('2e950eca','@craft/web/assets/jquerypayment/dist'),('2ec6d1a8','@craft/web/assets/jquerytouchevents/dist'),('30c54c68','@craft/web/assets/dashboard/dist'),('3346e1a1','@craft/web/assets/fabric/dist'),('342b8ad5','@craft/web/assets/animationblocker/dist'),('3981fa70','@verbb/navigation/resources/dist'),('3db4e5bc','@craft/web/assets/sites/dist'),('3dc4ceb9','@craft/web/assets/dashboard/dist'),('3f22d426','@craft/web/assets/vue/dist'),('3f7a2479','@craft/web/assets/editsection/dist'),('4314e7fd','@craft/web/assets/jquerypayment/dist'),('4347389f','@craft/web/assets/jquerytouchevents/dist'),('4487e872','@craft/web/assets/feed/dist'),('45af41f3','@craft/web/assets/axios/dist'),('4683e54a','@craft/web/assets/velocity/dist'),('47026e02','@craft/web/assets/animationblocker/dist'),('4920e05d','@craft/web/assets/assetindexes/dist'),('499227d0','@craft/web/assets/htmx/dist'),('4b82679b','@craft/web/assets/velocity/dist'),('4c0b30f1','@craft/web/assets/vue/dist'),('4e15652c','@craft/web/assets/jquerypayment/dist'),('4e2c967a','@craft/web/assets/clearcaches/dist'),('4e46ba4e','@craft/web/assets/jquerytouchevents/dist'),('4e93dcfc','@craft/web/assets/assetindexes/dist'),('52a33d11','@craft/web/assets/vue/dist'),('52fbcd4e','@craft/web/assets/editsection/dist'),('572e6743','@craft/web/assets/feed/dist'),('582be8aa','@craft/web/assets/velocity/dist'),('5d44a55f','@craft/web/assets/dashboard/dist'),('5d5ad4aa','@craft/web/assets/recententries/dist'),('5dbcea1d','@craft/web/assets/jquerypayment/dist'),('5def357f','@craft/web/assets/jquerytouchevents/dist'),('5eddbcfe','@craft/web/assets/conditionbuilder/dist'),('5fa2bfc0','@craft/web/assets/vue/dist'),('5ffa4f9f','@craft/web/assets/editsection/dist'),('60cab01d','@verbb/base/resources/dist'),('61e730c3','@craft/web/assets/picturefill/dist'),('62ac7d0b','@craft/web/assets/dbbackup/dist'),('63ab691c','@craft/web/assets/d3/dist'),('63e096c4','@craft/web/assets/updateswidget/dist'),('6495fa09','@craft/web/assets/updates/dist'),('68ca60ab','@craft/web/assets/iframeresizer/dist'),('6a5f8dc3','@craft/web/assets/xregexp/dist'),('6acfc29f','@craft/web/assets/generalsettings/dist'),('6b683519','@craft/web/assets/theme/dist'),('6ca7e3bf','@craft/web/assets/fileupload/dist'),('6e95c07f','@craft/web/assets/timepicker/dist'),('6ea3b59d','@craft/web/assets/fieldsettings/dist'),('70e57f28','@craft/web/assets/pluginstore/dist'),('71206b46','@craft/web/assets/craftsupport/dist'),('724ebff2','@craft/web/assets/picturefill/dist'),('72c3573f','@craft/web/assets/tailwindreset/dist'),('72dc3514','@craft/web/assets/jqueryui/dist'),('74f78023','@craft/web/assets/xregexp/dist'),('75d6ed1d','@craft/web/assets/selectize/dist'),('769357e7','@craft/web/assets/craftsupport/dist'),('783ba502','@bower/jquery/dist'),('799e4f55','@craft/web/assets/cp/dist'),('79f602f2','@craft/web/assets/xregexp/dist'),('7b92d536','@craft/web/assets/craftsupport/dist'),('7f4f3d23','@craft/web/assets/picturefill/dist'),('818362e3','@craft/web/assets/conditionbuilder/dist'),('8199d68b','@craft/web/assets/fabric/dist'),('82040ab7','@craft/web/assets/recententries/dist'),('821a7b42','@craft/web/assets/dashboard/dist'),('862aea2a','@craft/web/assets/fabric/dist'),('8bc74ce8','@craft/web/assets/updater/dist'),('8c98545a','@craft/web/assets/fabric/dist'),('8f1b4d55','@craft/web/assets/utilities/dist'),('914133e','@craft/web/assets/updates/dist'),('9190ffe0','@craft/web/assets/routes/dist'),('91b340b5','@craft/web/assets/utilities/dist'),('9469161d','@craft/web/assets/matrix/dist'),('946faa5e','@craft/web/assets/userpermissions/dist'),('96ccf9cd','@craft/web/assets/htmx/dist'),('985cb01f','@craft/web/assets/animationblocker/dist'),('996894cc','@craft/web/assets/matrix/dist'),('9a9c4cce','@verbb/navigation/resources/dist'),('9af19fee','@craft/web/assets/axios/dist'),('9edba86d','@craft/web/assets/matrix/dist'),('a42a634d','@craft/web/assets/garnish/dist'),('a6c09148','@craft/web/assets/cp/dist'),('a7657b1f','@bower/jquery/dist'),('a7a9549','@craft/web/assets/admintable/dist'),('a92be19c','@craft/web/assets/garnish/dist'),('aa883300','@craft/web/assets/selectize/dist'),('aae29e1','@craft/web/assets/prismjs/dist'),('ad82eb09','@craft/web/assets/jqueryui/dist'),('ad9d8922','@craft/web/assets/tailwindreset/dist'),('b1241d5','@bower/jquery/dist'),('b1fd6b80','@craft/web/assets/fieldsettings/dist'),('b3f93da2','@craft/web/assets/fileupload/dist'),('b436eb04','@craft/web/assets/theme/dist'),('b5a420b2','@craft/web/assets/admintable/dist'),('b65cab54','@verbb/base/resources/dist'),('b783ec7c','@craft/web/assets/garnish/dist'),('b794beb6','@craft/web/assets/iframeresizer/dist'),('b7fbfd57','@verbb/navigation/resources/dist'),('b8711ecb','@craft/web/assets/prismjs/dist'),('b8a5a263','@craft/web/assets/admintable/dist'),('bbcb2414','@craft/web/assets/updates/dist'),('bcbe48d9','@craft/web/assets/updateswidget/dist'),('bcf5b701','@craft/web/assets/d3/dist'),('bf169ec2','@craft/web/assets/admintable/dist'),('c01c6015','@craft/web/assets/tailwindreset/dist'),('c23a4802','@craft/web/assets/pluginstore/dist'),('c278859','@craft/web/assets/fileupload/dist'),('c28faa78','@mediakreativ/blocksmith/assets'),('c2d48f57','@craft/web/assets/fieldsettings/dist'),('c327874a','@mediakreativ/blocksmith/assets'),('c44c60cd','@craft/web/assets/craftsupport/dist'),('c4aa08ab','@craft/web/assets/garnish/dist'),('c4bd5a61','@craft/web/assets/iframeresizer/dist'),('c628b709','@craft/web/assets/xregexp/dist'),('c640faae','@craft/web/assets/cp/dist'),('c709da37','@craft/web/assets/selectize/dist'),('c71f0fd3','@craft/web/assets/theme/dist'),('c7af5cb4','@craft/web/assets/tailwindreset/dist'),('ca0858e6','@craft/web/assets/selectize/dist'),('cb41787f','@craft/web/assets/cp/dist'),('ccd1baea','@mediakreativ/blocksmith/assets'),('ccf244de','@craft/web/assets/cp/dist'),('cd1de2c4','@craft/web/assets/tailwindreset/dist'),('cd900a09','@craft/web/assets/picturefill/dist'),('cf3bcad3','@craft/web/assets/pluginstore/dist'),('cf97ac0e','@craft/web/assets/updateswidget/dist'),('cfdc53d6','@craft/web/assets/d3/dist'),('d13fa1ee','@craft/web/assets/updateswidget/dist'),('d1745e36','@craft/web/assets/d3/dist'),('d17d0066','@craft/web/assets/fieldsettings/dist'),('d4b680e2','@craft/web/assets/theme/dist'),('d5244b54','@craft/web/assets/admintable/dist'),('d714d550','@craft/web/assets/iframeresizer/dist'),('d9a1d7d7','@craft/web/assets/selectize/dist'),('d9b70233','@craft/web/assets/theme/dist'),('da155781','@craft/web/assets/iframeresizer/dist'),('db83ca9b','@verbb/navigation/resources/dist'),('dc3e233f','@craft/web/assets/updateswidget/dist'),('dc75dce7','@craft/web/assets/d3/dist'),('dc7c82b7','@craft/web/assets/fieldsettings/dist'),('e024fa64','@craft/web/assets/editsection/dist'),('e07c0a3b','@craft/web/assets/vue/dist'),('e2846151','@craft/web/assets/recententries/dist'),('e646a5df','@craft/web/assets/updater/dist'),('eb47270e','@craft/web/assets/updater/dist'),('ec028bd4','@craft/web/assets/conditionbuilder/dist'),('ec183fbc','@craft/web/assets/fabric/dist'),('ef85e380','@craft/web/assets/recententries/dist'),('f0c34a78','@craft/web/assets/axios/dist'),('f12dee60','@craft/web/assets/recententries/dist'),('f1980fb5','@craft/web/assets/jquerytouchevents/dist'),('f1cbd0d7','@craft/web/assets/jquerypayment/dist'),('f45cd260','@craft/web/assets/velocity/dist'),('f4e97dfb','@craft/web/assets/matrix/dist'),('f7432d01','@verbb/base/resources/dist'),('f77076d9','@craft/web/assets/axios/dist'),('f8eea83f','@craft/web/assets/updater/dist'),('fa71f408','@craft/web/assets/axios/dist'),('fb595d89','@craft/web/assets/feed/dist'),('fc32a982','@craft/web/assets/utilities/dist'),('fc6f1148','@craft/web/assets/findreplace/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_joqealqywkdkigbegwrrdsihqbszqqgvrzvk` (`canonicalId`,`num`),
  KEY `fk_hucptubdrvqzkwzsdwqiqpywhnonhszvruhw` (`creatorId`),
  CONSTRAINT `fk_hucptubdrvqzkwzsdwqiqpywhnonhszvruhw` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zlqikcmiwjseexczckxzggbfcspabwxnbrta` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,2,1,2,NULL),(3,2,1,3,NULL),(4,2,1,4,NULL),(5,2,1,5,'Applied “Draft 1”'),(6,2,1,6,'Applied “Draft 1”'),(7,2,1,7,'Applied “Draft 1”'),(8,2,1,8,'Applied “Draft 1”'),(9,44,1,1,NULL),(10,45,1,1,NULL),(11,46,1,1,NULL),(12,2,1,9,'Applied “Draft 1”'),(13,2,1,10,'Applied “Draft 1”'),(14,46,1,2,NULL),(15,2,1,11,'Applied “Draft 1”'),(16,45,1,2,NULL),(17,46,1,3,NULL),(18,2,1,12,'Applied “Draft 1”'),(19,2,1,13,'Applied “Draft 1”'),(20,2,1,14,'Applied “Draft 1”'),(21,2,1,15,'Applied “Draft 1”'),(22,2,1,16,'Applied “Draft 1”'),(23,2,1,17,'Applied “Draft 1”'),(24,2,1,18,'Applied “Draft 1”'),(25,2,1,19,'Applied “Draft 1”'),(26,2,1,20,'');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_diqrjwplzkcabqzbqognjcqbcooxinshgnem` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' lubo jordanov gmail com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' finedigital '),(2,'slug',0,1,' homepage '),(2,'title',0,1,' homepage '),(4,'slug',0,1,' 1 '),(4,'title',0,1,' home '),(6,'slug',0,1,''),(6,'title',0,1,' about '),(7,'slug',0,1,''),(7,'title',0,1,' services '),(8,'slug',0,1,''),(8,'title',0,1,' contact '),(9,'slug',0,1,' 1 '),(9,'title',0,1,' home '),(10,'slug',0,1,''),(10,'title',0,1,' services '),(11,'slug',0,1,''),(11,'title',0,1,' web design '),(12,'slug',0,1,''),(12,'title',0,1,' seo '),(13,'slug',0,1,''),(13,'title',0,1,' google ads '),(14,'slug',0,1,''),(14,'title',0,1,' about '),(15,'slug',0,1,''),(15,'title',0,1,' contact '),(16,'slug',0,1,''),(16,'title',0,1,' privacy policy '),(17,'slug',0,1,''),(17,'title',0,1,' terms conditions '),(20,'slug',0,1,''),(20,'title',0,1,' book free call '),(24,'slug',0,1,''),(24,'title',0,1,' web design '),(25,'slug',0,1,''),(25,'title',0,1,' seo '),(26,'slug',0,1,''),(26,'title',0,1,' google ads '),(33,'alt',0,1,''),(33,'extension',0,1,' mp4 '),(33,'filename',0,1,' hero mp4 '),(33,'kind',0,1,' video '),(33,'slug',0,1,''),(33,'title',0,1,' hero '),(44,'slug',0,1,' call to action 1 '),(44,'title',0,1,' call to action 1 '),(45,'slug',0,1,' call to action 1 '),(45,'title',0,1,' book a free strategy call '),(46,'slug',0,1,' call to action 1 '),(46,'title',0,1,' our services '),(69,'alt',0,1,''),(69,'extension',0,1,' jpg '),(69,'filename',0,1,' testimonial jpg '),(69,'kind',0,1,' image '),(69,'slug',0,1,''),(69,'title',0,1,' testimonial '),(76,'alt',0,1,''),(76,'extension',0,1,' webp '),(76,'filename',0,1,' plamen webp '),(76,'kind',0,1,' image '),(76,'slug',0,1,''),(76,'title',0,1,' plamen '),(77,'alt',0,1,''),(77,'extension',0,1,' png '),(77,'filename',0,1,' laservision png '),(77,'kind',0,1,' image '),(77,'slug',0,1,''),(77,'title',0,1,' laservision '),(85,'slug',0,1,' homepage '),(85,'title',0,1,' homepage '),(86,'slug',0,1,' temp slgqbrayycpjkvlyzadxjofovrtseqyfbvos '),(86,'title',0,1,''),(91,'slug',0,1,' call to action 1 '),(91,'title',0,1,' book a free strategy call ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue`
--

DROP TABLE IF EXISTS `searchindexqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oftlvzotaiccuqtgxkqyfzurkiedpaskqcwu` (`elementId`,`siteId`,`reserved`),
  CONSTRAINT `fk_ouwrspqtajtslpfrfscflqgpggvrszehffnu` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue`
--

LOCK TABLES `searchindexqueue` WRITE;
/*!40000 ALTER TABLE `searchindexqueue` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue_fields`
--

DROP TABLE IF EXISTS `searchindexqueue_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue_fields` (
  `jobId` int NOT NULL,
  `fieldHandle` varchar(255) NOT NULL,
  PRIMARY KEY (`jobId`,`fieldHandle`),
  UNIQUE KEY `idx_cvjdtgqukoergcnyfnskuzbotnnhlqjyermr` (`jobId`,`fieldHandle`),
  CONSTRAINT `fk_mummixvuzillyhukbnzpndytwwpguoqyquyr` FOREIGN KEY (`jobId`) REFERENCES `searchindexqueue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue_fields`
--

LOCK TABLES `searchindexqueue_fields` WRITE;
/*!40000 ALTER TABLE `searchindexqueue_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lkcjebxzdzjuobbgqtmuoehtvlyzaceyhyte` (`handle`),
  KEY `idx_jjlfnstwfhnpnahkktankkarojfkregdgnql` (`name`),
  KEY `idx_ejuhupblkfkzlshltsfmeftaacopkmjcuvub` (`structureId`),
  KEY `idx_xhpbkvfigupcfgziwjilxaeqqxlrlutxqhah` (`dateDeleted`),
  CONSTRAINT `fk_nisylfjjmpjhvzhmsqqcuevzetzwnblfisng` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Homepage','homepage','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2025-07-10 13:36:44','2025-07-10 13:36:44',NULL,'24b1eeee-2cc0-4c0f-a7a5-028ca91a32f3');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_iwohugajzsclfkptdttfrzrfjxtdhvzchbkz` (`typeId`),
  CONSTRAINT `fk_hngtzybkiwswkarylqewwtnpoacokxjptnjd` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iwohugajzsclfkptdttfrzrfjxtdhvzchbkz` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tfhwsgzcksyjwhpwrxcdjlrxpjiezdwkogel` (`sectionId`,`siteId`),
  KEY `idx_chebpiascphsfjfuhzmjzwtundqlniagcpxt` (`siteId`),
  CONSTRAINT `fk_gemxzzzlolatdnnlrkysmidizhjdcrzxgtzv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wzzjsflxhbgiayeocglflruxyuooyhyuzpov` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','index.twig',1,'2025-07-10 13:36:44','2025-07-10 17:24:41','f3d2e4a8-b315-4661-8dc7-e530925ae77a');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yyrzykhhwginzckwmkxcwixdhuluemtuneip` (`uid`),
  KEY `idx_tmirumoajyrbyrwnqgtfrmhfrsohioaloial` (`token`),
  KEY `idx_juyqhqpprrjnpzsllfwdrordxynihrdmhfah` (`dateUpdated`),
  KEY `idx_eaaazfpyrrvyivmyuxqyymaofvricmzqfkky` (`userId`),
  CONSTRAINT `fk_kxjkpiizfyrauhuszcoikmdwpkvhoszcxkvz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uxkmrbdxhfemcmpdefoliwirmmnjpjiuzbkt` (`userId`,`message`),
  CONSTRAINT `fk_kzjzhyqwqqpfwvnqxdmavmlwliebrpnafisk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_riowgfrvbdpctwyhwhteytaoniqfgxrtdxly` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Fine Digital','2025-07-10 10:15:15','2025-07-10 10:15:15',NULL,'ea9e13a0-c734-466e-b4da-e96997d32dbf');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jgrtjonovfvdayjazjfnemnsddbimlnpygxc` (`dateDeleted`),
  KEY `idx_dhovsgyrlfpqmpodbqjgeoqcszlzfcpmtioh` (`handle`),
  KEY `idx_jpyvfhfdnrczoarnyfhocbpwghgubvtwbvuu` (`sortOrder`),
  KEY `fk_tjtgbtjtmcdaltfyleprnooxetorhsnrznxo` (`groupId`),
  CONSTRAINT `fk_tjtgbtjtmcdaltfyleprnooxetorhsnrznxo` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','Fine Digital','default','en',1,'$PRIMARY_SITE_URL',1,'2025-07-10 10:15:15','2025-07-10 10:15:15',NULL,'6a3879bd-c2fc-4069-a70f-3720e125a496');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_toxtncngdxnvuilkyxhzvsigptxevvgsbxfu` (`userId`),
  CONSTRAINT `fk_toxtncngdxnvuilkyxhzvsigptxevvgsbxfu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pwatogjooonwjdyzrsfnvoxznilzxnnoiqcb` (`structureId`,`elementId`),
  KEY `idx_cabfxtvgzndclngotdfvkhquyrsiwhkrvfdn` (`root`),
  KEY `idx_jorpfasrnrddjcftkrjgodvrhofiosefkcde` (`lft`),
  KEY `idx_gmxqooqpshgdtlcyxxhvjhnvhcwtfuazkqir` (`rgt`),
  KEY `idx_bxtkjqcjyhsnigtgteqydmxyqcorxnskwpou` (`level`),
  KEY `idx_gwwnsehummugoebtkfdltndbfgdjipegfxvz` (`elementId`),
  CONSTRAINT `fk_zjlvrrulnykbprujvbenglmdmgxdncevvmor` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,18,0,'2025-07-10 17:16:03','2025-07-10 17:54:47','37c1af7d-9762-4e79-815b-c25a41e57aa7'),(2,1,4,1,2,3,1,'2025-07-10 17:16:03','2025-07-10 17:16:03','950cd05f-5865-4c24-a00a-c9fdbcb4d302'),(3,1,6,1,12,13,1,'2025-07-10 17:17:24','2025-07-10 17:54:47','c8fcd4af-6265-4380-bbd9-d52b74c957b1'),(4,1,7,1,4,11,1,'2025-07-10 17:17:34','2025-07-10 17:54:47','eda8dccb-7461-4117-8636-5d2880867b79'),(5,1,8,1,14,15,1,'2025-07-10 17:17:43','2025-07-10 17:54:47','0110f77b-c15d-431d-b4b2-d1b9d9dbe504'),(6,2,NULL,6,1,18,0,'2025-07-10 17:18:21','2025-07-10 17:19:36','741d7ac0-35e5-4027-953b-b431e1402fe4'),(7,2,9,6,2,3,1,'2025-07-10 17:18:21','2025-07-10 17:18:21','8a847e1f-5006-4141-ad43-8735ba787c51'),(8,2,10,6,10,11,1,'2025-07-10 17:18:32','2025-07-10 17:19:12','3420a1bd-172d-434d-a6d8-ccd62f7554cc'),(9,2,11,6,4,5,1,'2025-07-10 17:18:54','2025-07-10 17:19:12','a41ad46f-dfce-4feb-8c9e-2f69d893d34b'),(10,2,12,6,6,7,1,'2025-07-10 17:18:57','2025-07-10 17:19:12','5b695aff-0f09-4355-b684-b77f96bbb204'),(11,2,13,6,8,9,1,'2025-07-10 17:19:05','2025-07-10 17:19:12','f9695bea-f2a2-4bf6-b369-6ebeb81202fa'),(12,2,15,6,12,13,1,'2025-07-10 17:19:24','2025-07-10 17:19:24','fc570361-8006-4fa2-8bb0-c5d9873a635b'),(13,2,16,6,14,15,1,'2025-07-10 17:19:31','2025-07-10 17:19:31','5123ddea-7ccc-4600-aea3-bce72b0abca6'),(14,2,17,6,16,17,1,'2025-07-10 17:19:36','2025-07-10 17:19:36','702d69c0-e0bc-47db-badb-0d8aa059ac15'),(15,1,20,1,16,17,1,'2025-07-10 17:28:08','2025-07-10 17:54:47','07723eff-2733-43b9-8ca4-5ce152820190'),(16,1,24,1,5,6,2,'2025-07-10 17:54:29','2025-07-10 17:54:33','1768cd05-c345-4edf-a943-460eb5349986'),(17,1,25,1,7,8,2,'2025-07-10 17:54:37','2025-07-10 17:54:40','b5ca3858-18d0-44d8-8ffd-03286b72b9aa'),(18,1,26,1,9,10,2,'2025-07-10 17:54:45','2025-07-10 17:54:47','41632501-8ce4-4d7a-9202-d6608a37b38c');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xpyenyrsyrjqkdefjwwdgmkwojtjamntulcd` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,2,'2025-07-10 17:15:03','2025-07-10 17:53:30',NULL,'a5ab0b85-d6ee-4cdd-ad87-b2f47a1a0bae'),(2,1,'2025-07-10 17:15:23','2025-07-10 17:15:23',NULL,'3b54b595-cdc3-4a78-b15e-46b02e60933e');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_avxfobplzkzcogbcsjqaxvtqclhuxqighcno` (`key`,`language`),
  KEY `idx_ynxjhndfkuzipefkqfahuuruzvvxcqxfdzrn` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gljojfigepjmyaimyymoyrmhpsejvowbrkgv` (`name`),
  KEY `idx_lweochhrdquoqlaejvrszkdsqypsepkxbiod` (`handle`),
  KEY `idx_ygggbxmaavasyowkwebqndawpozbkwyanbrp` (`dateDeleted`),
  KEY `fk_byevxhyridwxwhapltdhqiqhbxyeumgvoxww` (`fieldLayoutId`),
  CONSTRAINT `fk_byevxhyridwxwhapltdhqiqhbxyeumgvoxww` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_clxfrtpstcecfvedniizrgxnuzrmifwliord` (`groupId`),
  CONSTRAINT `fk_gxbswfdcsisqanksyubfhhmjspwmkwykmver` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qetemcfjixpwyoddrwtgcetvqrvuaettctfo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ovlaoycfwjeqmnymdzdfzctiuajgcrlypudw` (`token`),
  KEY `idx_ptldduqahugnbuxvtzelyhkdfodondpeprfy` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,'eDzql2qzscr-b7UyUs6IATJbeSZqjiLX','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":2,\"siteId\":1,\"draftId\":null,\"revisionId\":null,\"userId\":1}]',NULL,NULL,'2025-07-14 09:57:23','2025-07-13 09:57:23','2025-07-13 09:57:23','a349266e-bd46-4f2a-b37e-98a9a4ff187b');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fgqdfmehoaqjerynprpakveguwojcminchsj` (`handle`),
  KEY `idx_cmdzbsmglhwvhekwtrheirgefdxhaczzccdj` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ggghmpulcquyivwdvswbnbanarqsghyhszlp` (`groupId`,`userId`),
  KEY `idx_rsjbkhyvtuxroqowwdhqqxnmxitindeaydiv` (`userId`),
  CONSTRAINT `fk_timpsnxexjrmrpbpwyvmjrmlswnjcjnkdpuh` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xjnxqahdezffogipihpjexarnyhcvdvpxosq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_awaftkcitcwkvusndxgsqlvhwuziesqpfvbu` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zralsojhgchrbemdetccfmynxxmpixsqlasg` (`permissionId`,`groupId`),
  KEY `idx_zkcpypghpscuwfiglpmiwwkvuibldepaewgd` (`groupId`),
  CONSTRAINT `fk_bpgiuqkpdmdnjcwmndpatgojqcjvatbbgrkl` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ejaevftdivgdodbizngwgnoqvicjwtqshhqx` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xwtkbrsqidkuafasnpdxndfoegnbvwprnbhs` (`permissionId`,`userId`),
  KEY `idx_davhovwukjerfzmzxsqrqgedkjwekdnvcnlj` (`userId`),
  CONSTRAINT `fk_qbwpsoiliabdwkrmwzifguazgcmbdwytquhs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_syrjvmukwnptovsxviupslujxspznvmtvyfh` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_tcnsxjlnciyvtefunxdhxipxzpamydbfbbqj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pbqeggfacbvpsjpxqnzjdwexvpexcnrtuhpl` (`active`),
  KEY `idx_lgflkzibyfytrzlygfaxmlhrtseahkhvhroo` (`locked`),
  KEY `idx_naerkezenmkziizdmgpurdphwtpafzcptscv` (`pending`),
  KEY `idx_czioavgvizistmtrtxtkqwpjxksppnfhhhsx` (`suspended`),
  KEY `idx_ejtrjjkltprdutvxwjodgzcxnbqjowkoyaqq` (`verificationCode`),
  KEY `idx_tbmrtezyeccqupnecpcnmrswgoetueorhfmg` (`email`),
  KEY `idx_jjkmkjuzyemabkjwcnkyivfowceakgooraqo` (`username`),
  KEY `fk_croimelahimssemnzslvpmsadsvwsrwwntwb` (`photoId`),
  KEY `fk_vskozayeooipixirbjhhpyhjjticgpwiygjj` (`affiliatedSiteId`),
  CONSTRAINT `fk_croimelahimssemnzslvpmsadsvwsrwwntwb` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_siilgrsdupmqklgjkyhnwgqhydotnktfrzpa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vskozayeooipixirbjhhpyhjjticgpwiygjj` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,NULL,1,0,0,0,1,'finedigital',NULL,NULL,NULL,'lubo.jordanov@gmail.com','$2y$13$4/Ed4mg7cngOdX6I22zuged1yl1fjhE6ZGhqAXpfZ6J4KXlSzWCIa','2025-09-09 16:26:38',NULL,NULL,NULL,'2025-09-09 16:26:13',NULL,1,NULL,NULL,NULL,0,'2025-09-09 16:26:07','2025-07-10 10:15:15','2025-09-09 16:26:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_shzqbjvrozkbepnjqdhjkbixxvgrrwpggeyz` (`name`,`parentId`,`volumeId`),
  KEY `idx_wjbjuztzwhqexwqldutoexbvkdxtccvdyvme` (`parentId`),
  KEY `idx_oaayhqzywdjgqekglrfpxexsbmgoiuliifrp` (`volumeId`),
  CONSTRAINT `fk_dbrdbjrrtompidvcpwbrbxlshfameckozojh` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tfsugceuklrfgvpuleuoeoncpgrlpkytojnb` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,NULL,'Temporary Uploads',NULL,'2025-07-10 17:14:17','2025-07-10 17:14:17','aefcf66b-a9d7-43e9-aa28-d6b9cdc5b406'),(2,1,NULL,'user_1','user_1/','2025-07-10 17:14:17','2025-07-10 17:14:17','0b311f96-3a96-462e-845e-8a6d4ba1c18f'),(3,NULL,1,'Images','','2025-07-12 14:40:53','2025-07-12 14:40:53','b1e0cdf8-4540-4987-bb48-39b459b99907');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_prafuigofmevmixugmcujvjplrwjbnyfgoaa` (`name`),
  KEY `idx_ydapoyemhxgllevlbjtwzomrrwncisabbzxw` (`handle`),
  KEY `idx_wybbtcxduzwfxvvgqaphmjmvvbefrqeetwaz` (`fieldLayoutId`),
  KEY `idx_aovazsqyoycdzsqdxbudwqgdazvepgaagpcc` (`dateDeleted`),
  CONSTRAINT `fk_otgnflkpyddbnztzgeslscihfpvlkhzcjabm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,4,'Images','images','images','','','','site',NULL,'none',NULL,1,'2025-07-12 14:40:53','2025-07-12 14:40:53',NULL,'de4e6ba3-84ff-4825-9f58-5cb381127cac');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_kjtwkhlaoxmhgrjewughohelstrzxuwtbspd` (`userId`),
  CONSTRAINT `fk_kjtwkhlaoxmhgrjewughohelstrzxuwtbspd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aqbhuhzzxjbqvzwpjegtvgnlpymvgdtimqwr` (`userId`),
  CONSTRAINT `fk_ulvwpbswfpbqdbnwnkeeesgaabwkobxtdilm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2025-07-10 10:24:12','2025-07-10 10:24:12','362b1e23-46d5-45fb-93c2-f2d6cb2f4e32'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2025-07-10 10:24:12','2025-07-10 10:24:12','c776aa42-c443-4832-ae7b-0b4044606853'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2025-07-10 10:24:12','2025-07-10 10:24:12','d7d72a96-07c0-4e55-86fd-335d73dc9db8'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2025-07-10 10:24:12','2025-07-10 10:24:12','ef72289e-2364-42f4-8343-192e42fa91ed');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-16 18:43:01
